#!/usr/bin/env python3
"""
Diagnostic script to identify where BasilicaTrainingClient hangs.

This script manually walks through each step the client does, with timestamps
and verbose output, to pinpoint where the hang occurs.

Run with:
    BASILICA_API_TOKEN=your-token python basilica_diagnostic.py

The script will show exactly which step is blocking.
"""

import os
import time
import asyncio

# Check for token early
if not os.getenv("BASILICA_API_TOKEN"):
    raise RuntimeError("Set BASILICA_API_TOKEN in your environment")


def timestamp():
    return time.strftime("%H:%M:%S")


async def diagnose_basilica():
    print(f"\n[{timestamp()}] === BASILICA DIAGNOSTIC START ===\n")

    # Step 1: Check environment
    print(f"[{timestamp()}] Step 1: Environment check")
    docker_image = os.getenv("BASILICA_DOCKER_IMAGE", "NOT SET")
    print(f"  BASILICA_DOCKER_IMAGE = {docker_image}")
    print(f"  BASILICA_GPU_COUNT = {os.getenv('BASILICA_GPU_COUNT', '1 (default)')}")
    print(f"  BASILICA_GPU_MEMORY_GB = {os.getenv('BASILICA_GPU_MEMORY_GB', '16 (default)')}")
    print(f"  BASILICA_GPU_TYPE = {os.getenv('BASILICA_GPU_TYPE', 'auto (default)')}")

    # Step 2: Import and create client
    print(f"\n[{timestamp()}] Step 2: Creating BasilicaClient...")
    try:
        from basilica import BasilicaClient
        client = BasilicaClient(api_key=os.getenv("BASILICA_API_TOKEN"))
        print(f"[{timestamp()}]   OK - Client created")
    except Exception as e:
        print(f"[{timestamp()}]   FAILED - {e}")
        return

    # Step 3: Test source-based deployment (known to work)
    print(f"\n[{timestamp()}] Step 3: Testing SOURCE-based deployment (should work)...")
    test_source = '''
from http.server import HTTPServer, BaseHTTPRequestHandler

class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        self.send_response(200)
        self.end_headers()
        self.wfile.write(b'Hello from diagnostic test!')
    def log_message(self, *args):
        pass

HTTPServer(('', 8000), Handler).serve_forever()
'''

    source_deployment = None
    try:
        print(f"[{timestamp()}]   Calling deploy(source=..., gpu_count=1, min_gpu_memory_gb=16)...")
        start = time.time()
        source_deployment = await asyncio.to_thread(
            client.deploy,
            name="diag-source-test",
            source=test_source,
            port=8000,
            gpu_count=1,
            min_gpu_memory_gb=16,
            ttl_seconds=120,
            timeout=300,
        )
        elapsed = time.time() - start
        print(f"[{timestamp()}]   OK - Source deployment created in {elapsed:.1f}s")
        print(f"[{timestamp()}]   URL: {source_deployment.url}")

        # Try to hit the endpoint
        print(f"[{timestamp()}]   Testing endpoint...")
        import httpx
        async with httpx.AsyncClient(timeout=30) as http:
            resp = await http.get(source_deployment.url)
            print(f"[{timestamp()}]   Response: {resp.status_code} - {resp.text[:100]}")

    except Exception as e:
        print(f"[{timestamp()}]   FAILED - {e}")
    finally:
        if source_deployment:
            print(f"[{timestamp()}]   Cleaning up source deployment...")
            try:
                await asyncio.to_thread(source_deployment.delete)
                print(f"[{timestamp()}]   Deleted OK")
            except Exception as e:
                print(f"[{timestamp()}]   Delete failed: {e}")

    # Step 4: Test image-based deployment (what the client uses)
    if docker_image == "NOT SET":
        print(f"\n[{timestamp()}] Step 4: SKIPPED - BASILICA_DOCKER_IMAGE not set")
        print("  To test image deployment, set BASILICA_DOCKER_IMAGE to your image")
    else:
        print(f"\n[{timestamp()}] Step 4: Testing IMAGE-based deployment...")
        print(f"  Image: {docker_image}")
        print(f"  WARNING: This may hang if the image doesn't exist or can't be pulled!")

        image_deployment = None
        try:
            print(f"[{timestamp()}]   Calling deploy(image=..., gpu_count=1, min_gpu_memory_gb=16)...")
            print(f"[{timestamp()}]   (timeout=300s, this may take a while to pull the image...)")
            start = time.time()

            # Show periodic progress
            async def deploy_with_progress():
                deploy_task = asyncio.to_thread(
                    client.deploy,
                    name="diag-image-test",
                    image=docker_image,
                    port=8000,
                    gpu_count=1,
                    min_gpu_memory_gb=16,
                    ttl_seconds=120,
                    timeout=300,
                )
                task = asyncio.create_task(deploy_task)
                while not task.done():
                    await asyncio.sleep(10)
                    if not task.done():
                        print(f"[{timestamp()}]   ... still deploying ({time.time() - start:.0f}s elapsed)")
                return await task

            image_deployment = await deploy_with_progress()
            elapsed = time.time() - start
            print(f"[{timestamp()}]   OK - Image deployment created in {elapsed:.1f}s")
            print(f"[{timestamp()}]   URL: {image_deployment.url}")

            # Now try to wait for it
            print(f"[{timestamp()}]   Calling deployment.wait(timeout=300)...")
            start = time.time()

            async def wait_with_progress():
                wait_task = asyncio.to_thread(image_deployment.wait, timeout=300)
                task = asyncio.create_task(wait_task)
                while not task.done():
                    await asyncio.sleep(10)
                    if not task.done():
                        print(f"[{timestamp()}]   ... still waiting ({time.time() - start:.0f}s elapsed)")
                return await task

            await wait_with_progress()
            elapsed = time.time() - start
            print(f"[{timestamp()}]   OK - Deployment ready in {elapsed:.1f}s")

            # Try to hit /health endpoint
            print(f"[{timestamp()}]   Testing /health endpoint...")
            import httpx
            async with httpx.AsyncClient(timeout=30) as http:
                health_url = f"{image_deployment.url.rstrip('/')}/health"
                resp = await http.get(health_url)
                print(f"[{timestamp()}]   Response: {resp.status_code} - {resp.text[:200]}")

        except asyncio.TimeoutError:
            print(f"[{timestamp()}]   TIMEOUT - Deployment timed out after 300s")
            print("  This usually means the Docker image doesn't exist or can't be pulled")
        except Exception as e:
            print(f"[{timestamp()}]   FAILED - {e}")
            import traceback
            traceback.print_exc()
        finally:
            if image_deployment:
                print(f"[{timestamp()}]   Cleaning up image deployment...")
                try:
                    await asyncio.to_thread(image_deployment.delete)
                    print(f"[{timestamp()}]   Deleted OK")
                except Exception as e:
                    print(f"[{timestamp()}]   Delete failed: {e}")

    print(f"\n[{timestamp()}] === DIAGNOSTIC COMPLETE ===\n")

    # Summary
    print("SUMMARY:")
    print("  - If Step 3 (source deploy) works but Step 4 (image deploy) hangs,")
    print("    the Docker image likely doesn't exist or can't be pulled.")
    print("  - Build and push the image first:")
    print("      docker build -f services/eval/remote_training/basilica/Dockerfile -t your-registry/image:tag .")
    print("      docker push your-registry/image:tag")
    print("      export BASILICA_DOCKER_IMAGE=your-registry/image:tag")


if __name__ == "__main__":
    asyncio.run(diagnose_basilica())
