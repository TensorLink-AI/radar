# Agent SDK Analysis: Patterns for Agentic NAS

## Executive Summary

This document analyzes two agent SDKs to identify patterns applicable to Agentic NAS:

1. **browser-use/agent-sdk (bu-agent-sdk)** - A minimalist framework (~300 LOC/provider) with explicit completion patterns
2. **anthropics/claude-agent-sdk-python** - Anthropic's official SDK for Claude Code integration with hooks and permissions

**Key Finding**: Agentic NAS already implements most of the valuable patterns from bu-agent-sdk (evident in `simple_agent.py`). The Claude Agent SDK offers patterns more suited for interactive CLI tools than autonomous NAS agents.

---

## SDK Comparison Matrix

| Feature | bu-agent-sdk | claude-agent-sdk | Agentic NAS (current) |
|---------|-------------|------------------|----------------------|
| Core Pattern | For-loop until done() | Query/response streaming | For-loop with done() |
| Explicit Completion | `TaskComplete` exception | `ResultMessage` | `TaskComplete` exception |
| Ephemeral Messages | Yes (`ephemeral=N`) | No | Yes (`ephemeral=N`) |
| Context Compaction | Yes (threshold-based) | No | No |
| Dependency Injection | Yes (`Annotated[T, Depends()]`) | No | No |
| Hooks System | No | Yes (Pre/PostToolUse) | No |
| Multi-Provider | Yes (~300 LOC each) | Claude only | ChutesClient only |
| Tool Decorator | `@tool(desc, ephemeral)` | `@tool(name, desc, schema)` | `@tool(desc, ephemeral, schema)` |
| Required Tools | No | No | Yes (`required_tools`) |
| Stall Detection | No | No | Yes (`AgentStalled`) |

---

## Pattern Analysis

### 1. Done Tool Pattern (Already Implemented ✅)

**bu-agent-sdk pattern:**
```python
@tool("Signal completion")
async def done(message: str) -> str:
    raise TaskComplete(message)

agent = Agent(llm=llm, tools=[..., done], require_done_tool=True)
```

**Agentic NAS (`simple_agent.py:30-35`, `213-221`):**
```python
class TaskComplete(Exception):
    def __init__(self, result: Any):
        self.result = result

@tool("Signal task completion with final result", schema=_done_schema)
def done(result: str = "", success: bool = True) -> None:
    raise TaskComplete({"result": result, "success": success})
```

**Status**: Already implemented identically. No action needed.

---

### 2. Ephemeral Messages (Already Implemented ✅)

**bu-agent-sdk pattern:**
```python
@tool("Get browser state", ephemeral=3)  # Keep last 3 only
async def get_state() -> str:
    return massive_dom_and_screenshot
```

**Agentic NAS (`simple_agent.py:158-190`):**
```python
def tool(description: str, *, ephemeral: int = 0, schema: Optional[Dict] = None):
    # If ephemeral > 0, only keep the last N outputs in context
```

**Status**: Already implemented identically. No action needed.

---

### 3. Context Compaction (NOT Implemented - HIGH PRIORITY ⚠️)

**bu-agent-sdk pattern:**
```python
from bu_agent_sdk.agent import CompactionConfig

agent = Agent(
    llm=llm,
    tools=tools,
    compaction=CompactionConfig(threshold_ratio=0.80),
)
```

When context approaches 80% capacity, the SDK auto-summarizes earlier messages to compress context.

**Agentic NAS gap**: No context compaction. Long-running agents with many tool calls can hit context limits.

**Why HIGH priority**: Your agents process heavy text:

| Agent | max_iterations | Risk Level |
|-------|----------------|------------|
| Planner | 25 | **HIGH** - reads scaffold files (~500 LOC), verbose prompts |
| Deduplicator | 25 | **HIGH** - reads scaffold files, verbose prompts |
| Debugger | 20 | **HIGH** - multi-turn error fix loops with stack traces |
| CodeChecker | 15 | **MEDIUM** - shape check fix loops |

**Reference implementation**: See `bu_agent_sdk/agent/compaction/service.py`

**Recommended implementation** for `SimpleAgent`:

```python
@dataclass
class CompactionConfig:
    threshold_ratio: float = 0.80  # Trigger at 80% capacity
    context_window: int = 128_000  # Model's max context (e.g., deepseek-coder)
    summary_prompt: str = "Summarize the progress and current state concisely."

class SimpleAgent:
    def __init__(self, ..., compaction: Optional[CompactionConfig] = None):
        self.compaction = compaction
        self._total_tokens = 0  # Updated after each LLM call

    async def _maybe_compact(self, messages: List[Dict]) -> List[Dict]:
        """Check token count and compact if over threshold."""
        if not self.compaction:
            return messages

        threshold = self.compaction.context_window * self.compaction.threshold_ratio
        if self._total_tokens < threshold:
            return messages

        # Keep system prompt (index 0) and recent messages (last 2)
        to_summarize = messages[1:-2]
        if len(to_summarize) < 3:
            return messages  # Not enough to summarize

        # Ask LLM to summarize the middle section
        summary_request = [
            {"role": "system", "content": "Summarize the following conversation concisely."},
            {"role": "user", "content": json.dumps(to_summarize)},
        ]
        response = await self.llm.ainvoke(summary_request, tools=None)
        summary = response.get("text", "")

        # Replace messages[1:-2] with summary
        return [
            messages[0],  # System prompt
            {"role": "user", "content": f"[Previous progress summary]: {summary}"},
            *messages[-2:],  # Keep recent context
        ]

    async def run(self, prompt: str, ...) -> Any:
        # ... existing loop ...
        for iteration in range(self.max_iterations):
            # Compact if needed (at end of each iteration)
            messages = await self._maybe_compact(messages)

            response = await self.llm.ainvoke(...)
            # Update token count from response metadata if available
            self._total_tokens = response.get("usage", {}).get("total_tokens", 0)
```

**Key insight**: This allows Planner/Debugger to run for 50+ turns without OOMing on context.

**Priority**: **HIGH** - implement soon to prevent context overflow in long-running agents

---

### 4. Dependency Injection (NOT Implemented - OPTIONAL)

**bu-agent-sdk pattern:**
```python
from typing import Annotated
from bu_agent_sdk import Depends

def get_db():
    return Database()

@tool("Query users")
async def get_user(id: int, db: Annotated[Database, Depends(get_db)]) -> str:
    return await db.find(id)
```

**Benefits**:
- Tools can receive shared resources (DB connections, configs)
- Enables sandboxed/mocked tool environments for testing
- Clean separation between tool logic and resource management

**Agentic NAS current approach**: Tools capture resources via closures in `make_read_file_tool()`, `make_write_file_tool()`.

**Recommendation**: Consider for future if:
- You need better testability of agents
- You want to run agents in sandboxed environments
- Multiple tools need shared state (DB connection, API clients)

**Priority**: Low - current closure approach is simpler and sufficient

---

### 5. Hooks System (NOT Implemented - POTENTIALLY USEFUL)

**claude-agent-sdk pattern:**
```python
async def check_bash_command(input_data, tool_use_id, context):
    if "dangerous_pattern" in input_data["tool_input"].get("command", ""):
        return {
            "hookSpecificOutput": {
                "permissionDecision": "deny",
                "permissionDecisionReason": "Blocked dangerous command",
            }
        }
    return {}

options = ClaudeAgentOptions(
    hooks={
        "PreToolUse": [HookMatcher(matcher="Bash", hooks=[check_bash_command])],
    }
)
```

**Use cases for Agentic NAS**:
- **PreToolUse**: Validate code before `write_file` commits it
- **PostToolUse**: Log/audit tool executions
- **PreCompact**: Control what gets summarized

**Potential implementation**:
```python
@dataclass
class HookConfig:
    pre_tool_use: Optional[Callable[[str, Dict], Optional[str]]] = None  # Return error msg to block
    post_tool_use: Optional[Callable[[str, Dict, str], None]] = None     # Audit/logging

class SimpleAgent:
    def __init__(self, ..., hooks: Optional[HookConfig] = None):
        self.hooks = hooks

    async def _execute_tool(self, name: str, args: Dict) -> str:
        if self.hooks and self.hooks.pre_tool_use:
            block_reason = self.hooks.pre_tool_use(name, args)
            if block_reason:
                return f"Blocked: {block_reason}"
        result = await self._call_tool(name, args)
        if self.hooks and self.hooks.post_tool_use:
            self.hooks.post_tool_use(name, args, result)
        return result
```

**Priority**: Low-Medium - useful for production safety but adds complexity

---

### 6. Streaming Events (NOT Implemented - OPTIONAL)

**bu-agent-sdk pattern:**
```python
async for event in agent.query_stream("do something"):
    match event:
        case ToolCallEvent(tool=name, args=args):
            print(f"Calling {name}")
        case ToolResultEvent(tool=name, result=result):
            print(f"{name} -> {result[:50]}")
```

**Agentic NAS gap**: No real-time event streaming. Current logging is print-based.

**Recommendation**: The existing agent logger (`services/utils/agent_logger.py`) handles observability. Streaming events would add complexity without clear benefit for NAS workloads.

**Priority**: Low - not needed for batch NAS operations

---

### 7. Required Tools Validation (Already Implemented ✅)

**Agentic NAS (`simple_agent.py:472-494`, `config.py:83-86`):**
```python
class SimpleAgent:
    def __init__(self, ..., required_tools: Optional[List[str]] = None):
        self.required_tools: List[str] = list(required_tools or [])
```

This is a pattern NOT present in either external SDK. Agentic NAS is ahead here.

---

### 8. Stall Detection (Already Implemented ✅)

**Agentic NAS (`simple_agent.py:49-51`, `81-86`, `407-427`):**
```python
class AgentStalled(Exception):
    """Raised when agent produces too many text-only responses without tool calls."""

def contains_code_block(text: str) -> bool:
    """Check if text contains markdown code blocks (excluding JSON)."""

# Recovery mechanism when code blocks detected in text
if contains_code_block(text):
    messages.append({"role": "user", "content": CODE_BLOCK_RECOVERY_MESSAGE})
```

This stall detection with recovery is more sophisticated than either external SDK.

---

### 9. JSON Output Parsing from Text (Already Implemented ✅)

**Agentic NAS (`simple_agent.py:119-151`):**
```python
def extract_finish_json(text: str) -> Optional[Dict[str, Any]]:
    """
    Try to extract finish/done JSON from text response.

    Following the Bitter Lesson: instead of fighting the model when it outputs
    JSON in text, parse it and treat as a successful completion.
    """
```

This follows the "Bitter Lesson" philosophy from bu-agent-sdk but with better implementation.

---

## Recommendations Summary

### High Priority (Implement Soon)

1. **Context Compaction** - Prevent context overflow in long-running agents
   - Estimated effort: ~80 LOC
   - Files: `simple_agent.py`
   - Reference: `bu_agent_sdk/agent/compaction/service.py`
   - Why: Planner/Deduplicator (25 iterations) and Debugger (20 iterations) process heavy text (scaffolds, stack traces)
   - Implementation: Check tokens at end of loop, summarize `messages[1:-2]` if over 80% threshold

### Medium Priority (Consider for Robustness)

### Low Priority (Nice to Have)

2. **Hooks System** - For production safety and auditing
   - Estimated effort: ~100 LOC
   - Useful if you need to block dangerous code patterns

3. **Dependency Injection** - For better testability
   - Estimated effort: ~150 LOC
   - Only needed if testing becomes a bottleneck

### Not Recommended

- **Multi-Provider Support**: Agentic NAS uses ChutesClient which already abstracts providers
- **Streaming Events**: Overkill for batch NAS operations
- **Permission System**: Too complex for trusted NAS environment

---

## Architecture Comparison

### bu-agent-sdk Philosophy
> "An agent is just a for-loop. The less you build, the more it works."

**Agentic NAS alignment**: `simple_agent.py` explicitly follows this philosophy (see line 1-13 docstring).

### claude-agent-sdk Philosophy
> "Bidirectional communication with hooks, permissions, and sandbox controls."

**Agentic NAS alignment**: This is designed for interactive CLI tools, not autonomous NAS. The complexity isn't warranted.

---

## Conclusion

Agentic NAS has already adopted the most valuable patterns from modern agent SDKs:

| Pattern | Status |
|---------|--------|
| Done tool with TaskComplete exception | ✅ Implemented |
| Ephemeral message management | ✅ Implemented |
| Required tools validation | ✅ Implemented (unique to Agentic NAS) |
| Stall detection with recovery | ✅ Implemented (more advanced than SDKs) |
| JSON-from-text parsing | ✅ Implemented |
| Context compaction | ❌ Not implemented (**HIGH PRIORITY**) |
| Hooks system | ❌ Not implemented (optional) |

The `simple_agent.py` implementation (~600 LOC) is well-aligned with the bu-agent-sdk philosophy while including additional safeguards (stall detection, required tools) that the external SDKs lack.

**Primary recommendation**: Add context compaction for long-running agents (HIGH PRIORITY). Your Planner/Debugger agents can run 20-25 iterations with heavy text (scaffolds, stack traces). Without compaction, they risk OOMing on context. Everything else is either already implemented or not necessary for the NAS use case.
