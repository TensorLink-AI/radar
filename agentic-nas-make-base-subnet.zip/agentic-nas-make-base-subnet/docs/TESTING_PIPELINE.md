# Pipeline Testing Playbook

This guide walks through spinning up the supporting services (MongoDB REST API and the OpenSearch-backed RAG service) and then exercising the experiment pipeline end-to-end. It assumes you are working from the repository root.

## 1. Prerequisites

1. **Python environment** – Create and activate a virtualenv with Python 3.10+ and install the project dependencies:
   ```bash
   python -m venv .venv
   source .venv/bin/activate
   pip install -r requirements.txt
   ```
2. **Docker & Docker Compose** – Required for MongoDB and OpenSearch containers.
3. **Repository configuration** – Update `services/config.py` so the `Config.DATABASE` and `Config.RAG` URLs point at the services you launch below (e.g., `http://localhost:8001` for the database API and `http://localhost:13142` for the RAG API).

## 2. Bring up the MongoDB stack

1. Start MongoDB and the Mongo Express dashboard:
   ```bash
   cd database
   docker compose up -d
   ```
2. Verify the containers are healthy:
   ```bash
   docker compose ps
   ```
3. (Optional) Open http://localhost:8081 and log in with `admin/admin123` to inspect the database.

## 3. Launch the MongoDB REST API

1. In a new terminal (still inside the `database/` directory), start the FastAPI service that the pipeline talks to:
   ```bash
   uvicorn mongodb_api:app --host 0.0.0.0 --port 8001 --reload
   ```
2. Confirm the API is reachable:
   ```bash
   curl http://localhost:8001/health | jq
   ```
   You should see a `"status": "healthy"` response with basic collection statistics.

## 4. Bring up the OpenSearch RAG stack

1. Start OpenSearch and the Dashboards UI:
   ```bash
   cd cognition_base
   docker compose up -d
   ```
2. Wait for the OpenSearch health check to report `green` or `yellow` (use `docker compose logs -f opensearch`).
3. (Optional) Visit http://localhost:5601 to explore indexed cognition documents.

## 5. Launch the RAG API service

1. With OpenSearch healthy, start the Flask API that wraps the RAG service:
   ```bash
   cd cognition_base
   python rag_api.py
   ```
   The script loads cognition documents and exposes endpoints on `http://localhost:13142`.
2. Verify the service initialized successfully:
   ```bash
   curl http://localhost:13142/health | jq
   ```
   Expect a `"status": "healthy"` payload along with index statistics.

## 6. Run a single experiment loop

1. Return to the repository root and ensure the virtual environment from step 1 is active.
2. Execute the experiment pipeline (replace the miner metadata with values appropriate for your setup if necessary):
   ```bash
   python -m services.pipeline
   ```
3. The run will:
   - fetch a program from the MongoDB API (`program_sample`),
   - evolve a new candidate,
   - evaluate it using the configured training tier, and
   - persist results back to MongoDB.

   Logs and intermediate artifacts are written under `Config.RUNS_DIR` (default `./runs`). Review the most recent run folder to validate outputs.

## 7. Tear down

1. Stop the Flask RAG API (`Ctrl+C`) and the FastAPI database service.
2. Shut down the Docker stacks:
   ```bash
   cd database
   docker compose down

   cd ../cognition_base
   docker compose down
   ```
3. Deactivate the Python virtualenv when finished:
   ```bash
   deactivate
   ```

With these steps you can repeatedly validate end-to-end pipeline runs against local MongoDB and OpenSearch instances.
