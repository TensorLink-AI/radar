#!/usr/bin/env python3
"""
Basilica stress test: deploy a container that concurrently trains multiple
models on the same GPU(s) using torch.multiprocessing.

Usage:
  1. Build and push the stress test image:
       docker build -t <registry>/stress-test:latest stress_test/
       docker push <registry>/stress-test:latest
  2. Set env vars:
       export BASILICA_API_TOKEN=your-token
       export STRESS_TEST_IMAGE=<registry>/stress-test:latest
  3. Run:
       python basilica_stress_multiproc_deploy.py
"""

import os
import time
from basilica import BasilicaClient

# ============================================================
# USER CONFIG (override via env on your machine)
# ============================================================
GPU_COUNT = int(os.getenv("GPU_COUNT", "1"))
MIN_GPU_MEM_GB = int(os.getenv("MIN_GPU_MEM_GB", "24"))
MEMORY = os.getenv("MEMORY", "16Gi")
TTL_SECONDS = int(os.getenv("TTL_SECONDS", "2400"))
DEPLOY_TIMEOUT = int(os.getenv("DEPLOY_TIMEOUT", "900"))

# Docker image built from stress_test/Dockerfile
STRESS_TEST_IMAGE = os.getenv("STRESS_TEST_IMAGE")

# Stress test knobs (passed into container as env)
STRESS_NUM_MODELS = os.getenv("STRESS_NUM_MODELS", "8")
STRESS_TRAIN_SECONDS = os.getenv("STRESS_TRAIN_SECONDS", str(30 * 60))
STRESS_GPU_MEM_FRACTION = os.getenv("STRESS_GPU_MEM_FRACTION", "0.12")
STRESS_OMP_THREADS = os.getenv("STRESS_OMP_THREADS", "2")
STRESS_ALLOC_CONF = os.getenv("STRESS_ALLOC_CONF", "max_split_size_mb:128")

PORT = int(os.getenv("PORT", "8000"))


def _diagnose_and_cleanup(client, instance_name: str):
    """Retrieve logs and status from a failed deployment, then delete it.

    When client.deploy() raises DeploymentFailed/DeploymentTimeout the
    deployment *does* exist on the server but the Deployment object is never
    returned to the caller.  We use client.get() with the instance_name
    (available via the exception's .instance_name attribute) to recover it.
    """
    try:
        dep = client.get(instance_name)
    except Exception as e:
        print(f"[diag] Could not retrieve deployment '{instance_name}': {e}")
        return

    print(f"\n[diag] Retrieved failed deployment '{dep.name}'")

    try:
        st = dep.status()
        print(f"[diag]   state : {st.state}")
        print(f"[diag]   phase : {st.phase}")
        print(f"[diag]   msg   : {st.message}")
        print(f"[diag]   replicas: {st.replicas_ready}/{st.replicas_desired}")
    except Exception as e:
        print(f"[diag]   status() failed: {e}")

    try:
        log_text = dep.logs(tail=200)
        print(f"[diag]   logs (last 200 lines):\n{log_text}")
    except Exception as e:
        print(f"[diag]   logs() failed: {e}")

    try:
        dep.delete()
        print(f"[diag]   cleaned up failed deployment '{instance_name}'")
    except Exception as e:
        print(f"[diag]   delete failed: {e}")


def main():
    token = os.getenv("BASILICA_API_TOKEN")
    if not token:
        raise RuntimeError("Set BASILICA_API_TOKEN in your environment")

    if not STRESS_TEST_IMAGE:
        raise RuntimeError(
            "Set STRESS_TEST_IMAGE to the Docker image built from stress_test/Dockerfile.\n"
            "  docker build -t <registry>/stress-test:latest stress_test/\n"
            "  docker push <registry>/stress-test:latest\n"
            "  export STRESS_TEST_IMAGE=<registry>/stress-test:latest"
        )

    # Pass api_key explicitly -- the SDK may not auto-read BASILICA_API_TOKEN
    client = BasilicaClient(api_key=token)
    deployment = None

    env = {
        "PORT": str(PORT),
        "STRESS_NUM_MODELS": STRESS_NUM_MODELS,
        "STRESS_TRAIN_SECONDS": STRESS_TRAIN_SECONDS,
        "STRESS_GPU_MEM_FRACTION": STRESS_GPU_MEM_FRACTION,
        "STRESS_OMP_THREADS": STRESS_OMP_THREADS,
        "STRESS_ALLOC_CONF": STRESS_ALLOC_CONF,
        "STRESS_RESULTS_PATH": "/tmp/stress_results.json",
        "OMP_NUM_THREADS": STRESS_OMP_THREADS,
        "MKL_NUM_THREADS": STRESS_OMP_THREADS,
        "OPENBLAS_NUM_THREADS": STRESS_OMP_THREADS,
        "PYTORCH_CUDA_ALLOC_CONF": STRESS_ALLOC_CONF,
    }

    try:
        print(f"Deploying with image={STRESS_TEST_IMAGE}, gpu_count={GPU_COUNT}, "
              f"min_gpu_memory_gb={MIN_GPU_MEM_GB}, memory={MEMORY}")
        print(f"Stress config: models={STRESS_NUM_MODELS}, "
              f"mem_fraction={STRESS_GPU_MEM_FRACTION}, "
              f"train_seconds={STRESS_TRAIN_SECONDS}")

        deployment = client.deploy(
            name="stress-multiproc",
            image=STRESS_TEST_IMAGE,
            port=PORT,
            gpu_count=GPU_COUNT,
            min_gpu_memory_gb=MIN_GPU_MEM_GB,
            memory=MEMORY,
            ttl_seconds=TTL_SECONDS,
            timeout=DEPLOY_TIMEOUT,
            env=env,
        )

        print("Deployment ready:", deployment.url)
        print("Endpoints:")
        print(f"  curl -s {deployment.url}/healthz")
        print(f"  curl -s {deployment.url}/results")

        print(f"Letting it run; TTL: {TTL_SECONDS} seconds")
        time.sleep(max(5, TTL_SECONDS - 15))

    except Exception as e:
        print(f"Deployment failed: {e}")
        import traceback
        traceback.print_exc()

        # DeploymentFailed / DeploymentTimeout carry .instance_name so we
        # can recover the server-side deployment for logs and cleanup.
        inst_name = getattr(e, "instance_name", None)
        if inst_name:
            _diagnose_and_cleanup(client, inst_name)
        else:
            print("[diag] Exception does not carry instance_name; "
                  "cannot retrieve deployment logs.")

    finally:
        if deployment is not None:
            print("Tearing down deployment...")
            try:
                deployment.delete()
            except Exception as e:
                print("Delete failed:", e)
            else:
                print("Deleted")


if __name__ == "__main__":
    main()
