"""
Time-series S3 Parquet dataloader.

Extends the generic :class:`core.data.s3_parquet_dataset.S3ParquetDataset`
with time-series-specific row conversion and batch collation.

Usage::

    from tasks.ts_foundation.s3_dataloader import (
        TimeSeriesS3Dataset,
        ts_s3_collate_fn,
        build_ts_s3_dataloader,
    )

    config = S3ParquetConfig(
        bucket="my-ts-data",
        root_prefix="datasets/v1",
        endpoint_url="https://acct.r2.cloudflarestorage.com",
        access_key="...",
        secret_key="...",
        domain_weights={"Energy/Grid": 2.0, "Traffic/Transportation": 1.0},
    )
    loader = build_ts_s3_dataloader(config, batch_size=64, num_workers=4)
    for batch in loader:
        print(batch["target"].shape)  # [B, T_max]
"""

from __future__ import annotations

from typing import Any, Dict, Optional, Sequence

import torch
from torch.utils.data import DataLoader

from core.data.s3_parquet_dataset import (
    S3ParquetConfig,
    S3ParquetDataset,
    build_s3_parquet_dataloader,
)
from core.data.s3_store import S3ObjectStore
from core.data.s3_parquet_dataset import ManifestIndex


# ── Row conversion ───────────────────────────────────────────────────────


def ts_row_to_sample(row: Dict[str, Any]) -> Dict[str, Any]:
    """Convert a raw Parquet row to a time-series training sample.

    Args:
        row: Raw dict from pyarrow with time-series fields.

    Returns:
        Dict with ``item_id``, ``start``, ``target`` (FloatTensor),
        ``domain``, ``freq``, ``dataset_name``, ``feat_static_cat``,
        ``feat_dynamic_real``.
    """
    target = row.get("target", [])
    if target is None:
        target = []
    target_tensor = torch.tensor(target, dtype=torch.float32)

    return {
        "item_id": str(row.get("item_id", "")),
        "start": str(row.get("start", "")),
        "target": target_tensor,
        "domain": str(row.get("domain", "")),
        "freq": str(row.get("freq", "")),
        "dataset_name": str(row.get("dataset_name", "")),
        "feat_static_cat": row.get("feat_static_cat"),
        "feat_dynamic_real": row.get("feat_dynamic_real"),
    }


# ── Collate function ─────────────────────────────────────────────────────


def ts_s3_collate_fn(
    samples: Sequence[Dict[str, Any]],
) -> Dict[str, Any]:
    """Collate variable-length time-series samples into a padded batch.

    Pads ``target`` tensors to the maximum length in the batch and
    produces a boolean ``attention_mask`` (``True`` for real values).

    Args:
        samples: List of sample dicts from :class:`TimeSeriesS3Dataset`.

    Returns:
        Dict with:

        - ``target``: ``FloatTensor [B, T_max]`` (zero-padded)
        - ``lengths``: ``LongTensor [B]``
        - ``attention_mask``: ``BoolTensor [B, T_max]``
        - ``item_id``: list of strings
        - ``start``: list of strings
        - ``domain``: list of strings
        - ``freq``: list of strings
        - ``dataset_name``: list of strings
        - ``feat_static_cat``: list (raw, may contain None)
        - ``feat_dynamic_real``: list (raw, may contain None)
    """
    targets = [s["target"] for s in samples]
    lengths = torch.tensor([t.shape[0] for t in targets], dtype=torch.long)
    max_len = int(lengths.max().item()) if len(lengths) > 0 else 0

    # Pad targets
    padded = torch.zeros(len(samples), max_len, dtype=torch.float32)
    mask = torch.zeros(len(samples), max_len, dtype=torch.bool)
    for i, (t, length) in enumerate(zip(targets, lengths)):
        L = int(length.item())
        padded[i, :L] = t[:L]
        mask[i, :L] = True

    return {
        "target": padded,
        "lengths": lengths,
        "attention_mask": mask,
        "item_id": [s["item_id"] for s in samples],
        "start": [s["start"] for s in samples],
        "domain": [s["domain"] for s in samples],
        "freq": [s["freq"] for s in samples],
        "dataset_name": [s["dataset_name"] for s in samples],
        "feat_static_cat": [s.get("feat_static_cat") for s in samples],
        "feat_dynamic_real": [s.get("feat_dynamic_real") for s in samples],
    }


# ── Time-series dataset subclass ─────────────────────────────────────────


class TimeSeriesS3Dataset(S3ParquetDataset):
    """S3 Parquet dataset specialised for time-series data.

    Overrides row conversion to produce samples with a ``target``
    FloatTensor and standard TS metadata fields (``item_id``, ``start``,
    ``domain``, ``freq``, ``dataset_name``, ``feat_static_cat``,
    ``feat_dynamic_real``).

    Args:
        config: S3 Parquet configuration.
        store: Pre-built S3 object store (optional).
        index: Pre-built manifest index (optional).
    """

    def __init__(
        self,
        config: S3ParquetConfig,
        *,
        store: Optional[S3ObjectStore] = None,
        index: Optional[ManifestIndex] = None,
    ) -> None:
        super().__init__(
            config,
            row_to_sample=ts_row_to_sample,
            store=store,
            index=index,
        )


# ── Builder ──────────────────────────────────────────────────────────────


def build_ts_s3_dataloader(
    config: S3ParquetConfig,
    *,
    batch_size: int = 32,
    num_workers: int = 0,
    store: Optional[S3ObjectStore] = None,
    index: Optional[ManifestIndex] = None,
) -> DataLoader:
    """Build a ``DataLoader`` for time-series S3 Parquet data.

    Convenience wrapper around :func:`build_s3_parquet_dataloader` that
    supplies the time-series row converter and collate function.

    Args:
        config: S3 Parquet configuration.
        batch_size: Batch size.
        num_workers: DataLoader worker count.
        store: Pre-built S3 store (optional).
        index: Pre-built manifest index (optional).

    Returns:
        Configured ``DataLoader`` yielding padded time-series batches.

    Example::

        config = S3ParquetConfig(
            bucket="my-ts-data",
            root_prefix="datasets/v1",
            endpoint_url="https://acct.r2.cloudflarestorage.com",
            access_key="...",
            secret_key="...",
            domain_weights={"Energy/Grid": 2.0, "Traffic/Transportation": 1.0},
            seed=42,
        )
        loader = build_ts_s3_dataloader(config, batch_size=64, num_workers=4)
        for batch in loader:
            print(batch["target"].shape)  # [64, T_max]
    """
    return build_s3_parquet_dataloader(
        config,
        row_to_sample=ts_row_to_sample,
        collate_fn=ts_s3_collate_fn,
        batch_size=batch_size,
        num_workers=num_workers,
        store=store,
        index=index,
    )


__all__ = [
    "ts_row_to_sample",
    "ts_s3_collate_fn",
    "TimeSeriesS3Dataset",
    "build_ts_s3_dataloader",
]
