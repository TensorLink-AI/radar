from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from pathlib import Path
from typing import Dict, Iterable, Iterator, List, Optional, Union

import torch
import torch.nn.functional as F
from torch.utils.data import DataLoader, Dataset, IterableDataset, Subset

import random

DEFAULT_SERIES_LENGTH = 4096
DEFAULT_SEED = 13
TRAIN_SPLIT = 0.7
VAL_SPLIT = 0.15
SEASONALITY = 24
HF_DEFAULT_REPO = "tensorlink-dev/time-series-six-datasets"


class ForecastingMode(str, Enum):
    """Supported sampling strategies for time-series forecasting datasets."""

    AUTOREGRESSIVE = "autoregressive"
    NONAUTOREGRESSIVE = "nonautoregressive"


@dataclass
class DatasetBundle:
    train: DataLoader
    val: DataLoader
    test: DataLoader
    mase_scale: float
    input_length: int
    forecast_length: int
    forecasting_mode: ForecastingMode = ForecastingMode.NONAUTOREGRESSIVE
    decoder_context_len: Optional[int] = None
    dataset_path: Optional[str] = None


def _iter_windows_from_series(
    series_vals: Iterable[float],
    *,
    input_length: int,
    forecast_length: int,
    stride: int,
) -> Iterator[tuple[int, list[float], list[float]]]:
    """Yield sliding windows (start, past window, future window) over a sequence."""

    total_needed = input_length + forecast_length
    series_list = list(series_vals)
    n = len(series_list)
    max_start = n - total_needed
    if max_start < 0:
        return

    for start in range(0, max_start + 1, stride):
        past = series_list[start : start + input_length]
        future = series_list[start + input_length : start + total_needed]
        yield start, past, future


class StreamingSlidingWindowDataset(IterableDataset):
    """Iterable sliding-window dataset that streams Hugging Face splits.

    For each univariate series row, multiple sliding windows are generated and yielded as
    dictionaries matching :class:`SlidingWindowDataset` outputs. Optional buffered shuffling
    provides approximate randomness for streaming training data.
    """

    def __init__(
        self,
        hf_repo_id: str,
        split: str,
        *,
        input_length: int,
        forecast_length: int,
        stride: Optional[int] = None,
        forecasting_mode: ForecastingMode = ForecastingMode.NONAUTOREGRESSIVE,
        decoder_context_len: Optional[int] = None,
        shuffle_buffer_size: int = 0,
        dtype: torch.dtype = torch.float32,
    ) -> None:
        self.hf_repo_id = hf_repo_id
        self.split = split
        self.input_length = int(input_length)
        self.forecast_length = int(forecast_length)
        self.window = self.input_length + self.forecast_length
        
        # Use provided stride, or default to a reasonable overlap (e.g. 64)
        # If not provided, the previous behavior was self.window (no overlap), which is very slow
        # to fill batches because it discards most data.
        if stride is not None:
            self.stride = stride
        else:
            self.stride = 64  # Good default for efficiency
            
        self.forecasting_mode = forecasting_mode
        self.decoder_context_len = (
            int(decoder_context_len)
            if decoder_context_len is not None
            else min(self.forecast_length, self.input_length)
        )
        self.shuffle_buffer_size = int(shuffle_buffer_size)
        self.dtype = dtype

        if self.decoder_context_len <= 0:
            raise ValueError("decoder_context_len must be positive.")

    def __iter__(self) -> Iterator[dict[str, torch.Tensor | str | int | None]]:
        from datasets import load_dataset  # Local import to keep dependency optional

        hf_iterable = load_dataset(self.hf_repo_id, split=self.split, streaming=True)
        window_stream = self._window_generator(hf_iterable)

        if self.shuffle_buffer_size > 0:
            yield from self._shuffle_generator(window_stream, self.shuffle_buffer_size)
        else:
            yield from window_stream

    def _window_generator(
        self, hf_iterable: Iterable[dict[str, list[list[float]]]]
    ) -> Iterator[dict[str, torch.Tensor | str | int | None]]:
        for row in hf_iterable:
            raw_target = row.get("target")
            if raw_target is None:
                continue

            # HF time-series datasets sometimes store univariate targets as a flat list
            # (e.g., Monash/TSF, M4) and other times as a nested list-of-lists. Accept
            # both formats by unwrapping a single nesting level when present.
            if isinstance(raw_target, (list, tuple)) and raw_target and isinstance(
                raw_target[0], (list, tuple)
            ):
                series_vals = raw_target[0]
            else:
                series_vals = raw_target

            if not series_vals:
                continue

            for start, past_list, future_list in _iter_windows_from_series(
                series_vals,
                input_length=self.input_length,
                forecast_length=self.forecast_length,
                stride=self.stride,
            ):
                series_tensor = torch.tensor(past_list + future_list, dtype=self.dtype)
                past = series_tensor[: self.input_length]
                future = series_tensor[self.input_length : self.window]
                horizon = future.unsqueeze(-1)

                example: dict[str, torch.Tensor | str | int | None] = {
                    "past_target": past.unsqueeze(-1),
                    "future_target": horizon,
                    "item_id": row.get("item_id"),
                    "freq": row.get("freq"),
                    "start_idx": start,
                    "start_time": row.get("start"),
                }

                if self.forecasting_mode == ForecastingMode.AUTOREGRESSIVE:
                    rollout_start = start + self.input_length - self.decoder_context_len
                    rollout_span = torch.tensor(
                        series_vals[rollout_start : start + self.window], dtype=self.dtype
                    )
                    pad = (-rollout_span.shape[0]) % self.decoder_context_len
                    if pad:
                        rollout_span = F.pad(rollout_span, (0, pad))
                    example["future_target_rollout"] = rollout_span.unfold(
                        dimension=0,
                        size=self.decoder_context_len,
                        step=self.decoder_context_len,
                    ).unsqueeze(-1)

                yield example

    @staticmethod
    def _shuffle_generator(
        iterator: Iterator[dict[str, torch.Tensor | str | int | None]], buf_size: int
    ) -> Iterator[dict[str, torch.Tensor | str | int | None]]:
        buffer: list[dict[str, torch.Tensor | str | int | None]] = []

        for sample in iterator:
            buffer.append(sample)
            if len(buffer) >= buf_size:
                idx = random.randrange(len(buffer))
                yield buffer.pop(idx)

        while buffer:
            idx = random.randrange(len(buffer))
            yield buffer.pop(idx)


class SlidingWindowDataset(Dataset):
    """
    Sliding-window dataset for univariate time series with explicit forecasting modes.

    Returns dictionaries with standardized keys:

    - ``past_target``: Tensor of shape ``(input_length, 1)`` containing the history window.
    - ``future_target``: Tensor of shape ``(forecast_length, 1)`` containing the full horizon.
    - ``future_target_rollout`` (only in ``autoregressive`` mode):
        Tensor of shape ``(num_chunks, decoder_context_len, 1)`` representing decoder rollouts
        with an initial context chunk drawn from the end of ``past_target``. The final chunk is
        zero-padded if needed.
    """

    def __init__(
        self,
        series: torch.Tensor,
        input_length: int,
        forecast_length: int,
        *,
        stride: Optional[int] = None,
        forecasting_mode: ForecastingMode = ForecastingMode.NONAUTOREGRESSIVE,
        decoder_context_len: Optional[int] = None,
    ):
        self.series = series.float()
        self.input_length = int(input_length)
        self.forecast_length = int(forecast_length)
        self.forecasting_mode = forecasting_mode
        self.decoder_context_len = (
            int(decoder_context_len)
            if decoder_context_len is not None
            else min(self.forecast_length, self.input_length)
        )
        self.window = self.input_length + self.forecast_length
        # Default stride to the window size if not provided
        self.stride = stride if stride is not None else self.window

        if self.window > len(self.series):
            raise ValueError(
                f"Series length {len(self.series)} is insufficient for "
                f"input_length={self.input_length} and forecast_length={self.forecast_length}"
            )
        # Calculate the number of possible windows with the given stride
        self.num_windows = (len(self.series) - self.window) // self.stride + 1

        if self.decoder_context_len <= 0:
            raise ValueError("decoder_context_len must be positive.")

    def __len__(self) -> int:
        return self.num_windows

    def __getitem__(self, idx: int) -> dict[str, torch.Tensor]:
        start = int(idx * self.stride)
        past = self.series[start : start + self.input_length]

        future = self.series[start + self.input_length : start + self.window]
        horizon = future.unsqueeze(-1)

        rollout_chunks = None
        if self.forecasting_mode == ForecastingMode.AUTOREGRESSIVE:
            rollout_start = start + self.input_length - self.decoder_context_len
            rollout_span = self.series[rollout_start : start + self.window]
            pad = (-rollout_span.shape[0]) % self.decoder_context_len
            if pad:
                rollout_span = F.pad(rollout_span, (0, pad))
            rollout_chunks = rollout_span.unfold(
                dimension=0,
                size=self.decoder_context_len,
                step=self.decoder_context_len,
            ).unsqueeze(-1)

        example = {
            "past_target": past.unsqueeze(-1),
            "future_target": horizon,
        }
        if rollout_chunks is not None:
            example["future_target_rollout"] = rollout_chunks

        return example


def _load_series(dataset_path: Optional[str], length: int, seed: int) -> torch.Tensor:
    if dataset_path:
        path = Path(dataset_path)
        if not path.exists():
            raise FileNotFoundError(f"No dataset found at {path}")
        if path.suffix == ".npy":
            try:
                import numpy as np  # type: ignore
            except ImportError as exc:  # pragma: no cover - optional dependency
                raise ImportError(
                    "Reading .npy datasets requires numpy to be installed."
                ) from exc
            values = np.load(path)
        else:
            import pandas as pd  # Local import to keep dependency optional

            df = pd.read_csv(path)
            if "value" not in df.columns:
                raise ValueError(
                    f"Expected a 'value' column in {path} for time-series data."
                )
            values = df["value"].to_numpy()
        return torch.tensor(values, dtype=torch.float32)

    generator = torch.Generator().manual_seed(seed)
    t = torch.arange(length, dtype=torch.float32)
    seasonal = torch.sin(2 * torch.pi * t / 96.0) + 0.5 * torch.sin(
        2 * torch.pi * t / 288.0
    )
    trend = 0.0005 * t
    noise = torch.randn(length, generator=generator) * 0.2
    return seasonal + trend + noise


def _compute_mase_scale(series: torch.Tensor, seasonality: int) -> float:
    if len(series) <= seasonality:
        return 1.0
    diffs = torch.abs(series[seasonality:] - series[:-seasonality])
    denom = torch.mean(diffs)
    scale = float(denom.item())
    return scale if scale > 1e-8 else 1.0


def _make_loader(dataset: SlidingWindowDataset, indices: list[int], batch_size: int, shuffle: bool) -> DataLoader:
    subset = Subset(dataset, indices if indices else list(range(len(dataset))))
    return DataLoader(
        subset,
        batch_size=batch_size,
        shuffle=shuffle,
        drop_last=False,
        num_workers=0,
    )


def _make_streaming_loader(dataset: IterableDataset, batch_size: int) -> DataLoader:
    return DataLoader(
        dataset,
        batch_size=batch_size,
        shuffle=False,
        drop_last=False,
        num_workers=0,
    )


def build_dataloaders(
    *,
    input_length: int,
    forecast_length: int,
    batch_size: int = 32,
    dataset_path: Optional[str] = None,
    synthetic_length: int = DEFAULT_SERIES_LENGTH,
    seed: int = DEFAULT_SEED,
    stride: Optional[int] = None,
    forecasting_mode: ForecastingMode = ForecastingMode.NONAUTOREGRESSIVE,
    decoder_context_len: Optional[int] = None,
    hf_repo_id: Optional[Union[str, List[str], Dict[str, str]]] = None,
    hf_train_split: str = "train",
    hf_val_split: str = "validation",
    hf_test_split: str = "test",
    shuffle_buffer_size: int = 0,
) -> DatasetBundle:
    """Create train/validation/test DataLoaders for the time-series task.

    Args:
        input_length: Number of past time steps provided to the model.
        forecast_length: Forecast horizon to evaluate.
        batch_size: Batch size for each split loader.
        dataset_path: Optional path to a CSV/NPY dataset; defaults to a synthetic series.
        synthetic_length: Length of generated synthetic data when no path is provided.
        seed: Random seed for data generation and shuffling.
        stride: Step size between sliding windows (defaults to ``input_length + forecast_length``).
        forecasting_mode: ``ForecastingMode.NONAUTOREGRESSIVE`` for encoder-style sampling or
            ``ForecastingMode.AUTOREGRESSIVE`` for decoder rollouts.
        decoder_context_len: Optional chunk length for decoder rollouts; defaults to
            ``min(forecast_length, input_length)`` when ``None``.
        hf_repo_id: Optional Hugging Face dataset repository id(s).
            Accepts a single string, a list of repo IDs, or a dict
            mapping logical names to repo IDs.  When provided,
            streaming sliding-window datasets are built from the
            specified splits instead of local data.  Multiple repos
            are chained sequentially.
        hf_train_split: Split name for the training set when streaming.
        hf_val_split: Split name for the validation set when streaming.
        hf_test_split: Split name for the test set when streaming.
        shuffle_buffer_size: Optional buffer size for approximate shuffling of streaming
            training windows.
    """
    from core.tasks.contracts import normalize_repo_ids

    repo_ids = normalize_repo_ids(hf_repo_id) if hf_repo_id else []

    if repo_ids:
        shared_kwargs = dict(
            input_length=input_length,
            forecast_length=forecast_length,
            stride=stride,
            forecasting_mode=forecasting_mode,
            decoder_context_len=decoder_context_len,
        )

        def _build_split(split: str, shuffle_buf: int = 0) -> IterableDataset:
            datasets = [
                StreamingSlidingWindowDataset(
                    hf_repo_id=rid,
                    split=split,
                    shuffle_buffer_size=shuffle_buf,
                    **shared_kwargs,
                )
                for rid in repo_ids
            ]
            if len(datasets) == 1:
                return datasets[0]
            from torch.utils.data import ChainDataset
            return ChainDataset(datasets)

        train_dataset = _build_split(hf_train_split, shuffle_buffer_size)
        val_dataset = _build_split(hf_val_split)
        test_dataset = _build_split(hf_test_split)

        train_loader = _make_streaming_loader(train_dataset, batch_size)
        val_loader = _make_streaming_loader(val_dataset, batch_size)
        test_loader = _make_streaming_loader(test_dataset, batch_size)

        # For decoder_context_len, use the first underlying dataset
        first_ds = (
            train_dataset.datasets[0]
            if hasattr(train_dataset, "datasets")
            else train_dataset
        )

        resolved_path = repo_ids[0] if len(repo_ids) == 1 else str(repo_ids)
        return DatasetBundle(
            train=train_loader,
            val=val_loader,
            test=test_loader,
            mase_scale=1.0,
            input_length=input_length,
            forecast_length=forecast_length,
            forecasting_mode=forecasting_mode,
            decoder_context_len=first_ds.decoder_context_len,
            dataset_path=resolved_path,
        )

    series = _load_series(dataset_path, synthetic_length, seed)
    dataset = SlidingWindowDataset(
        series,
        input_length,
        forecast_length,
        stride=stride,
        forecasting_mode=forecasting_mode,
        decoder_context_len=decoder_context_len,
    )
    total = len(dataset)
    if total < 3:
        raise ValueError(
            "Dataset too small to split into train/validation/test windows."
        )

    generator = torch.Generator().manual_seed(seed)
    permuted = torch.randperm(total, generator=generator).tolist()
    train_cut = max(1, int(total * TRAIN_SPLIT))
    val_cut = max(train_cut + 1, int(total * (TRAIN_SPLIT + VAL_SPLIT)))

    train_idx = permuted[:train_cut]
    val_idx = permuted[train_cut:val_cut]
    test_idx = permuted[val_cut:] or permuted[train_cut:val_cut]

    train_loader = _make_loader(dataset, train_idx, batch_size, True)
    val_loader = _make_loader(dataset, val_idx, batch_size, False)
    test_loader = _make_loader(dataset, test_idx, batch_size, False)

    scale_series = series[
        : max(input_length + len(train_idx), input_length + forecast_length + 1)
    ]
    mase_scale = _compute_mase_scale(scale_series, seasonality=SEASONALITY)
    resolved_path = str(Path(dataset_path).resolve()) if dataset_path else None

    return DatasetBundle(
        train=train_loader,
        val=val_loader,
        test=test_loader,
        mase_scale=mase_scale,
        input_length=input_length,
        forecast_length=forecast_length,
        forecasting_mode=forecasting_mode,
        decoder_context_len=dataset.decoder_context_len,
        dataset_path=resolved_path,
    )
