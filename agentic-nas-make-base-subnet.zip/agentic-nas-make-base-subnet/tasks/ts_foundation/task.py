"""Thin time-series foundation task.

This module defines ``TimeSeriesFoundationTask`` using the
*Thin Task, Fat Core* pattern.  All heavy-lifting (training loop,
evaluation, remote harness generation) is delegated to ``core/``
modules.  This file owns only:

- The declarative ``TaskDefinition``.
- Prompt / challenge metadata (delegated to ``task_prompts``).
- Dataset construction (delegated to ``dataloader``).
- A thin ``train_and_eval`` dispatcher that wires the universal
  trainer to the ts-specific callables exported by ``model_base``.
"""

from __future__ import annotations

import math
import os
from typing import Any, Dict, List, Optional, Tuple, TYPE_CHECKING

from core.tasks.contracts import BaseTask, TaskDefinition
from core.tasks.registry import register_task
from .task_prompts import (
    PLANNER_CONTEXT_PROMPT,
    PLANNER_CHALLENGE_PRIORITIES,
    MOTIVATION_CONTEXT_PROMPT,
    METRIC_DESCRIPTIONS_PROMPT,
    BASELINE_REFERENCE_PROMPT,
    TS_CHALLENGE_CATEGORIES,
    TS_CHALLENGE_PATTERNS,
    TS_ANALYZER_CHALLENGE_CONTEXT,
    build_role_instruction,
    get_performance_rubric,
)

if TYPE_CHECKING:  # pragma: no cover
    import torch
    from .dataloader import DatasetBundle

# ── Declarative task definition ──────────────────────────────────────

TASK_DEFINITION = TaskDefinition(
    name="time_series_foundation",
    description=(
        "Long-range univariate time-series forecasting with "
        "probabilistic quantile outputs."
    ),
    hf_repo_id="tensorlink-dev/time-series-six-datasets",
    hf_split_map={"train": "train", "val": "validation", "test": "test"},
    max_params=125_000_000,
    model_base_module="tasks.ts_foundation.model_base",
    scaffold_path="scaffolds/ts_base_model.py",
    primary_metric="MASE",
    direction="minimize",
    extra_metrics=["CRPS", "quantile_loss"],
    zero_cost_timeout_sec=120,
    small_budget_steps=20,
    small_budget_timeout_sec=1800,
    large_budget_steps=6000,
    large_budget_timeout_sec=14400,
    keywords=[
        "time-series", "forecasting", "sequence-modeling",
        "prediction", "state-space-models",
    ],
    challenge_categories=[
        "Long-Range Dependencies",
        "Multi-Scale & Frequency",
        "Non-Stationarity",
        "Scale-Free Generalization",
        "SNR Variability",
        "Computational Efficiency",
    ],
    supported_training_styles=["teacher_forced", "direct"],
)


# ── Task class ───────────────────────────────────────────────────────


@register_task("time_series_foundation")
class TimeSeriesFoundationTask(BaseTask):
    """Thin task for time-series forecasting.

    All training / evaluation logic lives in ``core.training`` and
    ``model_base``.  This class provides the declarative definition,
    dataset construction, and prompt fragments.
    """

    def __init__(self) -> None:
        self.run_dir: str = os.getcwd()
        self._dataset_bundle: Optional["DatasetBundle"] = None
        self._model_config: Optional[Dict[str, Any]] = None

    # ── TaskDefinition property ──────────────────────────────────────

    @property
    def definition(self) -> TaskDefinition:
        return TASK_DEFINITION

    # ── Dataset construction ─────────────────────────────────────────

    def build_datasets(self, cfg: Dict[str, Any]) -> "DatasetBundle":
        """Build data loaders for training and evaluation.

        Supports three data sources (selected via ``cfg["data_source"]``
        or the ``TRAINING_DATA_SOURCE`` environment variable):

        ``"gifteval_pretrain"``
            Stream pre-windowed shards from R2 / S3.  Requires R2
            credentials (``R2_ENDPOINT_URL``, ``R2_ACCESS_KEY_ID``,
            ``R2_SECRET_ACCESS_KEY``).  Best for small_budget and
            large_budget training with diverse, shuffled data.

        ``"hf"`` (default)
            Stream from a Hugging Face dataset repository.

        ``"local"``
            Load from a local CSV / NPY file.
        """
        from .model_base import DEFAULT_FORECAST_LENGTH, DEFAULT_INPUT_LENGTH

        input_length = int(cfg.get("input_length", DEFAULT_INPUT_LENGTH))
        forecast_length = int(cfg.get("forecast_length", DEFAULT_FORECAST_LENGTH))
        batch_size = int(cfg.get("batch_size", 32))
        self._model_config = cfg.get("model_config", self._model_config)

        # Resolve data source: explicit cfg > env var > default "hf"
        data_source = cfg.get(
            "data_source",
            os.getenv("TRAINING_DATA_SOURCE", "hf"),
        ).lower()

        if data_source == "gifteval_pretrain":
            self._dataset_bundle = self._build_gifteval_pretrain(
                cfg, input_length, forecast_length, batch_size,
            )
            return self._dataset_bundle

        # Original HF / local path
        from .dataloader import (
            ForecastingMode,
            HF_DEFAULT_REPO,
            build_dataloaders,
        )

        forecasting_mode = ForecastingMode(
            cfg.get("forecasting_mode", ForecastingMode.NONAUTOREGRESSIVE)
        )
        decoder_context_len = cfg.get("decoder_context_len", None)

        dataset_path = cfg.get("dataset_path", None)
        hf_repo_id = cfg.get("hf_repo_id", None)
        if dataset_path:
            hf_repo_id = None
        elif hf_repo_id is None:
            hf_repo_id = HF_DEFAULT_REPO

        self._dataset_bundle = build_dataloaders(
            input_length=input_length,
            forecast_length=forecast_length,
            batch_size=batch_size,
            dataset_path=dataset_path,
            hf_repo_id=hf_repo_id,
            forecasting_mode=forecasting_mode,
            decoder_context_len=decoder_context_len,
        )
        return self._dataset_bundle

    def _build_gifteval_pretrain(
        self,
        cfg: Dict[str, Any],
        input_length: int,
        forecast_length: int,
        batch_size: int,
    ) -> "DatasetBundle":
        """Build loaders from GiftEval pretrain shards on R2."""
        from .gifteval_pretrain_loader import (
            GIFTEVAL_PRETRAIN_BUCKET,
            GIFTEVAL_PRETRAIN_ENV_PREFIX,
            GIFTEVAL_PRETRAIN_PREFIX,
            build_gifteval_pretrain_dataloaders,
        )

        return build_gifteval_pretrain_dataloaders(
            input_length=input_length,
            forecast_length=forecast_length,
            batch_size=batch_size,
            seed=int(cfg.get("seed", 42)),
            num_workers=int(cfg.get("num_workers", 0)),
            bucket=cfg.get("gifteval_bucket", GIFTEVAL_PRETRAIN_BUCKET),
            prefix=cfg.get("gifteval_prefix", GIFTEVAL_PRETRAIN_PREFIX),
            env_prefix=cfg.get("gifteval_env_prefix", GIFTEVAL_PRETRAIN_ENV_PREFIX),
            endpoint_url=cfg.get("gifteval_endpoint_url", ""),
            access_key=cfg.get("gifteval_access_key", ""),
            secret_key=cfg.get("gifteval_secret_key", ""),
        )

    # ── Training / evaluation ────────────────────────────────────────

    def train_and_eval(
        self,
        candidate_code_path: str,
        datasets: Dict[str, Any],
        run_dir: str,
        eval_type: str,
    ) -> Dict[str, Any]:
        """Dispatch evaluation using the universal trainer + ts-specific callables."""
        from .dataloader import DatasetBundle
        from .model_base import (
            DEFAULT_FORECAST_LENGTH,
            DEFAULT_INPUT_LENGTH,
            load_candidate_model,
        )
        from .metrics import make_eval_fn, make_forward_fn, make_loss_fn

        bundle: Optional[DatasetBundle] = (
            datasets if isinstance(datasets, DatasetBundle) else self._dataset_bundle
        )
        if bundle is None:
            bundle = self.build_datasets({})

        input_length = bundle.input_length
        forecast_length = bundle.forecast_length
        mase_scale = getattr(bundle, "mase_scale", 1.0)

        if eval_type == "zero_cost":
            return self._zero_cost_eval(
                candidate_code_path, run_dir, input_length, forecast_length,
            )

        # Build callables parameterised by this dataset bundle
        ts_loss_fn = make_loss_fn()
        ts_forward_fn = make_forward_fn(forecast_length, input_length)
        ts_eval_fn = make_eval_fn(
            forecast_length, input_length, mase_scale,
            max_batches=10 if eval_type == "small_budget" else None,
        )

        # Load model
        import torch
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        model = load_candidate_model(
            candidate_code_path,
            device,
            model_config=self._model_config,
            input_length=input_length,
            forecast_length=forecast_length,
        )

        # Configure training budget
        from core.training.universal_trainer import TrainingConfig, train_model

        if eval_type == "large_budget":
            config = TrainingConfig(
                max_steps=TASK_DEFINITION.large_budget_steps,
                eval_interval=200,
                batch_size=64,
                warmup_steps=300,
                lr_scheduler="cosine",
                device=str(device),
            )
        else:  # small_budget
            config = TrainingConfig(
                max_steps=TASK_DEFINITION.small_budget_steps,
                eval_interval=10,
                batch_size=8,
                max_val_batches=10,
                device=str(device),
            )

        result = train_model(
            model=model,
            train_loader=bundle.train,
            loss_fn=ts_loss_fn,
            config=config,
            val_loader=bundle.val,
            eval_fn=ts_eval_fn,
            forward_fn=ts_forward_fn,
            run_dir=run_dir,
            eval_type=eval_type,
        )

        return result.metrics

    def _zero_cost_eval(
        self,
        candidate_code_path: str,
        run_dir: str,
        input_length: int,
        forecast_length: int,
    ) -> Dict[str, Any]:
        """Signal-aware zero-cost evaluation using architecture-agnostic proxies.

        Computes expressivity, grad-saliency, sensitivity profile, collapse
        ratio, gradient coherence, state velocity, and local contrast without
        any training.
        """
        import json
        import torch
        from pathlib import Path
        from .model_base import load_candidate_model
        from .zero_cost_proxies import evaluate_candidate

        device = torch.device("cpu")
        model = load_candidate_model(
            candidate_code_path,
            device,
            model_config=self._model_config,
            input_length=input_length,
            forecast_length=forecast_length,
        )

        proxy = evaluate_candidate(
            model,
            input_length=input_length,
            forecast_length=forecast_length,
            batch_size=4,
            num_variants=7,
            device=device,
            name=os.path.basename(candidate_code_path),
        )

        # Also compute weight L2 norm for backwards compatibility
        weight_sq = sum(
            float(torch.sum(p.detach().float() ** 2).item())
            for p in model.parameters() if p.requires_grad
        )

        metrics = {
            "zero_cost": {
                "parameter_count": float(proxy.param_count),
                "weight_l2_norm": float(math.sqrt(max(weight_sq, 0.0))),
                **proxy.to_dict(),
            }
        }

        # Persist
        out_path = Path(run_dir) / "zero_cost_metrics.json"
        out_path.parent.mkdir(parents=True, exist_ok=True)
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(metrics["zero_cost"], f, indent=2, default=float)

        return metrics

    # ── Remote harness ───────────────────────────────────────────────

    def build_remote_harness(
        self,
        *,
        candidate_code: str,
        dataset_spec: Dict[str, Any],
        eval_type: str,
        primary_metrics: List[str],
    ) -> str:
        """Generate a standalone training script via the universal packager."""
        from services.packager import build_universal_harness
        return build_universal_harness(
            task_def=TASK_DEFINITION,
            candidate_code=candidate_code,
            eval_type=eval_type,
        )

    # ── Objective / constraint metadata ──────────────────────────────

    def primary_objectives(self) -> List[str]:
        return ["MASE", "CRPS"]

    def task_constraints(self) -> List[str]:
        from .model_base import DEFAULT_FORECAST_LENGTH, DEFAULT_INPUT_LENGTH
        styles = ", ".join(TASK_DEFINITION.supported_training_styles) or "teacher_forced"
        return [
            f"Input context window must be exactly {DEFAULT_INPUT_LENGTH} time steps.",
            f"Forecast horizon must cover {DEFAULT_FORECAST_LENGTH} future steps.",
            f"Total model size must not exceed {TASK_DEFINITION.max_params / 1e6:.0f} million parameters.",
            f"Model must declare a training_style class attribute (supported: {styles}).",
        ]

    # ── Environment / paths ──────────────────────────────────────────

    def set_run_environment(self, run_dir: str) -> None:
        self.run_dir = run_dir
        os.makedirs(self.run_dir, exist_ok=True)

    def get_scaffold_path(self) -> str:
        return os.path.abspath(TASK_DEFINITION.scaffold_path)

    def get_source_file_path(self, name: str) -> str:
        filename = f"{name}.py" if not name.endswith(".py") else name
        return os.path.join(self.run_dir, filename)

    def get_result_file_path(self, name: str, eval_type: str) -> str:
        return os.path.join(self.run_dir, f"{name}_{eval_type}_train.csv")

    def get_test_result_file_path(self, name: str, eval_type: str) -> str:
        return os.path.join(self.run_dir, f"{name}_{eval_type}_eval.csv")

    def get_evaluation_script(self) -> str:
        task_dir = os.path.dirname(__file__)
        return os.path.abspath(os.path.join(task_dir, "evaluate.sh"))

    def get_task_description(self) -> str:
        return TASK_DEFINITION.description

    def get_task_keywords(self) -> List[str]:
        return TASK_DEFINITION.keywords

    # ── Prompt / agent integration ───────────────────────────────────

    def planner_context(self) -> str:
        return PLANNER_CONTEXT_PROMPT

    def get_role_instruction(self, role: str) -> str:
        from .model_base import DEFAULT_FORECAST_LENGTH, DEFAULT_INPUT_LENGTH
        return build_role_instruction(
            role=role,
            model_name="TimeSeriesFoundationModel",
            input_length=DEFAULT_INPUT_LENGTH,
            forecast_length=DEFAULT_FORECAST_LENGTH,
        )

    def get_motivation_context(self) -> str:
        return MOTIVATION_CONTEXT_PROMPT

    def get_analysis_context(self, eval_type: str) -> Dict[str, str]:
        return {
            "metric_descriptions": METRIC_DESCRIPTIONS_PROMPT,
            "baseline_reference": BASELINE_REFERENCE_PROMPT,
            "performance_rubric": get_performance_rubric(eval_type),
        }

    def build_prompt_fragments(self, role: str, channel: str | None = None) -> Dict[str, str]:
        fragments = super().build_prompt_fragments(role, channel)
        role_lower = (role or "").lower()
        if role_lower in {"planner", "deduplicator", "code_checker", "stability_checker"}:
            fragments["challenge_priorities"] = PLANNER_CHALLENGE_PRIORITIES.strip()
        return fragments

    def get_code_generation_constraints(self) -> Dict[str, Any]:
        from .model_base import DEFAULT_FORECAST_LENGTH, DEFAULT_INPUT_LENGTH
        return {
            "input_length": DEFAULT_INPUT_LENGTH,
            "forecast_length": DEFAULT_FORECAST_LENGTH,
            "model_class_name": "TimeSeriesFoundationModel",
            "model_base_module": TASK_DEFINITION.model_base_module,
            "supported_training_styles": TASK_DEFINITION.supported_training_styles,
        }

    # ── Shape sanity (used by services eval) ─────────────────────────

    def load_model_for_shape_sanity(
        self, candidate_code_path: str, device: "torch.device", datasets: Dict[str, Any],
    ) -> Any:
        from .dataloader import DatasetBundle
        from .model_base import (
            DEFAULT_FORECAST_LENGTH,
            DEFAULT_INPUT_LENGTH,
            load_candidate_model,
        )

        bundle: Optional[DatasetBundle] = (
            datasets if isinstance(datasets, DatasetBundle) else self._dataset_bundle
        )
        input_length = getattr(bundle, "input_length", DEFAULT_INPUT_LENGTH)
        forecast_length = getattr(bundle, "forecast_length", DEFAULT_FORECAST_LENGTH)

        return load_candidate_model(
            candidate_code_path,
            device,
            model_config=self._model_config,
            input_length=input_length,
            forecast_length=forecast_length,
        )

    def build_shape_sanity_batch(
        self, datasets: Dict[str, Any], device: "torch.device",
    ) -> Dict[str, Any]:
        import torch
        from .dataloader import DatasetBundle
        from .model_base import DEFAULT_FORECAST_LENGTH, DEFAULT_INPUT_LENGTH

        bundle: Optional[DatasetBundle] = (
            datasets if isinstance(datasets, DatasetBundle) else self._dataset_bundle
        )
        input_length = getattr(bundle, "input_length", DEFAULT_INPUT_LENGTH)
        forecast_length = getattr(bundle, "forecast_length", DEFAULT_FORECAST_LENGTH)

        past = torch.zeros((1, int(input_length), 1), device=device)
        future = torch.zeros((1, int(forecast_length), 1), device=device)

        return {
            "past_y": past,
            "y_future_tf": future,
            "forecast_length": int(forecast_length),
            "input_length": int(input_length),
        }

    # ── Challenge metadata ───────────────────────────────────────────

    def get_challenge_categories(self) -> List[str]:
        return TS_CHALLENGE_CATEGORIES

    def get_challenge_patterns(self) -> Dict[str, Tuple[str, List[str]]]:
        return TS_CHALLENGE_PATTERNS

    def get_challenge_context_for_analyzer(self) -> str:
        return TS_ANALYZER_CHALLENGE_CONTEXT
