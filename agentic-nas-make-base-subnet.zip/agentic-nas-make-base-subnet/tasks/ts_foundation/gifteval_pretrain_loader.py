"""GiftEval Pretrain streaming dataloader.

Streams pre-windowed time-series data from flat Parquet shards stored on
S3-compatible storage (Cloudflare R2, Hippius, etc.).

The upstream ingestion pipeline (``gifteval_pretrain_ingest.py``) converts
``Salesforce/GiftEvalPretrain`` into univariate, shuffled Parquet shards::

    <prefix>/part_000000.parquet
    <prefix>/part_000001.parquet
    ...

Each row contains a **pre-windowed** target of length 1024 (stride 256)
with columns:

    item_id, start, target (list[float64]), feat_dynamic_real,
    feat_static_cat, dataset_name, domain, freq, is_multivariate

This loader sub-windows each row into ``(past_target, future_target)``
pairs matching the codebase convention expected by the universal trainer:

    {\"past_target\": [L, 1], \"future_target\": [H, 1]}

Environment variables (credentials via ``R2_*`` by default)::

    R2_ENDPOINT_URL          - S3-compatible endpoint
    R2_ACCESS_KEY_ID         - Access key
    R2_SECRET_ACCESS_KEY     - Secret key

    GIFTEVAL_PRETRAIN_BUCKET  - Bucket name (default: \"giftevalpretrain\")
    GIFTEVAL_PRETRAIN_PREFIX  - Key prefix  (default: \"gifteval_pretrain_flat_1024x256/\")
"""

from __future__ import annotations

import io
import logging
import os
import random
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass
from typing import Any, Dict, Iterator, List, Optional

import torch
from torch.utils.data import DataLoader, IterableDataset, get_worker_info

from core.data.s3_store import (
    S3ObjectStore,
    S3StoreConfig,
    build_s3_store_from_env,
)
from tasks.ts_foundation.model_base import (
    DEFAULT_FORECAST_LENGTH,
    DEFAULT_INPUT_LENGTH,
)

logger = logging.getLogger(__name__)

# ── Defaults (overridable via env) ───────────────────────────────────────

GIFTEVAL_PRETRAIN_BUCKET = os.getenv(
    "GIFTEVAL_PRETRAIN_BUCKET", "giftevalpretrain"
)
GIFTEVAL_PRETRAIN_PREFIX = os.getenv(
    "GIFTEVAL_PRETRAIN_PREFIX", "gifteval_pretrain_flat_1024x256/"
)
GIFTEVAL_PRETRAIN_ENV_PREFIX = os.getenv(
    "GIFTEVAL_PRETRAIN_ENV_PREFIX", "R2"
)

# Window length produced by the ingestion pipeline.
SHARD_WINDOW_LENGTH = 1024


# ── Configuration ────────────────────────────────────────────────────────


@dataclass
class GiftEvalPretrainConfig:
    """Configuration for the GiftEval pretrain streaming dataset.

    Args:
        bucket: S3 bucket holding the shards.
        prefix: Key prefix (must end with ``/``).
        env_prefix: Environment-variable prefix for credentials.
        endpoint_url: Explicit S3 endpoint (overrides env).
        access_key: Explicit access key (overrides env).
        secret_key: Explicit secret key (overrides env).
        region: AWS region or ``"auto"`` for R2.
        input_length: Context window passed to the model.
        forecast_length: Forecast horizon.
        seed: Base RNG seed for reproducibility.
        shuffle_rows: Shuffle rows within each shard.
        prefetch_files: Background shard prefetch count.
        parquet_batch_size: pyarrow ``iter_batches`` size.
        max_retries: S3 retry limit.
        retry_backoff_base: Backoff base in seconds.
    """

    bucket: str = GIFTEVAL_PRETRAIN_BUCKET
    prefix: str = GIFTEVAL_PRETRAIN_PREFIX
    env_prefix: str = GIFTEVAL_PRETRAIN_ENV_PREFIX

    # Explicit credentials (overrides env vars when set).
    endpoint_url: str = ""
    access_key: str = ""
    secret_key: str = ""
    region: str = "auto"

    # Windowing
    input_length: int = DEFAULT_INPUT_LENGTH
    forecast_length: int = DEFAULT_FORECAST_LENGTH

    # Performance / reproducibility
    seed: int = 42
    shuffle_rows: bool = True
    prefetch_files: int = 2
    parquet_batch_size: int = 1024

    # S3 robustness
    max_retries: int = 3
    retry_backoff_base: float = 1.0

    def build_store(self) -> S3ObjectStore:
        """Build an :class:`S3ObjectStore` from this config.

        Uses explicit credentials if ``endpoint_url`` is set, otherwise
        falls back to environment variables via ``env_prefix``.
        """
        if self.endpoint_url:
            store_cfg = S3StoreConfig(
                endpoint_url=self.endpoint_url,
                access_key=self.access_key,
                secret_key=self.secret_key,
                region=self.region,
                max_retries=self.max_retries,
                retry_backoff_base=self.retry_backoff_base,
            )
            return S3ObjectStore(store_cfg, self.bucket)
        store = build_s3_store_from_env(
            self.bucket,
            env_prefix=self.env_prefix,
            required=True,
        )
        assert store is not None  # required=True guarantees this
        return store


# ── Shard I/O helpers ────────────────────────────────────────────────────


def _list_shard_keys(store: S3ObjectStore, prefix: str) -> List[str]:
    """List all parquet shard keys under *prefix*."""
    keys = store.list_keys(prefix)
    parquet_keys = sorted(k for k in keys if k.endswith(".parquet"))
    return parquet_keys


def _read_shard(
    store: S3ObjectStore,
    key: str,
    batch_size: int,
    shuffle: bool,
    rng: random.Random,
) -> List[Dict[str, Any]]:
    """Download and parse all rows from a single Parquet shard."""
    import pyarrow.parquet as pq

    raw = store.get_bytes(key)
    buf = io.BytesIO(raw)
    pf = pq.ParquetFile(buf)

    rows: List[Dict[str, Any]] = []
    for batch in pf.iter_batches(batch_size=batch_size):
        for row in batch.to_pylist():
            rows.append(row)

    if shuffle and len(rows) > 1:
        rng.shuffle(rows)

    return rows


# ── Row conversion ───────────────────────────────────────────────────────


def _row_to_training_sample(
    row: Dict[str, Any],
    input_length: int,
    forecast_length: int,
    rng: random.Random,
) -> Optional[Dict[str, torch.Tensor]]:
    """Convert a pre-windowed row into a ``(past_target, future_target)`` sample.

    Each row's ``target`` is a list of floats with length up to
    :data:`SHARD_WINDOW_LENGTH` (1024).  A random sub-window of size
    ``input_length + forecast_length`` is extracted to produce the
    training pair.
    """
    target = row.get("target")
    if target is None:
        return None

    total_needed = input_length + forecast_length
    series_len = len(target)

    if series_len < total_needed:
        return None

    # Random start within the pre-windowed series
    max_start = series_len - total_needed
    start = rng.randint(0, max_start) if max_start > 0 else 0

    past = torch.tensor(
        target[start : start + input_length], dtype=torch.float32,
    )
    future = torch.tensor(
        target[start + input_length : start + total_needed], dtype=torch.float32,
    )

    # Sanitise NaN / inf without discarding the sample
    if not torch.isfinite(past).all() or not torch.isfinite(future).all():
        past = torch.nan_to_num(past, nan=0.0, posinf=0.0, neginf=0.0)
        future = torch.nan_to_num(future, nan=0.0, posinf=0.0, neginf=0.0)

    return {
        "past_target": past.unsqueeze(-1),      # [L, 1]
        "future_target": future.unsqueeze(-1),   # [H, 1]
    }


# ── Streaming IterableDataset ────────────────────────────────────────────


class GiftEvalPretrainDataset(IterableDataset):
    """Streaming ``IterableDataset`` for GiftEval pretrain shards on S3.

    Endlessly yields training samples by:

    1. Randomly selecting a Parquet shard.
    2. Reading and (optionally) shuffling its rows.
    3. Converting each row's pre-windowed target into
       ``(past_target, future_target)`` pairs.
    4. Prefetching the next shard(s) in a background thread pool.

    When used with ``DataLoader(num_workers>0)``, each worker gets a
    deterministic RNG seeded with ``config.seed + worker_id``.

    Args:
        config: Dataset configuration.
    """

    def __init__(self, config: GiftEvalPretrainConfig) -> None:
        self.config = config
        self._store: Optional[S3ObjectStore] = None
        self._shard_keys: Optional[List[str]] = None

    def _ensure_store(self) -> S3ObjectStore:
        if self._store is None:
            self._store = self.config.build_store()
        return self._store

    def _ensure_shard_keys(self, store: S3ObjectStore) -> List[str]:
        if self._shard_keys is None:
            self._shard_keys = _list_shard_keys(store, self.config.prefix)
            if not self._shard_keys:
                raise RuntimeError(
                    f"No parquet shards found under "
                    f"s3://{self.config.bucket}/{self.config.prefix}"
                )
            logger.info(
                "GiftEvalPretrain: found %d shards under %s",
                len(self._shard_keys),
                self.config.prefix,
            )
        return self._shard_keys

    def __iter__(self) -> Iterator[Dict[str, torch.Tensor]]:
        store = self._ensure_store()
        shard_keys = self._ensure_shard_keys(store)

        # Deterministic RNG per worker
        worker_info = get_worker_info()
        worker_id = worker_info.id if worker_info is not None else 0
        rng = random.Random(self.config.seed + worker_id)

        prefetch_n = max(1, self.config.prefetch_files)
        executor = ThreadPoolExecutor(max_workers=prefetch_n)

        try:
            yield from self._stream_loop(
                store, shard_keys, rng, executor, prefetch_n,
            )
        finally:
            executor.shutdown(wait=False)

    def _stream_loop(
        self,
        store: S3ObjectStore,
        shard_keys: List[str],
        rng: random.Random,
        executor: ThreadPoolExecutor,
        prefetch_n: int,
    ) -> Iterator[Dict[str, torch.Tensor]]:
        """Core streaming loop with prefetch and error resilience.

        Stops after 50 consecutive shard-read failures.
        """
        max_consecutive_errors = 50
        input_length = self.config.input_length
        forecast_length = self.config.forecast_length

        def _submit_read():
            key = rng.choice(shard_keys)
            return executor.submit(
                _read_shard,
                store,
                key,
                self.config.parquet_batch_size,
                self.config.shuffle_rows,
                rng,
            )

        # Initial prefetch
        futures = [_submit_read() for _ in range(prefetch_n)]

        consecutive_errors = 0
        while futures:
            done_fut = futures.pop(0)
            try:
                rows = done_fut.result()
            except Exception as exc:
                consecutive_errors += 1
                logger.warning("GiftEvalPretrain shard read failed: %s", exc)
                if consecutive_errors >= max_consecutive_errors:
                    logger.error(
                        "Stopping after %d consecutive shard errors",
                        consecutive_errors,
                    )
                    return
                futures.append(_submit_read())
                continue

            consecutive_errors = 0

            for row in rows:
                sample = _row_to_training_sample(
                    row, input_length, forecast_length, rng,
                )
                if sample is not None:
                    yield sample

            # Submit next shard
            futures.append(_submit_read())


# ── DataLoader builder ───────────────────────────────────────────────────


def build_gifteval_pretrain_dataloaders(
    *,
    input_length: int = DEFAULT_INPUT_LENGTH,
    forecast_length: int = DEFAULT_FORECAST_LENGTH,
    batch_size: int = 32,
    seed: int = 42,
    num_workers: int = 0,
    bucket: str = GIFTEVAL_PRETRAIN_BUCKET,
    prefix: str = GIFTEVAL_PRETRAIN_PREFIX,
    env_prefix: str = GIFTEVAL_PRETRAIN_ENV_PREFIX,
    endpoint_url: str = "",
    access_key: str = "",
    secret_key: str = "",
) -> "DatasetBundle":
    """Build train and validation ``DataLoader`` instances for GiftEval
    pretrain data.

    Both loaders stream from the same shard pool but use different RNG
    seeds so they draw different sub-windows.  The validation loader is
    bounded by the trainer's ``max_val_batches`` parameter.

    Args:
        input_length: Model input (context) length.
        forecast_length: Forecast horizon.
        batch_size: Batch size for both loaders.
        seed: Base RNG seed.
        num_workers: DataLoader workers.
        bucket: S3 bucket name.
        prefix: Key prefix for the shard files.
        env_prefix: Environment variable prefix for S3 credentials.
        endpoint_url: Explicit S3 endpoint (optional).
        access_key: Explicit access key (optional).
        secret_key: Explicit secret key (optional).

    Returns:
        :class:`~tasks.ts_foundation.dataloader.DatasetBundle` with
        ``train``, ``val``, ``test`` loaders plus metadata.
    """
    from tasks.ts_foundation.dataloader import DatasetBundle, ForecastingMode

    cred_kwargs = dict(
        bucket=bucket,
        prefix=prefix,
        env_prefix=env_prefix,
        endpoint_url=endpoint_url,
        access_key=access_key,
        secret_key=secret_key,
        input_length=input_length,
        forecast_length=forecast_length,
    )

    # Train dataset
    train_config = GiftEvalPretrainConfig(
        seed=seed,
        shuffle_rows=True,
        **cred_kwargs,
    )
    train_ds = GiftEvalPretrainDataset(train_config)
    train_loader = DataLoader(
        train_ds,
        batch_size=batch_size,
        shuffle=False,  # IterableDataset handles its own randomisation
        drop_last=False,
        num_workers=num_workers,
    )

    # Validation dataset (different seed → different sub-windows)
    val_config = GiftEvalPretrainConfig(
        seed=seed + 10_000,
        shuffle_rows=False,
        **cred_kwargs,
    )
    val_ds = GiftEvalPretrainDataset(val_config)
    val_loader = DataLoader(
        val_ds,
        batch_size=batch_size,
        shuffle=False,
        drop_last=False,
        num_workers=num_workers,
    )

    return DatasetBundle(
        train=train_loader,
        val=val_loader,
        test=val_loader,  # reuse val in pretrain setting
        mase_scale=1.0,
        input_length=input_length,
        forecast_length=forecast_length,
        forecasting_mode=ForecastingMode.NONAUTOREGRESSIVE,
        dataset_path=f"s3://{bucket}/{prefix}",
    )


__all__ = [
    "GiftEvalPretrainConfig",
    "GiftEvalPretrainDataset",
    "build_gifteval_pretrain_dataloaders",
    "GIFTEVAL_PRETRAIN_BUCKET",
    "GIFTEVAL_PRETRAIN_PREFIX",
    "SHARD_WINDOW_LENGTH",
]
