"""Signal-aware zero-cost proxies for architecture screening.

Adapted from AZ-NAS-style proxy scoring for diverse time-series
architectures.  All proxies are architecture-agnostic and operate on
the ``TimeSeriesFoundationModel`` forward interface.

**Core proxies:**

1. **Expressivity** -- effective rank of the deepest *internal*
   representation obtained via forward hooks (higher = better feature
   diversity).
2. **Grad-Saliency** -- data-dependent ``sum(|theta * grad|) / n_params``
   (higher = more active parameter utilisation).  *Not* canonical SynFlow
   which uses data-free ones-input + absolute weights.
3. **Sensitivity Profile** -- VJP-based log-norm measured across the
   last *K* output timesteps (median), targeting log-norm ~ 0 (closer
   to 0 = better gradient flow across the full temporal horizon).
4. **Deep Collapse Ratio** -- ``eff_rank(deep_hook) / eff_rank(input)``.
   Uses a forward hook on the deepest block rather than the projected
   output head.  Penalises distance from 1.0 (collapse <1, fracture >1).
5. **Gradient Coherence** -- per-sample gradient alignment ratio
   (higher = stronger generalisation signal).
6. **State Velocity** -- max rate of output change in response to a
   *step-function* probe input (higher = faster reaction to regime
   shifts).
7. **Local Contrast** -- peak-to-neighbour signal ratio in response to
   an *impulse* probe input (higher = better local anomaly preservation).

**UCB probe variants (7 total):**

0. Identity (structured random walk)
1. Additive Gaussian jitter
2. Feature dropout
3. Mild per-sample scale
4. Small time shift (roll)
5. Step function -- regime shift at midpoint
6. Impulse -- single spike at midpoint

**Ranking:**

Borda count (rank-sum) across all proxies.  Lower total = better
architecture.  Used by the validator's Phase 2 filtering to rank
candidates *relative* to each other without any training.

Measurements that fall back to the output head (no deep hook found)
are penalised via a reliability multiplier.

References:
    - AZ-NAS (ICLR 2024): architecture-agnostic zero-cost proxies
    - SynFlow (ICML 2020): pruning-at-init (canonical form uses ones input)
"""

from __future__ import annotations

import math
import logging
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

import numpy as np
import torch
import torch.nn as nn

logger = logging.getLogger(__name__)

# Maximum complexity boost factor for distance-metric handicapping.
# Caps how much a larger model's penalties can be reduced.
_MAX_BOOST = 2.0


# ── Dataclass for per-candidate proxy results ────────────────────────


@dataclass
class ProxyResult:
    """Raw proxy metrics for a single candidate model."""

    name: str = ""
    status: str = "PASS"  # PASS | FAIL | SKIP_NO_GRAD
    error: str = ""

    # Core proxies
    eff_rank: float = 0.0
    deep_collapse_ratio: float = 0.0
    saliency_per_param: float = 0.0
    sensitivity_log_norm: float = 0.0
    grad_coherence: float = 0.0
    state_velocity: float = 0.0
    local_contrast: float = 0.0

    # Measurement reliability
    deep_rep_source: str = "none"  # "hook" | "output_fallback" | "none"
    sensitivity_ok_rate: float = 0.0  # fraction of variants with valid VJP

    # Metadata
    param_count: int = 0
    trainable_params: int = 0
    seconds: float = 0.0

    def to_dict(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "status": self.status,
            "error": self.error,
            "eff_rank": self.eff_rank,
            "deep_collapse_ratio": self.deep_collapse_ratio,
            "saliency_per_param": self.saliency_per_param,
            "sensitivity_log_norm": self.sensitivity_log_norm,
            "grad_coherence": self.grad_coherence,
            "state_velocity": self.state_velocity,
            "local_contrast": self.local_contrast,
            "deep_rep_source": self.deep_rep_source,
            "sensitivity_ok_rate": self.sensitivity_ok_rate,
            "param_count": self.param_count,
            "trainable_params": self.trainable_params,
            "seconds": self.seconds,
        }


# ── Universal Calibration Batch (UCB) ────────────────────────────────


def make_ucb_variants(
    past_y: torch.Tensor,
    num_variants: int = 7,
    jitter_std: float = 0.01,
    dropout_p: float = 0.05,
    seed: int = 123,
) -> List[Tuple[torch.Tensor, str]]:
    """Create calibration-batch variants from a structured base input.

    Returns up to ``num_variants`` (input, tag) pairs.  The tag
    identifies the probe type for targeted metric computation.

    Variants:
        0 – identity (original input)
        1 – additive Gaussian jitter
        2 – feature dropout (same mask across time)
        3 – mild per-sample scale perturbation
        4 – small time-shift (roll)
        5 – step function (regime shift at midpoint)
        6 – impulse (single spike at midpoint)
    """
    torch.manual_seed(seed)
    if past_y.is_cuda:
        torch.cuda.manual_seed_all(seed)

    B, T, C = past_y.shape
    dev, dtype = past_y.device, past_y.dtype
    variants: List[Tuple[torch.Tensor, str]] = []

    # 0: identity
    variants.append((past_y, "identity"))

    # 1: jitter
    noise = torch.randn(past_y.shape, device=dev, dtype=dtype) * jitter_std
    variants.append((past_y + noise, "jitter"))

    # 2: feature dropout (same mask across time)
    mask = (torch.rand((B, 1, C), device=dev, dtype=dtype) > dropout_p).to(dtype)
    variants.append((past_y * mask, "dropout"))

    # 3: mild per-sample scale
    scale = (1.0 + 0.05 * torch.randn((B, 1, 1), device=dev, dtype=dtype)).clamp(0.8, 1.2)
    variants.append((past_y * scale, "scale"))

    # 4: small time shift
    shift = max(1, T // 32)
    variants.append((torch.roll(past_y, shifts=shift, dims=1), "roll"))

    # 5: step function -- zeros then +1 at midpoint
    mid = T // 2
    step = torch.zeros_like(past_y)
    step[:, mid:, :] = 1.0
    variants.append((step, "step"))

    # 6: impulse -- single spike at midpoint
    impulse = torch.zeros_like(past_y)
    impulse[:, mid, :] = 3.0  # 3-sigma spike
    variants.append((impulse, "impulse"))

    return variants[:max(1, num_variants)]


def build_calibration_input(
    batch_size: int = 4,
    input_length: int = 512,
    channels: int = 1,
    forecast_length: int = 256,
    device: Optional[torch.device] = None,
) -> Dict[str, Any]:
    """Build a structured random-walk calibration batch.

    Returns a dict matching the ``TimeSeriesFoundationModel.forward``
    signature: ``past_y``, ``y_future_tf``, ``forecast_length``,
    ``input_length``.
    """
    if device is None:
        device = torch.device("cpu")

    total = input_length + forecast_length
    raw = torch.cumsum(
        torch.randn(batch_size, total, channels, device=device), dim=1,
    )
    mean = raw.mean(dim=1, keepdim=True)
    std = raw.std(dim=1, keepdim=True).clamp(min=1e-6)
    normed = (raw - mean) / std

    past_y = normed[:, :input_length, :].clone()
    y_future_tf = normed[:, input_length:, :].clone()

    return {
        "past_y": past_y,
        "y_future_tf": y_future_tf,
        "forecast_length": forecast_length,
        "input_length": input_length,
    }


# ── Tensor extraction helpers ─────────────────────────────────────────


def _extract_tensor(obj: Any) -> Optional[torch.Tensor]:
    """Extract the primary output tensor from model output (dict, tuple, etc.)."""
    if isinstance(obj, torch.Tensor):
        return obj
    if isinstance(obj, dict):
        for key in ("quantiles", "logits", "prediction", "pred", "output"):
            if key in obj and isinstance(obj[key], torch.Tensor):
                return obj[key]
        for v in obj.values():
            if isinstance(v, torch.Tensor):
                return v
    if isinstance(obj, (list, tuple)):
        for x in obj:
            if isinstance(x, torch.Tensor):
                return x
    return None


# ── Deep representation extraction via hooks ──────────────────────────


def _find_deepest_block(model: nn.Module) -> Optional[nn.Module]:
    """Find the deepest 'block-like' module for hooking.

    Walks the module tree and returns the last module that is either:
    - An element of a Sequential / ModuleList (i.e. a repeated block)
    - A TransformerEncoderLayer / TransformerDecoderLayer
    - An LSTM / GRU cell

    Returns None if no suitable target is found (caller should fall
    back to output-head measurement).
    """
    best: Optional[nn.Module] = None

    block_types = (
        nn.TransformerEncoderLayer,
        nn.TransformerDecoderLayer,
        nn.LSTM,
        nn.GRU,
    )

    for m in model.modules():
        if isinstance(m, block_types):
            best = m
        elif isinstance(m, (nn.Sequential, nn.ModuleList)):
            children = list(m.children())
            if len(children) >= 2:
                best = children[-1]

    return best


class _HookCapture:
    """Captures the output of a hooked module."""

    def __init__(self) -> None:
        self.output: Optional[torch.Tensor] = None

    def __call__(self, module: nn.Module, inp: Any, out: Any) -> None:
        t = out
        if isinstance(t, tuple):
            t = t[0]
        if isinstance(t, torch.Tensor):
            self.output = t.detach()


# ── Effective rank ────────────────────────────────────────────────────


def _flatten_features(feat: torch.Tensor) -> torch.Tensor:
    """Reshape arbitrary tensor to [C, N] for SVD-based effective rank."""
    if feat.ndim == 3:  # [B, T, D] -> [D, B*T]
        B, T, D = feat.shape
        return feat.permute(2, 0, 1).reshape(D, B * T)
    if feat.ndim == 2:  # [B, D] -> [D, B]
        return feat.t()
    if feat.ndim == 4:  # [B, C, H, W] -> [C, B*H*W]
        B, C, H, W = feat.shape
        return feat.permute(1, 0, 2, 3).reshape(C, B * H * W)
    C = feat.shape[-1]
    return feat.reshape(-1, C).t()


def effective_rank(x: torch.Tensor, eps: float = 1e-12) -> float:
    """Effective rank = exp(H(p)) where p are normalised singular values.

    Measures information content / feature diversity of a representation.
    """
    try:
        X = _flatten_features(x.detach()).float()
        C, N = X.shape
        if N <= 1 or C <= 1:
            return 1.0
        X = X - X.mean(dim=1, keepdim=True)
        s = torch.linalg.svdvals(X)
        p = (s + eps) / (s.sum() + eps)
        H = -(p * torch.log(p + eps)).sum()
        r = torch.exp(H).item()
        return float(r) if np.isfinite(r) else 1.0
    except Exception:
        return 1.0


# ── Grad-saliency (NOT canonical SynFlow) ─────────────────────────────


def compute_saliency(
    model: nn.Module,
    batch: Dict[str, Any],
    device: torch.device,
) -> float:
    """Data-dependent gradient saliency per trainable parameter.

    Computes ``sum(|theta * grad_theta|) / n_params`` using the actual
    calibration input (not ones-input as in canonical SynFlow).

    This measures how well signal propagates through the network given
    structured input.  Higher values indicate more active parameters.
    """
    try:
        model.zero_grad(set_to_none=True)
        out = model(**{
            k: v.to(device) if isinstance(v, torch.Tensor) else v
            for k, v in batch.items()
        })
        t = _extract_tensor(out)
        if t is None:
            return 0.0
        loss = t.sum()
        loss.backward()

        total = 0.0
        denom = 0
        for p in model.parameters():
            if p.requires_grad:
                denom += p.numel()
                if p.grad is not None:
                    total += (p * p.grad).abs().sum().item()

        model.zero_grad(set_to_none=True)
        return float(total / max(denom, 1))
    except Exception:
        try:
            model.zero_grad(set_to_none=True)
        except Exception:
            pass
        return 0.0


# ── Sensitivity profile (VJP across last K timesteps) ────────────────


def compute_sensitivity(
    model: nn.Module,
    batch: Dict[str, Any],
    device: torch.device,
    log_band: float = 8.0,
    last_k: int = 8,
) -> Tuple[float, bool]:
    """Input sensitivity via VJP profiled across the last K output timesteps.

    For each of the last ``last_k`` output steps, computes
    log‖∂y_t/∂x‖ and returns the median.  This captures gradient
    health across the temporal horizon rather than relying on a single
    final-step measurement.

    Returns (median_log_norm, valid).
    """
    try:
        past_y = batch["past_y"].to(device).detach().requires_grad_(True)
        batch_copy = {
            k: (v.to(device) if isinstance(v, torch.Tensor) else v)
            for k, v in batch.items()
        }
        batch_copy["past_y"] = past_y

        out = model(**batch_copy)
        y = _extract_tensor(out)
        if y is None:
            return 0.0, False

        if y.ndim < 3:
            # Can't profile across timesteps
            yT = y
            v = (torch.randint(0, 2, yT.shape, device=device, dtype=torch.int32) * 2 - 1).float()
            scalar = (yT.float() * v).sum()
            (g,) = torch.autograd.grad(scalar, past_y, retain_graph=False, allow_unused=False)
            if g is None:
                return 0.0, False
            norm = g.float().norm().item()
            if not np.isfinite(norm) or norm <= 0:
                return 0.0, False
            logn = float(math.log(norm + 1e-12))
            return logn, abs(logn) <= log_band

        # Profile across last K output timesteps
        T_out = y.shape[1]
        K = min(last_k, T_out)
        step_indices = list(range(max(0, T_out - K), T_out))

        log_norms: List[float] = []
        for t_idx in step_indices:
            try:
                yT = y[:, t_idx, ...]
                v = (torch.randint(0, 2, yT.shape, device=device, dtype=torch.int32) * 2 - 1).float()
                scalar = (yT.float() * v).sum()
                (g,) = torch.autograd.grad(
                    scalar, past_y, retain_graph=True, allow_unused=False,
                )
                if g is None:
                    continue
                norm = g.float().norm().item()
                if np.isfinite(norm) and norm > 0:
                    log_norms.append(float(math.log(norm + 1e-12)))
            except Exception:
                continue

        if not log_norms:
            return 0.0, False

        med = float(np.median(log_norms))
        return med, abs(med) <= log_band
    except Exception:
        return 0.0, False


# ── Gradient coherence ────────────────────────────────────────────────


def compute_gradient_coherence(
    model: nn.Module,
    batch: Dict[str, Any],
    device: torch.device,
    max_samples: int = 4,
) -> float:
    """Gradient alignment ratio: norm(sum(g_i)) / sum(norm(g_i)).

    Measures how much per-sample gradients agree on an update direction.
    Range [0, 1].  Higher = better generalisation signal.
    """
    try:
        was_training = model.training
        model.train()

        past_y = batch["past_y"].to(device)
        B = past_y.shape[0]
        subset = min(B, max_samples)

        grads: List[torch.Tensor] = []
        for i in range(subset):
            model.zero_grad(set_to_none=True)
            sample_batch = {
                k: (v[i : i + 1].to(device) if isinstance(v, torch.Tensor) and v.ndim > 0 else v)
                for k, v in batch.items()
            }
            out = model(**sample_batch)
            t = _extract_tensor(out)
            if t is None:
                continue
            t.sum().backward()

            g_vec = []
            for p in model.parameters():
                if p.grad is not None:
                    g_vec.append(p.grad.reshape(-1))
            if g_vec:
                grads.append(torch.cat(g_vec))

        model.train(was_training)
        model.zero_grad(set_to_none=True)

        if not grads:
            return 0.0

        G = torch.stack(grads)
        sum_of_norms = torch.norm(G, dim=1).sum()
        norm_of_sum = torch.norm(G.sum(dim=0))

        if sum_of_norms < 1e-9:
            return 0.0
        return float((norm_of_sum / sum_of_norms).item())
    except Exception:
        return 0.0


# ── State velocity (transient agility on step input) ──────────────────


def compute_state_velocity(output_tensor: torch.Tensor) -> float:
    """Max rate of output change along time.

    Meaningful when run on the *step-function* probe: measures how
    quickly the model reacts to a regime shift.
    High = good transient response; Low = over-smoothing.
    """
    try:
        if output_tensor.ndim != 3:
            return 0.0
        diff = output_tensor[:, 1:, :] - output_tensor[:, :-1, :]
        velocity = torch.norm(diff, dim=2)
        return float(velocity.max(dim=1)[0].median().item())
    except Exception:
        return 0.0


# ── Local contrast (impulse preservation on impulse input) ────────────


def compute_local_contrast(output_tensor: torch.Tensor) -> float:
    """Peak-to-neighbour signal ratio.

    Meaningful when run on the *impulse* probe: measures how well the
    model preserves a local anomaly / spike.
    High = sharp; Low = blurry.
    """
    try:
        if output_tensor.ndim != 3:
            return 0.0
        signal = torch.norm(output_tensor, dim=2) + 1e-9
        center = signal[:, 1:-1]
        neighbours = 0.5 * (signal[:, :-2] + signal[:, 2:])
        contrast = center / neighbours
        return float(contrast.max(dim=1)[0].median().item())
    except Exception:
        return 0.0


# ── Single-model evaluation ──────────────────────────────────────────


def evaluate_candidate(
    model: nn.Module,
    *,
    input_length: int = 512,
    forecast_length: int = 256,
    batch_size: int = 4,
    num_variants: int = 7,
    device: Optional[torch.device] = None,
    name: str = "",
) -> ProxyResult:
    """Run all signal-aware proxies on a single candidate model.

    Returns a ``ProxyResult`` with raw metric values (not ranked).
    Ranking happens in :func:`borda_rank` when comparing multiple
    candidates.

    Args:
        model: Loaded ``TimeSeriesFoundationModel`` (already on device).
        input_length: Past context window length.
        forecast_length: Forecast horizon length.
        batch_size: UCB batch size (small is fine; 4 is default).
        num_variants: Number of UCB probe variants (max 7).
        device: Evaluation device (defaults to model's device).
        name: Human-readable candidate name for logging.
    """
    import time as _time

    if device is None:
        device = next(model.parameters()).device

    t0 = _time.time()
    result = ProxyResult(name=name)

    # Parameter counts
    result.param_count = sum(p.numel() for p in model.parameters())
    result.trainable_params = sum(
        p.numel() for p in model.parameters() if p.requires_grad
    )
    if result.trainable_params == 0:
        result.status = "SKIP_NO_GRAD"
        result.seconds = _time.time() - t0
        return result

    # Build calibration input
    cal = build_calibration_input(
        batch_size=batch_size,
        input_length=input_length,
        channels=1,
        forecast_length=forecast_length,
        device=device,
    )

    # Generate UCB variants (tagged)
    ucb_list = make_ucb_variants(
        cal["past_y"], num_variants=num_variants, seed=123,
    )

    # Set up deep-representation hook
    deep_target = _find_deepest_block(model)
    hook_capture = _HookCapture()
    hook_handle = None
    if deep_target is not None:
        hook_handle = deep_target.register_forward_hook(hook_capture)
        result.deep_rep_source = "hook"
    else:
        result.deep_rep_source = "output_fallback"

    # Accumulators
    eff_ranks: List[float] = []
    collapse_ratios: List[float] = []
    saliencies: List[float] = []
    sens_logs: List[float] = []
    sens_oks: List[bool] = []
    coherences: List[float] = []
    step_velocities: List[float] = []
    impulse_contrasts: List[float] = []

    try:
        model.train()

        for variant, tag in ucb_list:
            var_batch = {
                "past_y": variant,
                "y_future_tf": cal["y_future_tf"],
                "forecast_length": cal["forecast_length"],
                "input_length": cal["input_length"],
            }

            # (A) Input effective rank baseline
            input_rank = max(effective_rank(variant), 1e-6)

            # (B) Forward pass + deep rep extraction
            hook_capture.output = None
            try:
                with torch.no_grad():
                    out = model(**{
                        k: v.to(device) if isinstance(v, torch.Tensor) else v
                        for k, v in var_batch.items()
                    })
                out_tensor = _extract_tensor(out)
            except Exception:
                out_tensor = None

            # Deep rep: prefer hooked output, fall back to output head
            deep_rep = hook_capture.output if hook_capture.output is not None else out_tensor

            if deep_rep is not None:
                r_out = effective_rank(deep_rep)
                eff_ranks.append(r_out)
                collapse_ratios.append(r_out / input_rank)
            else:
                eff_ranks.append(0.0)
                collapse_ratios.append(0.0)

            # (C) Step velocity -- only on step probe
            if tag == "step" and out_tensor is not None:
                step_velocities.append(compute_state_velocity(out_tensor))

            # (D) Impulse contrast -- only on impulse probe
            if tag == "impulse" and out_tensor is not None:
                impulse_contrasts.append(compute_local_contrast(out_tensor))

            # (E) Grad-saliency
            saliencies.append(compute_saliency(model, var_batch, device))

            # (F) Gradient coherence
            coherences.append(
                compute_gradient_coherence(model, var_batch, device)
            )

            # (G) Sensitivity profile
            logn, ok = compute_sensitivity(model, var_batch, device)
            sens_logs.append(logn)
            sens_oks.append(ok)

        # Aggregate medians
        result.eff_rank = float(np.median(eff_ranks)) if eff_ranks else 0.0
        result.deep_collapse_ratio = float(np.median(collapse_ratios)) if collapse_ratios else 0.0
        result.saliency_per_param = float(np.median(saliencies)) if saliencies else 0.0
        result.sensitivity_log_norm = float(np.median(sens_logs)) if sens_logs else 0.0
        result.sensitivity_ok_rate = float(np.mean(sens_oks)) if sens_oks else 0.0
        result.grad_coherence = float(np.median(coherences)) if coherences else 0.0
        result.state_velocity = float(np.median(step_velocities)) if step_velocities else 0.0
        result.local_contrast = float(np.median(impulse_contrasts)) if impulse_contrasts else 0.0
        result.status = "PASS"

    except Exception as exc:
        result.status = "FAIL"
        result.error = str(exc)
        logger.warning("Proxy eval failed for %s: %s", name, exc)
    finally:
        if hook_handle is not None:
            hook_handle.remove()

    result.seconds = _time.time() - t0
    return result


# ── Borda rank scoring ───────────────────────────────────────────────


def borda_rank(results: List[ProxyResult]) -> List[Tuple[ProxyResult, float]]:
    """Compute Borda-count (rank-sum) scores across candidates.

    Only candidates with ``status == "PASS"`` are ranked.  The returned
    list is sorted ascending by score (lower = better architecture).

    The score is the sum of per-metric ranks (1-indexed):

    - Expressivity (eff_rank): higher is better
    - Grad-Saliency (saliency_per_param): higher is better
    - Gradient Coherence: higher is better
    - State Velocity: higher is better
    - Local Contrast: higher is better
    - Deep Collapse Ratio: |ratio - 1| closer to 0 is better
      (boosted by capped complexity factor)
    - Sensitivity: |log_norm - 0| closer to 0 is better
      (boosted by capped complexity factor)

    Candidates whose ``deep_rep_source == "output_fallback"`` receive
    a reliability penalty on their expressivity and collapse ranks.

    Returns:
        List of (ProxyResult, borda_score) sorted ascending by score.
    """
    passing = [r for r in results if r.status == "PASS"]
    if not passing:
        return [(r, float("inf")) for r in results]

    n = len(passing)

    # Extract arrays
    eff_ranks = np.array([r.eff_rank for r in passing])
    saliencies = np.array([r.saliency_per_param for r in passing])
    coherences = np.array([r.grad_coherence for r in passing])
    velocities = np.array([r.state_velocity for r in passing])
    contrasts = np.array([r.local_contrast for r in passing])
    collapse_dists = np.abs(np.array([r.deep_collapse_ratio for r in passing]) - 1.0)
    sens_dists = np.abs(np.array([r.sensitivity_log_norm for r in passing]))

    # Capped complexity boost for distance metrics
    params = np.array([r.trainable_params for r in passing], dtype=np.float64)
    complexity = np.log10(params + 100.0)
    min_complexity = complexity.min() if len(complexity) > 0 else 1.0
    boost = np.clip(complexity / max(min_complexity, 1e-6), 1.0, _MAX_BOOST)
    adj_collapse = collapse_dists / boost
    adj_sens = sens_dists / boost

    def _rank_asc(arr: np.ndarray) -> np.ndarray:
        """Rank ascending (1 = smallest value = best for distance metrics)."""
        temp = arr.argsort().argsort() + 1
        return temp.astype(float)

    def _rank_desc(arr: np.ndarray) -> np.ndarray:
        """Rank descending (1 = largest value = best for 'higher is better')."""
        return _rank_asc(-arr)

    # Higher is better
    rE = _rank_desc(eff_ranks)
    rS = _rank_desc(saliencies)
    rG = _rank_desc(coherences)
    rV = _rank_desc(velocities)
    rL = _rank_desc(contrasts)

    # Lower distance is better
    rC = _rank_asc(adj_collapse)
    rI = _rank_asc(adj_sens)

    scores = rE + rS + rG + rV + rL + rC + rI

    # Reliability penalty: candidates that fell back to output head
    # for deep rep get a penalty on their expressivity + collapse ranks.
    # This pushes them toward the bottom without completely discarding them.
    for i, r in enumerate(passing):
        penalty = 0.0
        if r.deep_rep_source == "output_fallback":
            # Half-rank penalty on the two affected metrics
            penalty += n * 0.5
        if r.sensitivity_ok_rate < 0.5:
            # Low VJP success rate degrades sensitivity rank
            penalty += n * 0.25
        scores[i] += penalty

    # Build (result, score) pairs sorted by score
    ranked = sorted(zip(passing, scores.tolist()), key=lambda x: x[1])
    return ranked


def normalise_borda_scores(
    ranked: List[Tuple[ProxyResult, float]],
) -> List[Tuple[ProxyResult, float]]:
    """Map raw Borda rank-sums to [0, 1] scores (1 = best).

    The best candidate (lowest rank-sum) gets score 1.0, the worst
    gets a score approaching 0.  This makes the output compatible
    with the validator's filtering sort (higher = better).
    """
    if not ranked:
        return []
    if len(ranked) == 1:
        return [(ranked[0][0], 1.0)]

    raw_scores = [s for _, s in ranked]
    worst = max(raw_scores)
    best = min(raw_scores)
    span = worst - best

    # Guard against non-finite scores (e.g. all-failed rankings return inf)
    # and degenerate spans (all candidates tied).
    if not (np.isfinite(span) and span > 1e-9):
        return [(r, 0.0 if not np.isfinite(s) else 1.0) for r, s in ranked]

    return [(r, 1.0 - (s - best) / span) for r, s in ranked]
