#!/bin/bash
set -euo pipefail

EXPERIMENT_NAME=$1
EVAL_TYPE=$2
RUN_DIR=${3:-"$(pwd)/runs/${EXPERIMENT_NAME}"}
CODE_PATH=${4:-"${RUN_DIR}/TimeSeriesFoundationTask.py"}

PYTHON_BIN=${PYTHON:-python}

echo "Running TIME-SERIES evaluation for: ${EXPERIMENT_NAME}"
echo "Strategy: ${EVAL_TYPE}"
echo "Run directory: ${RUN_DIR}"
echo "Candidate file: ${CODE_PATH}"

case "${EVAL_TYPE}" in
  zero_cost)
    CODE_PATH_ARG="${CODE_PATH}" RUN_DIR_ARG="${RUN_DIR}" "${PYTHON_BIN}" - <<'PY'
import json
import os
from tasks.ts_foundation.task import TimeSeriesFoundationTask

task = TimeSeriesFoundationTask()
task.set_run_environment(os.environ["RUN_DIR_ARG"])
metrics = task.train_and_eval(os.environ["CODE_PATH_ARG"], {}, os.environ["RUN_DIR_ARG"], "zero_cost")
print(json.dumps(metrics, indent=2))
PY
    ;;
  small_budget|large_budget)
    CODE_PATH_ARG="${CODE_PATH}" RUN_DIR_ARG="${RUN_DIR}" EVAL_TYPE_ARG="${EVAL_TYPE}" "${PYTHON_BIN}" - <<'PY'
import json
import os
from tasks.ts_foundation.task import TimeSeriesFoundationTask

task = TimeSeriesFoundationTask()
task.set_run_environment(os.environ["RUN_DIR_ARG"])
metrics = task.train_and_eval(os.environ["CODE_PATH_ARG"], {}, os.environ["RUN_DIR_ARG"], os.environ["EVAL_TYPE_ARG"])
print(json.dumps(metrics, indent=2, default=float))
PY
    ;;
  *)
    echo "Error: Unknown eval type '${EVAL_TYPE}'" >&2
    exit 1
    ;;
esac
