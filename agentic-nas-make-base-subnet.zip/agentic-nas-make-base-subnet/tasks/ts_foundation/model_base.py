"""Canonical base contract for time-series foundation models.

This module is the authoritative source for:
- ``TimeSeriesFoundationModel`` – the abstract base class all candidates subclass.
- ``validate_time_series_model`` – FX-based shape validation.
- ``load_candidate_model`` – load, validate, and return a candidate model.

Scoring / metric logic lives in ``tasks.ts_foundation.metrics``.
"""

from __future__ import annotations

import importlib.util
import json
from abc import ABC, abstractmethod
from enum import Enum
from typing import Any, Dict, Optional

import torch
import torch.nn as nn
from torch.fx.experimental.proxy_tensor import make_fx
from torch.fx.passes.shape_prop import ShapeProp

__all__ = [
    "TrainingStyle",
    "TimeSeriesFoundationModel",
    "validate_time_series_model",
    "load_candidate_model",
    "DEFAULT_INPUT_LENGTH",
    "DEFAULT_FORECAST_LENGTH",
]

# ── Task constants ────────────────────────────────────────────────────

DEFAULT_INPUT_LENGTH = 512
DEFAULT_FORECAST_LENGTH = 256
SEASONALITY = 24


class TrainingStyle(str, Enum):
    """Declares how a model should be trained.

    Models set ``training_style`` as a class attribute so the training
    pipeline can adapt its behaviour automatically.

    ``TEACHER_FORCED``
        The trainer passes ground-truth future targets as
        ``y_future_tf`` during training.  Suitable for encoder-decoder
        architectures that attend to future context during the forward
        pass (e.g. causal-decoder with teacher forcing, sequence-to-
        sequence models).

    ``DIRECT``
        The trainer does **not** pass ``y_future_tf``.  The model
        predicts all ``H`` future steps in a single shot from the
        history alone.  Suitable for encoder-only, MLP, convolutional,
        state-space, and other non-decoder architectures that do not
        benefit from teacher forcing.
    """

    TEACHER_FORCED = "teacher_forced"
    DIRECT = "direct"


class TimeSeriesFoundationModel(nn.Module, ABC):
    """Abstract interface all candidate models must implement.

    Subclasses **may** set the class attribute ``training_style`` to
    declare how the universal trainer should call ``forward()`` during
    training.  The default is ``TrainingStyle.TEACHER_FORCED``.
    """

    training_style: TrainingStyle = TrainingStyle.TEACHER_FORCED

    def __init__(self) -> None:
        super().__init__()

    @abstractmethod
    def forward(
        self,
        past_y: torch.Tensor,
        past_cov: Optional[torch.Tensor] = None,
        future_cov: Optional[torch.Tensor] = None,
        static: Optional[torch.Tensor] = None,
        y_future_tf: Optional[torch.Tensor] = None,
        *,
        forecast_length: Optional[int] = None,
        input_length: Optional[int] = None,
    ) -> Dict[str, torch.Tensor]:
        """
        Forward pass (training mode).

        When ``training_style`` is ``TEACHER_FORCED``, the trainer will
        supply ground-truth future targets via *y_future_tf*.  When
        ``DIRECT``, *y_future_tf* will be ``None``.

        Implementations **must** handle ``y_future_tf=None`` gracefully
        regardless of training style, since ``generate()`` never passes
        teacher-forcing data.

        Args:
            past_y: Target history shaped ``[B, T, C_y]``.
            past_cov: Optional past covariates shaped ``[B, T, C_p]``.
            future_cov: Optional future covariates shaped ``[B, H, C_f]``.
            static: Optional static features shaped ``[B, C_s]``.
            y_future_tf: Teacher-forcing labels shaped ``[B, H, C_y]``.
                ``None`` for direct models and during inference.
            forecast_length: Horizon ``H`` override.
            input_length: Past window ``T`` cap override.

        Returns:
            Dictionary containing at least:
                - ``quantiles``: forecast quantiles shaped ``[B, H, Q]``.
                - ``quantile_levels``: tensor of quantile levels shaped ``[Q]``.
        """
        raise NotImplementedError

    @torch.no_grad()
    @abstractmethod
    def generate(
        self,
        past_y: torch.Tensor,
        past_cov: Optional[torch.Tensor] = None,
        future_cov: Optional[torch.Tensor] = None,
        static: Optional[torch.Tensor] = None,
        *,
        forecast_length: Optional[int] = None,
        input_length: Optional[int] = None,
    ) -> Dict[str, torch.Tensor]:
        """
        Unified forecast API (inference without teacher forcing).

        This is the single entry-point for producing forecasts at
        inference time.  Unlike ``forward()``, *y_future_tf* is never
        provided.

        The implementation is architecture-dependent:

        - **Encoder-decoder / causal-decoder** models may iterate
          autoregressively, feeding their own predictions back.
        - **Direct / encoder-only** models may simply delegate to
          ``forward(past_y, ..., y_future_tf=None)`` since they
          already produce all ``H`` steps in one shot.
        - **Non-transformer** models (SSMs, convolutions, MLPs) may
          use whatever inference strategy fits their architecture.

        Args mirror :meth:`forward` except ``y_future_tf`` is absent.

        Returns:
            Dictionary containing at least:
                - ``quantiles``: forecast quantiles shaped ``[B, H, Q]``.
                - ``quantile_levels``: tensor of quantile levels shaped ``[Q]``.
        """
        raise NotImplementedError

    @classmethod
    @abstractmethod
    def from_config(cls, cfg: Dict[str, Any]) -> "TimeSeriesFoundationModel":
        """Instantiate a model from a serialized configuration dictionary."""
        raise NotImplementedError

    @abstractmethod
    def to_config(self) -> Dict[str, Any]:
        """Serialize the model configuration so it can be reproduced."""
        raise NotImplementedError


def validate_time_series_model(
    model: Any,
    *,
    input_length_override: Optional[int] = None,
    forecast_length_override: Optional[int] = None,
) -> TimeSeriesFoundationModel:
    """
    Ensure ``instantiate_model`` returned a compliant model.

    Raises:
        TypeError: if the object does not inherit from :class:`TimeSeriesFoundationModel`.
        RuntimeError: if ``forward`` or ``generate`` cannot produce forecasts for
            both the configured horizon and a nearby alternate horizon. Using two
            horizons helps surface models that hard-code output lengths (the root
            cause of the earlier einsum shape mismatch between 257 and 256).
    """

    if not isinstance(model, TimeSeriesFoundationModel):
        raise TypeError(
            "instantiate_model() must return an instance of TimeSeriesFoundationModel"
        )

    try:
        param = next(model.parameters())
    except StopIteration:
        param = next(iter(model.buffers()), None)

    device = param.device if param is not None else torch.device("cpu")
    dtype = param.dtype if param is not None else torch.float32

    batch_size = 2

    def _int_cfg_value(cfg: Dict[str, Any], key: str, default: int, *, minimum: int) -> int:
        try:
            value = int(cfg.get(key, default))
        except Exception:
            return default
        return max(value, minimum)

    cfg: Dict[str, Any] = {}
    try:  # pragma: no cover - defensive config inspection
        if isinstance(getattr(model, "cfg", None), dict):
            cfg = model.cfg
        else:
            maybe_cfg = model.to_config()
            if isinstance(maybe_cfg, dict):
                cfg = maybe_cfg
    except Exception:
        cfg = {}

    constraints = cfg.get("constraints", {}) if isinstance(cfg, dict) else {}
    input_length = (
        max(int(input_length_override), 1)
        if input_length_override is not None
        else _int_cfg_value(constraints, "input_length", 512, minimum=1)
    )
    forecast_length = (
        max(int(forecast_length_override), 1)
        if forecast_length_override is not None
        else _int_cfg_value(
            constraints,
            "forecast_length",
            _int_cfg_value(cfg, "horizon", 96, minimum=1),
            minimum=1,
        )
    )
    target_dim = _int_cfg_value(
        constraints, "target_dim", _int_cfg_value(cfg, "target_dim", 1, minimum=1), minimum=1
    )
    past_cov_dim = _int_cfg_value(
        constraints, "past_cov_dim", _int_cfg_value(cfg, "past_cov_dim", 0, minimum=0), minimum=0
    )
    future_cov_dim = _int_cfg_value(
        constraints,
        "future_cov_dim",
        _int_cfg_value(cfg, "future_cov_dim", 0, minimum=0),
        minimum=0,
    )
    static_dim = _int_cfg_value(
        constraints, "static_dim", _int_cfg_value(cfg, "static_dim", 0, minimum=0), minimum=0
    )

    def _make_inputs(
        current_forecast_length: int, current_input_length: int
    ) -> tuple[
        torch.Tensor,
        Optional[torch.Tensor],
        Optional[torch.Tensor],
        Optional[torch.Tensor],
        torch.Tensor,
    ]:
        past_y = torch.zeros(
            (batch_size, current_input_length, target_dim), device=device, dtype=dtype
        )
        past_cov = (
            torch.zeros(
                (batch_size, current_input_length, past_cov_dim),
                device=device,
                dtype=dtype,
            )
            if past_cov_dim > 0
            else None
        )
        future_cov = (
            torch.zeros(
                (batch_size, current_forecast_length, future_cov_dim),
                device=device,
                dtype=dtype,
            )
            if future_cov_dim > 0
            else None
        )
        static = (
            torch.zeros((batch_size, static_dim), device=device, dtype=dtype)
            if static_dim > 0
            else None
        )
        y_future_tf = torch.zeros(
            (batch_size, current_forecast_length, target_dim),
            device=device,
            dtype=dtype,
        )
        return past_y, past_cov, future_cov, static, y_future_tf

    def _format_last_call_context(last_call: Dict[str, Optional[str]]) -> str:
        module_ctx = f" in module '{last_call['module']}'" if last_call.get("module") else ""
        shape_ctx = (
            f" with operand shapes {last_call['shapes']}" if last_call.get("shapes") else ""
        )
        return f"{module_ctx}{shape_ctx}"

    def _shape_prop(
        current_forecast_length: int,
        current_input_length: int,
        past_y: torch.Tensor,
        past_cov: Optional[torch.Tensor],
        future_cov: Optional[torch.Tensor],
        static: Optional[torch.Tensor],
        y_future_tf: torch.Tensor,
        last_call: Dict[str, Optional[str]],
    ) -> None:
        def _traceable_forward(
            past_y_arg: torch.Tensor,
            past_cov_arg: Optional[torch.Tensor],
            future_cov_arg: Optional[torch.Tensor],
            static_arg: Optional[torch.Tensor],
            y_future_tf_arg: torch.Tensor,
            current_forecast_length_arg: int,
            current_input_length_arg: int,
        ) -> Dict[str, torch.Tensor]:
            return model.forward(
                past_y_arg,
                past_cov_arg,
                future_cov_arg,
                static=static_arg,
                y_future_tf=y_future_tf_arg,
                forecast_length=current_forecast_length_arg,
                input_length=current_input_length_arg,
            )
        try:
            traced = make_fx(
                _traceable_forward,
                tracing_mode="symbolic",
                _allow_non_fake_inputs=True,
            )(
                past_y,
                past_cov,
                future_cov,
                static,
                y_future_tf,
                current_forecast_length,
                current_input_length,
            )
        except Exception as trace_err:  # pragma: no cover - defensive tracing
            context = _format_last_call_context(last_call)
            raise RuntimeError(
                "shape propagation tracing failed "
                f"(forecast_length={current_forecast_length}, input_length={current_input_length}){context}: "
                f"{trace_err.__class__.__name__}: {trace_err}"
            ) from trace_err

        def _format_shape_prop_operands(args: tuple[Any, ...], kwargs: Dict[str, Any]) -> str:
            shapes = []

            def _append(name: str, value: Any) -> None:
                if isinstance(value, torch.Tensor):
                    shapes.append(f"{name}={tuple(value.shape)}")

            for idx, arg in enumerate(args):
                _append(f"arg{idx}", arg)
            for key, value in (kwargs or {}).items():
                _append(key, value)

            return f"[{', '.join(shapes)}]" if shapes else "[]"

        class _SafeShapeProp(ShapeProp):
            def call_function(self, target, args, kwargs):  # type: ignore[override]
                try:
                    return super().call_function(target, args, kwargs)
                except RuntimeError as err:
                    if target is torch.ops.aten.view.default:
                        try:
                            return torch.ops.aten.reshape.default(args[0], args[1])
                        except Exception:
                            pass
                    if target in (torch.ops.aten.mm.default, torch.ops.aten.matmul.default):
                        lhs, rhs = args[:2] if len(args) >= 2 else (None, None)
                        if isinstance(lhs, torch.Tensor) and isinstance(rhs, torch.Tensor):
                            lhs_inner = lhs.shape[-1] if lhs.dim() >= 1 else None
                            rhs_leading = rhs.shape[-2] if rhs.dim() >= 2 else None
                            if lhs_inner is not None and rhs_leading is not None:
                                if lhs_inner != rhs_leading:
                                    alt_rhs = None
                                    if rhs.dim() >= 2 and rhs.shape[-1] == lhs_inner:
                                        alt_rhs = rhs.transpose(-2, -1)
                                    elif rhs.numel() % lhs_inner == 0:
                                        new_shape = (lhs_inner, rhs.numel() // lhs_inner)
                                        try:
                                            alt_rhs = torch.ops.aten.reshape.default(
                                                rhs, new_shape
                                            )
                                        except Exception:
                                            alt_rhs = None
                                    if alt_rhs is not None:
                                        try:
                                            if target is torch.ops.aten.matmul.default:
                                                return torch.ops.aten.matmul.default(
                                                    lhs, alt_rhs
                                                )
                                            return torch.ops.aten.mm.default(lhs, alt_rhs)
                                        except Exception:
                                            pass
                                    err = RuntimeError(
                                        "matmul dimension mismatch "
                                        f"(lhs inner={lhs_inner}, rhs leading={rhs_leading})"
                                    )
                    shape_ctx = _format_shape_prop_operands(args, kwargs)
                    raise RuntimeError(
                        f"ShapeProp failed at call_function target={target} with operand shapes {shape_ctx}: "
                        f"{err.__class__.__name__}: {err}"
                    ) from err

            def call_module(self, target, args, kwargs):  # type: ignore[override]
                try:
                    return super().call_module(target, args, kwargs)
                except RuntimeError as err:
                    module = None
                    try:
                        module = self.fetch_attr(target)
                    except Exception:
                        module = None
                    module_name = (
                        module.__class__.__name__ if module is not None else str(target)
                    )
                    shape_ctx = _format_shape_prop_operands(args, kwargs)
                    raise RuntimeError(
                        "ShapeProp failed at call_module "
                        f"target={target} ({module_name}) with operand shapes {shape_ctx}: "
                        f"{err.__class__.__name__}: {err}"
                    ) from err

            def call_method(self, target, args, kwargs):  # type: ignore[override]
                try:
                    return super().call_method(target, args, kwargs)
                except RuntimeError as err:
                    if target == "view":
                        try:
                            return args[0].reshape(*args[1:], **(kwargs or {}))
                        except Exception:
                            pass
                    if target in ("matmul", "__matmul__", "mm"):
                        lhs, rhs = args[:2] if len(args) >= 2 else (None, None)
                        if isinstance(lhs, torch.Tensor) and isinstance(rhs, torch.Tensor):
                            lhs_inner = lhs.shape[-1] if lhs.dim() >= 1 else None
                            rhs_leading = rhs.shape[-2] if rhs.dim() >= 2 else None
                            if lhs_inner is not None and rhs_leading is not None:
                                if lhs_inner != rhs_leading:
                                    alt_rhs = None
                                    if rhs.dim() >= 2 and rhs.shape[-1] == lhs_inner:
                                        alt_rhs = rhs.transpose(-2, -1)
                                    elif rhs.numel() % lhs_inner == 0:
                                        new_shape = (lhs_inner, rhs.numel() // lhs_inner)
                                        try:
                                            alt_rhs = torch.ops.aten.reshape.default(
                                                rhs, new_shape
                                            )
                                        except Exception:
                                            alt_rhs = None
                                    if alt_rhs is not None:
                                        try:
                                            if target in ("matmul", "__matmul__"):
                                                return lhs.matmul(alt_rhs)
                                            return lhs.mm(alt_rhs)
                                        except Exception:
                                            pass
                                    err = RuntimeError(
                                        "matmul dimension mismatch "
                                        f"(lhs inner={lhs_inner}, rhs leading={rhs_leading})"
                                    )
                    shape_ctx = _format_shape_prop_operands(args, kwargs)
                    raise RuntimeError(
                        f"ShapeProp failed at call_method target={target} with operand shapes {shape_ctx}: "
                        f"{err.__class__.__name__}: {err}"
                    ) from err

        try:
            _SafeShapeProp(traced).propagate(
                past_y,
                past_cov,
                future_cov,
                static,
                y_future_tf,
                current_forecast_length,
                current_input_length,
            )
        except Exception as prop_err:  # pragma: no cover - defensive tracing
            failing_node = getattr(prop_err, "node", None)
            node_ctx = (
                f" at node '{failing_node.name}' (target={failing_node.target}, op={failing_node.op})"
                if failing_node is not None
                else ""
            )
            raise RuntimeError(
                "shape propagation failed "
                f"(forecast_length={current_forecast_length}, input_length={current_input_length}){node_ctx}: "
                f"{prop_err.__class__.__name__}: {prop_err}"
            ) from prop_err

    def _validate_outputs(
        outputs: Dict[str, torch.Tensor], call_name: str, expected_forecast_length: int
    ) -> None:
        if not isinstance(outputs, dict):
            raise ValueError(
                f"{call_name} must return a dictionary with forecast outputs"
            )

        if "quantiles" not in outputs:
            raise ValueError(f"{call_name} must return 'quantiles' in the output dict")

        quantiles = outputs["quantiles"]
        if not isinstance(quantiles, torch.Tensor):
            raise ValueError(f"{call_name} output 'quantiles' must be a torch.Tensor")

        if quantiles.ndim != 3:
            raise ValueError(f"{call_name} output 'quantiles' must have shape [B, H, Q]")

        if quantiles.shape[0] != batch_size or quantiles.shape[1] != expected_forecast_length:
            raise ValueError(
                f"{call_name} output 'quantiles' expected shape [{batch_size}, {expected_forecast_length}, Q], "
                f"got {tuple(quantiles.shape)}"
            )

        if quantiles.device != device or quantiles.dtype != dtype:
            raise ValueError(
                f"{call_name} output 'quantiles' must be on device {device} and dtype {dtype}"
            )

        if "quantile_levels" not in outputs:
            raise ValueError(
                f"{call_name} must return 'quantile_levels' in the output dict"
            )

        quantile_levels = outputs["quantile_levels"]
        if not isinstance(quantile_levels, torch.Tensor):
            raise ValueError(
                f"{call_name} output 'quantile_levels' must be a torch.Tensor"
            )

        if quantile_levels.ndim != 1:
            raise ValueError(
                f"{call_name} output 'quantile_levels' must be a 1-D tensor, got shape {tuple(quantile_levels.shape)}"
            )

        if quantile_levels.shape[0] != quantiles.shape[2]:
            raise ValueError(
                f"{call_name} output 'quantile_levels' length must match 'quantiles' last dimension "
                f"({quantiles.shape[2]}), got {quantile_levels.shape[0]}"
            )

        if quantile_levels.device != quantiles.device or quantile_levels.dtype != quantiles.dtype:
            raise ValueError(
                f"{call_name} 'quantile_levels' must share device/dtype with 'quantiles' "
                f"(device={quantiles.device}, dtype={quantiles.dtype})"
            )

        # Values must lie strictly inside (0, 1)
        ql_min = float(quantile_levels.min())
        ql_max = float(quantile_levels.max())
        if ql_min <= 0.0 or ql_max >= 1.0:
            raise ValueError(
                f"{call_name} 'quantile_levels' values must be in the open interval (0, 1), "
                f"got min={ql_min}, max={ql_max}"
            )

        # Values must be strictly increasing
        if quantile_levels.shape[0] > 1:
            diffs = quantile_levels[1:] - quantile_levels[:-1]
            if float(diffs.min()) <= 0.0:
                raise ValueError(
                    f"{call_name} 'quantile_levels' must be strictly increasing, "
                    f"got {quantile_levels.tolist()}"
                )

    def _format_operand_shapes(args: tuple[Any, ...], kwargs: Dict[str, Any]) -> str:
        shapes = []

        def _append(name: str, value: Any) -> None:
            if isinstance(value, torch.Tensor):
                shapes.append(f"{name}={tuple(value.shape)}")

        for idx, arg in enumerate(args):
            _append(f"arg{idx}", arg)
        for key, value in kwargs.items():
            _append(key, value)

        return f"[{', '.join(shapes)}]" if shapes else "[]"

    def _capture_module_context():
        module_names = {id(model): "<root>"}
        module_names.update({id(mod): name or "<root>" for name, mod in model.named_modules()})
        last_call: Dict[str, Optional[str]] = {"module": None, "shapes": None}
        handles = []
        seen = set()

        def _hook(mod: nn.Module, args: tuple[Any, ...], kwargs: Dict[str, Any]) -> None:
            module_name = module_names.get(id(mod), mod.__class__.__name__)
            last_call["module"] = module_name
            last_call["shapes"] = _format_operand_shapes(args, kwargs)

        for name, mod in [("<root>", model), *list(model.named_modules())]:
            if id(mod) in seen:
                continue
            seen.add(id(mod))
            handles.append(mod.register_forward_pre_hook(_hook, with_kwargs=True))

        return last_call, handles

    def _augment_and_raise(
        err: Exception,
        call_name: str,
        current_forecast_length: int,
        current_input_length: int,
        last_call: Dict[str, Optional[str]],
    ) -> RuntimeError:
        return RuntimeError(
            f"{call_name} failed for forecast_length={current_forecast_length}, "
            f"input_length={current_input_length}{_format_last_call_context(last_call)}: "
            f"{err.__class__.__name__}: {err}"
        )

    style = getattr(model, "training_style", TrainingStyle.TEACHER_FORCED)

    def _run_validation(current_forecast_length: int, current_input_length: int) -> None:
        past_y, past_cov, future_cov, static, y_future_tf = _make_inputs(
            current_forecast_length, current_input_length
        )

        last_call, handles = _capture_module_context()
        try:
            # FX shape-prop always runs with y_future_tf so the graph
            # covers the full signature (even if the model ignores it).
            _shape_prop(
                current_forecast_length,
                current_input_length,
                past_y,
                past_cov,
                future_cov,
                static,
                y_future_tf,
                last_call,
            )

            # --- forward with teacher forcing (always, for contract completeness) ---
            try:
                forward_outputs = model.forward(
                    past_y,
                    past_cov,
                    future_cov,
                    static,
                    y_future_tf=y_future_tf,
                    forecast_length=current_forecast_length,
                    input_length=current_input_length,
                )
            except Exception as err:  # pragma: no cover - defensive validation
                raise _augment_and_raise(
                    err,
                    "model.forward (teacher_forced)",
                    current_forecast_length,
                    current_input_length,
                    last_call,
                ) from err

            _validate_outputs(forward_outputs, "model.forward (teacher_forced)", current_forecast_length)

            # --- forward WITHOUT teacher forcing (required for direct models) ---
            if style == TrainingStyle.DIRECT:
                try:
                    direct_outputs = model.forward(
                        past_y,
                        past_cov,
                        future_cov,
                        static,
                        y_future_tf=None,
                        forecast_length=current_forecast_length,
                        input_length=current_input_length,
                    )
                except Exception as err:  # pragma: no cover - defensive validation
                    raise _augment_and_raise(
                        err,
                        "model.forward (direct, y_future_tf=None)",
                        current_forecast_length,
                        current_input_length,
                        last_call,
                    ) from err

                _validate_outputs(
                    direct_outputs, "model.forward (direct)", current_forecast_length
                )

            # --- generate (unified forecast API, no teacher forcing) ---
            if hasattr(model, "generate"):
                try:
                    with torch.no_grad():
                        generate_outputs = model.generate(
                            past_y,
                            past_cov,
                            future_cov,
                            static,
                            forecast_length=current_forecast_length,
                            input_length=current_input_length,
                        )
                except Exception as err:  # pragma: no cover - defensive validation
                    raise _augment_and_raise(
                        err,
                        "model.generate",
                        current_forecast_length,
                        current_input_length,
                        last_call,
                    ) from err

                _validate_outputs(
                    generate_outputs, "model.generate", current_forecast_length
                )
        finally:
            for handle in handles:
                handle.remove()

    _run_validation(forecast_length, input_length)

    alternate_forecast_length = max(1, forecast_length - 1)
    if alternate_forecast_length != forecast_length:
        _run_validation(alternate_forecast_length, input_length)

    alternate_input_length = input_length + 1 if input_length > 0 else 1
    if alternate_input_length != input_length:
        _run_validation(forecast_length, alternate_input_length)

    # ── to_config() / from_config() round-trip validation ────────────
    try:
        cfg_out = model.to_config()
    except Exception as err:
        raise RuntimeError(
            f"to_config() failed: {err.__class__.__name__}: {err}"
        ) from err

    if not isinstance(cfg_out, dict):
        raise TypeError(
            f"to_config() must return a dict, got {type(cfg_out).__name__}"
        )

    # Verify JSON-serialisable (catches non-primitive values)
    try:
        json.dumps(cfg_out)
    except (TypeError, ValueError, OverflowError) as err:
        raise ValueError(
            f"to_config() returned a dict that is not JSON-serialisable: "
            f"{err.__class__.__name__}: {err}"
        ) from err

    # Reconstruct from config and verify it still produces valid outputs
    try:
        reconstructed = model.__class__.from_config(cfg_out)
    except Exception as err:
        raise RuntimeError(
            f"from_config(to_config()) round-trip failed: "
            f"{err.__class__.__name__}: {err}"
        ) from err

    if not isinstance(reconstructed, TimeSeriesFoundationModel):
        raise TypeError(
            "from_config() must return a TimeSeriesFoundationModel instance, "
            f"got {type(reconstructed).__name__}"
        )

    return model


# ══════════════════════════════════════════════════════════════════════
# Exported callables for core.training / services.packager integration
# ══════════════════════════════════════════════════════════════════════


def load_candidate_model(
    candidate_code_path: str,
    device: torch.device,
    *,
    model_config: Optional[Dict[str, Any]] = None,
    input_length: Optional[int] = None,
    forecast_length: Optional[int] = None,
) -> TimeSeriesFoundationModel:
    """Load, validate, and return a candidate time-series model.

    Moved here from ``training.py`` so that model loading lives
    alongside the model contract.
    """
    spec = importlib.util.spec_from_file_location(
        "candidate_model", candidate_code_path,
    )
    if spec is None or spec.loader is None:
        raise ImportError(
            f"Could not load candidate module at {candidate_code_path}"
        )
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)

    if not hasattr(module, "instantiate_model"):
        raise AttributeError(
            f"Candidate module '{candidate_code_path}' must define "
            "instantiate_model()."
        )

    instantiate = getattr(module, "instantiate_model")
    try:
        model = (
            instantiate(model_config)
            if model_config is not None
            else instantiate()
        )
    except TypeError:
        if model_config is None:
            raise
        model = instantiate(**model_config)

    model = validate_time_series_model(
        model,
        input_length_override=input_length,
        forecast_length_override=forecast_length,
    )
    model.to(device)
    return model
