"""
Task-specific prompt constants for TimeSeriesFoundationTask.

This module centralizes all large prompt blocks used by the task's agent
interfaces. Extracting prompts here keeps task.py focused on logic and makes
prompt maintenance easier across the codebase.

Constants follow a consistent naming convention:
- PLANNER_CONTEXT_PROMPT: Full model contract for the planner agent
- ROLE_BASE_PROMPT: Base contract shared across multiple roles
- ROLE_*_ADDENDUM: Role-specific additions appended to the base prompt
- MOTIVATION_CONTEXT_PROMPT: Context for the MotivationChecker agent
- METRIC_DESCRIPTIONS_PROMPT: Metrics overview for the Analyzer
- BASELINE_REFERENCE_PROMPT: Baseline reference table for the Analyzer
- PERFORMANCE_RUBRIC_*: Eval-type-specific rubrics for the Analyzer
"""

# -----------------------------------------------------------------------------
# Challenge Categories and Patterns (Task-Specific)
# -----------------------------------------------------------------------------

# Canonical list of challenge categories for time-series foundation models
TS_CHALLENGE_CATEGORIES = [
    "Long-Range Dependencies",
    "Multi-Scale & Frequency",
    "Non-Stationarity",
    "Scale-Free Generalization",
    "SNR Variability",
    "Computational Efficiency",
]

# Challenge detection patterns for keyword-based inference
# Maps challenge_id to (display_name, detection_keywords)
TS_CHALLENGE_PATTERNS = {
    "long_range": (
        "Long-Range Dependencies",
        ["long-range", "long range", "receptive field", "distant", "memory", "state-space", "ssm", "mamba", "s4", "retention"],
    ),
    "multi_scale": (
        "Multi-Scale & Frequency",
        ["multi-scale", "multiscale", "frequency", "fourier", "wavelet", "spectral", "multi-resolution", "temporal scale", "different clocks"],
    ),
    "non_stationary": (
        "Non-Stationarity",
        ["non-stationary", "nonstationary", "distribution shift", "regime", "adaptive normalization", "covariate shift", "concept drift"],
    ),
    "scale_free": (
        "Scale-Free Generalization",
        ["revin", "reversible", "instance norm", "scale-free", "magnitude", "normalization", "scale shock", "domain transfer"],
    ),
    "snr": (
        "SNR Variability",
        ["signal-to-noise", "snr", "noise", "sensitivity", "robust", "denoising", "filtering", "confidence"],
    ),
    "efficiency": (
        "Computational Efficiency",
        ["sub-quadratic", "linear attention", "sparse", "flash", "efficient", "o(n)", "o(l)", "chunked", "memory efficient"],
    ),
}

# Formatted challenge context for the Analyzer agent
TS_ANALYZER_CHALLENGE_CONTEXT = """
Explicitly tag which key challenges this experiment targeted. Choose from:
- **Long-Range Dependencies**: Mechanisms for capturing distant history (SSMs, sparse attention, memory)
- **Multi-Scale & Frequency**: Handling different temporal scales (wavelets, multi-resolution, frequency-domain)
- **Non-Stationarity**: Adapting to distribution shifts (adaptive normalization, regime detection)
- **Scale-Free Generalization**: Robustness to magnitude differences (RevIN, normalization schemes)
- **SNR Variability**: Adaptive sensitivity to noise levels (denoising, confidence weighting)
- **Computational Efficiency**: Sub-quadratic complexity (linear attention, chunking, FlashAttention)

Only include challenges that the experiment ACTUALLY targeted with concrete mechanisms—do not tag challenges that were merely mentioned but not implemented.
"""

# -----------------------------------------------------------------------------
# Challenge Priorities for Planner
# -----------------------------------------------------------------------------

PLANNER_CHALLENGE_PRIORITIES = """
**DESIGN PRIORITIES: Key Challenges for Univariate Foundation Models**

Your architectural innovations should directly address one or more of these fundamental challenges:

1. **Long-Range Dependencies (The "Receptive Field" Problem)**
   - Challenge: Distinguishing relevant history from irrelevant noise over long horizons (5,000+ steps)
   - Standard attention dilutes signal over distance; need mechanisms that retain precise distant information
   - Promising directions: State-space models, sparse/linear attention, hierarchical compression

2. **Multi-Scale & Frequency Generalization**
   - Challenge: Single model must handle fundamentally different "clocks" (high-freq audio vs low-freq quarterly GDP)
   - A model trained on hourly data may fail on weekly trends due to different rates of change
   - Promising directions: Multi-resolution tokenizers, adaptive binning, frequency-domain processing

3. **Non-Stationarity & Distribution Shift**
   - Challenge: Statistical properties evolve during both history AND forecast window
   - Inter-series shift (Dataset A ≠ Dataset B) AND intra-series shift (behavior changes mid-sequence)
   - Promising directions: Adaptive normalization, regime detection, online adaptation mechanisms

4. **Scale-Free Generalization (The Magnitude Issue)**
   - Challenge: Transfer across domains with wildly different magnitudes ([0.001, 0.005] vs [10,000, 50,000])
   - Without proper handling, model suffers "scale shock" and fails cross-domain transfer
   - Promising directions: RevIN (Reversible Instance Normalization), learnable affine transforms, percentile encoding

5. **Signal-to-Noise Ratio Variability**
   - Challenge: Adaptively toggle sensitivity—skeptical of noisy financial data, sensitive to clean physical data
   - A single model must learn WHEN small fluctuations matter vs when they're noise
   - Promising directions: Learned noise estimation, confidence-weighted attention, adaptive filtering

6. **Computational Efficiency (Inference Latency)**
   - Challenge: Sub-quadratic complexity for real-time inference with long lookback windows
   - O(L²) attention explodes memory; need O(L log L) or O(L) alternatives
   - Promising directions: FlashAttention, sparse patterns, linear attention, state-space models

**Your Innovation Should:**
- Explicitly target at least one challenge above
- Propose a concrete mechanism (not just "improve X")
- Consider trade-offs (e.g., efficiency vs expressivity)
- Build on what worked/failed in the experimental context
"""

# -----------------------------------------------------------------------------
# Planner Context Prompt
# -----------------------------------------------------------------------------

PLANNER_CONTEXT_PROMPT = PLANNER_CHALLENGE_PRIORITIES + """
        THE MODEL CONTRACT (MUST COMPLY EXACTLY)

        Import the base contract and use it as your superclass:

        from tasks.ts_foundation.model_base import (
            TimeSeriesFoundationModel as BaseTSFM,
            validate_time_series_model,
        )

        YOU MUST PROVIDE
        - A concrete subclass named TimeSeriesFoundationModel that extends BaseTSFM.
        - Implement:
        - forward(past_y, past_cov=None, future_cov=None, static=None, y_future_tf=None, *, forecast_length=None, input_length=None) -> Dict[str, torch.Tensor]
        - generate(past_y, past_cov=None, future_cov=None, static=None, *, forecast_length=None, input_length=None) -> Dict[str, torch.Tensor]   # no teacher forcing
        - @classmethod from_config(cls, cfg: Dict[str, Any]) -> TimeSeriesFoundationModel
        - to_config(self) -> Dict[str, Any]

        TOP-LEVEL FACTORY
        def instantiate_model(config: Optional[Dict[str, Any]] = None) -> TimeSeriesFoundationModel
        - Must call validate_time_series_model(model) before returning.

        REQUIRED OUTPUTS OF forward AND generate
        - "quantiles": [B, H, Q] (float32 or float64)
        - "quantile_levels": [Q] strictly increasing in (0,1), same dtype/device as outputs

        IO SHAPE & SEMANTICS (NON-NEGOTIABLE)
        - past_y: [B, T, C_y] with C_y >= 1
        - past_cov: [B, T, C_p] or None
        - future_cov: [B, H, C_f] or None
        - static: [B, C_s] or None
        - y_future_tf (teacher forcing): [B, H, C_y] or None
        - forecast_length (H) and input_length (T_cap) may override default horizon/window if provided.
        - No future leakage:
        * In forward, if you use attention, masks must be applied BEFORE softmax.
        * In generate, roll forward autoregressively without peeking at future labels.

        DEVICE, DTYPES, SHAPES
        - Derive shapes from runtime tensors. No hardcoded batch/length/head sizes.
        - Respect the input device and dtype (e.g., use x.device; do not hardcode .cuda()).
        - Must work for batch sizes 1, 4, 32… and long sequences within reasonable limits.

        CONFIG EXPECTATIONS
        - from_config(cfg) must accept a plain dict (unknown keys allowed) and set sensible defaults.
        - to_config() returns only JSON-serializable values.
        - Keep config minimal (e.g., hidden sizes, heads, dropout, horizon) and DO NOT tie design to transformers; any architecture is allowed if the contract holds.
        - CRITICAL: Ensure input and output dimensions of Linear layers match 'd_model' (often 256 or 512). Do NOT hardcode dimensions like 64, 128, etc. unless you explicitly project to them. Mismatches like "shapes cannot be multiplied (2x256 and 64x256)" mean you used a hardcoded size (e.g. 64) but received 'd_model' (e.g. 256).

        PERFORMANCE & SAFETY GUARDRAILS
        - Prefer sub-quadratic complexity: avoid full O(N^2) over long sequences unless chunked/sparse/linearized.
        - If using attention, build causal masks with dynamic shapes and apply BEFORE softmax.
        - Standard train/eval semantics (e.g., dropout active only in train mode).
        - No file/network I/O, no global state, no external datasets. Pure PyTorch module.

        TRAINING STYLE SELECTION (IMPORTANT)
        Your model can declare how the training pipeline should call forward():

        from tasks.ts_foundation.model_base import TrainingStyle

        class TimeSeriesFoundationModel(BaseTSFM):
            training_style = TrainingStyle.TEACHER_FORCED  # or TrainingStyle.DIRECT

        Two options:
        - TrainingStyle.TEACHER_FORCED (default): During training, forward() receives
          y_future_tf=[B,H,C_y] with ground-truth future targets. Best for encoder-decoder
          and causal-decoder architectures that attend to future context.
        - TrainingStyle.DIRECT: During training, forward() is called WITHOUT y_future_tf.
          The model predicts all H future steps from history alone. Best for encoder-only,
          MLP, convolutional, state-space, and other architectures that do not benefit
          from teacher forcing.

        IMPORTANT: forward() must ALWAYS handle y_future_tf=None gracefully, regardless of
        training_style, because generate() never passes teacher-forcing data.

        GENERATE (UNIFIED FORECAST API)
        generate() is the single inference entry-point. It never receives y_future_tf.
        How you implement it depends on your architecture:
        - Encoder-decoder: may iterate autoregressively, feeding own predictions back.
        - Direct/encoder-only: may simply delegate to forward(past_y, y_future_tf=None).
        - SSM/conv/MLP: whatever inference strategy fits the architecture.

        MINIMAL DEFAULT (STARTING POINT)
        - Start from a decoder-only baseline (embedding → causal blocks → quantile head).
        - You may innovate (state-space, convolutional, MoE, linear attention, kernel/state augmentation, diffusion-decoder, etc.). Whatever you build must still satisfy the contract and return the exact dictionaries.
        - Choose the training_style that matches your architecture. If your model does NOT
          use y_future_tf during training, set training_style = TrainingStyle.DIRECT.

        FACTORY & VALIDATION (REQUIRED)
        instantiate_model(config) must:
        1) Build the model via TimeSeriesFoundationModel.from_config(config or {{}}).
        2) Call validate_time_series_model(model).
        3) Return the validated instance.

        SELF-CHECKLIST (BEFORE YOU FINISH)
        - Class name is exactly TimeSeriesFoundationModel and subclasses BaseTSFM.
        - training_style is set to TEACHER_FORCED or DIRECT (matching your architecture).
        - forward() returns dict with "quantiles":[B,H,Q] and "quantile_levels":[Q].
        - forward() handles y_future_tf=None gracefully (required for both styles).
        - generate() returns the same keys/shapes WITHOUT teacher forcing.
        - No hardcoded sizes; masks applied BEFORE softmax; no future leakage.
        - from_config() accepts dict; to_config() is JSON-serializable.
        - instantiate_model() exists and calls validate_time_series_model.
        - Checked for matrix multiplication shape mismatches (e.g., d_model vs hardcoded sizes).

        DELIVER ONLY THE UPDATED FILE CONTENT. NO PROSE, NO EXPLANATIONS.
        """

# -----------------------------------------------------------------------------
# Role Base Prompt (shared across roles, parameterized by constraints)
# -----------------------------------------------------------------------------

ROLE_BASE_PROMPT_TEMPLATE = """### TIME-SERIES FOUNDATION TASK CONTEXT
You are modifying the reference implementation for the TimeSeriesFoundationTask. All code must ultimately expose a `{model_name}` class that subclasses `BaseTSFM` (imported as `TimeSeriesFoundationModel` from `tasks.ts_foundation.model_base`).

Key contract requirements:
- Implement `forward(past_y, past_cov=None, future_cov=None, static=None, y_future_tf=None, *, forecast_length=None, input_length=None)` and return a dict with `"quantiles"` `[B, H, Q]` and `"quantile_levels"` `[Q]` (strictly increasing values in (0, 1)). The context window is `{input_length}` time steps and the forecast horizon covers `{forecast_length}` steps. `forward()` **must** handle `y_future_tf=None` gracefully.
- Implement `generate(past_y, past_cov=None, future_cov=None, static=None, *, forecast_length=None, input_length=None)` returning the same keys without teacher forcing. This is the unified forecast API — implementation is architecture-dependent (autoregressive, direct, or any strategy). Outputs must always respect the runtime `forecast_length` argument—do not hardcode horizon sizes.
- Set `training_style = TrainingStyle.TEACHER_FORCED` (default, for encoder-decoders) or `TrainingStyle.DIRECT` (for encoder-only, MLP, SSM, conv models that don't use teacher forcing). Import `TrainingStyle` from `tasks.ts_foundation.model_base`.
- Provide `@classmethod from_config(cls, cfg: Dict[str, Any]) -> {model_name}` and `to_config(self) -> Dict[str, Any]` with JSON-serializable values only.
- Define `instantiate_model(config: Optional[Dict[str, Any]] = None) -> {model_name}` that builds the model via `from_config`, calls `validate_time_series_model(model)`, then returns it. Use this exact factory pattern:
```
from tasks.ts_foundation.model_base import (
    TimeSeriesFoundationModel as BaseTSFM,
    validate_time_series_model,
)

def instantiate_model(config: Optional[Dict[str, Any]] = None) -> {model_name}:
    model = {model_name}.from_config(config or {{}})
    validate_time_series_model(model)
    return model
```
- Shape contract summary: `past_y` `[B, T, C_y]`; optional `y_future_tf` `[B, H, C_y]`; outputs `quantiles` `[B, H, Q]` and `quantile_levels` `[Q]`. When present, `past_cov` and `future_cov` align with `[B, T, C_p]` and `[B, H, C_f]` respectively.
- Respect dynamic shapes/devices/dtypes from runtime tensors. Do not hardcode sequence lengths, batch sizes, or devices.
- Maintain causal masking: never leak future information, and apply masks before softmax/normalization.
- Prefer sub-quadratic complexity (linear, chunked, or O(N log N)).
- Keep the model free of side effects (no file/network I/O) and pure PyTorch.

LEAN & ROBUST
- Avoid inline asserts; delegate structural validation to `validate_time_series_model` or explicit error handling.
- Keep forward/generate lean and focused on tensor ops; configuration validation belongs in the factory or `from_config`.
"""

# -----------------------------------------------------------------------------
# Role-Specific Addenda
# -----------------------------------------------------------------------------

ROLE_IMPLEMENTATION_ADDENDUM = """

### IMPLEMENTATION REMINDERS
- Preserve the class name and BaseTSFM inheritance.
- Honor the I/O contract above when designing new modules.
- Validate with `validate_time_series_model` before returning from the factory.
- Double check Linear layer dimensions against `d_model`. Do not use hardcoded '64' or '128' if `d_model` is passed.
"""

ROLE_DEBUGGER_ADDENDUM = """

### DEBUGGER REMINDERS
- Apply minimal fixes that keep the `{model_name}` contract intact.
- Preserve the class/function signatures listed above and keep `@torch.compile` decorations where provided.
- If you see 'shapes cannot be multiplied' (e.g., 2x256 and 64x256), checking if a layer is initialized with a fixed size (64) instead of `d_model` (256).
"""

ROLE_JUDGER_ADDENDUM = """

### JUDGING RUBRIC
Use the provided training/evaluation logs plus the rubric below to compare candidates against the reference implementations.

**Reference Profiles:**
1. **Reference Baseline (score 5/10)** — O(n) decoder with causal masking and quantile head.
   - Final training loss: 4.5787
   - Average evaluation score: 0.224
2. **Enhanced Reference (score 10/10)** — Baseline plus adaptive gating for long-horizon state tracking.
   - Final training loss: 4.3772
   - Average evaluation score: 0.226

**Scoring Guidelines:**
- **Performance (30%)**: Quantify percentage gains/losses vs. the Reference Baseline.
- **Innovation (25%)**: Reward mechanisms that address the contract's pain points (long-range memory, dynamic horizons, non-stationarity).
- **Complexity (45%)**: Prefer O(n) implementations with clean configs and clear sampling procedures.

Use 1–10 scores per dimension with weighted aggregation `(0.3 * performance) + (0.25 * innovation) + (0.45 * complexity)` and justify each score with quantitative evidence."""

ROLE_STABILITY_CHECKER_ADDENDUM = """

### NUMERICAL STABILITY CHECKS

Your role is to identify and fix code patterns that cause NaN values or exploding gradients during training.

**Critical Patterns for Time-Series Models:**

1. **Attention Stability:**
   - Attention scores must be scaled by `1/sqrt(d_k)` before softmax
   - Masks must be applied BEFORE softmax using `masked_fill(..., float('-inf'))`
   - Never apply masks after softmax (causes information leak AND instability)

2. **Positional Encoding:**
   - Sinusoidal embeddings with very long sequences can cause overflow
   - Check that frequencies are properly bounded

3. **Layer Normalization:**
   - Every transformer block should have LayerNorm (pre-norm or post-norm)
   - Missing normalization in deep networks leads to gradient explosion

4. **Quantile Head:**
   - The cumulative sum for monotonic quantiles needs care
   - Ensure the head doesn't produce extreme values on initialization

5. **State-Space Models (if used):**
   - Discretization parameters must be bounded
   - Log-space parameterization for stability (e.g., log(dt) instead of dt)
   - Check for proper initialization of A, B, C, D matrices

6. **Activation Functions:**
   - Unbounded activations (linear, leaky_relu with large negative slope) can explode
   - Prefer GELU, SiLU, or bounded ReLU variants

**Fix Priorities:**
- Add epsilon (1e-8) to all divisions: `x / (y + 1e-8)`
- Clamp exponentials: `torch.exp(x.clamp(max=88.0))`  # float32 overflow at ~88
- Clamp logarithms: `torch.log(x.clamp(min=1e-8))`
- Ensure proper attention scaling and masking order
- Verify LayerNorm is present in all deep paths
"""

# -----------------------------------------------------------------------------
# Motivation Context Prompt
# -----------------------------------------------------------------------------

MOTIVATION_CONTEXT_PROMPT = """
**TIME-SERIES FORECASTING MOTIVATION CONTEXT:**

The primary goal of this task is to develop novel architectures for **long-range, univariate, universal time-series forecasting**. Motivations should address the specific challenges of this domain, which differ significantly from standard NLP tasks.

**Key Challenges for Univariate Foundation Models:**

1. **Long-Range Dependencies (The "Receptive Field" Problem)**
   It is not just about capturing distant events, but distinguishing relevant history from irrelevant noise over long horizons.
   - *Why it matters:* Foundation models require massive context windows to understand the "rhythm" of a new series. Standard attention mechanisms struggle to retain precise information from 5,000 steps back without diluting the signal.

2. **Multi-Scale & Frequency Generalization**
   The model must handle fundamentally different "clocks." It needs to generalize across high-frequency signals (audio, voltage) and low-frequency aggregates (quarterly GDP) using a single tokenizer.
   - *Why it matters:* A univariate model trained largely on hourly weather data may fail to recognize the slow-moving trends of weekly sales data because the rate of change is drastically different.

3. **Non-Stationarity & Distribution Shift**
   The statistical properties (mean, variance) evolve not just over time, but often during the forecast window itself.
   - *Why it matters:* In a foundation model context, this is doubly hard because the model faces inter-series non-stationarity (Dataset A looks nothing like Dataset B) and intra-series non-stationarity (the series changes behavior halfway through).

4. **Scale-Free Generalization (The Magnitude Issue)**
   One time series might range from [0.001, 0.005] (sensor readings) and another from [10,000, 50,000] (stock prices). A foundation model must be robust to these absolute values.
   - *Why it matters:* Without techniques like Reversible Instance Normalization (RevIN) or similar, the model suffers "scale shock" and fails to transfer across domains with different magnitudes.

5. **Signal-to-Noise Ratio Variability**
   The challenge is not just "robustness," but adaptivity. The model must learn to be "skeptical" of noisy financial data (ignoring small fluctuations) but "sensitive" to clean physical data (where small fluctuations mean something).
   - *Why it matters:* A single model struggles to toggle this sensitivity automatically without explicit mechanisms for SNR-aware processing.

6. **Computational Efficiency (Inference Latency)**
   Processing long sequences efficiently with sub-quadratic complexity (O(L²) → O(L log L) or O(L)).
   - *Why it matters:* Foundation models are heavy. For real-time forecasting (e.g., cloud API limits), the attention mechanism must be optimized (e.g., FlashAttention, sparse attention) to handle long lookback windows without exploding memory usage.

**Evaluation Criteria for Motivations:**
- **Relevance**: Does the motivation directly address one or more of the key challenges above?
- **Novelty**: Is the proposed approach a genuinely new idea in the context of our existing experiments, or is it a minor variation?
- **Specificity**: Is the motivation detailed enough to be implemented and tested? Avoid vague statements.
- **Plausibility**: Is the proposed mechanism likely to lead to an improvement in forecasting accuracy or efficiency?

**Examples of High-Quality Motivations:**
- "Introduce a state-space model with learnable discretization to explicitly handle non-stationarity and improve long-range dependency modeling without O(L²) cost."
- "Implement a multi-resolution tokenizer that adaptively bins time steps based on local frequency content, enabling generalization across high-frequency sensor data and low-frequency economic indicators."
- "Add RevIN with learnable affine parameters per-channel to achieve scale-free generalization, preventing 'scale shock' when transferring between domains."
- "Design an SNR-aware attention mechanism that dynamically adjusts its sensitivity based on estimated local noise levels in the input sequence."

**Examples of Low-Quality Motivations:**
- "Let's try a different activation function." (Not specific or impactful enough)
- "Improve the model's performance." (Too vague)
- "Use a standard Transformer, but with more layers." (Incremental, not novel)
"""

# -----------------------------------------------------------------------------
# Analysis Context Prompts (Analyzer agent)
# -----------------------------------------------------------------------------

METRIC_DESCRIPTIONS_PROMPT = """
        **METRICS OVERVIEW:**
        - **Zero-Cost Proxies (e.g., synflow, snip):** Estimates of a model's performance without training. Higher is generally better.
        - **Curve Extrapolation (small_budget):**
            - **extrapolated_objective:** The projected final performance based on the initial learning curve.
            - **curve_fit_error:** How well the power-law curve fits the observed training steps. Lower is better.
        - **Full Training Metrics (large_budget):**
            - **MASE:** Mean Absolute Scaled Error. Lower is better.
            - **CRPS:** Continuous Ranked Probability Score. Lower is better.
        """

BASELINE_REFERENCE_PROMPT = """
        ### Baseline Reference (Full Training):
        | Model         | MASE  | CRPS  |
        |---------------|-------|------|
        | Nexus-1.0     | 0.699 | 0.479 |
        """

PERFORMANCE_RUBRIC_ZERO_COST = """
            ### Performance Rubric (Zero-Cost Proxies):
            This is a preliminary check. High scores are promising but not definitive.
            - **Excellent (> 10,000):** Indicates a very strong architectural prior for this task.
            - **Good (1,000 - 10,000):** Shows promise. Worth investigating with a small budget.
            - **Acceptable (100 - 1,000):** The architecture is viable but not exceptional.
            - **Poor (< 100):** Unlikely to be a competitive architecture.
            """

PERFORMANCE_RUBRIC_SMALL_BUDGET = """
            ### Performance Rubric (Curve Extrapolation / Small Budget):
            This assesses the model's learning potential.
            - **Excellent (extrapolated_MASE < 0.7):** Projects to be a state-of-the-art model. High priority for full training.
            - **Good (extrapolated_MASE < 0.8):** Shows potential to outperform baselines. Strong candidate for full training.
            - **Acceptable (extrapolated_MASE < 1.0):** The model is learning but does not project to be better than standard models.
            - **Poor (extrapolated_MASE > 1.0):** The model is not learning efficiently and is unlikely to be competitive.
            - **Regarding curve_fit_error:** A low error (< 0.1) gives higher confidence in the extrapolation.
            """

PERFORMANCE_RUBRIC_LARGE_BUDGET = """
            ### Performance Rubric (Full Training / Large Budget):
            This is the definitive measure of performance.
            - **Excellent (MASE < 0.7, CRPS < 0.47):** State-of-the-art result. A significant achievement.
            - **Good (MASE 0.7 - 0.8, CRPS 0.47 - 0.5):** Strong performance, competitive with baselines.
            - **Acceptable (MASE 0.8 - 1.0, CRPS 0.5 - 0.6):** The model works but does not offer an advantage over standard methods.
            - **Poor (MASE > 1.0, CRPS > 0.6):** The model underperforms and is not a good candidate.
            """


def get_performance_rubric(eval_type: str) -> str:
    """Return the appropriate performance rubric based on evaluation type."""
    if eval_type == "zero_cost":
        return PERFORMANCE_RUBRIC_ZERO_COST
    elif eval_type == "small_budget":
        return PERFORMANCE_RUBRIC_SMALL_BUDGET
    elif eval_type == "large_budget":
        return PERFORMANCE_RUBRIC_LARGE_BUDGET
    return ""


def build_role_base_prompt(
    model_name: str,
    input_length: int,
    forecast_length: int,
) -> str:
    """Build the base prompt with task-specific constraints interpolated."""
    return ROLE_BASE_PROMPT_TEMPLATE.format(
        model_name=model_name,
        input_length=input_length,
        forecast_length=forecast_length,
    )


def build_role_instruction(
    role: str,
    model_name: str,
    input_length: int,
    forecast_length: int,
) -> str:
    """
    Build the complete role instruction by combining base prompt with role-specific addendum.

    This function preserves the exact behavior of the original get_role_instruction method.
    """
    role_lower = (role or "").lower()

    # MotivationChecker uses the motivation context prompt directly
    if role_lower == "motivation_checker":
        return MOTIVATION_CONTEXT_PROMPT

    base_prompt = build_role_base_prompt(model_name, input_length, forecast_length)

    if role_lower in {"planner", "deduplicator", "code_checker"}:
        return (base_prompt + ROLE_IMPLEMENTATION_ADDENDUM).strip()
    if role_lower == "debugger":
        return (base_prompt + ROLE_DEBUGGER_ADDENDUM.format(model_name=model_name)).strip()
    if role_lower == "judger":
        return (base_prompt + ROLE_JUDGER_ADDENDUM).strip()
    if role_lower == "stability_checker":
        return (base_prompt + ROLE_STABILITY_CHECKER_ADDENDUM).strip()
    return base_prompt
