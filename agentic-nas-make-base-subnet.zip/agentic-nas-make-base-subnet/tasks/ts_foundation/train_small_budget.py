from __future__ import annotations

import argparse
import json
import logging
from pathlib import Path
from typing import Any, Dict, Optional

from .dataloader import HF_DEFAULT_REPO, build_dataloaders
from .training import TrainingConfig, train_model


def _parse_model_config(raw: Optional[str]) -> Optional[Dict[str, Any]]:
    if raw is None or raw.strip() == "":
        return None
    config = json.loads(raw)
    if not isinstance(config, dict):
        raise ValueError("--model-config must decode to a JSON object.")
    return config


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Small-budget training entrypoint for the time-series foundation task."
    )
    parser.add_argument("--code-path", required=True, help="Candidate python file to execute.")
    parser.add_argument("--run-dir", required=True, help="Directory to store metrics and logs.")
    parser.add_argument("--max-steps", type=int, default=5)
    parser.add_argument("--dataset-path", default=None)
    parser.add_argument(
        "--model-config", default=None, help="JSON string with model configuration overrides."
    )
    parser.add_argument("--input-length", type=int, default=512)
    parser.add_argument("--forecast-length", type=int, default=96)
    parser.add_argument("--batch-size", type=int, default=32)
    parser.add_argument("--eval-interval", type=int, default=64)
    parser.add_argument("--device", default=None)
    parser.add_argument("--stride", type=int, default=None)
    parser.add_argument("--hf-repo-id", default=None, help="Optional HF repo id for streaming data")
    parser.add_argument("--hf-train-split", default="train")
    parser.add_argument("--hf-val-split", default="validation")
    parser.add_argument("--hf-test-split", default="test")
    parser.add_argument(
        "--shuffle-buffer-size",
        type=int,
        default=0,
        help="Buffer size for approximate shuffling when streaming training data.",
    )
    args = parser.parse_args()

    run_dir = Path(args.run_dir)
    run_dir.mkdir(parents=True, exist_ok=True)

    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s | %(levelname)s | %(message)s",
        handlers=[
            logging.StreamHandler(),
            logging.FileHandler(run_dir / "training.log", encoding="utf-8"),
        ],
    )

    hf_repo_id = args.hf_repo_id
    if args.dataset_path:
        hf_repo_id = None
    elif hf_repo_id is None:
        hf_repo_id = HF_DEFAULT_REPO

    logging.info("Preparing dataloaders (input=%d, forecast=%d, batch=%d)", args.input_length, args.forecast_length, args.batch_size)
    bundle = build_dataloaders(
        input_length=args.input_length,
        forecast_length=args.forecast_length,
        batch_size=args.batch_size,
        dataset_path=args.dataset_path,
        stride=args.stride,
        hf_repo_id=hf_repo_id,
        hf_train_split=args.hf_train_split,
        hf_val_split=args.hf_val_split,
        hf_test_split=args.hf_test_split,
        shuffle_buffer_size=args.shuffle_buffer_size,
    )
    def _describe_length(loader):
        try:
            return str(len(loader))
        except TypeError:
            return "unknown"

    logging.info(
        "Dataloaders ready | train=%s batches | val=%s batches | test=%s batches",
        _describe_length(bundle.train),
        _describe_length(bundle.val),
        _describe_length(bundle.test),
    )

    config = TrainingConfig(
        input_length=args.input_length,
        forecast_length=args.forecast_length,
        batch_size=args.batch_size,
        max_steps=args.max_steps,
        eval_interval=args.eval_interval,
        dataset_path=args.dataset_path,
        device=args.device,
        stride=args.stride,
        hf_repo_id=hf_repo_id,
        hf_train_split=args.hf_train_split,
        hf_val_split=args.hf_val_split,
        hf_test_split=args.hf_test_split,
        shuffle_buffer_size=args.shuffle_buffer_size,
    )

    def _log_progress(event: Dict[str, Any]) -> None:
        logging.info(
            "Step %d/%d | train_loss=%.4f | val_loss=%.4f | val_MASE=%.4f | val_CRPS=%.4f",
            event.get("step", 0),
            event.get("max_steps", config.max_steps),
            event.get("train_quantile_loss", float("nan")),
            event.get("val_quantile_loss", float("nan")),
            event.get("val_MASE", float("nan")),
            event.get("val_CRPS", float("nan")),
        )

    logging.info(
        "Starting training for up to %d steps (eval interval=%d)",
        args.max_steps,
        args.eval_interval,
    )

    metrics = train_model(
        candidate_code_path=args.code_path,
        run_dir=str(run_dir),
        config=config,
        datasets=bundle,
        eval_type="small_budget",
        model_config=_parse_model_config(args.model_config),
        progress_callback=_log_progress,
    )
    logging.info(
        "Training finished | validation loss=%.4f | test loss=%.4f",
        metrics["validation"].get("quantile_loss", float("nan")),
        metrics["test"].get("quantile_loss", float("nan")),
    )
    print(json.dumps(metrics, indent=2))


if __name__ == "__main__":
    main()
