"""Time-series foundation task package."""

from . import task as _task  # noqa: F401 — triggers @register_task

__all__: list = []
