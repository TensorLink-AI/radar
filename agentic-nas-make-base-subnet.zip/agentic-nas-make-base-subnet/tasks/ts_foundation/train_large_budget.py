from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any, Dict, Optional

from .dataloader import build_dataloaders
from .training import TrainingConfig, train_model


def _parse_model_config(raw: Optional[str]) -> Optional[Dict[str, Any]]:
    if raw is None or raw.strip() == "":
        return None
    config = json.loads(raw)
    if not isinstance(config, dict):
        raise ValueError("--model-config must decode to a JSON object.")
    return config


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Large-budget training entrypoint for the time-series foundation task."
    )
    parser.add_argument("--code-path", required=True)
    parser.add_argument("--run-dir", required=True)
    parser.add_argument("--max-steps", type=int, default=6000)
    parser.add_argument("--dataset-path", default=None)
    parser.add_argument("--model-config", default=None)
    parser.add_argument("--input-length", type=int, default=512)
    parser.add_argument("--forecast-length", type=int, default=96)
    parser.add_argument("--batch-size", type=int, default=64)
    parser.add_argument("--eval-interval", type=int, default=200)
    parser.add_argument("--device", default=None)
    args = parser.parse_args()

    run_dir = Path(args.run_dir)
    run_dir.mkdir(parents=True, exist_ok=True)

    bundle = build_dataloaders(
        input_length=args.input_length,
        forecast_length=args.forecast_length,
        batch_size=args.batch_size,
        dataset_path=args.dataset_path,
    )

    config = TrainingConfig(
        input_length=args.input_length,
        forecast_length=args.forecast_length,
        batch_size=args.batch_size,
        max_steps=args.max_steps,
        eval_interval=args.eval_interval,
        dataset_path=args.dataset_path,
        device=args.device,
    )

    metrics = train_model(
        candidate_code_path=args.code_path,
        run_dir=str(run_dir),
        config=config,
        datasets=bundle,
        eval_type="large_budget",
        model_config=_parse_model_config(args.model_config),
    )
    print(json.dumps(metrics, indent=2))


if __name__ == "__main__":
    main()
