"""Time-series forecasting metrics and callable factories.

This module owns all scoring logic for the ts_foundation task:

- ``_quantile_loss`` / ``_crps_from_quantiles`` — raw metric math.
- ``make_loss_fn`` / ``make_forward_fn`` / ``make_eval_fn`` — factory
  functions that create callables matching the
  ``core.training.universal_trainer`` protocols.
- ``row_to_sample`` — converts an HF dataset row into a single
  training sample for ``core.data.hf_streaming``.
- Module-level instances (``loss_fn``, ``eval_fn``, ``forward_fn``)
  for use by ``services.packager``.
"""

from __future__ import annotations

import random
from typing import Any, Callable, Dict, Optional

import torch
import torch.nn as nn

from .model_base import DEFAULT_FORECAST_LENGTH, DEFAULT_INPUT_LENGTH, TrainingStyle

__all__ = [
    "make_loss_fn",
    "make_forward_fn",
    "make_eval_fn",
    "row_to_sample",
    "loss_fn",
    "eval_fn",
    "forward_fn",
]


# ── Raw metric functions ─────────────────────────────────────────────


def _quantile_loss(
    pred: torch.Tensor, target: torch.Tensor, quantile_levels: torch.Tensor,
) -> torch.Tensor:
    """Pinball (quantile) loss for probabilistic forecasting."""
    if target.ndim == pred.ndim - 1:
        target_expanded = target.unsqueeze(-1)
    elif target.ndim == pred.ndim and target.size(-1) == 1:
        target_expanded = target
    else:
        raise ValueError(
            "Target tensor shape must broadcast with predicted quantiles."
        )
    q = quantile_levels.view(1, 1, -1)
    diff = target_expanded - pred
    return torch.maximum(q * diff, (q - 1.0) * diff).mean()


def _crps_from_quantiles(
    pred: torch.Tensor, target: torch.Tensor, quantile_levels: torch.Tensor,
) -> float:
    """Compute CRPS from quantile predictions using the ensemble/PWN method.

    Uses the properscoring approach: approximate CRPS via numerical integration
    over quantile levels using the trapezoidal rule on the quantile function.

    CRPS can be computed from quantiles as:
        CRPS = ∫₀¹ 2 * (𝟙{y ≤ F⁻¹(τ)} - τ) * (F⁻¹(τ) - y) dτ

    Which simplifies to:
        CRPS ≈ Σᵢ wᵢ * |qᵢ - y| - ½ * Σᵢ,ⱼ wᵢ * wⱼ * |qᵢ - qⱼ|

    Where qᵢ are the quantile predictions at levels τᵢ, and wᵢ are the
    trapezoidal weights for integrating over [0, 1].

    This matches the properscoring library's ensemble/pwn method.
    """
    # Ensure target has proper shape for broadcasting
    if target.ndim == pred.ndim - 1:
        target_expanded = target.unsqueeze(-1)  # [B, H, 1]
    elif target.ndim == pred.ndim and target.size(-1) == 1:
        target_expanded = target
    else:
        raise ValueError(
            "Target tensor shape must broadcast with predicted quantiles."
        )

    # pred: [B, H, Q], target_expanded: [B, H, 1], quantile_levels: [Q]
    device = pred.device
    dtype = pred.dtype
    q_levels = quantile_levels.to(device=device, dtype=dtype)
    n_quantiles = q_levels.shape[0]

    if n_quantiles < 2:
        # Fallback to MAE if only one quantile
        return float(torch.abs(pred - target_expanded).mean().item())

    # Compute trapezoidal integration weights over [0, 1]
    # For interior points, weight = (τ_{i+1} - τ_{i-1}) / 2
    # For endpoints, extend to 0 and 1

    # Pad with 0 at start and 1 at end for proper integration bounds
    q_padded = torch.cat([
        torch.zeros(1, device=device, dtype=dtype),
        q_levels,
        torch.ones(1, device=device, dtype=dtype),
    ])  # [Q+2]

    # Trapezoidal weights: w_i = (q_{i+1} - q_{i-1}) / 2
    weights = (q_padded[2:] - q_padded[:-2]) / 2.0  # [Q]
    weights = weights.view(1, 1, -1)  # [1, 1, Q] for broadcasting

    # Term 1: Σ wᵢ * |qᵢ - y| - weighted absolute error
    abs_errors = torch.abs(pred - target_expanded)  # [B, H, Q]
    term1 = (weights * abs_errors).sum(dim=-1).mean()  # scalar

    # Term 2: ½ * Σᵢ,ⱼ wᵢ * wⱼ * |qᵢ - qⱼ| - ensemble spread term
    # This is ½ * E[|X - X'|] where X, X' are independent samples from ensemble
    # Can be computed as: Σᵢ wᵢ * (2*Σⱼ<ᵢ wⱼ + wᵢ - 1) * qᵢ simplified form
    # Or directly as pairwise computation

    # For efficiency, compute: ½ * Σᵢ<ⱼ wᵢ * wⱼ * |qᵢ - qⱼ| * 2
    # = Σᵢ<ⱼ wᵢ * wⱼ * |qᵢ - qⱼ|

    # pred: [B, H, Q]
    batch_size, horizon, n_q = pred.shape

    # Reshape for pairwise computation
    pred_i = pred.unsqueeze(-1)  # [B, H, Q, 1]
    pred_j = pred.unsqueeze(-2)  # [B, H, 1, Q]

    pairwise_diff = torch.abs(pred_i - pred_j)  # [B, H, Q, Q]

    # Weight matrix: w_i * w_j
    w = weights.squeeze(0).squeeze(0)  # [Q]
    weight_matrix = w.unsqueeze(-1) * w.unsqueeze(0)  # [Q, Q]

    # Apply weights and sum
    weighted_pairwise = pairwise_diff * weight_matrix.unsqueeze(0).unsqueeze(0)  # [B, H, Q, Q]
    # Sum over all pairs (each pair counted twice, so divide by 2)
    term2 = weighted_pairwise.sum(dim=(-1, -2)).mean() / 2.0  # scalar

    crps = float((term1 - term2).item())
    return max(crps, 0.0)  # CRPS is non-negative


# ── Callable factories (parameterised by dataset bundle) ─────────────


def make_loss_fn() -> Callable:
    """Create a ``loss_fn(output, batch, device)`` for the universal trainer."""

    def _loss_fn(
        output: Dict[str, torch.Tensor],
        batch: Dict[str, torch.Tensor],
        device: torch.device,
    ) -> torch.Tensor:
        quantiles = output["quantiles"]
        quantile_levels = output["quantile_levels"].to(device)
        target = batch["future_target"].to(device)
        return _quantile_loss(quantiles, target, quantile_levels)

    return _loss_fn


def make_forward_fn(
    forecast_length: int = DEFAULT_FORECAST_LENGTH,
    input_length: int = DEFAULT_INPUT_LENGTH,
) -> Callable:
    """Create a ``forward_fn(model, batch, device)`` for the universal trainer.

    Reads ``model.training_style`` at call time to decide whether to
    pass ``y_future_tf`` (teacher forcing) or not:

    - ``TrainingStyle.TEACHER_FORCED`` (default): passes ground-truth
      future targets as ``y_future_tf`` so the model can attend to them.
    - ``TrainingStyle.DIRECT``: omits ``y_future_tf``; the model must
      predict all ``H`` steps from history alone.
    """

    def _forward_fn(
        model: nn.Module,
        batch: Dict[str, torch.Tensor],
        device: torch.device,
    ) -> Dict[str, torch.Tensor]:
        past = batch["past_target"].to(device)

        style = getattr(model, "training_style", TrainingStyle.TEACHER_FORCED)

        if style == TrainingStyle.DIRECT:
            return model(
                past_y=past,
                forecast_length=forecast_length,
                input_length=input_length,
            )

        # Default: teacher-forced
        target = batch["future_target"].to(device)
        return model(
            past_y=past,
            y_future_tf=target,
            forecast_length=forecast_length,
            input_length=input_length,
        )

    return _forward_fn


def make_eval_fn(
    forecast_length: int = DEFAULT_FORECAST_LENGTH,
    input_length: int = DEFAULT_INPUT_LENGTH,
    mase_scale: float = 1.0,
    max_batches: Optional[int] = None,
) -> Callable:
    """Create an ``eval_fn(model, loader, device)`` for the universal trainer."""

    def _eval_fn(
        model: nn.Module,
        loader: torch.utils.data.DataLoader,
        device: torch.device,
    ) -> Dict[str, float]:
        model.eval()
        total_loss = 0.0
        mase_total = 0.0
        crps_total = 0.0
        batches = 0

        with torch.no_grad():
            for i, batch in enumerate(loader):
                if max_batches is not None and i >= max_batches:
                    break

                past = batch["past_target"].to(device)
                target = batch["future_target"].to(device)
                output = model.generate(
                    past_y=past,
                    forecast_length=forecast_length,
                    input_length=input_length,
                )
                quantiles = output["quantiles"]
                quantile_levels = output["quantile_levels"].to(device)
                loss = _quantile_loss(quantiles, target, quantile_levels)
                total_loss += loss.item()

                median_idx = int(
                    torch.argmin(torch.abs(quantile_levels - 0.5))
                )
                median_pred = quantiles[..., median_idx : median_idx + 1]
                mase_total += torch.mean(
                    torch.abs(median_pred - target)
                ).item()
                crps_total += _crps_from_quantiles(
                    quantiles, target, quantile_levels,
                )
                batches += 1

        if batches == 0:
            return {"quantile_loss": 0.0, "MASE": 0.0, "CRPS": 0.0}

        mase = (mase_total / batches) / max(mase_scale, 1e-8)
        return {
            "quantile_loss": total_loss / batches,
            "MASE": mase,
            "CRPS": crps_total / batches,
        }

    return _eval_fn


# ── row_to_sample for core.data.hf_streaming ─────────────────────────


def row_to_sample(row: Dict[str, Any]) -> Dict[str, torch.Tensor]:
    """Convert a single HF time-series row to a training sample.

    Extracts a random sliding window from the series.  This is the
    simplified streaming version used by the generic
    ``core.data.hf_streaming.StreamingWindowDataset``.
    """
    raw_target = row.get("target")
    if raw_target is None:
        raise ValueError("Row missing 'target' field")

    if (
        isinstance(raw_target, (list, tuple))
        and raw_target
        and isinstance(raw_target[0], (list, tuple))
    ):
        series_vals = raw_target[0]
    else:
        series_vals = raw_target

    total_needed = DEFAULT_INPUT_LENGTH + DEFAULT_FORECAST_LENGTH
    if len(series_vals) < total_needed:
        raise ValueError(
            f"Series too short ({len(series_vals)}) for "
            f"window ({total_needed})"
        )

    max_start = len(series_vals) - total_needed
    start = random.randint(0, max_start)

    past = torch.tensor(
        series_vals[start : start + DEFAULT_INPUT_LENGTH],
        dtype=torch.float32,
    )
    future = torch.tensor(
        series_vals[start + DEFAULT_INPUT_LENGTH : start + total_needed],
        dtype=torch.float32,
    )

    return {
        "past_target": past.unsqueeze(-1),    # [T, 1]
        "future_target": future.unsqueeze(-1),  # [H, 1]
    }


# ── Module-level instances (default config, used by services.packager) ──

loss_fn = make_loss_fn()
forward_fn = make_forward_fn()
eval_fn = make_eval_fn()
