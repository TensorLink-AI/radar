"""Task package initialization."""

# Import task modules to ensure registry side-effects run on package import.
from .ts_foundation import task as _ts_foundation_task  # noqa: F401

__all__ = []
