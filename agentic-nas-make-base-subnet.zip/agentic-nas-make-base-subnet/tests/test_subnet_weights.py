"""Tests for subnet.validator.weights – weight submission to chain."""

from __future__ import annotations

import asyncio
import unittest
from unittest.mock import AsyncMock, MagicMock

from subnet.validator.weights import set_weights_on_chain


class TestSetWeightsOnChain(unittest.TestCase):
    """Test set_weights_on_chain functionality."""

    def _run(self, coro):
        loop = asyncio.new_event_loop()
        try:
            return loop.run_until_complete(coro)
        finally:
            loop.close()

    def test_empty_weights_returns_false(self):
        chain = MagicMock()
        chain.set_weights_async = AsyncMock(return_value=True)
        result = self._run(set_weights_on_chain(chain, {}))
        self.assertFalse(result)
        chain.set_weights_async.assert_not_called()

    def test_calls_set_weights_async_with_sorted_uids(self):
        chain = MagicMock()
        chain.set_weights_async = AsyncMock(return_value=True)
        weights = {3: 0.5, 1: 0.3, 2: 0.2}

        result = self._run(set_weights_on_chain(chain, weights))

        self.assertTrue(result)
        chain.set_weights_async.assert_called_once()
        call_kwargs = chain.set_weights_async.call_args
        uids = call_kwargs.kwargs.get("uids") or call_kwargs[1].get("uids")
        self.assertEqual(uids, [1, 2, 3])

    def test_renormalises_weights_to_sum_to_one(self):
        chain = MagicMock()
        chain.set_weights_async = AsyncMock(return_value=True)
        # Weights that don't sum to 1.0
        weights = {0: 0.3, 1: 0.3}

        self._run(set_weights_on_chain(chain, weights))

        call_kwargs = chain.set_weights_async.call_args
        vals = call_kwargs.kwargs.get("weights") or call_kwargs[1].get("weights")
        self.assertAlmostEqual(sum(vals), 1.0, places=6)

    def test_single_uid(self):
        chain = MagicMock()
        chain.set_weights_async = AsyncMock(return_value=True)
        weights = {42: 1.0}

        result = self._run(set_weights_on_chain(chain, weights))

        self.assertTrue(result)
        call_kwargs = chain.set_weights_async.call_args
        uids = call_kwargs.kwargs.get("uids") or call_kwargs[1].get("uids")
        vals = call_kwargs.kwargs.get("weights") or call_kwargs[1].get("weights")
        self.assertEqual(uids, [42])
        self.assertAlmostEqual(vals[0], 1.0)

    def test_propagates_failure(self):
        chain = MagicMock()
        chain.set_weights_async = AsyncMock(return_value=False)
        weights = {0: 0.5, 1: 0.5}

        result = self._run(set_weights_on_chain(chain, weights))
        self.assertFalse(result)


if __name__ == "__main__":
    unittest.main()
