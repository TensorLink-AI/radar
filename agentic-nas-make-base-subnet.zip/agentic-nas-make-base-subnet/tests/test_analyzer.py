import asyncio
from pathlib import Path
import sys
import os

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.append(str(ROOT))

os.environ.setdefault("MODEL_NAME", "dummy-model")
os.environ.setdefault("CHUTES_API_KEY", "dummy-key")

import pytest

import services.analyse.analyzer as analyzer_module
from services.analyse import interface as analyse_interface
# Use simplified agents (following "The Bitter Lesson of Agent Frameworks")
from services.providers.agents import AnalyzerOutput
from services.analyse import strategies
from services.eval.interface import EvaluationArtifacts
from services.database import DataElement
from core.tasks.contracts import BaseTask


class _StubTask(BaseTask):
    def __init__(self, source_path: Path):
        self.source_path = source_path

    def planner_context(self) -> str:
        return ""

    def set_run_environment(self, run_dir: str):
        del run_dir

    def build_datasets(self, cfg):
        del cfg
        return {}

    def train_and_eval(self, candidate_code_path: str, datasets, run_dir: str, eval_type: str):
        del candidate_code_path, datasets, run_dir, eval_type
        return {}

    def primary_objectives(self):
        return []

    def task_constraints(self):
        return []

    def get_analysis_context(self, eval_type: str):
        return {"metric_descriptions": eval_type}

    def get_scaffold_path(self) -> str:
        return ""

    def get_source_file_path(self, name: str) -> str:
        del name
        return str(self.source_path)

    def get_result_file_path(self, name: str, eval_type: str) -> str:
        del name, eval_type
        return ""

    def get_test_result_file_path(self, name: str, eval_type: str) -> str:
        del name, eval_type
        return ""

    def get_task_description(self) -> str:
        return "test task"

    def get_task_keywords(self):
        return []

    def get_evaluation_script(self) -> str:
        return ""


class _FakeRunnerResult:
    def __init__(self):
        self.final_output = AnalyzerOutput(
            design_evaluation="ok",
            experimental_results_analysis="ok",
            expectation_vs_reality_comparison="ok",
            theoretical_explanation_with_evidence="ok",
            synthesis_and_insights="ok",
        )


def test_analyse_builds_payload_with_program_path(monkeypatch, tmp_path):
    program_path = tmp_path / "candidate.py"
    program_path.write_text("print('hello world')\n")

    task = _StubTask(program_path)

    class _StubStrategy:
        async def analyze(self, name, motivation, ref_context, task, eval_type):
            del name, motivation, ref_context, task, eval_type
            return {"analysis_type": "quick"}

    monkeypatch.setattr(analyzer_module, "get_analysis_strategy", lambda eval_type: _StubStrategy())
    monkeypatch.setattr(strategies, "get_analysis_strategy", lambda eval_type: _StubStrategy())

    captured = {}

    async def _fake_run(**call_kwargs):
        captured.update(call_kwargs)
        return AnalyzerOutput(
            design_evaluation="ok",
            experimental_results_analysis="ok",
            expectation_vs_reality_comparison="ok",
            theoretical_explanation_with_evidence="ok",
            synthesis_and_insights="ok",
        )

    monkeypatch.setattr(analyse_interface.analyzer, "run", _fake_run)
    monkeypatch.setattr(analyse_interface, "run_rag", lambda *_args, **_kwargs: {"results": []})

    class _StubClient:
        def get_analyse_elements(self, parent_index):
            assert parent_index is None
            return None

    monkeypatch.setattr(analyse_interface, "create_client", lambda: _StubClient())

    artifacts = EvaluationArtifacts(
        success=True,
        result={"train": "", "test": ""},
        logs="",
        run_dir=str(tmp_path),
        candidate_code_path=str(program_path),
        eval_type="quick",
    )

    analysis_input = AnalysisInput(
        name="candidate",
        motivation="motivation",
        context="",
        parent=None,
        eval_type="quick",
    )

    result = asyncio.run(
        analyse_interface.analyse(
            name="candidate",
            motivation="motivation",
            task=task,
            evaluation_artifacts=artifacts,
            program_text=program_path.read_text(),
        )
    )

    assert captured["program_file_path"] == str(program_path)
    assert captured["program_code"] == program_path.read_text()
    assert isinstance(result, DataElement)


def test_analyse_uses_task_description(monkeypatch, tmp_path):
    program_path = tmp_path / "candidate.py"
    program_path.write_text("print('hello world')\n")

    task = _StubTask(program_path)

    class _StubStrategy:
        async def analyze(self, name, motivation, ref_context, task, eval_type):
            del name, motivation, ref_context, task, eval_type
            return {"analysis_type": "quick"}

    monkeypatch.setattr(analyzer_module, "get_analysis_strategy", lambda eval_type: _StubStrategy())
    monkeypatch.setattr(strategies, "get_analysis_strategy", lambda eval_type: _StubStrategy())

    captured = {}

    async def _fake_run(**call_kwargs):
        captured.update(call_kwargs)
        return AnalyzerOutput(**{field: "ok" for field in AnalyzerOutput.model_fields})

    monkeypatch.setattr(analyse_interface.analyzer, "run", _fake_run)
    monkeypatch.setattr(analyse_interface, "run_rag", lambda *_args, **_kwargs: {"results": []})

    class _StubClient:
        def get_analyse_elements(self, parent_index):
            assert parent_index is None
            return None

    monkeypatch.setattr(analyse_interface, "create_client", lambda: _StubClient())

    artifacts = EvaluationArtifacts(
        success=True,
        result={"train": "", "test": ""},
        logs="",
        run_dir=str(tmp_path),
        candidate_code_path=str(program_path),
        eval_type="quick",
    )

    analysis_input = AnalysisInput(
        name="candidate",
        motivation="motivation",
        context="",
        parent=None,
        eval_type="quick",
    )

    result = asyncio.run(
        analyse_interface.analyse(
            name="candidate",
            motivation="motivation",
            task=task,
            evaluation_artifacts=artifacts,
            program_text=program_path.read_text(),
        )
    )

    assert isinstance(result, DataElement)
    assert captured["task_name"] == task.get_task_description()


def test_analyse_applies_safe_defaults(monkeypatch, tmp_path):
    program_path = tmp_path / "candidate.py"
    program_path.write_text("print('hello world')\n")

    task = _StubTask(program_path)

    class _StubStrategy:
        async def analyze(self, name, motivation, ref_context, task, eval_type):
            return {
                "analysis_type": eval_type,
                "train_result": "train",
                "test_result": "test",
                "content": ref_context,
            }

    monkeypatch.setattr(analyzer_module, "get_analysis_strategy", lambda eval_type: _StubStrategy())
    monkeypatch.setattr(strategies, "get_analysis_strategy", lambda eval_type: _StubStrategy())

    captured = {}

    async def _fake_run(**call_kwargs):
        captured.update(call_kwargs)
        return AnalyzerOutput(**{field: "ok" for field in AnalyzerOutput.model_fields})

    monkeypatch.setattr(analyse_interface.analyzer, "run", _fake_run)
    monkeypatch.setattr(analyse_interface, "run_rag", lambda *_args, **_kwargs: {"results": []})

    class _StubClient:
        def get_analyse_elements(self, parent_index):
            assert parent_index is None
            return None

    monkeypatch.setattr(analyse_interface, "create_client", lambda: _StubClient())

    artifacts = EvaluationArtifacts(
        success=True,
        result={"train": "", "test": ""},
        logs="",
        run_dir=str(tmp_path),
        candidate_code_path=str(program_path),
        eval_type="",
    )

    analysis_input = AnalysisInput(
        name="candidate",
        motivation="motivation",
        context="",
        parent=None,
        eval_type="",
    )

    result = asyncio.run(
        analyse_interface.analyse(
            name="candidate",
            motivation="motivation",
            task=task,
            evaluation_artifacts=artifacts,
            program_text=program_path.read_text(),
        )
    )

    assert isinstance(result, DataElement)
    assert captured["ref_context"] == "No reference experiments provided."
    expected_eval_type = getattr(analyse_interface.Config, "FIRST_EVAL_TIER", "unspecified") or "unspecified"
    assert captured["eval_type"] == expected_eval_type


def test_analyse_falls_back_to_empty_reference_context(monkeypatch, tmp_path):
    program_path = tmp_path / "candidate.py"
    program_path.write_text("print('hello world')\n")

    task = _StubTask(program_path)
    artifacts = EvaluationArtifacts(
        success=True,
        result={"train": "", "test": ""},
        logs="",
        run_dir=str(tmp_path),
        candidate_code_path=str(program_path),
        eval_type="quick",
    )

    class _StubClient:
        def get_analyse_elements(self, parent_index):
            assert parent_index is None
            return None

    captured = {}

    class _FakeRunnerResult:
        def __init__(self):
            self.final_output = AnalyzerOutput(
                design_evaluation="ok",
                experimental_results_analysis="ok",
                expectation_vs_reality_comparison="ok",
                theoretical_explanation_with_evidence="ok",
                synthesis_and_insights="ok",
            )

    async def _fake_run(**kwargs):
        captured.update(kwargs)
        return _FakeRunnerResult().final_output

    monkeypatch.setattr(analyse_interface, "create_client", lambda: _StubClient())
    monkeypatch.setattr(analyse_interface, "run_rag", lambda *_args, **_kwargs: {"results": []})
    monkeypatch.setattr(analyse_interface.analyzer, "run", _fake_run)

    result = asyncio.run(
        analyse_interface.analyse(
            name="candidate",
            motivation="motivation",
            task=task,
            evaluation_artifacts=artifacts,
            program_text="print('program text')\n",
        )
    )

    assert isinstance(result, DataElement)
    assert captured["ref_context"].strip() != ""
    assert captured["ref_context"].strip() == "No reference experiments provided."


def test_analyse_requires_base_task(monkeypatch, tmp_path):
    artifacts = EvaluationArtifacts(
        success=True,
        result={"train": "", "test": ""},
        logs="",
        run_dir=str(tmp_path),
        candidate_code_path=str(tmp_path / "candidate.py"),
        eval_type="quick",
    )

    with pytest.raises(ValueError, match="BaseTask instance"):
        asyncio.run(
            analyse_interface.analyse(
                name="candidate",
                motivation="motivation",
                task=None,
                evaluation_artifacts=artifacts,
                program_text="print('program text')\n",
            )
        )


def test_analyzer_run_requires_base_task():
    analyzer = analyzer_module.Analyzer()

    with pytest.raises(ValueError, match="BaseTask instance"):
        asyncio.run(
            analyzer.run(
                name="candidate",
                motivation="motivation",
                ref_context="",
                task=None,
                eval_type="quick",
            )
        )


def test_analyse_accepts_base_task_without_duplicate_validation(monkeypatch, tmp_path):
    program_path = tmp_path / "candidate.py"
    program_path.write_text("print('hello world')\n")

    task = _StubTask(program_path)

    class _StubStrategy:
        async def analyze(self, name, motivation, ref_context, task, eval_type):
            del name, motivation, ref_context, task, eval_type
            return {"analysis_type": "quick"}

    monkeypatch.setattr(analyzer_module, "get_analysis_strategy", lambda eval_type: _StubStrategy())
    monkeypatch.setattr(strategies, "get_analysis_strategy", lambda eval_type: _StubStrategy())

    captured = {}

    async def _fake_run(**kwargs):
        captured["task"] = kwargs.get("task")
        return AnalyzerOutput(**{field: "ok" for field in AnalyzerOutput.model_fields})

    monkeypatch.setattr(analyse_interface, "run_rag", lambda *_args, **_kwargs: {"results": []})
    monkeypatch.setattr(analyse_interface.analyzer, "run", _fake_run)

    class _StubClient:
        def get_analyse_elements(self, parent_index):
            assert parent_index is None
            return None

    monkeypatch.setattr(analyse_interface, "create_client", lambda: _StubClient())

    artifacts = EvaluationArtifacts(
        success=True,
        result={"train": "", "test": ""},
        logs="",
        run_dir=str(tmp_path),
        candidate_code_path=str(program_path),
        eval_type="quick",
    )

    analysis_input = AnalysisInput(
        name="candidate",
        motivation="motivation",
        context="context",
        parent=None,
        eval_type="quick",
    )

    result = asyncio.run(
        analyse_interface.analyse(
            name="candidate",
            motivation="motivation",
            task=task,
            evaluation_artifacts=artifacts,
            program_text=program_path.read_text(),
        )
    )

    assert isinstance(result, DataElement)
    assert captured["task"] is task
