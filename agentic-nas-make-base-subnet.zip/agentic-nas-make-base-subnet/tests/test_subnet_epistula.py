"""Tests for subnet.protocol.epistula – Epistula HTTP signing and verification."""

from __future__ import annotations

import os
import time
import unittest
from unittest.mock import patch

from subnet.protocol.epistula import (
    HEADER_HOTKEY,
    HEADER_SIGNATURE,
    HEADER_TIMESTAMP,
    EpistulaAuth,
    build_headers,
    verify_headers,
)


# ── Mock keypair compatible with build_headers ──────────────────────────


class _MockKeypair:
    """Minimal bittensor.Keypair replacement for tests."""

    def __init__(self, ss58_address: str = "5TestHotkey123"):
        self.ss58_address = ss58_address

    def sign(self, message: bytes) -> bytes:
        import hashlib
        return hashlib.sha256(b"test_seed" + message).digest()


# ── build_headers tests ──────────────────────────────────────────────────


class TestBuildHeaders(unittest.TestCase):
    """Test build_headers produces correct Epistula headers."""

    def test_returns_three_required_headers(self):
        kp = _MockKeypair()
        headers = build_headers(kp)
        self.assertIn(HEADER_TIMESTAMP, headers)
        self.assertIn(HEADER_SIGNATURE, headers)
        self.assertIn(HEADER_HOTKEY, headers)

    def test_timestamp_is_recent(self):
        kp = _MockKeypair()
        headers = build_headers(kp)
        ts = int(headers[HEADER_TIMESTAMP])
        self.assertAlmostEqual(ts, int(time.time()), delta=2)

    def test_hotkey_matches_keypair(self):
        kp = _MockKeypair(ss58_address="5FooBarBaz")
        headers = build_headers(kp)
        self.assertEqual(headers[HEADER_HOTKEY], "5FooBarBaz")

    def test_signature_is_hex_encoded(self):
        kp = _MockKeypair()
        headers = build_headers(kp)
        sig = headers[HEADER_SIGNATURE]
        # Must be valid hex
        bytes.fromhex(sig)

    def test_signature_deterministic_for_same_timestamp(self):
        kp = _MockKeypair()
        with patch("subnet.protocol.epistula.time") as mock_time:
            mock_time.time.return_value = 1700000000
            h1 = build_headers(kp)
            h2 = build_headers(kp)
        self.assertEqual(h1[HEADER_SIGNATURE], h2[HEADER_SIGNATURE])


# ── verify_headers tests ────────────────────────────────────────────────


class TestVerifyHeaders(unittest.TestCase):
    """Test verify_headers with various valid and invalid inputs."""

    def test_missing_headers_rejected(self):
        valid, reason, auth = verify_headers({})
        self.assertFalse(valid)
        self.assertIn("missing", reason)
        self.assertIsNone(auth)

    def test_partial_headers_rejected(self):
        valid, reason, auth = verify_headers({
            HEADER_TIMESTAMP: str(int(time.time())),
            # Missing signature and hotkey
        })
        self.assertFalse(valid)
        self.assertIn("missing", reason)

    def test_invalid_timestamp_rejected(self):
        valid, reason, auth = verify_headers({
            HEADER_TIMESTAMP: "not_a_number",
            HEADER_SIGNATURE: "deadbeef",
            HEADER_HOTKEY: "5SomeHotkey",
        })
        self.assertFalse(valid)
        self.assertIn("timestamp", reason.lower())

    def test_stale_timestamp_rejected(self):
        """Timestamp older than freshness window should be rejected."""
        old_ts = str(int(time.time()) - 120)  # 2 minutes ago
        valid, reason, auth = verify_headers(
            {
                HEADER_TIMESTAMP: old_ts,
                HEADER_SIGNATURE: "deadbeef",
                HEADER_HOTKEY: "5SomeHotkey",
            },
            freshness_sec=60,
        )
        self.assertFalse(valid)
        self.assertIn("old", reason)

    def test_future_timestamp_rejected(self):
        """Timestamp far in the future should also be rejected (abs check)."""
        future_ts = str(int(time.time()) + 120)
        valid, reason, auth = verify_headers(
            {
                HEADER_TIMESTAMP: future_ts,
                HEADER_SIGNATURE: "deadbeef",
                HEADER_HOTKEY: "5SomeHotkey",
            },
            freshness_sec=60,
        )
        self.assertFalse(valid)
        self.assertIn("old", reason)

    def test_valid_headers_with_unverified_mode(self):
        """With EPISTULA_ALLOW_UNVERIFIED=1 and no bittensor SDK, should pass."""
        now_ts = str(int(time.time()))
        kp = _MockKeypair()
        sig = kp.sign(now_ts.encode()).hex()

        with patch.dict(os.environ, {"EPISTULA_ALLOW_UNVERIFIED": "1"}):
            valid, reason, auth = verify_headers(
                {
                    HEADER_TIMESTAMP: now_ts,
                    HEADER_SIGNATURE: sig,
                    HEADER_HOTKEY: kp.ss58_address,
                },
                freshness_sec=60,
            )
        # bittensor isn't installed, but ALLOW_UNVERIFIED lets it through
        self.assertTrue(valid)
        self.assertEqual(reason, "ok")
        self.assertIsInstance(auth, EpistulaAuth)
        self.assertEqual(auth.hotkey, kp.ss58_address)

    def test_without_unverified_mode_fails_without_bittensor(self):
        """Without EPISTULA_ALLOW_UNVERIFIED, missing bittensor SDK should fail."""
        now_ts = str(int(time.time()))
        with patch.dict(os.environ, {"EPISTULA_ALLOW_UNVERIFIED": "0"}, clear=False):
            valid, reason, auth = verify_headers(
                {
                    HEADER_TIMESTAMP: now_ts,
                    HEADER_SIGNATURE: "deadbeef",
                    HEADER_HOTKEY: "5SomeHotkey",
                },
                freshness_sec=60,
            )
        self.assertFalse(valid)
        self.assertIn("bittensor", reason.lower())


if __name__ == "__main__":
    unittest.main()
