"""Unit tests for the GiftEval pretrain streaming dataloader.

Uses a mock S3 store so no real S3/R2 access is required.
"""

from __future__ import annotations

import io
import json
import sys
from pathlib import Path
from typing import Any, Dict, List
from unittest.mock import patch

import pytest
import torch

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from tasks.ts_foundation.gifteval_pretrain_loader import (
    GiftEvalPretrainConfig,
    GiftEvalPretrainDataset,
    _list_shard_keys,
    _row_to_training_sample,
    build_gifteval_pretrain_dataloaders,
)

# ── Helpers ──────────────────────────────────────────────────────────────


def _make_parquet_bytes(rows: List[Dict[str, Any]]) -> bytes:
    """Create a Parquet file in memory from a list of dicts."""
    import pyarrow as pa
    import pyarrow.parquet as pq

    table = pa.Table.from_pylist(rows)
    buf = io.BytesIO()
    pq.write_table(table, buf)
    return buf.getvalue()


def _sample_rows(
    n: int = 5,
    target_length: int = 1024,
    domain: str = "Energy_Grid",
    freq: str = "1H",
) -> List[Dict[str, Any]]:
    """Generate sample rows matching the GiftEval pretrain schema."""
    import random

    rng = random.Random(42)
    return [
        {
            "item_id": f"item_{i}_w0",
            "start": "2024-01-01",
            "target": [rng.gauss(0, 1) for _ in range(target_length)],
            "feat_dynamic_real": None,
            "feat_static_cat": None,
            "dataset_name": "test_dataset",
            "domain": domain,
            "freq": freq,
            "is_multivariate": False,
        }
        for i in range(n)
    ]


class MockS3Store:
    """Mock S3ObjectStore that serves from an in-memory dict."""

    def __init__(self, objects: Dict[str, bytes]) -> None:
        self.objects = objects
        self.bucket = "test-bucket"

    def list_keys(self, prefix: str) -> List[str]:
        return [k for k in self.objects if k.startswith(prefix)]

    def get_bytes(self, key: str) -> bytes:
        if key not in self.objects:
            raise Exception(f"NoSuchKey: {key}")
        return self.objects[key]


# ── Tests: _row_to_training_sample ───────────────────────────────────────


class TestRowToTrainingSample:
    def test_basic_conversion(self) -> None:
        import random

        rng = random.Random(42)
        row = _sample_rows(1, target_length=1024)[0]
        sample = _row_to_training_sample(row, 512, 256, rng)

        assert sample is not None
        assert "past_target" in sample
        assert "future_target" in sample
        assert sample["past_target"].shape == (512, 1)
        assert sample["future_target"].shape == (256, 1)
        assert sample["past_target"].dtype == torch.float32

    def test_none_target_returns_none(self) -> None:
        import random

        rng = random.Random(42)
        row = {"target": None}
        assert _row_to_training_sample(row, 512, 256, rng) is None

    def test_short_target_returns_none(self) -> None:
        import random

        rng = random.Random(42)
        row = {"target": [1.0, 2.0, 3.0]}
        assert _row_to_training_sample(row, 512, 256, rng) is None

    def test_exact_length(self) -> None:
        """Target length == input + forecast should still produce a sample."""
        import random

        rng = random.Random(42)
        row = {"target": [float(i) for i in range(768)]}
        sample = _row_to_training_sample(row, 512, 256, rng)
        assert sample is not None
        assert sample["past_target"].shape == (512, 1)
        assert sample["future_target"].shape == (256, 1)

    def test_nan_sanitisation(self) -> None:
        import random
        import math

        rng = random.Random(42)
        target = [1.0] * 768
        target[100] = float("nan")
        target[600] = float("inf")
        row = {"target": target}
        sample = _row_to_training_sample(row, 512, 256, rng)
        assert sample is not None
        assert torch.isfinite(sample["past_target"]).all()
        assert torch.isfinite(sample["future_target"]).all()

    def test_random_subwindow(self) -> None:
        """Different RNG seeds should produce different sub-windows."""
        import random

        row = {"target": [float(i) for i in range(1024)]}
        s1 = _row_to_training_sample(row, 512, 256, random.Random(1))
        s2 = _row_to_training_sample(row, 512, 256, random.Random(2))
        assert s1 is not None and s2 is not None
        # Very unlikely to be identical with different seeds on a 1024-length target
        assert not torch.equal(s1["past_target"], s2["past_target"])


# ── Tests: _list_shard_keys ──────────────────────────────────────────────


class TestListShardKeys:
    def test_filters_parquet_only(self) -> None:
        store = MockS3Store({
            "pfx/part_000000.parquet": b"",
            "pfx/part_000001.parquet": b"",
            "pfx/manifest.json": b"",
            "pfx/README.md": b"",
        })
        keys = _list_shard_keys(store, "pfx/")  # type: ignore[arg-type]
        assert len(keys) == 2
        assert all(k.endswith(".parquet") for k in keys)

    def test_sorted_output(self) -> None:
        store = MockS3Store({
            "pfx/part_000002.parquet": b"",
            "pfx/part_000000.parquet": b"",
            "pfx/part_000001.parquet": b"",
        })
        keys = _list_shard_keys(store, "pfx/")  # type: ignore[arg-type]
        assert keys == [
            "pfx/part_000000.parquet",
            "pfx/part_000001.parquet",
            "pfx/part_000002.parquet",
        ]


# ── Tests: GiftEvalPretrainDataset ───────────────────────────────────────


class TestGiftEvalPretrainDataset:
    def _make_store_with_shards(
        self, n_shards: int = 2, rows_per_shard: int = 5,
    ) -> MockS3Store:
        objects: Dict[str, bytes] = {}
        for i in range(n_shards):
            rows = _sample_rows(rows_per_shard, target_length=1024)
            key = f"gifteval_pretrain_flat_1024x256/part_{i:06d}.parquet"
            objects[key] = _make_parquet_bytes(rows)
        return objects, MockS3Store(objects)

    def test_yields_samples(self) -> None:
        objects, store = self._make_store_with_shards(2, 5)
        config = GiftEvalPretrainConfig(
            bucket="test",
            prefix="gifteval_pretrain_flat_1024x256/",
            input_length=512,
            forecast_length=256,
            seed=42,
            prefetch_files=1,
        )
        ds = GiftEvalPretrainDataset(config)
        ds._store = store  # Inject mock
        ds._shard_keys = [k for k in objects if k.endswith(".parquet")]

        samples = []
        for sample in ds:
            samples.append(sample)
            if len(samples) >= 10:
                break

        assert len(samples) == 10
        assert all("past_target" in s for s in samples)
        assert all("future_target" in s for s in samples)
        assert all(s["past_target"].shape == (512, 1) for s in samples)
        assert all(s["future_target"].shape == (256, 1) for s in samples)

    def test_no_shards_raises(self) -> None:
        store = MockS3Store({})
        config = GiftEvalPretrainConfig(
            bucket="test",
            prefix="empty/",
            seed=42,
        )
        ds = GiftEvalPretrainDataset(config)
        ds._store = store

        with pytest.raises(RuntimeError, match="No parquet shards"):
            next(iter(ds))

    def test_corrupt_shard_resilience(self) -> None:
        """A mix of corrupt and valid shards should still yield samples."""
        good_rows = _sample_rows(5, target_length=1024)
        objects = {
            "pfx/part_000000.parquet": b"not-a-parquet",
            "pfx/part_000001.parquet": _make_parquet_bytes(good_rows),
        }
        store = MockS3Store(objects)
        config = GiftEvalPretrainConfig(
            bucket="test",
            prefix="pfx/",
            input_length=512,
            forecast_length=256,
            seed=42,
            prefetch_files=1,
        )
        ds = GiftEvalPretrainDataset(config)
        ds._store = store
        ds._shard_keys = sorted(k for k in objects if k.endswith(".parquet"))

        samples = []
        for sample in ds:
            samples.append(sample)
            if len(samples) >= 5:
                break

        assert len(samples) == 5


# ── Tests: build_gifteval_pretrain_dataloaders ───────────────────────────


class TestBuildGiftEvalPretrainDataloaders:
    def test_returns_dataset_bundle(self) -> None:
        """Integration test: builder returns a DatasetBundle with valid loaders."""
        good_rows = _sample_rows(20, target_length=1024)
        parquet_bytes = _make_parquet_bytes(good_rows)
        objects = {
            "pfx/part_000000.parquet": parquet_bytes,
        }

        mock_store = MockS3Store(objects)
        shard_keys = ["pfx/part_000000.parquet"]

        # Patch build_store to return our mock
        with patch.object(
            GiftEvalPretrainConfig, "build_store", return_value=mock_store,
        ):
            bundle = build_gifteval_pretrain_dataloaders(
                input_length=512,
                forecast_length=256,
                batch_size=4,
                seed=42,
                bucket="test",
                prefix="pfx/",
            )

        assert bundle.input_length == 512
        assert bundle.forecast_length == 256
        assert bundle.mase_scale == 1.0
        assert bundle.train is not None
        assert bundle.val is not None
        assert bundle.test is not None

        # Draw a batch from train
        batch = next(iter(bundle.train))
        assert batch["past_target"].shape == (4, 512, 1)
        assert batch["future_target"].shape == (4, 256, 1)
