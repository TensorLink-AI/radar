"""Tests for subnet.validator.training – two-stage deep training funnel."""

from __future__ import annotations

import asyncio
import sys
import types
import unittest
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional
from unittest.mock import AsyncMock, MagicMock, patch

# Stub heavy modules that services.eval.__init__ pulls in
_STUB_MODULES = [
    "pydantic",
    "torch", "torch.nn", "torch.nn.functional",
    "torch.utils", "torch.utils.data",
    "torch.fx", "torch.fx.experimental",
    "torch.fx.experimental.proxy_tensor",
    "torch.amp", "torch.cuda.amp", "torch.cuda",
]
for _mod in _STUB_MODULES:
    if _mod not in sys.modules:
        _stub = types.ModuleType(_mod)
        # pydantic needs a BaseModel class stub
        if _mod == "pydantic":
            _stub.BaseModel = type("BaseModel", (), {})
        sys.modules[_mod] = _stub

from subnet.config import SubnetConfig
from subnet.protocol.types import CandidateResult
from subnet.validator.training import (
    _PARENT_BASELINE_HOTKEY,
    _PARENT_BASELINE_UID,
    run_training_phase,
    _run_training_round,
)
from services.eval.remote_training.remote_types import (
    TrainingResult,
    TrainingStatus,
)


def _make_candidate(uid: int, name: str = "", model_code: str = "# code") -> CandidateResult:
    return CandidateResult(
        hotkey=f"5Miner{uid:03d}",
        uid=uid,
        name=name or f"model_{uid}",
        motivation="test motivation",
        model_code=model_code,
    )


def _make_training_result(
    status=TrainingStatus.SUCCEEDED,
    train_loss=0.3,
    test_loss=0.5,
) -> TrainingResult:
    return TrainingResult(
        job_id="test-job",
        status=status,
        metrics={"train_loss": train_loss, "test_loss": test_loss},
        stdout_tail="ok",
        budget_tier="small",
        wall_time_sec=10.0,
    )


class _MockStreamClient:
    """Mock training client with batch_train_streams and batch_train."""

    def __init__(self, results: Optional[List[TrainingResult]] = None):
        self._results = results or []

    async def batch_train_streams(self, model_codes, **kwargs):
        if self._results:
            return self._results[:len(model_codes)]
        return [
            _make_training_result(test_loss=0.3 + 0.1 * i)
            for i in range(len(model_codes))
        ]

    async def batch_train(self, specs, **kwargs):
        if self._results:
            return self._results[:len(specs)]
        return [
            _make_training_result(test_loss=0.3 + 0.1 * i)
            for i in range(len(specs))
        ]


def _run(coro):
    loop = asyncio.new_event_loop()
    try:
        return loop.run_until_complete(coro)
    finally:
        loop.close()


class TestRunTrainingPhase(unittest.TestCase):
    """Test run_training_phase – the two-stage funnel."""

    def test_empty_candidates_returns_empty(self):
        with patch("subnet.validator.training._build_training_client"):
            result = _run(run_training_phase([]))
        self.assertEqual(result, [])

    def test_candidates_survive_both_rounds(self):
        candidates = [_make_candidate(i) for i in range(3)]
        mock_client = _MockStreamClient()

        with patch("subnet.validator.training._build_training_client", return_value=mock_client):
            finalists = _run(run_training_phase(candidates))

        # Should have at most DEEP_TRAIN_TOP_L finalists
        self.assertLessEqual(len(finalists), SubnetConfig.DEEP_TRAIN_TOP_L)

    def test_parent_baseline_excluded_from_finalists(self):
        """Parent baseline trains but is excluded from returned finalists."""
        candidates = [_make_candidate(0), _make_candidate(1)]

        # Parent gets the best loss (0.1), but should not appear in finalists
        results = [
            _make_training_result(test_loss=0.3),
            _make_training_result(test_loss=0.4),
            _make_training_result(test_loss=0.1),  # parent baseline
        ]
        mock_client = _MockStreamClient(results=results)

        with patch("subnet.validator.training._build_training_client", return_value=mock_client), \
             patch.object(SubnetConfig, "INJECT_BEST_PARENT", True):
            finalists = _run(run_training_phase(
                candidates,
                parent_code="# parent code",
                parent_name="parent_v1",
            ))

        # No finalist should have the parent sentinel UID
        for f in finalists:
            self.assertNotEqual(f.uid, _PARENT_BASELINE_UID)
            self.assertNotEqual(f.hotkey, _PARENT_BASELINE_HOTKEY)


class TestRunTrainingRound(unittest.TestCase):
    """Test _run_training_round – single round logic."""

    def test_sorts_by_test_loss_ascending(self):
        candidates = [_make_candidate(i) for i in range(5)]
        results = [
            _make_training_result(test_loss=loss)
            for loss in [0.9, 0.1, 0.5, 0.3, 0.7]
        ]
        mock_client = _MockStreamClient(results=results)

        with patch("subnet.validator.training._build_training_client", return_value=mock_client):
            survivors = _run(_run_training_round(
                candidates=candidates,
                parent_baseline=None,
                budget="small_budget",
                budget_tier="small",
                timeout_sec=60,
                top_n=3,
                round_label="test",
            ))

        # Best 3 by loss: 0.1, 0.3, 0.5
        losses = [s.test_loss for s in survivors]
        self.assertEqual(len(survivors), 3)
        self.assertEqual(losses, sorted(losses))

    def test_failed_training_result_gets_none_loss(self):
        candidates = [_make_candidate(0)]
        results = [_make_training_result(status=TrainingStatus.FAILED)]
        mock_client = _MockStreamClient(results=results)

        with patch("subnet.validator.training._build_training_client", return_value=mock_client):
            survivors = _run(_run_training_round(
                candidates=candidates,
                parent_baseline=None,
                budget="small_budget",
                budget_tier="small",
                timeout_sec=60,
                top_n=5,
                round_label="test",
            ))

        # Should still return the candidate (with None loss → sorted to end)
        self.assertEqual(len(survivors), 1)

    def test_top_n_limits_output(self):
        candidates = [_make_candidate(i) for i in range(10)]
        mock_client = _MockStreamClient()

        with patch("subnet.validator.training._build_training_client", return_value=mock_client):
            survivors = _run(_run_training_round(
                candidates=candidates,
                parent_baseline=None,
                budget="small_budget",
                budget_tier="small",
                timeout_sec=60,
                top_n=3,
                round_label="test",
            ))

        self.assertEqual(len(survivors), 3)


if __name__ == "__main__":
    unittest.main()
