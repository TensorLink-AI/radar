"""Tests for the signal-aware zero-cost proxy module."""

import math
from typing import Any, Dict, Optional

import numpy as np
import pytest
import torch
import torch.nn as nn

from tasks.ts_foundation.zero_cost_proxies import (
    ProxyResult,
    _HookCapture,
    _find_deepest_block,
    borda_rank,
    build_calibration_input,
    compute_gradient_coherence,
    compute_local_contrast,
    compute_saliency,
    compute_sensitivity,
    compute_state_velocity,
    effective_rank,
    evaluate_candidate,
    make_ucb_variants,
    normalise_borda_scores,
)


# ── Tiny model that matches the TimeSeriesFoundationModel interface ───


class _TinyModel(nn.Module):
    """Minimal model matching the forward(past_y, ...) signature."""

    def __init__(self, d_model: int = 16, forecast_length: int = 256, n_quantiles: int = 3):
        super().__init__()
        self.proj = nn.Linear(1, d_model)
        self.out = nn.Linear(d_model, n_quantiles)
        self.forecast_length = forecast_length
        self.register_buffer(
            "quantile_levels", torch.tensor([0.1, 0.5, 0.9]),
        )

    def forward(
        self,
        past_y: torch.Tensor,
        past_cov=None,
        future_cov=None,
        static=None,
        y_future_tf=None,
        *,
        forecast_length=None,
        input_length=None,
    ) -> Dict[str, torch.Tensor]:
        H = forecast_length or self.forecast_length
        B = past_y.shape[0]
        h = self.proj(past_y)  # [B, T, d_model]
        # Pool over time -> expand to horizon
        pooled = h.mean(dim=1, keepdim=True).expand(B, H, -1)
        q = self.out(pooled)  # [B, H, Q]
        return {"quantiles": q, "quantile_levels": self.quantile_levels}


class _FrozenModel(nn.Module):
    """Model with no trainable parameters."""

    def __init__(self):
        super().__init__()
        self.w = nn.Parameter(torch.randn(4), requires_grad=False)

    def forward(self, past_y, **kw):
        return {"quantiles": past_y[:, :1, :1]}


class _SequentialModel(nn.Module):
    """Model with a Sequential block for hook testing."""

    def __init__(self, d_model: int = 8, n_blocks: int = 3):
        super().__init__()
        self.proj = nn.Linear(1, d_model)
        self.blocks = nn.Sequential(
            *[nn.Linear(d_model, d_model) for _ in range(n_blocks)]
        )
        self.out = nn.Linear(d_model, 3)

    def forward(self, past_y, **kw):
        h = self.proj(past_y)
        h = self.blocks(h)
        return {"quantiles": self.out(h)}


# ── UCB variants ─────────────────────────────────────────────────────


class TestMakeUcbVariants:
    def test_returns_correct_count(self):
        x = torch.randn(2, 64, 1)
        variants = make_ucb_variants(x, num_variants=5)
        assert len(variants) == 5

    def test_all_seven_variants(self):
        x = torch.randn(2, 64, 1)
        variants = make_ucb_variants(x, num_variants=7)
        assert len(variants) == 7

    def test_returns_tagged_tuples(self):
        x = torch.randn(2, 64, 1)
        variants = make_ucb_variants(x, num_variants=7)
        for item in variants:
            assert isinstance(item, tuple)
            assert len(item) == 2
            tensor, tag = item
            assert isinstance(tensor, torch.Tensor)
            assert isinstance(tag, str)

    def test_first_variant_is_identity(self):
        x = torch.randn(2, 64, 1)
        variants = make_ucb_variants(x, num_variants=3)
        tensor, tag = variants[0]
        assert torch.equal(tensor, x)
        assert tag == "identity"

    def test_single_variant(self):
        x = torch.randn(2, 64, 1)
        variants = make_ucb_variants(x, num_variants=1)
        assert len(variants) == 1

    def test_shapes_preserved(self):
        x = torch.randn(4, 128, 3)
        variants = make_ucb_variants(x, num_variants=7)
        for tensor, tag in variants:
            assert tensor.shape == x.shape

    def test_step_variant_is_binary(self):
        x = torch.randn(2, 64, 1)
        variants = make_ucb_variants(x, num_variants=7)
        step_variants = [(t, tag) for t, tag in variants if tag == "step"]
        assert len(step_variants) == 1
        step_tensor = step_variants[0][0]
        # First half should be zeros, second half should be ones
        mid = 64 // 2
        assert step_tensor[:, :mid, :].abs().max() == 0.0
        assert (step_tensor[:, mid:, :] == 1.0).all()

    def test_impulse_variant_has_spike(self):
        x = torch.randn(2, 64, 1)
        variants = make_ucb_variants(x, num_variants=7)
        impulse_variants = [(t, tag) for t, tag in variants if tag == "impulse"]
        assert len(impulse_variants) == 1
        impulse_tensor = impulse_variants[0][0]
        mid = 64 // 2
        # Spike at midpoint
        assert impulse_tensor[:, mid, :].abs().max() > 0.0
        # Zeros elsewhere
        assert impulse_tensor[:, :mid, :].abs().max() == 0.0

    def test_tags_are_correct(self):
        x = torch.randn(2, 64, 1)
        variants = make_ucb_variants(x, num_variants=7)
        tags = [tag for _, tag in variants]
        assert tags == ["identity", "jitter", "dropout", "scale", "roll", "step", "impulse"]


# ── Calibration input ────────────────────────────────────────────────


class TestBuildCalibrationInput:
    def test_shapes(self):
        cal = build_calibration_input(
            batch_size=2, input_length=64, channels=1, forecast_length=32,
        )
        assert cal["past_y"].shape == (2, 64, 1)
        assert cal["y_future_tf"].shape == (2, 32, 1)
        assert cal["forecast_length"] == 32
        assert cal["input_length"] == 64

    def test_not_constant(self):
        cal = build_calibration_input(batch_size=4, input_length=64)
        assert cal["past_y"].std() > 0.01


# ── Hook infrastructure ──────────────────────────────────────────────


class TestFindDeepestBlock:
    def test_finds_sequential_last_child(self):
        model = _SequentialModel(d_model=8, n_blocks=3)
        target = _find_deepest_block(model)
        assert target is not None
        # Should be the last child of the Sequential
        children = list(model.blocks.children())
        assert target is children[-1]

    def test_returns_none_for_flat_model(self):
        """A model with just two Linear layers and no Sequential/block."""
        model = nn.Sequential(nn.Linear(4, 4))
        # nn.Sequential with <2 children should not match
        target = _find_deepest_block(model)
        assert target is None

    def test_finds_transformer_layer(self):
        encoder_layer = nn.TransformerEncoderLayer(d_model=16, nhead=2, batch_first=True)
        model = nn.TransformerEncoder(encoder_layer, num_layers=2)
        target = _find_deepest_block(model)
        assert target is not None
        assert isinstance(target, (nn.TransformerEncoderLayer, nn.Module))


class TestHookCapture:
    def test_captures_tensor_output(self):
        cap = _HookCapture()
        dummy_module = nn.Linear(4, 4)
        output = torch.randn(2, 4)
        cap(dummy_module, None, output)
        assert cap.output is not None
        assert cap.output.shape == (2, 4)

    def test_captures_from_tuple(self):
        cap = _HookCapture()
        dummy_module = nn.Linear(4, 4)
        output = (torch.randn(2, 4), torch.randn(2, 4))
        cap(dummy_module, None, output)
        assert cap.output is not None
        assert cap.output.shape == (2, 4)

    def test_detaches_output(self):
        cap = _HookCapture()
        dummy_module = nn.Linear(4, 4)
        output = torch.randn(2, 4, requires_grad=True)
        cap(dummy_module, None, output)
        assert not cap.output.requires_grad


# ── Effective rank ───────────────────────────────────────────────────


class TestEffectiveRank:
    def test_identity_matrix_high_rank(self):
        x = torch.eye(8).unsqueeze(0)  # [1, 8, 8]
        r = effective_rank(x)
        assert r > 5.0  # Should be close to 8

    def test_rank_one_tensor(self):
        x = torch.ones(4, 16, 1)
        r = effective_rank(x)
        assert r == pytest.approx(1.0, abs=0.5)

    def test_handles_empty(self):
        x = torch.randn(1, 1, 1)
        r = effective_rank(x)
        assert r == 1.0


# ── Grad-Saliency ────────────────────────────────────────────────────


class TestComputeSaliency:
    def test_positive_for_trained_model(self):
        model = _TinyModel(d_model=8, forecast_length=4)
        batch = build_calibration_input(2, 16, 1, 4)
        s = compute_saliency(model, batch, torch.device("cpu"))
        assert s >= 0.0

    def test_zero_for_frozen(self):
        model = _FrozenModel()
        batch = {"past_y": torch.randn(2, 16, 1)}
        s = compute_saliency(model, batch, torch.device("cpu"))
        assert s == 0.0


# ── Sensitivity (VJP profile) ────────────────────────────────────────


class TestComputeSensitivity:
    def test_returns_float_and_bool(self):
        model = _TinyModel(d_model=8, forecast_length=4)
        batch = build_calibration_input(2, 16, 1, 4)
        logn, ok = compute_sensitivity(model, batch, torch.device("cpu"))
        assert isinstance(logn, float)
        assert isinstance(ok, bool)

    def test_finite(self):
        model = _TinyModel(d_model=8, forecast_length=4)
        batch = build_calibration_input(2, 16, 1, 4)
        logn, _ = compute_sensitivity(model, batch, torch.device("cpu"))
        assert np.isfinite(logn)


# ── Gradient coherence ───────────────────────────────────────────────


class TestGradientCoherence:
    def test_in_range(self):
        model = _TinyModel(d_model=8, forecast_length=4)
        batch = build_calibration_input(4, 16, 1, 4)
        c = compute_gradient_coherence(model, batch, torch.device("cpu"))
        assert 0.0 <= c <= 1.0

    def test_frozen_returns_zero(self):
        model = _FrozenModel()
        batch = {"past_y": torch.randn(4, 16, 1)}
        c = compute_gradient_coherence(model, batch, torch.device("cpu"))
        assert c == 0.0


# ── State velocity ───────────────────────────────────────────────────


class TestStateVelocity:
    def test_positive_for_varying_signal(self):
        t = torch.randn(2, 32, 4)
        v = compute_state_velocity(t)
        assert v > 0.0

    def test_zero_for_constant(self):
        t = torch.ones(2, 32, 4)
        v = compute_state_velocity(t)
        assert v == pytest.approx(0.0, abs=1e-5)

    def test_wrong_ndim(self):
        t = torch.randn(32, 4)
        assert compute_state_velocity(t) == 0.0


# ── Local contrast ───────────────────────────────────────────────────


class TestLocalContrast:
    def test_positive(self):
        t = torch.randn(2, 32, 4).abs() + 0.1
        c = compute_local_contrast(t)
        assert c > 0.0

    def test_wrong_ndim(self):
        assert compute_local_contrast(torch.randn(16)) == 0.0


# ── evaluate_candidate (integration) ─────────────────────────────────


class TestEvaluateCandidate:
    def test_pass_status(self):
        model = _TinyModel(d_model=8, forecast_length=4)
        result = evaluate_candidate(
            model,
            input_length=16,
            forecast_length=4,
            batch_size=2,
            num_variants=3,
            name="tiny",
        )
        assert result.status == "PASS"
        assert result.param_count > 0
        assert result.trainable_params > 0

    def test_skip_no_grad(self):
        model = _FrozenModel()
        result = evaluate_candidate(
            model,
            input_length=16,
            forecast_length=4,
            batch_size=2,
            num_variants=3,
            name="frozen",
        )
        assert result.status == "SKIP_NO_GRAD"

    def test_metrics_populated(self):
        model = _TinyModel(d_model=16, forecast_length=4)
        result = evaluate_candidate(
            model,
            input_length=32,
            forecast_length=4,
            batch_size=2,
            num_variants=7,
            name="test",
        )
        assert result.eff_rank > 0.0
        assert np.isfinite(result.saliency_per_param)
        assert np.isfinite(result.sensitivity_log_norm)
        assert np.isfinite(result.deep_collapse_ratio)

    def test_deep_rep_source_populated(self):
        model = _TinyModel(d_model=8, forecast_length=4)
        result = evaluate_candidate(
            model, input_length=16, forecast_length=4,
            batch_size=2, num_variants=3,
        )
        assert result.deep_rep_source in ("hook", "output_fallback")

    def test_sensitivity_ok_rate_populated(self):
        model = _TinyModel(d_model=8, forecast_length=4)
        result = evaluate_candidate(
            model, input_length=16, forecast_length=4,
            batch_size=2, num_variants=3,
        )
        assert 0.0 <= result.sensitivity_ok_rate <= 1.0

    def test_step_impulse_with_seven_variants(self):
        """With 7 variants, step/impulse probes should produce velocity/contrast."""
        model = _TinyModel(d_model=8, forecast_length=4)
        result = evaluate_candidate(
            model,
            input_length=16,
            forecast_length=4,
            batch_size=2,
            num_variants=7,
            name="full",
        )
        assert result.status == "PASS"
        # With step and impulse probes, these should be computed
        assert np.isfinite(result.state_velocity)
        assert np.isfinite(result.local_contrast)

    def test_to_dict(self):
        model = _TinyModel(d_model=8, forecast_length=4)
        result = evaluate_candidate(
            model, input_length=16, forecast_length=4,
            batch_size=2, num_variants=3,
        )
        d = result.to_dict()
        assert "eff_rank" in d
        assert "saliency_per_param" in d
        assert "sensitivity_log_norm" in d
        assert "deep_rep_source" in d
        assert "sensitivity_ok_rate" in d
        assert "status" in d

    def test_hook_with_sequential_model(self):
        """Model with Sequential should use hook-based deep rep."""
        model = _SequentialModel(d_model=8, n_blocks=3)
        result = evaluate_candidate(
            model, input_length=16, forecast_length=4,
            batch_size=2, num_variants=3,
        )
        assert result.deep_rep_source == "hook"


# ── Borda ranking ────────────────────────────────────────────────────


class TestBordaRank:
    def _make_results(self, n: int = 3) -> list:
        results = []
        for i in range(n):
            r = ProxyResult(
                name=f"model_{i}",
                status="PASS",
                eff_rank=float(i + 1),
                deep_collapse_ratio=1.0 + 0.1 * i,
                saliency_per_param=float(n - i),
                sensitivity_log_norm=0.1 * i,
                grad_coherence=float(n - i) / n,
                state_velocity=float(i + 1),
                local_contrast=float(i + 1),
                trainable_params=(i + 1) * 1000,
            )
            results.append(r)
        return results

    def test_returns_sorted(self):
        results = self._make_results(5)
        ranked = borda_rank(results)
        scores = [s for _, s in ranked]
        assert scores == sorted(scores)

    def test_normalise_bounds(self):
        results = self._make_results(4)
        ranked = borda_rank(results)
        normed = normalise_borda_scores(ranked)
        scores = [s for _, s in normed]
        assert max(scores) == pytest.approx(1.0)
        assert all(0.0 <= s <= 1.0 for s in scores)

    def test_single_candidate(self):
        results = self._make_results(1)
        ranked = borda_rank(results)
        normed = normalise_borda_scores(ranked)
        assert len(normed) == 1
        assert normed[0][1] == pytest.approx(1.0)

    def test_skips_failed(self):
        results = self._make_results(3)
        results[1].status = "FAIL"
        ranked = borda_rank(results)
        passing_names = {r.name for r, _ in ranked}
        assert "model_1" not in passing_names

    def test_empty_input(self):
        ranked = borda_rank([])
        assert ranked == []
        normed = normalise_borda_scores([])
        assert normed == []

    def test_all_failed_returns_zero_scores(self):
        """When every candidate fails, normalise must return 0.0 (not NaN)."""
        results = self._make_results(3)
        for r in results:
            r.status = "FAIL"
        ranked = borda_rank(results)
        # borda_rank returns inf for all-failed
        assert all(s == float("inf") for _, s in ranked)
        normed = normalise_borda_scores(ranked)
        scores = [s for _, s in normed]
        # All scores must be finite (0.0), not NaN
        assert all(np.isfinite(s) for s in scores)
        assert all(s == 0.0 for s in scores)

    def test_reliability_penalty_output_fallback(self):
        """Candidates with output_fallback deep_rep_source get penalised."""
        results = self._make_results(3)
        results[0].deep_rep_source = "hook"
        results[1].deep_rep_source = "output_fallback"
        results[2].deep_rep_source = "hook"
        ranked = borda_rank(results)
        # The output_fallback candidate should be penalised (higher score)
        fallback_score = None
        hook_scores = []
        for r, s in ranked:
            if r.deep_rep_source == "output_fallback":
                fallback_score = s
            else:
                hook_scores.append(s)
        assert fallback_score is not None
        # Fallback should have at least some penalty applied
        # (not necessarily worst, but penalised)

    def test_sensitivity_ok_rate_penalty(self):
        """Candidates with low sensitivity_ok_rate get penalised."""
        results = self._make_results(3)
        results[0].sensitivity_ok_rate = 1.0
        results[1].sensitivity_ok_rate = 0.0  # Low rate
        results[2].sensitivity_ok_rate = 1.0
        ranked = borda_rank(results)
        # Low sensitivity_ok_rate candidate should be penalised

    def test_boost_is_capped(self):
        """Verify huge param models don't get unlimited boost."""
        results = self._make_results(2)
        results[0].trainable_params = 100
        results[1].trainable_params = 10_000_000_000  # 10B params
        # Should not crash and boost should be capped
        ranked = borda_rank(results)
        assert len(ranked) == 2
        scores = [s for _, s in ranked]
        assert all(np.isfinite(s) for s in scores)
