"""Tests for subnet scoring and weight computation."""

import pytest
from subnet.validator.scoring import compute_weights, MAX_ABSENT_EPOCHS
from subnet.protocol.types import CandidateResult


class TestComputeWeights:
    """Test the compute_weights function."""

    def _make_result(self, uid: int, test_loss: float, name: str = "") -> CandidateResult:
        """Helper to create a CandidateResult with test_loss."""
        return CandidateResult(
            hotkey=f"hotkey_{uid}",
            uid=uid,
            name=name or f"model_{uid}",
            motivation="test",
            model_code="# test code",
            test_loss=test_loss,
            constraints_satisfied=True,
        )

    def test_empty_results_returns_empty_weights(self):
        """Empty results should return empty weights."""
        ema_scores = {}
        weights = compute_weights([], ema_scores)
        assert weights == {}

    def test_single_result_gets_full_weight(self):
        """Single result should get weight of 1.0."""
        results = [self._make_result(uid=1, test_loss=0.1)]
        ema_scores = {}
        weights = compute_weights(results, ema_scores)

        assert len(weights) == 1
        assert 1 in weights
        assert abs(weights[1] - 1.0) < 1e-6

    def test_lower_loss_gets_higher_weight(self):
        """Lower test loss should result in higher weight."""
        results = [
            self._make_result(uid=1, test_loss=0.1),  # Better
            self._make_result(uid=2, test_loss=0.5),  # Worse
        ]
        ema_scores = {}
        weights = compute_weights(results, ema_scores)

        assert len(weights) == 2
        assert weights[1] > weights[2], "Lower loss should have higher weight"
        assert abs(sum(weights.values()) - 1.0) < 1e-6, "Weights should sum to 1"

    def test_ema_updates_in_place(self):
        """EMA scores dict should be updated in place."""
        results = [self._make_result(uid=1, test_loss=0.1)]
        ema_scores = {}

        compute_weights(results, ema_scores)

        assert 1 in ema_scores
        assert ema_scores[1] > 0  # Score should be positive

    def test_ema_builds_reputation_over_time(self):
        """Repeated good performance should build EMA reputation."""
        ema_scores = {}

        # First epoch
        results1 = [self._make_result(uid=1, test_loss=0.1)]
        compute_weights(results1, ema_scores)
        first_ema = ema_scores[1]

        # Second epoch (same good performance)
        results2 = [self._make_result(uid=1, test_loss=0.1)]
        compute_weights(results2, ema_scores)
        second_ema = ema_scores[1]

        # EMA should be similar (converging)
        assert abs(second_ema - first_ema) < 0.5

    def test_absent_uid_ema_decays(self):
        """Absent UIDs should have their EMA decayed."""
        ema_scores = {1: 0.9, 2: 0.8}  # Pre-existing scores

        # Only uid=1 participates this epoch
        results = [self._make_result(uid=1, test_loss=0.1)]
        compute_weights(results, ema_scores)

        # uid=2's EMA should have decayed
        assert ema_scores[2] < 0.8

    def test_stale_uids_are_pruned(self):
        """UIDs absent for too long should be pruned."""
        ema_scores = {1: 0.9, 2: 0.8}
        absent_counts = {1: 0, 2: MAX_ABSENT_EPOCHS}  # uid=2 at prune threshold

        # Only uid=1 participates
        results = [self._make_result(uid=1, test_loss=0.1)]
        compute_weights(results, ema_scores, absent_counts)

        # uid=2 should be pruned (exceeded MAX_ABSENT_EPOCHS)
        assert 2 not in ema_scores
        assert 2 not in absent_counts

    def test_weights_only_for_active_uids(self):
        """Weights should only be computed for active (participating) UIDs."""
        ema_scores = {1: 0.9, 2: 0.8, 3: 0.7}  # 3 UIDs with history

        # Only uid=1 and uid=2 participate this epoch
        results = [
            self._make_result(uid=1, test_loss=0.1),
            self._make_result(uid=2, test_loss=0.2),
        ]
        weights = compute_weights(results, ema_scores)

        # Only active UIDs should have weights
        assert 1 in weights
        assert 2 in weights
        assert 3 not in weights  # Not active this epoch

    def test_infinite_loss_gets_minimum_score(self):
        """Infinite/invalid loss should get minimum score."""
        results = [
            self._make_result(uid=1, test_loss=0.1),
            self._make_result(uid=2, test_loss=float("inf")),
        ]
        ema_scores = {}
        weights = compute_weights(results, ema_scores)

        assert weights[1] > weights[2]

    def test_negative_loss_treated_as_invalid(self):
        """Negative loss should be treated as invalid."""
        results = [
            self._make_result(uid=1, test_loss=0.1),
            self._make_result(uid=2, test_loss=-0.5),  # Invalid
        ]
        ema_scores = {}
        weights = compute_weights(results, ema_scores)

        # Both should get weights, but negative loss should be penalized
        assert 1 in weights
        assert 2 in weights

    def test_none_loss_treated_as_invalid(self):
        """None loss should be treated as invalid."""
        result = self._make_result(uid=1, test_loss=0.1)
        result.test_loss = None

        results = [result]
        ema_scores = {}
        weights = compute_weights(results, ema_scores)

        assert 1 in weights

    def test_final_score_populated(self):
        """CandidateResult.final_score should be populated."""
        results = [self._make_result(uid=1, test_loss=0.1)]
        ema_scores = {}
        compute_weights(results, ema_scores)

        assert results[0].final_score > 0


class TestScoreTransformation:
    """Test the loss-to-score transformation."""

    def test_zero_loss_gives_max_score(self):
        """Zero loss should give score of 1.0."""
        # score = 1 / (1 + loss) = 1 / (1 + 0) = 1.0
        result = CandidateResult(
            hotkey="h1", uid=1, name="m1", motivation="", model_code="",
            test_loss=0.0, constraints_satisfied=True,
        )
        ema_scores = {}
        compute_weights([result], ema_scores)

        # The transformation is score = 1 / (1 + loss)
        # For loss=0, score should be close to 1.0
        assert result.final_score > 0.99

    def test_high_loss_gives_low_score(self):
        """High loss should give low score."""
        result = CandidateResult(
            hotkey="h1", uid=1, name="m1", motivation="", model_code="",
            test_loss=10.0, constraints_satisfied=True,
        )
        ema_scores = {}
        compute_weights([result], ema_scores)

        # score = 1 / (1 + 10) = 0.0909...
        assert result.final_score < 0.15
