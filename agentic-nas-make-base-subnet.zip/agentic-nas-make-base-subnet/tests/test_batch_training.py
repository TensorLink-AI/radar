"""Tests for batch training via BasilicaTrainingClient and the validator
training phase.

These tests mock ``torch`` and other heavy dependencies so they can run
in a lightweight CI environment without GPU libraries installed.
"""

from __future__ import annotations

import asyncio
import sys
import time
import types
from dataclasses import dataclass, field
from typing import Any, Dict, List
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

# ---------------------------------------------------------------------------
# Stub out heavy dependencies that are transitively imported through
# services.eval.__init__ -> interface -> shape_sanity -> torch.
# This lets us import the remote_training subpackage in isolation.
# ---------------------------------------------------------------------------

_MOCK_MODULES = [
    "torch", "torch.nn", "torch.nn.functional", "torch.utils",
    "torch.utils.data", "torch.cuda", "torch.fx",
    "torch.fx.experimental", "torch.fx.experimental.proxy_tensor",
    "torch.cuda.amp", "torch.nn.utils",
]

_originals: dict[str, types.ModuleType] = {}
for _mod_name in _MOCK_MODULES:
    if _mod_name not in sys.modules:
        _mock = types.ModuleType(_mod_name)
        # Give common attributes so `from torch import Tensor` doesn't crash
        _mock.__dict__.setdefault("Tensor", MagicMock)
        _mock.__dict__.setdefault("nn", MagicMock())
        _mock.__dict__.setdefault("device", MagicMock)
        sys.modules[_mod_name] = _mock

# Now safe to import the modules under test
from services.eval.remote_training.remote_types import (  # noqa: E402
    BudgetTier,
    TrainingJobSpec,
    TrainingJobMetadata,
    TrainingResult,
    TrainingStatus,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_spec(job_id: str = "test-job", code: str = "print('hi')") -> TrainingJobSpec:
    return TrainingJobSpec(
        metadata=TrainingJobMetadata(task="ts", eval_type="small_budget"),
        dataset_spec={},
        model_code_content=code,
        job_id=job_id,
        budget_tier="small",
        timeout_sec=60.0,
    )


def _make_result(
    job_id: str = "test-job",
    status: TrainingStatus = TrainingStatus.SUCCEEDED,
    test_loss: float = 0.5,
    train_loss: float = 0.6,
    wall_time: float = 10.0,
) -> TrainingResult:
    return TrainingResult(
        job_id=job_id,
        status=status,
        metrics={"test_loss": test_loss, "train_loss": train_loss},
        stdout_tail="",
        budget_tier=BudgetTier.SMALL,
        wall_time_sec=wall_time,
        updated_at=time.time(),
    )


# ---------------------------------------------------------------------------
# BasilicaTrainingClient.batch_train (multi-pod)
# ---------------------------------------------------------------------------


class TestBatchTrain:
    """Tests for BasilicaTrainingClient.batch_train()."""

    @pytest.fixture
    def client(self):
        """Return a BasilicaTrainingClient with mocked credentials."""
        with patch.dict(
            "os.environ",
            {"BASILICA_API_TOKEN": "fake-token", "BASILICA_DOCKER_IMAGE": "img:latest"},
        ):
            with patch(
                "services.eval.remote_training.client.BasilicaTrainingClient._validate_credentials"
            ):
                from services.eval.remote_training.client import BasilicaTrainingClient
                return BasilicaTrainingClient(
                    api_token="fake-token",
                    docker_image="img:latest",
                    validate_credentials=False,
                )

    @pytest.mark.asyncio
    async def test_batch_train_empty_list(self, client):
        results = await client.batch_train([])
        assert results == []

    @pytest.mark.asyncio
    async def test_batch_train_preserves_order(self, client):
        """Results come back in the same order as input specs."""
        specs = [_make_spec(job_id=f"job-{i}") for i in range(5)]
        expected = [_make_result(job_id=f"job-{i}", test_loss=float(i)) for i in range(5)]

        call_count = 0

        async def _mock_train(spec):
            nonlocal call_count
            idx = int(spec.job_id.split("-")[1])
            # Introduce varying delays to verify ordering is maintained
            await asyncio.sleep(0.01 * (5 - idx))
            call_count += 1
            return expected[idx]

        client.train = _mock_train
        results = await client.batch_train(specs, max_concurrency=5)

        assert len(results) == 5
        assert call_count == 5
        for i, r in enumerate(results):
            assert r.job_id == f"job-{i}"
            assert r.metrics["test_loss"] == float(i)

    @pytest.mark.asyncio
    async def test_batch_train_respects_concurrency_limit(self, client):
        """At most max_concurrency jobs run simultaneously."""
        max_concurrent_seen = 0
        currently_running = 0
        lock = asyncio.Lock()

        async def _mock_train(spec):
            nonlocal max_concurrent_seen, currently_running
            async with lock:
                currently_running += 1
                if currently_running > max_concurrent_seen:
                    max_concurrent_seen = currently_running
            await asyncio.sleep(0.05)
            async with lock:
                currently_running -= 1
            return _make_result(job_id=spec.job_id)

        client.train = _mock_train

        specs = [_make_spec(job_id=f"job-{i}") for i in range(8)]
        results = await client.batch_train(specs, max_concurrency=2)

        assert len(results) == 8
        assert max_concurrent_seen <= 2

    @pytest.mark.asyncio
    async def test_batch_train_handles_individual_failures(self, client):
        """A failure in one job doesn't cancel the rest."""
        async def _mock_train(spec):
            if spec.job_id == "job-1":
                raise RuntimeError("GPU OOM")
            return _make_result(job_id=spec.job_id)

        client.train = _mock_train

        specs = [_make_spec(job_id=f"job-{i}") for i in range(3)]
        results = await client.batch_train(specs, max_concurrency=3)

        assert len(results) == 3
        assert results[0].status == TrainingStatus.SUCCEEDED
        assert results[1].status == TrainingStatus.FAILED
        assert "GPU OOM" in results[1].stdout_tail
        assert results[2].status == TrainingStatus.SUCCEEDED

    @pytest.mark.asyncio
    async def test_batch_train_all_fail(self, client):
        """Even if all jobs fail, we get results for each."""
        async def _mock_train(spec):
            raise RuntimeError("cluster down")

        client.train = _mock_train

        specs = [_make_spec(job_id=f"job-{i}") for i in range(3)]
        results = await client.batch_train(specs, max_concurrency=3)

        assert len(results) == 3
        assert all(r.status == TrainingStatus.FAILED for r in results)


# ---------------------------------------------------------------------------
# BasilicaTrainingClient.batch_train_streams (single-pod CUDA streams)
# ---------------------------------------------------------------------------


class TestBatchTrainStreams:
    """Tests for BasilicaTrainingClient.batch_train_streams()."""

    @pytest.fixture
    def client(self):
        with patch.dict(
            "os.environ",
            {"BASILICA_API_TOKEN": "fake-token", "BASILICA_DOCKER_IMAGE": "img:latest"},
        ):
            with patch(
                "services.eval.remote_training.client.BasilicaTrainingClient._validate_credentials"
            ):
                from services.eval.remote_training.client import BasilicaTrainingClient
                return BasilicaTrainingClient(
                    api_token="fake-token",
                    docker_image="img:latest",
                    validate_credentials=False,
                )

    @pytest.mark.asyncio
    async def test_batch_train_streams_empty_list(self, client):
        results = await client.batch_train_streams([])
        assert results == []

    @pytest.mark.asyncio
    async def test_batch_train_streams_success(self, client):
        """Successful batch stream training returns per-model results."""
        # Mock the deployment and HTTP call
        mock_env = MagicMock()
        mock_env.url = "http://test-pod:8000"
        mock_env.cleanup = AsyncMock()

        client._deploy_training_container = AsyncMock(
            return_value=("http://test-pod:8000", mock_env)
        )
        client._check_container_health = AsyncMock()
        client._cleanup_deployment = AsyncMock()

        # Mock httpx response
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.raise_for_status = MagicMock()
        mock_response.json.return_value = {
            "status": "succeeded",
            "metrics": {
                "batch_results": [
                    {"train": {"loss": 0.3}, "validation": {"quantile_loss": 0.1}},
                    {"train": {"loss": 0.5}, "validation": {"quantile_loss": 0.2}},
                    None,  # third model failed to load
                ],
            },
            "wall_time_sec": 120.0,
        }

        mock_http_client = MagicMock()
        mock_http_client.__aenter__ = AsyncMock(return_value=mock_http_client)
        mock_http_client.__aexit__ = AsyncMock(return_value=None)
        mock_http_client.post = AsyncMock(return_value=mock_response)

        # httpx is imported inside batch_train_streams, so patch via sys.modules
        mock_httpx = MagicMock()
        mock_httpx.AsyncClient.return_value = mock_http_client
        mock_httpx.Timeout = MagicMock()

        with patch.dict("sys.modules", {"httpx": mock_httpx}):
            results = await client.batch_train_streams(
                ["code_a", "code_b", "code_c"],
                budget_tier="small",
                timeout_sec=1800.0,
            )

        assert len(results) == 3
        # First two succeeded
        assert results[0].status == TrainingStatus.SUCCEEDED
        assert results[0].metrics["train"]["loss"] == 0.3
        assert results[1].status == TrainingStatus.SUCCEEDED
        # Third failed to load
        assert results[2].status == TrainingStatus.FAILED
        assert "failed to load" in results[2].stdout_tail

    @pytest.mark.asyncio
    async def test_batch_train_streams_deploy_failure(self, client):
        """If pod deployment fails, all models get FAILED results."""
        client._deploy_training_container = AsyncMock(
            side_effect=RuntimeError("quota exceeded")
        )
        client._cleanup_deployment = AsyncMock()

        results = await client.batch_train_streams(
            ["code_a", "code_b"],
            budget_tier="small",
        )

        assert len(results) == 2
        assert all(r.status == TrainingStatus.FAILED for r in results)
        assert "quota exceeded" in results[0].stdout_tail

    @pytest.mark.asyncio
    async def test_batch_train_streams_pads_missing_results(self, client):
        """If the server returns fewer results than models sent, pad with FAILED."""
        mock_env = MagicMock()
        mock_env.url = "http://test-pod:8000"
        mock_env.cleanup = AsyncMock()

        client._deploy_training_container = AsyncMock(
            return_value=("http://test-pod:8000", mock_env)
        )
        client._check_container_health = AsyncMock()
        client._cleanup_deployment = AsyncMock()

        # Server returns only 1 result for 3 models
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.raise_for_status = MagicMock()
        mock_response.json.return_value = {
            "status": "succeeded",
            "metrics": {
                "batch_results": [
                    {"train": {"loss": 0.3}},
                ],
            },
            "wall_time_sec": 60.0,
        }

        mock_http_client = MagicMock()
        mock_http_client.__aenter__ = AsyncMock(return_value=mock_http_client)
        mock_http_client.__aexit__ = AsyncMock(return_value=None)
        mock_http_client.post = AsyncMock(return_value=mock_response)

        mock_httpx = MagicMock()
        mock_httpx.AsyncClient.return_value = mock_http_client
        mock_httpx.Timeout = MagicMock()

        with patch.dict("sys.modules", {"httpx": mock_httpx}):
            results = await client.batch_train_streams(
                ["code_a", "code_b", "code_c"],
                budget_tier="small",
                timeout_sec=1800.0,
            )

        assert len(results) == 3
        assert results[0].status == TrainingStatus.SUCCEEDED
        # Padded entries are FAILED
        assert results[1].status == TrainingStatus.FAILED
        assert "Missing from batch" in results[1].stdout_tail
        assert results[2].status == TrainingStatus.FAILED


# ---------------------------------------------------------------------------
# run_training_phase (validator integration)
# ---------------------------------------------------------------------------


@dataclass
class FakeCandidateResult:
    """Minimal stand-in for CandidateResult for testing."""
    hotkey: str = ""
    uid: int = 0
    name: str = ""
    motivation: str = ""
    model_code: str = "print('model')"
    parent_id: int | None = None
    config: Dict[str, Any] = field(default_factory=dict)
    zero_cost_score: float | None = None
    zero_cost_details: Dict[str, Any] = field(default_factory=dict)
    param_count: int | None = None
    inference_latency_ms: float | None = None
    constraints_satisfied: bool = True
    train_metrics: Dict[str, Any] = field(default_factory=dict)
    train_loss: float | None = None
    test_loss: float | None = None
    analysis: Dict[str, Any] = field(default_factory=dict)
    model_diff: str = ""
    final_score: float = 0.0


class TestRunTrainingPhase:
    """Tests for the validator's run_training_phase()."""

    @pytest.mark.asyncio
    async def test_empty_candidates(self):
        from subnet.validator.training import run_training_phase
        result = await run_training_phase([])
        assert result == []

    @pytest.mark.asyncio
    async def test_streams_dispatches_all_candidates(self):
        """With TRAINING_USE_STREAMS=1 (default), all model codes go to
        batch_train_streams on a single pod."""
        mock_client = MagicMock()
        mock_client.batch_train_streams = AsyncMock(
            return_value=[
                _make_result(job_id="j0", test_loss=0.3, train_loss=0.4),
                _make_result(job_id="j1", test_loss=0.2, train_loss=0.3),
                _make_result(job_id="j2", test_loss=0.5, train_loss=0.6),
            ]
        )

        candidates = [
            FakeCandidateResult(uid=i, name=f"model-{i}", model_code=f"code-{i}")
            for i in range(3)
        ]

        with patch("subnet.validator.training._build_training_client", return_value=mock_client), \
             patch.dict("os.environ", {"TRAINING_USE_STREAMS": "1"}):
            from subnet.validator.training import run_training_phase
            finalists = await run_training_phase(candidates)

        # batch_train_streams was called (not batch_train)
        mock_client.batch_train_streams.assert_called_once()
        model_codes_arg = mock_client.batch_train_streams.call_args[0][0]
        assert model_codes_arg == ["code-0", "code-1", "code-2"]

        # Results sorted by test_loss ascending
        assert finalists[0].test_loss == 0.2
        assert finalists[1].test_loss == 0.3

    @pytest.mark.asyncio
    async def test_pods_fallback_when_streams_disabled(self):
        """With TRAINING_USE_STREAMS=0, falls back to multi-pod batch_train."""
        mock_client = MagicMock()
        mock_client.batch_train = AsyncMock(
            return_value=[
                _make_result(job_id="j0", test_loss=0.3, train_loss=0.4),
                _make_result(job_id="j1", test_loss=0.2, train_loss=0.3),
            ]
        )

        candidates = [
            FakeCandidateResult(uid=i, name=f"model-{i}", model_code=f"code-{i}")
            for i in range(2)
        ]

        with patch("subnet.validator.training._build_training_client", return_value=mock_client), \
             patch.dict("os.environ", {"TRAINING_USE_STREAMS": "0"}):
            from subnet.validator.training import run_training_phase
            finalists = await run_training_phase(candidates)

        # batch_train was called (not batch_train_streams)
        mock_client.batch_train.assert_called_once()
        specs_arg = mock_client.batch_train.call_args[0][0]
        assert len(specs_arg) == 2

    @pytest.mark.asyncio
    async def test_failed_training_gets_none_losses(self):
        """Candidates whose training failed get None losses."""
        mock_client = MagicMock()
        failed_result = _make_result(
            job_id="j0",
            status=TrainingStatus.FAILED,
            test_loss=0.0,
            train_loss=0.0,
        )
        # Override metrics to have no losses (simulating real failure)
        failed_result.metrics = {}
        mock_client.batch_train_streams = AsyncMock(return_value=[failed_result])

        candidates = [
            FakeCandidateResult(uid=0, name="broken", model_code="bad code")
        ]

        with patch("subnet.validator.training._build_training_client", return_value=mock_client), \
             patch.dict("os.environ", {"TRAINING_USE_STREAMS": "1"}):
            from subnet.validator.training import run_training_phase
            finalists = await run_training_phase(candidates)

        assert len(finalists) == 1
        assert finalists[0].train_loss is None
        assert finalists[0].test_loss is None
