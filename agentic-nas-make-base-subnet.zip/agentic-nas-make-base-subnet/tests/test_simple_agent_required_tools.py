"""Tests for SimpleAgent required_tools enforcement with JSON text extraction."""

import sys
import asyncio
from pathlib import Path
from typing import List, Dict, Any, Optional

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.append(str(ROOT))

from services.providers.simple_agent import (
    SimpleAgent,
    LLMProtocol,
    tool,
    extract_finish_json,
    RequiredToolsNotCalled,
)


class MockLLM(LLMProtocol):
    """Mock LLM that returns predefined responses."""

    def __init__(self, responses: List[Dict[str, Any]]):
        self.responses = list(responses)
        self.call_count = 0

    async def ainvoke(
        self,
        messages: List[Dict[str, Any]],
        tools: Optional[List[Dict]] = None,
    ) -> Dict[str, Any]:
        if self.call_count >= len(self.responses):
            # Fallback: return empty response
            return {"text": "", "tool_calls": []}
        response = self.responses[self.call_count]
        self.call_count += 1
        return response


@tool("A required tool that must be called")
def required_tool() -> str:
    return "SUCCESS"


@tool("An optional tool")
def optional_tool() -> str:
    return "done"


def test_extract_finish_json_detects_success():
    """Test that extract_finish_json correctly parses CodeChecker-style output."""
    text = '{"success": true}'
    result = extract_finish_json(text)
    assert result is not None
    assert result["success"] is True


def test_extract_finish_json_detects_name_motivation():
    """Test that extract_finish_json correctly parses Planner-style output."""
    text = '{"name": "MyModel", "motivation": "Improved attention"}'
    result = extract_finish_json(text)
    assert result is not None
    assert result["name"] == "MyModel"
    assert result["motivation"] == "Improved attention"


def test_required_tools_enforced_for_json_text_extraction():
    """
    Test that when model outputs JSON in text (bypassing done() tool),
    the required_tools check is still enforced.

    This is the core bug fix: previously, JSON text extraction would
    return immediately without checking required_tools.
    """
    # Mock LLM responses:
    # 1. First: model outputs finish JSON in text WITHOUT calling required_tool
    # 2. After rejection: model calls required_tool
    # 3. Then: model outputs finish JSON in text again
    responses = [
        # First response: JSON in text, but required_tool not called
        {"text": '{"success": true}', "tool_calls": []},
        # Second response: model calls the required tool after rejection
        {
            "text": "",
            "tool_calls": [
                {
                    "id": "call_1",
                    "function": {"name": "required_tool", "arguments": "{}"},
                }
            ],
        },
        # Third response: JSON in text again, now should be accepted
        {"text": '{"success": true}', "tool_calls": []},
    ]

    llm = MockLLM(responses)
    agent = SimpleAgent(
        llm=llm,
        instructions="Test agent",
        tools=[required_tool, optional_tool],
        required_tools=["required_tool"],
        max_iterations=10,
        include_done_tool=True,
    )

    result = asyncio.run(agent.run("Test prompt"))

    # Agent should complete successfully after required tool was called
    assert result is not None
    assert result.get("success") is True
    # LLM should have been called 3 times
    assert llm.call_count == 3


def test_required_tools_not_enforced_when_empty():
    """Test that JSON text extraction works normally when no required_tools."""
    responses = [
        # Model outputs finish JSON directly
        {"text": '{"success": true}', "tool_calls": []},
    ]

    llm = MockLLM(responses)
    agent = SimpleAgent(
        llm=llm,
        instructions="Test agent",
        tools=[optional_tool],
        required_tools=None,  # No required tools
        max_iterations=10,
        include_done_tool=True,
    )

    result = asyncio.run(agent.run("Test prompt"))

    # Should complete immediately
    assert result is not None
    assert result.get("success") is True
    assert llm.call_count == 1


def test_required_tools_enforced_for_done_tool():
    """Test that required_tools check also works for done() tool calls."""
    responses = [
        # Model calls done() without calling required_tool first
        {
            "text": "",
            "tool_calls": [
                {
                    "id": "call_1",
                    "function": {"name": "done", "arguments": '{"result": "done", "success": true}'},
                }
            ],
        },
        # After rejection, model calls required_tool
        {
            "text": "",
            "tool_calls": [
                {
                    "id": "call_2",
                    "function": {"name": "required_tool", "arguments": "{}"},
                }
            ],
        },
        # Then model calls done() again
        {
            "text": "",
            "tool_calls": [
                {
                    "id": "call_3",
                    "function": {"name": "done", "arguments": '{"result": "done", "success": true}'},
                }
            ],
        },
    ]

    llm = MockLLM(responses)
    agent = SimpleAgent(
        llm=llm,
        instructions="Test agent",
        tools=[required_tool],
        required_tools=["required_tool"],
        max_iterations=10,
        include_done_tool=True,
    )

    result = asyncio.run(agent.run("Test prompt"))

    # Agent should complete after required tool was called
    assert result is not None
    assert result.get("success") is True
    assert llm.call_count == 3


def test_multiple_required_tools():
    """Test that ALL required tools must be called."""

    @tool("Another required tool")
    def required_tool_2() -> str:
        return "SUCCESS"

    responses = [
        # Model outputs JSON with only one required tool called
        {"text": '{"success": true}', "tool_calls": []},
        # Model calls first required tool
        {
            "text": "",
            "tool_calls": [
                {
                    "id": "call_1",
                    "function": {"name": "required_tool", "arguments": "{}"},
                }
            ],
        },
        # Model tries JSON again, but still missing required_tool_2
        {"text": '{"success": true}', "tool_calls": []},
        # Model calls second required tool
        {
            "text": "",
            "tool_calls": [
                {
                    "id": "call_2",
                    "function": {"name": "required_tool_2", "arguments": "{}"},
                }
            ],
        },
        # Now JSON should be accepted
        {"text": '{"success": true}', "tool_calls": []},
    ]

    llm = MockLLM(responses)
    agent = SimpleAgent(
        llm=llm,
        instructions="Test agent",
        tools=[required_tool, required_tool_2],
        required_tools=["required_tool", "required_tool_2"],
        max_iterations=15,
        include_done_tool=True,
    )

    result = asyncio.run(agent.run("Test prompt"))

    assert result is not None
    assert result.get("success") is True
    # All 5 calls should have happened
    assert llm.call_count == 5
