"""Tests for subnet filtering phase."""

import pytest
from subnet.protocol.types import CandidateResult
from subnet.validator.filtering import _check_constraints


class TestCheckConstraints:
    """Test the _check_constraints function."""

    def _make_result(
        self,
        uid: int = 1,
        param_count: int = 1000,
        latency_ms: float = 10.0,
    ) -> CandidateResult:
        """Create a CandidateResult for testing."""
        return CandidateResult(
            hotkey=f"hotkey_{uid}",
            uid=uid,
            name=f"model_{uid}",
            motivation="test",
            model_code="# test",
            param_count=param_count,
            inference_latency_ms=latency_ms,
        )

    def test_passes_when_under_limits(self):
        """Should pass when all constraints are satisfied."""
        result = self._make_result(param_count=5000, latency_ms=25.0)
        constraints = {
            "max_params": 10000,
            "max_inference_latency_ms": 50.0,
        }

        assert _check_constraints(result, constraints) is True

    def test_fails_when_params_exceeded(self):
        """Should fail when param count exceeds limit."""
        result = self._make_result(param_count=15000, latency_ms=25.0)
        constraints = {
            "max_params": 10000,
            "max_inference_latency_ms": 50.0,
        }

        assert _check_constraints(result, constraints) is False

    def test_fails_when_latency_exceeded(self):
        """Should fail when latency exceeds limit."""
        result = self._make_result(param_count=5000, latency_ms=75.0)
        constraints = {
            "max_params": 10000,
            "max_inference_latency_ms": 50.0,
        }

        assert _check_constraints(result, constraints) is False

    def test_passes_at_exact_limits(self):
        """Should pass when exactly at limits."""
        result = self._make_result(param_count=10000, latency_ms=50.0)
        constraints = {
            "max_params": 10000,
            "max_inference_latency_ms": 50.0,
        }

        assert _check_constraints(result, constraints) is True

    def test_passes_when_no_constraints(self):
        """Should pass when no constraints specified."""
        result = self._make_result(param_count=999999, latency_ms=999.0)
        constraints = {}

        assert _check_constraints(result, constraints) is True

    def test_skips_check_when_result_has_none(self):
        """Should skip check when result field is None."""
        result = self._make_result()
        result.param_count = None
        result.inference_latency_ms = None

        constraints = {
            "max_params": 1000,
            "max_inference_latency_ms": 1.0,
        }

        # Should pass because we can't check None values
        assert _check_constraints(result, constraints) is True

    def test_partial_constraints(self):
        """Should only check constraints that are specified."""
        result = self._make_result(param_count=5000, latency_ms=100.0)

        # Only param constraint - latency should be ignored
        constraints = {"max_params": 10000}
        assert _check_constraints(result, constraints) is True

        # Only latency constraint - params should be ignored
        constraints = {"max_inference_latency_ms": 50.0}
        assert _check_constraints(result, constraints) is False


class TestConstraintEdgeCases:
    """Test edge cases in constraint checking."""

    def test_zero_param_limit(self):
        """Should handle zero param limit."""
        result = CandidateResult(
            hotkey="h", uid=1, name="m", motivation="", model_code="",
            param_count=1,
        )
        constraints = {"max_params": 0}

        assert _check_constraints(result, constraints) is False

    def test_zero_latency_limit(self):
        """Should handle zero latency limit."""
        result = CandidateResult(
            hotkey="h", uid=1, name="m", motivation="", model_code="",
            inference_latency_ms=0.1,
        )
        constraints = {"max_inference_latency_ms": 0.0}

        assert _check_constraints(result, constraints) is False

    def test_negative_values_in_result(self):
        """Should handle negative values gracefully."""
        result = CandidateResult(
            hotkey="h", uid=1, name="m", motivation="", model_code="",
            param_count=-100,  # Invalid but should not crash
            inference_latency_ms=-5.0,  # Invalid but should not crash
        )
        constraints = {
            "max_params": 1000,
            "max_inference_latency_ms": 50.0,
        }

        # Negative values are less than positive limits, so should pass
        assert _check_constraints(result, constraints) is True
