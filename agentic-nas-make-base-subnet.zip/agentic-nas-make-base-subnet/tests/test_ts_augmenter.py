"""Tests for the universal time-series augmenter and its GIFT loader integration.

Covers:
* UniversalTSAugmenter standalone (each challenge category)
* AugmentationConfig + augment_from_config
* GIFT loader integration (augmented vs unaugmented samples)
"""

from __future__ import annotations

import sys
from pathlib import Path
from typing import Any, Dict, List, Optional
from unittest.mock import MagicMock, patch

import numpy as np
import pytest
import torch

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from core.data.ts_augmenter import AugmentationConfig, UniversalTSAugmenter
from core.data.gift_loader import (
    GiftEvalDataset,
    _GiftEvalFineTuningDataset,
    _GiftEvalZeroShotDataset,
)


# ── UniversalTSAugmenter unit tests ────────────────────────────────────


class TestAugmenterBasics:
    def test_jitter_changes_values(self):
        aug = UniversalTSAugmenter(random_seed=0)
        x = np.sin(np.linspace(0, 4 * np.pi, 200))
        y = aug.jitter(x, sigma=0.1)
        assert y.shape == x.shape
        assert not np.allclose(x, y)

    def test_scale_preserves_shape(self):
        aug = UniversalTSAugmenter(random_seed=0)
        x = np.arange(50, dtype=float)
        y = aug.scale(x, sigma=0.2)
        assert y.shape == x.shape

    def test_affine_preserves_shape(self):
        aug = UniversalTSAugmenter(random_seed=0)
        x = np.arange(50, dtype=float)
        y = aug.affine(x)
        assert y.shape == x.shape

    def test_1d_required(self):
        aug = UniversalTSAugmenter(random_seed=0)
        with pytest.raises(ValueError, match="1D"):
            aug.jitter(np.zeros((5, 5)))


class TestTimeWarp:
    def test_basic(self):
        aug = UniversalTSAugmenter(random_seed=0)
        x = np.sin(np.linspace(0, 4 * np.pi, 100))
        y = aug.time_warp(x, sigma=0.3, knots=4)
        assert y.shape == x.shape
        assert not np.allclose(x, y)

    def test_short_series_passthrough(self):
        aug = UniversalTSAugmenter(random_seed=0)
        x = np.array([1.0, 2.0, 3.0])
        y = aug.time_warp(x)
        np.testing.assert_array_equal(x, y)


class TestHistoryCutout:
    @pytest.mark.parametrize("mode", ["interp", "hold", "noise", "zero"])
    def test_modes(self, mode):
        aug = UniversalTSAugmenter(random_seed=0)
        x = np.arange(100, dtype=float)
        y = aug.history_cutout(x, cut_frac=0.2, mode=mode)
        assert y.shape == x.shape
        # At least some values should differ
        assert not np.allclose(x, y)

    def test_unknown_mode_raises(self):
        aug = UniversalTSAugmenter(random_seed=0)
        with pytest.raises(ValueError, match="Unknown mode"):
            aug.history_cutout(np.arange(100, dtype=float), mode="bad")


class TestBlockPermute:
    def test_changes_order(self):
        aug = UniversalTSAugmenter(random_seed=0)
        x = np.arange(100, dtype=float)
        y = aug.block_permute(x, num_blocks=4)
        assert y.shape == x.shape
        # Same elements, possibly different order
        assert set(y.astype(int)) == set(x.astype(int))

    def test_short_series_passthrough(self):
        aug = UniversalTSAugmenter(random_seed=0)
        x = np.array([1.0, 2.0])
        y = aug.block_permute(x, num_blocks=4)
        np.testing.assert_array_equal(x, y)


class TestWaveletMask:
    @pytest.mark.parametrize(
        "target",
        ["random", "approx", "detail_1", "fine", "mixed", "coarse"],
    )
    def test_targets(self, target):
        aug = UniversalTSAugmenter(random_seed=0)
        x = np.sin(np.linspace(0, 8 * np.pi, 256))
        y = aug.wavelet_mask(x, level=2, target=target, s=0.8)
        assert y.shape == x.shape

    def test_short_series_passthrough(self):
        aug = UniversalTSAugmenter(random_seed=0)
        x = np.array([1.0, 2.0, 3.0])
        y = aug.wavelet_mask(x)
        np.testing.assert_array_equal(x, y)


class TestRegimeSplice:
    def test_basic(self):
        aug = UniversalTSAugmenter(random_seed=0)
        x = np.random.default_rng(1).normal(0, 1, 200)
        y = aug.regime_splice(x, mean_shift=1.0, var_scale=0.5)
        assert y.shape == x.shape
        assert not np.allclose(x, y)

    def test_short_series(self):
        aug = UniversalTSAugmenter(random_seed=0)
        x = np.array([1.0, 2.0, 3.0])
        y = aug.regime_splice(x)
        np.testing.assert_array_equal(x, y)


class TestAdaptiveSmoothing:
    def test_basic(self):
        aug = UniversalTSAugmenter(random_seed=0)
        x = np.random.default_rng(1).normal(0, 1, 200)
        y = aug.adaptive_smoothing(x, max_smoothing=0.8)
        assert y.shape == x.shape
        # Smoothed signal should have lower variance
        assert np.std(y) <= np.std(x) + 1e-6


# ── Stress interface ────────────────────────────────────────────────────


class TestStress:
    @pytest.mark.parametrize(
        "challenge",
        [
            "long_range",
            "long_range/cutout_zero",
            "long_range/cutout_hold",
            "long_range/cutout_noise",
            "long_range/cutout_interp",
            "long_range/permute",
            "long_range/warp",
            "multi_scale",
            "multi_scale/approx",
            "multi_scale/detail_1",
            "multi_scale/fine",
            "multi_scale/mixed",
            "non_stationary",
            "snr",
        ],
    )
    def test_all_challenges(self, challenge):
        aug = UniversalTSAugmenter(random_seed=42)
        x = np.sin(np.linspace(0, 8 * np.pi, 256))
        y = aug.stress(x, challenge, severity=0.7)
        assert y.shape == x.shape

    def test_unknown_challenge_raises(self):
        aug = UniversalTSAugmenter(random_seed=0)
        with pytest.raises(ValueError, match="Unknown challenge"):
            aug.stress(np.arange(100, dtype=float), "bogus")

    def test_severity_integer_mapping(self):
        """Severity > 1 should be mapped to [0,1] by dividing by 10."""
        aug = UniversalTSAugmenter(random_seed=0)
        x = np.sin(np.linspace(0, 4 * np.pi, 128))
        y = aug.stress(x, "snr", severity=7)  # mapped to 0.7
        assert y.shape == x.shape

    def test_constrain_preserves_mean(self):
        aug = UniversalTSAugmenter(random_seed=0)
        x = np.random.default_rng(1).normal(5.0, 1.0, 200)
        y = aug.stress(x, "snr", severity=0.5, preserve_mean=True)
        assert abs(np.mean(y) - np.mean(x)) < 0.1


# ── AugmentationConfig + augment_from_config ────────────────────────────


class TestAugmentFromConfig:
    def test_always_augment(self):
        cfg = AugmentationConfig(
            challenges=["snr"],
            severity=0.5,
            probability=1.0,
            random_seed=42,
        )
        aug = UniversalTSAugmenter(random_seed=42)
        x = np.sin(np.linspace(0, 4 * np.pi, 128))
        y = aug.augment_from_config(x, cfg)
        assert y.shape == x.shape
        assert not np.allclose(x, y)

    def test_never_augment(self):
        cfg = AugmentationConfig(
            challenges=["snr"],
            severity=0.5,
            probability=0.0,
            random_seed=42,
        )
        aug = UniversalTSAugmenter(random_seed=42)
        x = np.sin(np.linspace(0, 4 * np.pi, 128))
        y = aug.augment_from_config(x, cfg)
        np.testing.assert_array_equal(x, y)

    def test_severity_override(self):
        cfg = AugmentationConfig(
            challenges=["snr"],
            severity=0.1,
            severity_overrides={"snr": 0.9},
            probability=1.0,
            random_seed=42,
        )
        aug = UniversalTSAugmenter(random_seed=42)
        x = np.sin(np.linspace(0, 4 * np.pi, 128))
        # Should use severity=0.9, not 0.1
        y = aug.augment_from_config(x, cfg)
        assert y.shape == x.shape


# ── GIFT loader integration ─────────────────────────────────────────────


def _make_mock_hf_dataset(
    n_series: int = 5,
    series_length: int = 200,
    freq: str = "H",
) -> MagicMock:
    """Create a mock HF Dataset for testing."""
    rows = []
    rng = np.random.default_rng(42)
    for i in range(n_series):
        series = rng.standard_normal(series_length).astype(np.float32)
        rows.append({
            "target": series,
            "item_id": f"series_{i}",
            "freq": freq,
        })

    mock_ds = MagicMock()
    mock_ds.__getitem__ = lambda _, idx: rows[idx]
    mock_ds.__iter__ = lambda _: iter(rows)
    mock_ds.__len__ = lambda _: len(rows)
    mock_ds.with_format = MagicMock(side_effect=lambda fmt: mock_ds)
    return mock_ds


class TestGiftLoaderAugmentation:
    def test_zero_shot_no_augmentation_unchanged(self):
        """Without augmentation, samples should be unchanged."""
        series = np.arange(100, dtype=np.float32)
        hf_data = [{"target": series.tolist(), "item_id": "ts_0"}]

        ds = _GiftEvalZeroShotDataset(
            hf_dataset=hf_data,
            prediction_length=10,
            windows=2,
            context_length=20,
            to_univariate=False,
            dataset_name="test",
            augmentation=None,
        )

        samples = list(ds)
        # Past should match original series exactly
        expected_past_0 = np.arange(60, 80, dtype=np.float32)
        np.testing.assert_array_almost_equal(
            samples[0]["past_target"].squeeze(-1).numpy(),
            expected_past_0,
        )

    def test_zero_shot_with_augmentation_modifies_past(self):
        """With augmentation, past context should be modified."""
        series = np.arange(100, dtype=np.float32)
        hf_data = [{"target": series.tolist(), "item_id": "ts_0"}]

        aug_cfg = AugmentationConfig(
            challenges=["snr"],
            severity=0.8,
            probability=1.0,
            random_seed=42,
        )
        ds = _GiftEvalZeroShotDataset(
            hf_dataset=hf_data,
            prediction_length=10,
            windows=2,
            context_length=20,
            to_univariate=False,
            dataset_name="test",
            augmentation=aug_cfg,
        )

        samples = list(ds)
        past_values = samples[0]["past_target"].squeeze(-1).numpy()
        original_past = np.arange(60, 80, dtype=np.float32)

        # Past should be modified by augmentation
        assert not np.allclose(past_values, original_past)

    def test_zero_shot_augmentation_preserves_future(self):
        """Future target (ground truth) must never be modified."""
        series = np.arange(100, dtype=np.float32)
        hf_data = [{"target": series.tolist(), "item_id": "ts_0"}]

        aug_cfg = AugmentationConfig(
            challenges=["long_range/cutout_zero"],
            severity=1.0,
            probability=1.0,
            random_seed=42,
        )
        ds = _GiftEvalZeroShotDataset(
            hf_dataset=hf_data,
            prediction_length=10,
            windows=2,
            context_length=20,
            to_univariate=False,
            dataset_name="test",
            augmentation=aug_cfg,
        )

        samples = list(ds)
        # Future target must be unmodified
        expected_future_0 = np.arange(80, 90, dtype=np.float32)
        np.testing.assert_array_almost_equal(
            samples[0]["future_target"].squeeze(-1).numpy(),
            expected_future_0,
        )

    def test_fine_tuning_with_augmentation(self):
        """Fine-tuning dataset should also support augmentation."""
        series = np.arange(100, dtype=np.float32)
        aug_cfg = AugmentationConfig(
            challenges=["snr"],
            severity=0.5,
            probability=1.0,
            random_seed=42,
        )

        ds = _GiftEvalFineTuningDataset(
            series_list=[series],
            item_ids=["ts_0"],
            static_features_list=[None],
            context_length=10,
            prediction_length=10,
            stride=10,
            train_end_offsets=[70],
            augmentation=aug_cfg,
        )

        sample = ds[0]
        original_past = np.arange(0, 10, dtype=np.float32)
        past_values = sample["past_target"].squeeze(-1).numpy()
        # Past should be modified
        assert not np.allclose(past_values, original_past)
        # Future should be unmodified
        expected_future = np.arange(10, 20, dtype=np.float32)
        np.testing.assert_array_almost_equal(
            sample["future_target"].squeeze(-1).numpy(),
            expected_future,
        )

    @patch("core.data.gift_loader.load_dataset")
    def test_gift_eval_dataset_with_augmentation(self, mock_load):
        """Integration: GiftEvalDataset passes augmentation through."""
        mock_ds = _make_mock_hf_dataset(n_series=3, series_length=200, freq="H")
        mock_load.return_value = mock_ds

        aug_cfg = AugmentationConfig(
            challenges=["snr"],
            severity=0.5,
            probability=1.0,
            random_seed=42,
        )

        gift = GiftEvalDataset(
            dataset_name="test/hourly",
            term="short",
            mode="zero_shot",
            context_length=48,
            batch_size=4,
            augmentation=aug_cfg,
        )

        loader = gift.get_dataloader()
        batch = next(iter(loader))
        assert "past_target" in batch
        assert "future_target" in batch
        assert batch["past_target"].shape[-1] == 1
        assert batch["future_target"].shape[1] == 48

    @patch("core.data.gift_loader.load_dataset")
    def test_gift_eval_dataset_without_augmentation(self, mock_load):
        """Integration: GiftEvalDataset works without augmentation (default)."""
        mock_ds = _make_mock_hf_dataset(n_series=3, series_length=200, freq="H")
        mock_load.return_value = mock_ds

        gift = GiftEvalDataset(
            dataset_name="test/hourly",
            term="short",
            mode="zero_shot",
            context_length=48,
            batch_size=4,
        )

        loader = gift.get_dataloader()
        batch = next(iter(loader))
        assert "past_target" in batch
        assert batch["future_target"].shape[1] == 48
