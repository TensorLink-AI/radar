"""Tests for TrainingStyle enum, quantile_levels validation, to_config()
round-trip, and training_style integration into the forward_fn dispatch
and model validation."""

from __future__ import annotations

import json
import sys
import types
import unittest
from unittest.mock import MagicMock, patch

# ── Stub heavy torch modules so imports succeed without GPU ──────────
_MOCK_MODULES = [
    "torch", "torch.nn", "torch.nn.functional", "torch.utils",
    "torch.utils.data", "torch.cuda", "torch.fx",
    "torch.fx.experimental", "torch.fx.experimental.proxy_tensor",
    "torch.fx.passes", "torch.fx.passes.shape_prop",
    "torch.amp", "torch.cuda.amp",
]
_original_modules = {}
for _mod_name in _MOCK_MODULES:
    if _mod_name in sys.modules:
        _original_modules[_mod_name] = sys.modules[_mod_name]
    else:
        _mock = types.ModuleType(_mod_name)
        sys.modules[_mod_name] = _mock

# Provide minimal torch stubs so model_base can parse
_torch = sys.modules["torch"]
_torch.Tensor = type("Tensor", (), {})
_torch.no_grad = lambda: (lambda f: f)  # decorator that returns function unchanged
_torch.device = str  # simplify

_nn = sys.modules["torch.nn"]
_nn.Module = type("Module", (), {"__init__": lambda self: None})

# Stubs that model_base imports at module level
_proxy_tensor = sys.modules["torch.fx.experimental.proxy_tensor"]
_proxy_tensor.make_fx = MagicMock()

_shape_prop = sys.modules["torch.fx.passes.shape_prop"]
_shape_prop.ShapeProp = type("ShapeProp", (), {})

# ABC needs to be real -- nn.Module must use ABCMeta to avoid metaclass
# conflict with TimeSeriesFoundationModel(nn.Module, ABC).
from abc import ABC, ABCMeta, abstractmethod  # noqa: E402

_nn.Module = ABCMeta("Module", (), {"__init__": lambda self: None})

# Now we can import our modules
from tasks.ts_foundation.model_base import TrainingStyle  # noqa: E402


# ── Tests ─────────────────────────────────────────────────────────────


class TestTrainingStyleEnum(unittest.TestCase):
    """Basic enum tests."""

    def test_enum_values(self):
        self.assertEqual(TrainingStyle.TEACHER_FORCED, "teacher_forced")
        self.assertEqual(TrainingStyle.DIRECT, "direct")

    def test_is_string_subclass(self):
        self.assertIsInstance(TrainingStyle.TEACHER_FORCED, str)
        self.assertIsInstance(TrainingStyle.DIRECT, str)

    def test_json_serialisable(self):
        """TrainingStyle values can be serialised to JSON."""
        s = json.dumps({"style": TrainingStyle.DIRECT})
        self.assertIn("direct", s)
        s = json.dumps({"style": TrainingStyle.TEACHER_FORCED})
        self.assertIn("teacher_forced", s)

    def test_from_string(self):
        """Can construct enum from string values."""
        self.assertEqual(TrainingStyle("teacher_forced"), TrainingStyle.TEACHER_FORCED)
        self.assertEqual(TrainingStyle("direct"), TrainingStyle.DIRECT)


class TestForwardFnDispatch(unittest.TestCase):
    """Test that make_forward_fn respects model.training_style.

    Uses mocked models to avoid needing real torch tensors.
    """

    def _make_mock_model(self, style):
        """Create a mock model with training_style set."""
        model = MagicMock()
        model.training_style = style
        model.return_value = {"quantiles": MagicMock(), "quantile_levels": MagicMock()}
        return model

    def _make_batch(self):
        past = MagicMock()
        past.to = MagicMock(return_value=past)
        future = MagicMock()
        future.to = MagicMock(return_value=future)
        return {"past_target": past, "future_target": future}

    def test_teacher_forced_passes_y_future_tf(self):
        """TEACHER_FORCED style should pass future_target as y_future_tf."""
        from tasks.ts_foundation.metrics import make_forward_fn

        model = self._make_mock_model(TrainingStyle.TEACHER_FORCED)
        fwd = make_forward_fn(forecast_length=256, input_length=512)
        batch = self._make_batch()
        device = "cpu"

        fwd(model, batch, device)

        model.assert_called_once()
        call_kwargs = model.call_args
        # y_future_tf should be the future_target tensor
        self.assertIn("y_future_tf", call_kwargs.kwargs)
        self.assertIsNotNone(call_kwargs.kwargs["y_future_tf"])

    def test_direct_omits_y_future_tf(self):
        """DIRECT style should NOT pass y_future_tf."""
        from tasks.ts_foundation.metrics import make_forward_fn

        model = self._make_mock_model(TrainingStyle.DIRECT)
        fwd = make_forward_fn(forecast_length=256, input_length=512)
        batch = self._make_batch()
        device = "cpu"

        fwd(model, batch, device)

        model.assert_called_once()
        call_kwargs = model.call_args
        # y_future_tf should NOT be in kwargs (direct style)
        self.assertNotIn("y_future_tf", call_kwargs.kwargs)

    def test_no_style_attribute_defaults_to_teacher_forced(self):
        """Model without training_style should get teacher forcing (default)."""
        from tasks.ts_foundation.metrics import make_forward_fn

        model = MagicMock(spec=[])  # no attributes
        del model.training_style  # ensure getattr falls back
        model.return_value = {"quantiles": MagicMock(), "quantile_levels": MagicMock()}
        fwd = make_forward_fn()
        batch = self._make_batch()

        fwd(model, batch, "cpu")

        model.assert_called_once()
        call_kwargs = model.call_args
        self.assertIn("y_future_tf", call_kwargs.kwargs)

    def test_forecast_length_passed_through(self):
        """forecast_length and input_length should be forwarded to model."""
        from tasks.ts_foundation.metrics import make_forward_fn

        model = self._make_mock_model(TrainingStyle.DIRECT)
        fwd = make_forward_fn(forecast_length=128, input_length=64)
        batch = self._make_batch()

        fwd(model, batch, "cpu")

        call_kwargs = model.call_args.kwargs
        self.assertEqual(call_kwargs["forecast_length"], 128)
        self.assertEqual(call_kwargs["input_length"], 64)


class TestForwardFnTeacherForcedBehavior(unittest.TestCase):
    """Verify the teacher-forced path sends the right tensor."""

    def test_future_target_is_the_tf_tensor(self):
        """The exact batch['future_target'] (moved to device) should be y_future_tf."""
        from tasks.ts_foundation.metrics import make_forward_fn

        model = MagicMock()
        model.training_style = TrainingStyle.TEACHER_FORCED
        model.return_value = {"quantiles": MagicMock(), "quantile_levels": MagicMock()}

        sentinel = MagicMock(name="future_on_device")
        future_raw = MagicMock()
        future_raw.to = MagicMock(return_value=sentinel)

        past_raw = MagicMock()
        past_raw.to = MagicMock(return_value=past_raw)

        batch = {"past_target": past_raw, "future_target": future_raw}
        fwd = make_forward_fn()
        fwd(model, batch, "cpu")

        # The y_future_tf kwarg should be the sentinel (future_target.to(device))
        self.assertIs(model.call_args.kwargs["y_future_tf"], sentinel)


class TestDirectPathBatch(unittest.TestCase):
    """Verify the direct path doesn't even call .to() on future_target."""

    def test_future_target_not_moved_to_device(self):
        """For DIRECT style, future_target.to() should NOT be called."""
        from tasks.ts_foundation.metrics import make_forward_fn

        model = MagicMock()
        model.training_style = TrainingStyle.DIRECT
        model.return_value = {"quantiles": MagicMock(), "quantile_levels": MagicMock()}

        future_raw = MagicMock()
        past_raw = MagicMock()
        past_raw.to = MagicMock(return_value=past_raw)

        batch = {"past_target": past_raw, "future_target": future_raw}
        fwd = make_forward_fn()
        fwd(model, batch, "cpu")

        # future_target.to() should NOT have been called
        future_raw.to.assert_not_called()


class TestEvalFnAlwaysUsesGenerate(unittest.TestCase):
    """Regardless of training_style, eval_fn should always call model.generate()."""

    def test_eval_calls_generate_for_teacher_forced(self):
        """Teacher-forced model: eval still uses generate (no TF)."""
        from tasks.ts_foundation.metrics import make_eval_fn

        model = MagicMock()
        model.training_style = TrainingStyle.TEACHER_FORCED
        model.eval = MagicMock()

        # Mock generate output
        quantiles = MagicMock()
        quantiles.shape = (2, 256, 9)
        ql = MagicMock()
        ql.to = MagicMock(return_value=ql)
        model.generate = MagicMock(return_value={
            "quantiles": quantiles,
            "quantile_levels": ql,
        })

        # Mock loader
        past = MagicMock()
        past.to = MagicMock(return_value=past)
        target = MagicMock()
        target.to = MagicMock(return_value=target)
        batch = {"past_target": past, "future_target": target}
        loader = [batch]

        eval_fn = make_eval_fn(max_batches=1)

        # Patch the metric functions to avoid real tensor ops
        with patch("tasks.ts_foundation.metrics._quantile_loss") as mock_ql, \
             patch("tasks.ts_foundation.metrics._crps_from_quantiles") as mock_crps:
            mock_ql.return_value = MagicMock(item=lambda: 0.5)
            mock_crps.return_value = 0.3

            # We need torch.no_grad and torch.argmin, torch.abs
            _torch.no_grad = lambda: type("ctx", (), {"__enter__": lambda s: None, "__exit__": lambda s, *a: None})()
            _torch.argmin = lambda x: MagicMock(item=lambda: 4)
            _torch.abs = lambda x: x
            _torch.mean = lambda x: MagicMock(item=lambda: 0.2)

            try:
                eval_fn(model, loader, "cpu")
            except Exception:
                pass  # Don't care about mock-related errors

        # The key assertion: generate was called, not forward
        model.generate.assert_called()


class TestQuantileLevelsValidation(unittest.TestCase):
    """Test that quantile_levels are validated for range and ordering."""

    def _make_tensor_like(self, values):
        """Create a minimal tensor-like object with .min(), .max(), .tolist(), slicing."""
        class FakeTensor:
            def __init__(self, vals):
                self._vals = list(vals)
                self.ndim = 1
                self.shape = (len(self._vals),)
                self.device = "cpu"
                self.dtype = "float32"

            def min(self):
                return min(self._vals)

            def max(self):
                return max(self._vals)

            def tolist(self):
                return list(self._vals)

            def __getitem__(self, key):
                result = self._vals[key]
                if isinstance(result, list):
                    return FakeTensor(result)
                return result

            def __sub__(self, other):
                if isinstance(other, FakeTensor):
                    return FakeTensor([a - b for a, b in zip(self._vals, other._vals)])
                return FakeTensor([v - other for v in self._vals])
        return FakeTensor(values)

    def _make_quantiles(self, batch_size, forecast_length, num_quantiles):
        """Create a minimal quantiles-like tensor."""
        class FakeTensor:
            def __init__(self):
                self.ndim = 3
                self.shape = (batch_size, forecast_length, num_quantiles)
                self.device = "cpu"
                self.dtype = "float32"
        return FakeTensor()

    def test_valid_quantile_levels_pass(self):
        """Standard 9 quantile levels should pass."""
        # We test via direct exercise of the validation logic
        ql = self._make_tensor_like([0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9])
        q = self._make_quantiles(2, 256, 9)

        # Verify basic properties that the validator checks
        self.assertTrue(float(ql.min()) > 0.0)
        self.assertTrue(float(ql.max()) < 1.0)

        # Verify strictly increasing
        diffs = ql[1:] - ql[:-1]
        self.assertTrue(float(diffs.min()) > 0.0)

    def test_zero_in_quantile_levels_detected(self):
        """quantile_levels containing 0.0 should be rejected."""
        ql = self._make_tensor_like([0.0, 0.25, 0.5, 0.75, 1.0])
        self.assertFalse(float(ql.min()) > 0.0)

    def test_one_in_quantile_levels_detected(self):
        """quantile_levels containing 1.0 should be rejected."""
        ql = self._make_tensor_like([0.1, 0.5, 1.0])
        self.assertFalse(float(ql.max()) < 1.0)

    def test_non_increasing_detected(self):
        """Non-strictly-increasing quantile_levels should be caught."""
        ql = self._make_tensor_like([0.1, 0.5, 0.5, 0.9])
        diffs = ql[1:] - ql[:-1]
        self.assertFalse(float(diffs.min()) > 0.0)

    def test_decreasing_detected(self):
        """Decreasing quantile_levels should be caught."""
        ql = self._make_tensor_like([0.9, 0.5, 0.1])
        diffs = ql[1:] - ql[:-1]
        self.assertFalse(float(diffs.min()) > 0.0)

    def test_single_quantile_level_passes(self):
        """Single quantile level (e.g. median only) should pass without monotonicity check."""
        ql = self._make_tensor_like([0.5])
        self.assertTrue(float(ql.min()) > 0.0)
        self.assertTrue(float(ql.max()) < 1.0)
        # shape[0] == 1 means no diff check needed
        self.assertEqual(ql.shape[0], 1)


class TestToConfigRoundTrip(unittest.TestCase):
    """Test the to_config()/from_config() round-trip validation logic."""

    def test_json_serialisable_dict_passes(self):
        """A dict of primitives is JSON-serialisable."""
        cfg = {"d_model": 256, "n_layers": 4, "dropout": 0.1, "name": "test"}
        # Should not raise
        json.dumps(cfg)

    def test_non_serialisable_dict_detected(self):
        """A dict with non-serialisable values should be caught."""
        cfg = {"model": object()}
        with self.assertRaises(TypeError):
            json.dumps(cfg)

    def test_non_dict_to_config_detected(self):
        """to_config() returning a non-dict should be caught."""
        result = "not a dict"
        self.assertNotIsInstance(result, dict)

    def test_round_trip_preserves_values(self):
        """Config values should survive JSON round-trip."""
        cfg = {"d_model": 256, "n_layers": 4, "dropout": 0.1, "styles": ["a", "b"]}
        serialised = json.dumps(cfg)
        restored = json.loads(serialised)
        self.assertEqual(cfg, restored)


class TestTaskDefinitionTrainingStyles(unittest.TestCase):
    """Test that TaskDefinition supports the training styles field."""

    def test_task_definition_has_supported_styles(self):
        """TaskDefinition should include supported_training_styles."""
        from core.tasks.contracts import TaskDefinition

        td = TaskDefinition(
            name="test_task",
            supported_training_styles=["teacher_forced", "direct"],
        )
        self.assertEqual(td.supported_training_styles, ["teacher_forced", "direct"])

    def test_task_definition_default_empty_styles(self):
        """Default supported_training_styles should be empty list."""
        from core.tasks.contracts import TaskDefinition

        td = TaskDefinition(name="test_task")
        self.assertEqual(td.supported_training_styles, [])

    def test_to_dict_includes_training_styles(self):
        """to_dict() should include supported_training_styles."""
        from core.tasks.contracts import TaskDefinition

        td = TaskDefinition(
            name="test_task",
            supported_training_styles=["teacher_forced", "direct"],
        )
        d = td.to_dict()
        self.assertIn("supported_training_styles", d)
        self.assertEqual(d["supported_training_styles"], ["teacher_forced", "direct"])

    def test_ts_foundation_task_definition_has_styles(self):
        """The actual TS foundation task should declare training styles."""
        # We can import the task definition since it doesn't require torch
        # (the module-level TaskDefinition is pure dataclass)
        from tasks.ts_foundation.task import TASK_DEFINITION

        self.assertIn("teacher_forced", TASK_DEFINITION.supported_training_styles)
        self.assertIn("direct", TASK_DEFINITION.supported_training_styles)


class TestCandidateResultTrainingStyle(unittest.TestCase):
    """Test that CandidateResult carries training_style."""

    def test_candidate_result_has_training_style(self):
        """CandidateResult should have a training_style field."""
        from subnet.protocol.types import CandidateResult

        cr = CandidateResult(
            hotkey="hk", uid=0, name="test", motivation="", model_code="",
        )
        self.assertIsNone(cr.training_style)

    def test_candidate_result_stores_training_style(self):
        """training_style should be settable on CandidateResult."""
        from subnet.protocol.types import CandidateResult

        cr = CandidateResult(
            hotkey="hk", uid=0, name="test", motivation="", model_code="",
            training_style="direct",
        )
        self.assertEqual(cr.training_style, "direct")

    def test_candidate_result_teacher_forced(self):
        """training_style 'teacher_forced' should persist."""
        from subnet.protocol.types import CandidateResult

        cr = CandidateResult(
            hotkey="hk", uid=0, name="test", motivation="", model_code="",
        )
        cr.training_style = "teacher_forced"
        self.assertEqual(cr.training_style, "teacher_forced")


if __name__ == "__main__":
    unittest.main()
