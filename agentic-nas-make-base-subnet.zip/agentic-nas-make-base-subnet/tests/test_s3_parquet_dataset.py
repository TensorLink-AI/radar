"""Unit tests for the S3 Parquet streaming dataset pipeline.

Tests both the generic core S3 dataset and the time-series specialisation.
Uses mocked S3 operations so no real S3 access is required.
"""

from __future__ import annotations

import io
import json
import random
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple
from unittest.mock import MagicMock, patch

import pytest
import torch

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from core.data.s3_store import S3ObjectStore, S3StoreConfig
from core.data.s3_parquet_dataset import (
    FileEntry,
    ManifestIndex,
    S3ParquetConfig,
    S3ParquetDataset,
    _GroupSampler,
    build_s3_parquet_dataloader,
)
from tasks.ts_foundation.s3_dataloader import (
    ts_row_to_sample,
    ts_s3_collate_fn,
    TimeSeriesS3Dataset,
    build_ts_s3_dataloader,
)


# ── Helpers ──────────────────────────────────────────────────────────────


def _make_parquet_bytes(rows: List[Dict[str, Any]]) -> bytes:
    """Create a Parquet file in memory from a list of dicts."""
    import pyarrow as pa
    import pyarrow.parquet as pq

    table = pa.Table.from_pylist(rows)
    buf = io.BytesIO()
    pq.write_table(table, buf)
    return buf.getvalue()


def _sample_rows(n: int = 5, domain: str = "Energy/Grid", freq: str = "1H") -> List[Dict[str, Any]]:
    """Generate sample Parquet rows."""
    return [
        {
            "dataset_name": "test_ds",
            "domain": domain,
            "freq": freq,
            "item_id": f"item_{i}",
            "start": "2024-01-01",
            "target": [float(j) for j in range(10)],
            "feat_static_cat": None,
            "feat_dynamic_real": None,
            "is_multivariate": False,
            "orig_dim": 1,
            "orig_num_dims": 1,
        }
        for i in range(n)
    ]


class MockS3Store:
    """Mock S3ObjectStore that serves from an in-memory dict."""

    def __init__(self, objects: Dict[str, bytes]) -> None:
        self.objects = objects
        self.bucket = "test-bucket"

    def list_keys(self, prefix: str) -> List[str]:
        return [k for k in self.objects if k.startswith(prefix)]

    def get_bytes(self, key: str) -> bytes:
        if key not in self.objects:
            raise Exception(f"NoSuchKey: {key}")
        return self.objects[key]

    def get_stream(self, key: str) -> io.BytesIO:
        return io.BytesIO(self.get_bytes(key))

    def get_json(self, key: str) -> Dict[str, Any]:
        return json.loads(self.get_bytes(key))


# ── Tests: ts_row_to_sample ─────────────────────────────────────────────


class TestTsRowToSample:
    def test_basic_conversion(self) -> None:
        row = _sample_rows(1)[0]
        sample = ts_row_to_sample(row)
        assert sample["item_id"] == "item_0"
        assert sample["domain"] == "Energy/Grid"
        assert sample["freq"] == "1H"
        assert sample["dataset_name"] == "test_ds"
        assert isinstance(sample["target"], torch.Tensor)
        assert sample["target"].shape == (10,)
        assert sample["target"].dtype == torch.float32

    def test_none_target(self) -> None:
        row = {"target": None, "item_id": "x", "domain": "d", "freq": "f"}
        sample = ts_row_to_sample(row)
        assert sample["target"].shape == (0,)

    def test_empty_target(self) -> None:
        row = {"target": [], "item_id": "x"}
        sample = ts_row_to_sample(row)
        assert sample["target"].shape == (0,)


# ── Tests: ts_s3_collate_fn ─────────────────────────────────────────────


class TestTsCollateFn:
    def test_padding_and_mask(self) -> None:
        samples = [
            {"target": torch.tensor([1.0, 2.0, 3.0]), "item_id": "a", "start": "s",
             "domain": "d1", "freq": "f1", "dataset_name": "ds"},
            {"target": torch.tensor([4.0, 5.0]), "item_id": "b", "start": "s",
             "domain": "d2", "freq": "f2", "dataset_name": "ds"},
        ]
        batch = ts_s3_collate_fn(samples)

        assert batch["target"].shape == (2, 3)
        assert batch["lengths"].tolist() == [3, 2]
        assert batch["attention_mask"].shape == (2, 3)
        # Second sample padded
        assert batch["target"][1, 2].item() == 0.0
        assert batch["attention_mask"][1, 2].item() is False
        assert batch["attention_mask"][0, 2].item() is True

    def test_metadata_lists(self) -> None:
        samples = [
            {"target": torch.tensor([1.0]), "item_id": "a", "start": "s1",
             "domain": "d", "freq": "f", "dataset_name": "ds",
             "feat_static_cat": [1], "feat_dynamic_real": None},
        ]
        batch = ts_s3_collate_fn(samples)
        assert batch["item_id"] == ["a"]
        assert batch["start"] == ["s1"]
        assert batch["feat_static_cat"] == [[1]]
        assert batch["feat_dynamic_real"] == [None]

    def test_empty_batch(self) -> None:
        batch = ts_s3_collate_fn([])
        assert batch["target"].shape == (0, 0)


# ── Tests: ManifestIndex ────────────────────────────────────────────────


class TestManifestIndex:
    def test_consolidated_jsonl(self) -> None:
        entries = [
            {"key": "pfx/data/domain=Energy/freq=1H/part-0.parquet", "domain": "Energy", "freq": "1H", "rows": 100, "bytes": 5000},
            {"key": "pfx/data/domain=Traffic/freq=daily/part-0.parquet", "domain": "Traffic", "freq": "daily", "rows": 50, "bytes": 2500},
        ]
        jsonl = "\n".join(json.dumps(e) for e in entries)
        store = MockS3Store({"pfx/manifest/consolidated.jsonl": jsonl.encode()})

        idx = ManifestIndex(store, "pfx")  # type: ignore[arg-type]
        idx.load()

        assert len(idx.groups()) == 2
        assert ("Energy", "1H") in idx.by_group
        assert idx.by_group[("Energy", "1H")][0].rows == 100

    def test_manifest_entries(self) -> None:
        entry = {"key": "pfx/data/domain=Energy/freq=1H/part-0.parquet",
                 "domain": "Energy", "freq": "1H", "rows": 10, "bytes": 100}
        store = MockS3Store({
            "pfx/manifest/entries/2024-01-01/batch.json": json.dumps([entry]).encode(),
        })
        idx = ManifestIndex(store, "pfx")  # type: ignore[arg-type]
        idx.load()
        assert ("Energy", "1H") in idx.by_group

    def test_scan_data_prefix(self) -> None:
        # No manifest, falls back to scanning data prefix
        parquet_data = _make_parquet_bytes(_sample_rows(3, "Weather", "daily"))
        store = MockS3Store({
            "pfx/data/domain=Weather/freq=daily/global_part=000000/part-000000.parquet": parquet_data,
        })
        idx = ManifestIndex(store, "pfx")  # type: ignore[arg-type]
        idx.load()
        assert ("Weather", "daily") in idx.by_group
        assert idx.by_group[("Weather", "daily")][0].rows == 0  # unknown from scan


# ── Tests: _GroupSampler ────────────────────────────────────────────────


class TestGroupSampler:
    def _make_index(self) -> ManifestIndex:
        """Create a ManifestIndex with known groups."""
        store = MockS3Store({})
        idx = ManifestIndex(store, "pfx")  # type: ignore[arg-type]
        idx.by_group[("Energy", "1H")] = [
            FileEntry(key="a.parquet", domain="Energy", freq="1H", rows=100),
            FileEntry(key="b.parquet", domain="Energy", freq="1H", rows=200),
        ]
        idx.by_group[("Traffic", "daily")] = [
            FileEntry(key="c.parquet", domain="Traffic", freq="daily", rows=50),
        ]
        return idx

    def test_uniform_sampling(self) -> None:
        idx = self._make_index()
        rng = random.Random(42)
        sampler = _GroupSampler(
            idx, domain_weights={}, freq_weights={}, joint_weights={}, rng=rng,
        )
        results = [sampler.sample_file() for _ in range(100)]
        assert all(r is not None for r in results)
        keys = [r.key for r in results]  # type: ignore[union-attr]
        # Should see both groups
        assert any(k == "c.parquet" for k in keys)
        assert any(k in ("a.parquet", "b.parquet") for k in keys)

    def test_domain_weighted(self) -> None:
        idx = self._make_index()
        rng = random.Random(42)
        # Weight Energy 100x more than Traffic
        sampler = _GroupSampler(
            idx,
            domain_weights={"Energy": 100.0, "Traffic": 0.001},
            freq_weights={},
            joint_weights={},
            rng=rng,
        )
        results = [sampler.sample_file() for _ in range(200)]
        energy_count = sum(1 for r in results if r and r.domain == "Energy")
        assert energy_count > 180  # should be heavily skewed

    def test_joint_weighted(self) -> None:
        idx = self._make_index()
        rng = random.Random(42)
        sampler = _GroupSampler(
            idx,
            domain_weights={},
            freq_weights={},
            joint_weights={("Traffic", "daily"): 1.0, ("Energy", "1H"): 0.0},
            rng=rng,
        )
        results = [sampler.sample_file() for _ in range(50)]
        assert all(r is not None and r.key == "c.parquet" for r in results)

    def test_file_selection_proportional_to_rows(self) -> None:
        idx = self._make_index()
        rng = random.Random(42)
        # Only Energy group, check b.parquet (200 rows) vs a.parquet (100 rows)
        sampler = _GroupSampler(
            idx,
            domain_weights={"Energy": 1.0},
            freq_weights={},
            joint_weights={},
            rng=rng,
        )
        results = [sampler.sample_file() for _ in range(300)]
        b_count = sum(1 for r in results if r and r.key == "b.parquet")
        # b should be ~2x more frequent than a (200 vs 100 rows)
        assert b_count > 150  # rough check


# ── Tests: Generic S3ParquetDataset ──────────────────────────────────────


class TestS3ParquetDatasetGeneric:
    """Test the base S3ParquetDataset with a custom row_to_sample."""

    def _make_store_and_index(self) -> Tuple[MockS3Store, ManifestIndex]:
        rows = _sample_rows(5, "Energy", "1H")
        parquet_bytes = _make_parquet_bytes(rows)
        objects = {
            "pfx/data/domain=Energy/freq=1H/global_part=000000/part-000000.parquet": parquet_bytes,
        }
        store = MockS3Store(objects)
        idx = ManifestIndex(store, "pfx")  # type: ignore[arg-type]
        idx.by_group[("Energy", "1H")] = [
            FileEntry(
                key="pfx/data/domain=Energy/freq=1H/global_part=000000/part-000000.parquet",
                domain="Energy",
                freq="1H",
                rows=5,
            ),
        ]
        return store, idx

    def test_default_row_to_sample_returns_raw(self) -> None:
        """Without a row_to_sample, raw Parquet dicts are yielded."""
        store, idx = self._make_store_and_index()
        config = S3ParquetConfig(
            bucket="test", root_prefix="pfx", seed=42, prefetch_files=1,
        )
        ds = S3ParquetDataset(config, store=store, index=idx)  # type: ignore[arg-type]
        sample = next(iter(ds))
        # Raw rows have the original Parquet columns
        assert "dataset_name" in sample
        assert "target" in sample
        # target is still a list (not a tensor) since no conversion
        assert isinstance(sample["target"], list)

    def test_custom_row_to_sample(self) -> None:
        """A custom row_to_sample callable transforms rows."""
        store, idx = self._make_store_and_index()
        config = S3ParquetConfig(
            bucket="test", root_prefix="pfx", seed=42, prefetch_files=1,
        )

        def my_converter(row: Dict[str, Any]) -> Dict[str, Any]:
            return {"custom_key": row.get("item_id", ""), "length": len(row.get("target", []))}

        ds = S3ParquetDataset(config, row_to_sample=my_converter, store=store, index=idx)  # type: ignore[arg-type]
        sample = next(iter(ds))
        assert "custom_key" in sample
        assert "length" in sample
        assert sample["length"] == 10


# ── Tests: TimeSeriesS3Dataset ───────────────────────────────────────────


class TestTimeSeriesS3Dataset:
    def _make_store_and_index(self) -> Tuple[MockS3Store, ManifestIndex]:
        rows = _sample_rows(5, "Energy", "1H")
        parquet_bytes = _make_parquet_bytes(rows)
        objects = {
            "pfx/data/domain=Energy/freq=1H/global_part=000000/part-000000.parquet": parquet_bytes,
        }
        store = MockS3Store(objects)
        idx = ManifestIndex(store, "pfx")  # type: ignore[arg-type]
        idx.by_group[("Energy", "1H")] = [
            FileEntry(
                key="pfx/data/domain=Energy/freq=1H/global_part=000000/part-000000.parquet",
                domain="Energy",
                freq="1H",
                rows=5,
            ),
        ]
        return store, idx

    def test_yields_ts_samples(self) -> None:
        store, idx = self._make_store_and_index()
        config = S3ParquetConfig(
            bucket="test",
            root_prefix="pfx",
            seed=42,
            prefetch_files=1,
        )
        ds = TimeSeriesS3Dataset(config, store=store, index=idx)  # type: ignore[arg-type]
        samples = []
        for sample in ds:
            samples.append(sample)
            if len(samples) >= 10:
                break
        assert len(samples) == 10
        assert all("target" in s for s in samples)
        assert all(isinstance(s["target"], torch.Tensor) for s in samples)

    def test_corrupt_file_skipped(self) -> None:
        store = MockS3Store({
            "pfx/data/bad.parquet": b"not-a-parquet-file",
        })
        idx = ManifestIndex(store, "pfx")  # type: ignore[arg-type]
        idx.by_group[("Bad", "unknown")] = [
            FileEntry(key="pfx/data/bad.parquet", domain="Bad", freq="unknown", rows=1),
        ]
        config = S3ParquetConfig(
            bucket="test",
            root_prefix="pfx",
            seed=42,
            prefetch_files=1,
        )
        ds = TimeSeriesS3Dataset(config, store=store, index=idx)  # type: ignore[arg-type]
        # Should not raise, just skip (and eventually stop when all prefetch exhausted)
        samples = []
        count = 0
        for sample in ds:
            samples.append(sample)
            count += 1
            if count >= 5:
                break
        # Corrupt file yields no samples, but shouldn't crash
        assert ds.corrupt_count >= 1


# ── Tests: build_ts_s3_dataloader ────────────────────────────────────────


class TestBuildTsDataloader:
    def test_returns_dataloader(self) -> None:
        rows = _sample_rows(8, "Energy", "1H")
        parquet_bytes = _make_parquet_bytes(rows)
        store = MockS3Store({
            "pfx/data/domain=Energy/freq=1H/part-0.parquet": parquet_bytes,
        })
        idx = ManifestIndex(store, "pfx")  # type: ignore[arg-type]
        idx.by_group[("Energy", "1H")] = [
            FileEntry(key="pfx/data/domain=Energy/freq=1H/part-0.parquet",
                      domain="Energy", freq="1H", rows=8),
        ]
        config = S3ParquetConfig(
            bucket="test",
            root_prefix="pfx",
            seed=0,
            prefetch_files=1,
        )
        loader = build_ts_s3_dataloader(
            config, batch_size=4, num_workers=0, store=store, index=idx,  # type: ignore[arg-type]
        )
        batch = next(iter(loader))
        assert batch["target"].shape[0] == 4
        assert "attention_mask" in batch
        assert "lengths" in batch
