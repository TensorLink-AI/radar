import torch

from scaffolds.ts_base_model import TimeSeriesFoundationModel


def test_past_cov_is_truncated_with_past_y():
    cfg = {
        "d_model": 32,
        "n_layers": 1,
        "n_heads": 4,
        "d_ff": 64,
        "dropout": 0.0,
        "target_dim": 1,
        "past_cov_dim": 2,
        "future_cov_dim": 0,
        "static_dim": 0,
        "constraints": {
            "input_length": 4,
            "forecast_length": 2,
            "max_total_tokens": None,
        },
        "max_len": 32,
    }

    model = TimeSeriesFoundationModel(cfg)
    model.eval()

    B, T, H = 2, 6, 2
    past_y = torch.randn(B, T, cfg["target_dim"])
    past_cov = torch.randn(B, T, cfg["past_cov_dim"])

    out_full = model.forward(
        past_y=past_y,
        past_cov=past_cov,
        forecast_length=H,
        input_length=4,
    )

    cropped_y = past_y[:, -4:, :]
    cropped_cov = past_cov[:, -4:, :]
    out_cropped = model.forward(
        past_y=cropped_y,
        past_cov=cropped_cov,
        forecast_length=H,
        input_length=4,
    )

    assert torch.allclose(out_full["quantiles"], out_cropped["quantiles"])
    assert torch.allclose(out_full["baseline"], out_cropped["baseline"])
