"""
Mock miner server for subnet integration testing.

Receives a Challenge from the validator, uses an LLM (via Chutes) to evolve
a model (either the scaffold or a sampled parent from the DB), validates the
result, and returns a MinerSubmission.

Combines the core miner pipeline into one condensed file:
  1. Sample: pick a parent from the DB (or fall back to scaffold)
  2. Evolve: LLM rewrites the parent with a targeted architectural change
  3. Validate: syntax check + contract compliance (instantiate_model works)
  4. Return: MinerSubmission with model_code, motivation, name, diff, parent_id

Endpoints:
  HEAD /                – affinetes health probe (returns 200)
  GET  /                – readiness probe
  GET  /health          – detailed health info
  POST /challenge       – receive Challenge, return MinerSubmission JSON

Usage:
  # Standalone
  CHUTES_API_KEY=... MODEL_NAME=... uvicorn tests.test_subnet.miner_server:app --port 9000

  # Inside Docker / Basilica (see Dockerfile.miner)
  docker build -f tests/test_subnet/Dockerfile.miner -t test-miner:latest .
  docker run -e CHUTES_API_KEY=... -e MODEL_NAME=... -p 9000:8000 test-miner:latest
"""

from __future__ import annotations

import ast
import difflib
import logging
import os
import sys
import tempfile
import time
import traceback
from pathlib import Path
from typing import Any, Dict, Optional, Tuple

from fastapi import FastAPI
from pydantic import BaseModel

# ── Ensure project root is importable ─────────────────────────────────
_PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent
if str(_PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(_PROJECT_ROOT))

try:
    from dotenv import load_dotenv
    load_dotenv(_PROJECT_ROOT / ".env")
except ImportError:
    pass

logger = logging.getLogger(__name__)
logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(levelname)s %(message)s")

app = FastAPI(title="Test Miner Agent")


# ═══════════════════════════════════════════════════════════════════════
#  Pydantic request/response models
# ═══════════════════════════════════════════════════════════════════════

class ChallengeRequest(BaseModel):
    task_name: str = ""
    challenge_type: str = ""
    constraints: Dict[str, Any] = {}
    db_snapshot_url: str = ""
    context: str = ""
    task_definition: Dict[str, Any] = {}
    scaffold_code: Optional[str] = None
    epoch: int = 0


class SubmissionResponse(BaseModel):
    model_code: str
    model_diff: str = ""
    parent_id: Optional[int] = None
    motivation: str = ""
    name: str = ""
    config: Dict[str, Any] = {}
    metadata: Dict[str, Any] = {}


# ═══════════════════════════════════════════════════════════════════════
#  Parent sampling from MongoDB REST API
# ═══════════════════════════════════════════════════════════════════════

async def sample_parent_from_db(
    task_name: str = "time_series_foundation",
) -> Optional[Dict[str, Any]]:
    """Query MongoDB REST API for a parent model to evolve from.

    Tries /elements/sample-range/{a}/{b}/{k} to get a random model
    from the top 50 ranked entries.  Returns the raw element dict
    (with 'program', 'name', 'index', etc.) or None if unavailable.
    """
    db_url = os.getenv("DATABASE_URL", "").rstrip("/")
    if not db_url:
        logger.info("DATABASE_URL not set — skipping parent sampling")
        return None

    try:
        import aiohttp

        async with aiohttp.ClientSession() as session:
            # Sample from top-50 ranked models (k=1 for a single parent)
            url = f"{db_url}/elements/sample-range/1/50/1"
            params = {"task": task_name}
            async with session.get(
                url, params=params, timeout=aiohttp.ClientTimeout(total=15)
            ) as resp:
                if resp.status == 200:
                    elements = await resp.json()
                    if elements and isinstance(elements, list) and len(elements) > 0:
                        parent = elements[0]
                        if parent.get("program"):
                            logger.info(
                                "Sampled parent from DB: name=%s index=%s",
                                parent.get("name", "?"),
                                parent.get("index", "?"),
                            )
                            return parent
                        else:
                            logger.info("Parent from DB has no program code — skipping")
                else:
                    logger.warning("DB parent sample returned %d", resp.status)

    except ImportError:
        logger.warning("aiohttp not installed — cannot sample parent from DB")
    except Exception:
        logger.warning("Failed to sample parent from DB", exc_info=True)

    return None


# ═══════════════════════════════════════════════════════════════════════
#  LLM-backed evolution (condensed planner + code checker)
# ═══════════════════════════════════════════════════════════════════════

EVOLVE_SYSTEM_PROMPT = """You are a neural architecture evolution agent for time-series forecasting.

You will receive:
1. A parent model source code (either scaffold or a DB-sampled model)
2. A challenge type describing what to improve
3. Constraints the model must satisfy
4. Experimental context from previous models

Your job: produce a COMPLETE, VALID Python file that is an improved variant of the parent.

CRITICAL CONTRACT REQUIREMENTS:
- Class must be named `TimeSeriesFoundationModel` and subclass `BaseTSFM`
- Must implement forward(), generate(), from_config(), to_config()
- Must define instantiate_model() that calls validate_time_series_model()
- forward/generate return {"quantiles": [B,H,Q], "quantile_levels": [Q]}
- All Linear layer dims must match d_model (typically 256) — no hardcoded 64/128
- Causal masks applied BEFORE softmax
- from_config() accepts dict with unknown keys; to_config() returns JSON-serializable values
- Set training_style = TrainingStyle.TEACHER_FORCED or TrainingStyle.DIRECT

RULES:
- Output ONLY the complete Python file content — no markdown fences, no prose
- Make ONE focused architectural change (not a rewrite)
- Keep the change small enough to be testable but meaningful
- Preserve all imports and the factory pattern
- The code must parse as valid Python (no syntax errors)

GOOD CHANGES (pick one per evolution):
- Replace vanilla attention with linear attention or sparse attention
- Add a state-space model (SSM/Mamba) layer alongside or replacing transformer blocks
- Add RevIN (Reversible Instance Normalization) for scale-free generalization
- Add multi-resolution temporal convolutions before the transformer
- Replace the positional encoding scheme (rotary, ALiBi, learnable)
- Add a gating mechanism (GLU, SwiGLU) in the feed-forward blocks
- Modify the quantile head (mixture density, copula, etc.)
- Add residual connections or skip connections across distant layers
- Add adaptive layer normalization conditioned on input statistics
"""


async def evolve_with_llm(
    parent_code: str,
    challenge_type: str,
    constraints: Dict[str, Any],
    context: str,
    parent_name: str = "scaffold",
) -> Tuple[str, str, str]:
    """Use LLM to evolve the parent into a new variant.

    Returns (model_code, motivation, name).
    """
    from services.providers.clients.chutes_client import ChutesClient

    model_name = os.getenv("MODEL_NAME", "")
    if not model_name:
        raise RuntimeError(
            "MODEL_NAME env var required (e.g. meta-llama/Llama-4-Scout-17B-16E-Instruct)"
        )

    user_prompt = f"""## Challenge Type
{challenge_type or "Open-ended — pick any improvement you think will help."}

## Constraints
- Max parameters: {constraints.get('max_params', 125_000_000)}
- Max inference latency: {constraints.get('max_inference_latency_ms', 50)}ms
- Required quantile levels: {constraints.get('required_quantile_levels', [0.1, 0.5, 0.9])}

## Experimental Context
{context[:3000] if context else "No prior experiments available."}

## Parent Model: {parent_name}
```python
{parent_code}
```

Produce the complete evolved Python file now. Remember: ONE focused change, valid Python, full contract compliance."""

    client = ChutesClient()
    messages = [
        {"role": "system", "content": EVOLVE_SYSTEM_PROMPT},
        {"role": "user", "content": user_prompt},
    ]

    raw = await client.chat(model=model_name, messages=messages)
    normalized = client.normalize(raw)
    text: str = normalized.get("text_response", "")

    code = _strip_markdown_fences(text)
    meta = await _extract_metadata(client, model_name, code, parent_code)

    return code, meta["motivation"], meta["name"]


async def _extract_metadata(
    client: Any,
    model_name: str,
    new_code: str,
    original_code: str,
) -> Dict[str, str]:
    """Ask the LLM for a short name + motivation for the change."""
    diff_lines = list(difflib.unified_diff(
        original_code.splitlines(),
        new_code.splitlines(),
        lineterm="",
        n=3,
    ))
    diff_text = "\n".join(diff_lines[:100])

    messages = [
        {"role": "system", "content": (
            "You are naming a neural architecture variant. "
            "Reply with EXACTLY two lines:\n"
            "NAME: <short_name_no_spaces>\n"
            "MOTIVATION: <one sentence explaining the architectural change>"
        )},
        {"role": "user", "content": f"Diff from parent:\n{diff_text}"},
    ]

    raw = await client.chat(model=model_name, messages=messages)
    normalized = client.normalize(raw)
    text = normalized.get("text_response", "")

    name = "EvolvedModel"
    motivation = "LLM-evolved variant"
    for line in text.strip().splitlines():
        if line.upper().startswith("NAME:"):
            name = line.split(":", 1)[1].strip().replace(" ", "_")[:50]
        elif line.upper().startswith("MOTIVATION:"):
            motivation = line.split(":", 1)[1].strip()[:500]

    return {"name": name, "motivation": motivation}


def _strip_markdown_fences(text: str) -> str:
    """Remove ```python ... ``` fences if present."""
    text = text.strip()
    if text.startswith("```"):
        lines = text.splitlines()
        lines = lines[1:]
        if lines and lines[-1].strip() == "```":
            lines = lines[:-1]
        text = "\n".join(lines)
    return text


# ═══════════════════════════════════════════════════════════════════════
#  Validation (condensed code checker)
# ═══════════════════════════════════════════════════════════════════════

def validate_candidate_code(code: str) -> Tuple[bool, str]:
    """Quick validation: syntax + basic contract checks.

    Returns (is_valid, error_message).
    """
    # 1. Syntax check
    try:
        tree = ast.parse(code)
    except SyntaxError as e:
        return False, f"Syntax error: {e}"

    # 2. Check for required class name
    class_names = [
        node.name for node in ast.walk(tree)
        if isinstance(node, ast.ClassDef)
    ]
    if "TimeSeriesFoundationModel" not in class_names:
        return False, "Missing class 'TimeSeriesFoundationModel'"

    # 3. Check for instantiate_model function
    func_names = [
        node.name for node in ast.walk(tree)
        if isinstance(node, ast.FunctionDef)
    ]
    if "instantiate_model" not in func_names:
        return False, "Missing function 'instantiate_model'"

    # 4. Check required methods exist on the class
    for cls_node in ast.walk(tree):
        if isinstance(cls_node, ast.ClassDef) and cls_node.name == "TimeSeriesFoundationModel":
            method_names = {
                node.name for node in cls_node.body
                if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))
            }
            required = {"forward", "generate", "from_config", "to_config"}
            missing = required - method_names
            if missing:
                return False, f"Missing methods on TimeSeriesFoundationModel: {missing}"
            break

    # 5. Try to actually import and instantiate (catches runtime errors)
    fd, tmp_path = tempfile.mkstemp(suffix=".py", prefix="miner_validate_")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            f.write(code)

        try:
            from tasks.ts_foundation.model_base import load_candidate_model
            import torch
            model = load_candidate_model(
                tmp_path,
                torch.device("cpu"),
                input_length=512,
                forecast_length=96,
            )
            return True, "OK"
        except Exception as e:
            return False, f"Runtime validation failed: {e}"
    finally:
        try:
            os.unlink(tmp_path)
        except OSError:
            pass


# ═══════════════════════════════════════════════════════════════════════
#  Fallback: return scaffold as-is with minor tweak
# ═══════════════════════════════════════════════════════════════════════

def make_fallback_submission(scaffold_code: str) -> Tuple[str, str, str]:
    """If LLM evolve fails, return the scaffold with a trivial change."""
    code = f"# Fallback submission (LLM evolve failed)\n{scaffold_code}"
    return code, "Fallback: scaffold baseline (evolve failed)", "FallbackBaseline"


# ═══════════════════════════════════════════════════════════════════════
#  Endpoints
# ═══════════════════════════════════════════════════════════════════════

@app.get("/")
@app.head("/")
async def root():
    """Health probe — affinetes sends HEAD / to check readiness."""
    return {"ok": True, "agent": "test-miner"}


@app.get("/health")
async def health():
    has_llm = bool(os.getenv("MODEL_NAME")) and bool(os.getenv("CHUTES_API_KEY"))
    has_db = bool(os.getenv("DATABASE_URL"))
    return {
        "ok": True,
        "agent": "test-miner",
        "llm_configured": has_llm,
        "db_configured": has_db,
        "model": os.getenv("MODEL_NAME", "(not set)"),
        "ts": time.time(),
    }


@app.post("/challenge")
async def handle_challenge(challenge: ChallengeRequest):
    """Receive a Challenge, evolve a model, return a MinerSubmission.

    Pipeline:
      1. Try to sample a parent from the DB (if DATABASE_URL is set)
      2. Fall back to scaffold if no DB parent found
      3. LLM-evolve the parent code
      4. Validate the evolved code (AST + runtime)
      5. Retry up to N times on validation failure
      6. Fall back to scaffold baseline if all attempts fail
    """
    logger.info(
        "Received challenge: type=%s epoch=%d task=%s",
        challenge.challenge_type, challenge.epoch, challenge.task_name,
    )

    # ── Load scaffold (always needed as fallback) ─────────────────
    scaffold = challenge.scaffold_code
    if not scaffold:
        scaffold_path = _PROJECT_ROOT / "scaffolds" / "ts_base_model.py"
        if scaffold_path.exists():
            scaffold = scaffold_path.read_text(encoding="utf-8")
        else:
            return SubmissionResponse(
                model_code="",
                motivation="No scaffold available",
                name="FAILED",
            ).model_dump()

    # ── Step 1: Sample parent from DB ─────────────────────────────
    parent_code = scaffold
    parent_id: Optional[int] = None
    parent_name = "scaffold"

    db_parent = await sample_parent_from_db(
        task_name=challenge.task_name or "time_series_foundation",
    )
    if db_parent and db_parent.get("program"):
        parent_code = db_parent["program"]
        parent_id = db_parent.get("index")
        parent_name = db_parent.get("name", "db_parent")
        logger.info(
            "Evolving from DB parent: name=%s index=%s",
            parent_name, parent_id,
        )
    else:
        logger.info("No DB parent found — evolving from scaffold")

    # ── Step 2: LLM evolution with retry ──────────────────────────
    max_attempts = int(os.getenv("MINER_MAX_EVOLVE_ATTEMPTS", "3"))
    last_error = ""

    for attempt in range(1, max_attempts + 1):
        logger.info("Evolution attempt %d/%d (parent=%s)", attempt, max_attempts, parent_name)
        try:
            code, motivation, name = await evolve_with_llm(
                parent_code=parent_code,
                challenge_type=challenge.challenge_type,
                constraints=challenge.constraints,
                context=challenge.context,
                parent_name=parent_name,
            )

            is_valid, error = validate_candidate_code(code)
            if is_valid:
                logger.info("Evolution succeeded: %s", name)
                diff = "\n".join(difflib.unified_diff(
                    parent_code.splitlines(),
                    code.splitlines(),
                    fromfile=f"parent ({parent_name})",
                    tofile="evolved",
                    lineterm="",
                ))
                return SubmissionResponse(
                    model_code=code,
                    model_diff=diff,
                    parent_id=parent_id,
                    motivation=motivation,
                    name=name,
                    config={"d_model": 256, "n_layers": 6},
                    metadata={
                        "attempt": attempt,
                        "evolved": True,
                        "parent_name": parent_name,
                        "parent_source": "db" if db_parent else "scaffold",
                    },
                ).model_dump()
            else:
                last_error = error
                logger.warning("Validation failed (attempt %d): %s", attempt, error)

        except Exception as e:
            last_error = str(e)
            logger.error("LLM evolve failed (attempt %d): %s", attempt, e)
            traceback.print_exc()

    # ── All attempts failed — fall back to scaffold ───────────────
    logger.warning("All evolution attempts failed (%s), using fallback", last_error)
    code, motivation, name = make_fallback_submission(scaffold)

    return SubmissionResponse(
        model_code=code,
        motivation=motivation,
        name=name,
        config={"d_model": 256, "n_layers": 6},
        metadata={"fallback": True, "last_error": last_error[:500]},
    ).model_dump()
