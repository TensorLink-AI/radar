"""Unit tests for the GIFT-Eval data loader.

Tests cover frequency normalisation, prediction-length resolution,
split-offset logic, windowing, and the dataset classes -- all without
requiring network access (HF datasets are mocked).
"""

from __future__ import annotations

import math
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional
from unittest.mock import MagicMock, patch

import numpy as np
import pytest
import torch

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from core.data.gift_loader import (
    PRED_LENGTH_MAP,
    M4_PRED_LENGTH_MAP,
    MAX_WINDOW,
    TEST_SPLIT_FRACTION,
    GiftEvalDataset,
    GiftEvalMode,
    GiftEvalSample,
    Term,
    _compute_min_series_length,
    _compute_windows,
    _extract_all_channels,
    _extract_target,
    _gift_collate,
    _GiftEvalFineTuningDataset,
    _GiftEvalZeroShotDataset,
    _observed_mask,
    maybe_reconvert_freq,
    normalize_freq,
    resolve_prediction_length,
)


# ── Frequency helpers ────────────────────────────────────────────────────


class TestMaybeReconvertFreq:
    def test_deprecated_aliases(self):
        assert maybe_reconvert_freq("Y") == "A"
        assert maybe_reconvert_freq("YE") == "A"
        assert maybe_reconvert_freq("ME") == "M"
        assert maybe_reconvert_freq("QE") == "Q"
        assert maybe_reconvert_freq("h") == "H"
        assert maybe_reconvert_freq("min") == "T"
        assert maybe_reconvert_freq("s") == "S"
        assert maybe_reconvert_freq("us") == "U"

    def test_passthrough(self):
        assert maybe_reconvert_freq("H") == "H"
        assert maybe_reconvert_freq("D") == "D"
        assert maybe_reconvert_freq("M") == "M"


class TestNormalizeFreq:
    def test_plain(self):
        assert normalize_freq("H") == "H"
        assert normalize_freq("D") == "D"
        assert normalize_freq("M") == "M"
        assert normalize_freq("W") == "W"
        assert normalize_freq("S") == "S"

    def test_with_numeric_prefix(self):
        assert normalize_freq("15T") == "T"
        assert normalize_freq("10S") == "S"
        assert normalize_freq("1h") == "H"
        assert normalize_freq("5min") == "T"

    def test_weekly_anchored(self):
        assert normalize_freq("W-WED") == "W"
        assert normalize_freq("W-MON") == "W"

    def test_deprecated_pandas2(self):
        assert normalize_freq("ME") == "M"
        assert normalize_freq("QE") == "Q"
        assert normalize_freq("YE") == "A"


class TestResolvePredictionLength:
    def test_standard_short(self):
        assert resolve_prediction_length("H", Term.SHORT, "electricity") == 48
        assert resolve_prediction_length("D", Term.SHORT, "covid_deaths") == 30
        assert resolve_prediction_length("W", Term.SHORT, "solar") == 8
        assert resolve_prediction_length("M", Term.SHORT, "hospital") == 12

    def test_standard_medium(self):
        assert resolve_prediction_length("H", Term.MEDIUM, "electricity") == 480

    def test_standard_long(self):
        assert resolve_prediction_length("H", Term.LONG, "electricity") == 720

    def test_m4_datasets(self):
        assert resolve_prediction_length("A", Term.SHORT, "m4_yearly") == 6
        assert resolve_prediction_length("Q", Term.SHORT, "m4_quarterly") == 8
        assert resolve_prediction_length("M", Term.SHORT, "m4_monthly") == 18

    def test_numeric_prefix(self):
        assert resolve_prediction_length("15T", Term.SHORT, "loop_seattle") == 48
        assert resolve_prediction_length("10S", Term.SHORT, "bizitobs") == 60

    def test_unsupported_freq_raises(self):
        with pytest.raises(ValueError, match="Unsupported frequency"):
            resolve_prediction_length("XYZ", Term.SHORT, "test")


# ── Term enum ────────────────────────────────────────────────────────────


class TestTerm:
    def test_multipliers(self):
        assert Term.SHORT.multiplier == 1
        assert Term.MEDIUM.multiplier == 10
        assert Term.LONG.multiplier == 15

    def test_from_string(self):
        assert Term("short") is Term.SHORT
        assert Term("medium") is Term.MEDIUM
        assert Term("long") is Term.LONG


# ── Internal helpers ─────────────────────────────────────────────────────


class TestExtractTarget:
    def test_univariate(self):
        row = {"target": [1.0, 2.0, 3.0]}
        arr = _extract_target(row)
        assert arr.shape == (3,)
        np.testing.assert_array_equal(arr, [1.0, 2.0, 3.0])

    def test_multivariate(self):
        row = {"target": [[1.0, 2.0], [3.0, 4.0], [5.0, 6.0]]}
        arr = _extract_target(row)
        assert arr.shape == (2,)
        np.testing.assert_array_equal(arr, [1.0, 2.0])

    def test_extract_all_channels_univariate(self):
        row = {"target": [1.0, 2.0, 3.0]}
        channels = _extract_all_channels(row)
        assert len(channels) == 1
        assert channels[0].shape == (3,)

    def test_extract_all_channels_multivariate(self):
        row = {"target": [[1.0, 2.0], [3.0, 4.0]]}
        channels = _extract_all_channels(row)
        assert len(channels) == 2
        np.testing.assert_array_equal(channels[0], [1.0, 2.0])
        np.testing.assert_array_equal(channels[1], [3.0, 4.0])


class TestObservedMask:
    def test_all_observed(self):
        arr = np.array([1.0, 2.0, 3.0])
        mask = _observed_mask(arr)
        np.testing.assert_array_equal(mask, [1.0, 1.0, 1.0])

    def test_with_nans(self):
        arr = np.array([1.0, np.nan, 3.0])
        mask = _observed_mask(arr)
        np.testing.assert_array_equal(mask, [1.0, 0.0, 1.0])

    def test_with_inf(self):
        arr = np.array([1.0, np.inf, 3.0])
        mask = _observed_mask(arr)
        np.testing.assert_array_equal(mask, [1.0, 0.0, 1.0])


class TestComputeMinSeriesLength:
    def _make_hf(self, targets):
        """Create a mock HF dataset from a list of target arrays."""
        rows = [{"target": t} for t in targets]
        return rows

    def test_univariate(self):
        ds = self._make_hf([[1.0, 2.0, 3.0], [1.0, 2.0]])
        assert _compute_min_series_length(ds, multivariate=False) == 2

    def test_multivariate(self):
        ds = self._make_hf([
            [[1.0, 2.0, 3.0], [4.0, 5.0, 6.0]],
            [[1.0, 2.0], [3.0, 4.0]],
        ])
        assert _compute_min_series_length(ds, multivariate=True) == 2


class TestComputeWindows:
    def test_m4_always_one(self):
        assert _compute_windows(1000, 48, "m4_hourly") == 1

    def test_standard_clamped(self):
        # 0.1 * 1000 / 48 = 2.08 → ceil = 3
        assert _compute_windows(1000, 48, "electricity") == 3

    def test_max_window_cap(self):
        # 0.1 * 100000 / 10 = 1000 → capped at 20
        assert _compute_windows(100000, 10, "test") == MAX_WINDOW

    def test_min_one(self):
        # Very short series: 0.1 * 10 / 100 = 0.01 → ceil = 1
        assert _compute_windows(10, 100, "test") == 1


# ── Collate ──────────────────────────────────────────────────────────────


class TestGiftCollate:
    def test_collate_tensors_and_strings(self):
        batch = [
            {"past_target": torch.ones(3, 1), "item_id": "a"},
            {"past_target": torch.zeros(3, 1), "item_id": "b"},
        ]
        out = _gift_collate(batch)
        assert out["past_target"].shape == (2, 3, 1)
        assert out["item_id"] == ["a", "b"]


# ── GiftEvalSample ──────────────────────────────────────────────────────


class TestGiftEvalSample:
    def test_to_dict(self):
        sample = GiftEvalSample(
            past_values=torch.zeros(10, 1),
            future_values=torch.ones(5, 1),
            past_observed_mask=torch.ones(10, 1),
            item_id="test_item",
        )
        d = sample.to_dict()
        assert "past_target" in d
        assert "future_target" in d
        assert "past_observed_mask" in d
        assert d["item_id"] == "test_item"
        assert "static_features" not in d

    def test_to_dict_with_static(self):
        sample = GiftEvalSample(
            past_values=torch.zeros(10, 1),
            future_values=torch.ones(5, 1),
            past_observed_mask=torch.ones(10, 1),
            item_id="test_item",
            static_features=torch.tensor([1.0, 2.0]),
        )
        d = sample.to_dict()
        assert "static_features" in d


# ── Zero-shot dataset ────────────────────────────────────────────────────


class TestZeroShotDataset:
    def test_yields_correct_windows(self):
        """A single series of length 100 with pred_len=10 and 3 windows
        should yield 3 samples."""
        series = np.arange(100, dtype=np.float32)
        hf_data = [{"target": series.tolist(), "item_id": "ts_0"}]

        ds = _GiftEvalZeroShotDataset(
            hf_dataset=hf_data,
            prediction_length=10,
            windows=3,
            context_length=20,
            to_univariate=False,
            dataset_name="test",
        )

        samples = list(ds)
        assert len(samples) == 3

        # Check shapes
        for s in samples:
            assert s["past_target"].shape == (20, 1)
            assert s["future_target"].shape == (10, 1)
            assert s["past_observed_mask"].shape == (20, 1)

    def test_multivariate_expansion(self):
        """With to_univariate=True, a 2-channel series should yield
        2x the windows."""
        series = np.stack([
            np.arange(100, dtype=np.float32),
            np.arange(100, 200, dtype=np.float32),
        ])
        hf_data = [{"target": series.tolist(), "item_id": "mv_0"}]

        ds = _GiftEvalZeroShotDataset(
            hf_dataset=hf_data,
            prediction_length=10,
            windows=2,
            context_length=20,
            to_univariate=True,
            dataset_name="test",
        )

        samples = list(ds)
        assert len(samples) == 4  # 2 channels * 2 windows

        item_ids = [s["item_id"] for s in samples]
        assert "mv_0_dim0" in item_ids
        assert "mv_0_dim1" in item_ids

    def test_window_values_are_correct(self):
        """Verify the actual values in the windows are from the right
        positions in the series."""
        n = 50
        series = np.arange(n, dtype=np.float32)
        pred_len = 5
        windows = 2
        ctx_len = 10

        hf_data = [{"target": series.tolist(), "item_id": "ts_0"}]
        ds = _GiftEvalZeroShotDataset(
            hf_dataset=hf_data,
            prediction_length=pred_len,
            windows=windows,
            context_length=ctx_len,
            to_univariate=False,
            dataset_name="test",
        )

        samples = list(ds)
        assert len(samples) == 2

        # Window 0: future = series[40:45], past = series[30:40]
        # test_start = 50 - 2*5 = 40
        # w=0: future_end=45, future_start=40, past_start=30
        np.testing.assert_array_almost_equal(
            samples[0]["future_target"].squeeze(-1).numpy(),
            np.arange(40, 45, dtype=np.float32),
        )
        np.testing.assert_array_almost_equal(
            samples[0]["past_target"].squeeze(-1).numpy(),
            np.arange(30, 40, dtype=np.float32),
        )

        # Window 1: future = series[45:50], past = series[35:45]
        np.testing.assert_array_almost_equal(
            samples[1]["future_target"].squeeze(-1).numpy(),
            np.arange(45, 50, dtype=np.float32),
        )


# ── Fine-tuning dataset ─────────────────────────────────────────────────


class TestFineTuningDataset:
    def test_sliding_windows(self):
        series = np.arange(100, dtype=np.float32)
        # train_end=70 (e.g. 100 - 10*(2+1) = 70)
        ds = _GiftEvalFineTuningDataset(
            series_list=[series],
            item_ids=["ts_0"],
            static_features_list=[None],
            context_length=10,
            prediction_length=10,
            stride=10,
            train_end_offsets=[70],
        )

        # usable = 70 steps, window = 20, max_start = 50
        # starts at 0, 10, 20, 30, 40, 50 → 6 windows
        assert len(ds) == 6

        sample = ds[0]
        assert sample["past_target"].shape == (10, 1)
        assert sample["future_target"].shape == (10, 1)
        assert "static_features" not in sample

    def test_with_static_features(self):
        series = np.arange(50, dtype=np.float32)
        static = np.array([1.0, 2.0], dtype=np.float32)
        ds = _GiftEvalFineTuningDataset(
            series_list=[series],
            item_ids=["ts_0"],
            static_features_list=[static],
            context_length=10,
            prediction_length=5,
            stride=5,
            train_end_offsets=[40],
        )

        sample = ds[0]
        assert "static_features" in sample
        torch.testing.assert_close(
            sample["static_features"],
            torch.tensor([1.0, 2.0]),
        )

    def test_empty_when_series_too_short(self):
        series = np.arange(5, dtype=np.float32)
        ds = _GiftEvalFineTuningDataset(
            series_list=[series],
            item_ids=["ts_0"],
            static_features_list=[None],
            context_length=10,
            prediction_length=10,
            stride=10,
            train_end_offsets=[5],
        )
        assert len(ds) == 0


# ── Integration: GiftEvalDataset with mocked HF ─────────────────────────


def _make_mock_hf_dataset(
    n_series: int = 5,
    series_length: int = 200,
    freq: str = "H",
    multivariate: bool = False,
    n_channels: int = 1,
) -> MagicMock:
    """Create a mock that behaves like an HF ``datasets.Dataset``."""
    rows = []
    for i in range(n_series):
        series = np.random.randn(series_length).astype(np.float32)
        if multivariate:
            series = np.stack([
                np.random.randn(series_length).astype(np.float32)
                for _ in range(n_channels)
            ])
        rows.append({
            "target": series,
            "item_id": f"series_{i}",
            "freq": freq,
        })

    mock_ds = MagicMock()
    mock_ds.__getitem__ = lambda _, idx: rows[idx]
    mock_ds.__iter__ = lambda _: iter(rows)
    mock_ds.__len__ = lambda _: len(rows)
    mock_ds.with_format = MagicMock(return_value=None)

    # with_format() should return an object with the same interface
    def _with_format(fmt):  # noqa: ARG001
        return mock_ds

    mock_ds.with_format.side_effect = _with_format
    return mock_ds


class TestGiftEvalDatasetIntegration:
    @patch("core.data.gift_loader.load_dataset")
    def test_zero_shot_mode(self, mock_load):
        mock_ds = _make_mock_hf_dataset(n_series=3, series_length=200, freq="H")
        mock_load.return_value = mock_ds

        gift = GiftEvalDataset(
            dataset_name="test/hourly",
            term="short",
            mode="zero_shot",
            context_length=48,
            batch_size=4,
        )

        assert gift.prediction_length == 48
        assert gift.context_length == 48
        assert gift.windows >= 1

        loader = gift.get_dataloader()
        batch = next(iter(loader))
        assert "past_target" in batch
        assert "future_target" in batch
        assert batch["past_target"].shape[-1] == 1
        assert batch["future_target"].shape[-1] == 1
        assert batch["future_target"].shape[1] == 48

    @patch("core.data.gift_loader.load_dataset")
    def test_fine_tuning_mode(self, mock_load):
        mock_ds = _make_mock_hf_dataset(n_series=3, series_length=500, freq="D")
        mock_load.return_value = mock_ds

        gift = GiftEvalDataset(
            dataset_name="test/daily",
            term="short",
            mode="fine_tuning",
            context_length=60,
            batch_size=8,
        )

        assert gift.prediction_length == 30

        loader = gift.get_dataloader()
        batch = next(iter(loader))
        assert batch["past_target"].shape[1] == 60
        assert batch["future_target"].shape[1] == 30

    @patch("core.data.gift_loader.load_dataset")
    def test_multivariate_to_univariate(self, mock_load):
        mock_ds = _make_mock_hf_dataset(
            n_series=2, series_length=300, freq="H",
            multivariate=True, n_channels=3,
        )
        mock_load.return_value = mock_ds

        gift = GiftEvalDataset(
            dataset_name="test/multi",
            term="short",
            mode="zero_shot",
            context_length=48,
        )

        assert gift.target_dim == 3
        # to_univariate should be auto-detected
        loader = gift.get_dataloader()
        samples = list(loader)
        # Should have samples from all channels
        all_ids = []
        for batch in samples:
            all_ids.extend(batch["item_id"])
        assert any("dim0" in str(i) for i in all_ids)
        assert any("dim1" in str(i) for i in all_ids)

    @patch("core.data.gift_loader.load_dataset")
    def test_from_disk_path(self, mock_load):
        mock_ds = _make_mock_hf_dataset(n_series=2, series_length=200, freq="M")

        with patch("core.data.gift_loader.load_from_disk", return_value=mock_ds) as mock_disk:
            gift = GiftEvalDataset(
                dataset_name="/tmp/fake_dataset",
                term="short",
                mode="zero_shot",
                from_disk=True,
            )
            mock_disk.assert_called_once_with("/tmp/fake_dataset")
            assert gift.prediction_length == 12
