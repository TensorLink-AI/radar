"""Tests for subnet.validator.chain – ChainInterface."""

from __future__ import annotations

import sys
import types
import unittest
from unittest.mock import MagicMock, patch


# Stub heavy dependencies that ChainInterface imports lazily
_MOCK_MODULES = [
    "bittensor",
    "torch", "torch.nn", "torch.nn.functional",
]
for _mod in _MOCK_MODULES:
    if _mod not in sys.modules:
        _m = types.ModuleType(_mod)
        sys.modules[_mod] = _m

# Ensure torch stub has tensor(), int64, float32 for set_weights
_torch_stub = sys.modules["torch"]
_torch_stub.tensor = lambda data, dtype=None: data  # passthrough
_torch_stub.int64 = "int64"
_torch_stub.float32 = "float32"

from subnet.validator.chain import ChainInterface


class TestChainInterface(unittest.TestCase):
    """Test ChainInterface with mocked bittensor."""

    def test_lazy_subtensor_not_created_on_init(self):
        """subtensor should NOT be created until first access."""
        chain = ChainInterface()
        self.assertIsNone(chain._subtensor)
        self.assertIsNone(chain._wallet)

    def test_read_commitments_delegates_to_protocol(self):
        """read_commitments should call read_miner_commitments."""
        chain = ChainInterface()
        mock_subtensor = MagicMock()
        chain._subtensor = mock_subtensor

        with patch("subnet.validator.chain.read_miner_commitments", return_value=[]) as mock_rmc:
            result = chain.read_commitments()

        mock_rmc.assert_called_once_with(mock_subtensor, 0)  # NETUID default
        self.assertEqual(result, [])

    def test_get_metagraph_delegates_to_subtensor(self):
        """get_metagraph should call subtensor.metagraph."""
        chain = ChainInterface()
        mock_subtensor = MagicMock()
        chain._subtensor = mock_subtensor

        chain.get_metagraph()

        mock_subtensor.metagraph.assert_called_once()

    def test_set_weights_calls_subtensor(self):
        """set_weights should call subtensor.set_weights and return success."""
        chain = ChainInterface()
        mock_subtensor = MagicMock()
        mock_subtensor.set_weights.return_value = (True, "ok")
        chain._subtensor = mock_subtensor
        chain._wallet = MagicMock()

        result = chain.set_weights([1, 2], [0.6, 0.4])

        self.assertTrue(result)
        mock_subtensor.set_weights.assert_called_once()

    def test_set_weights_returns_false_on_failure(self):
        """set_weights should return False when subtensor returns failure."""
        chain = ChainInterface()
        mock_subtensor = MagicMock()
        mock_subtensor.set_weights.return_value = (False, "rate limited")
        chain._subtensor = mock_subtensor
        chain._wallet = MagicMock()

        result = chain.set_weights([1], [1.0])

        self.assertFalse(result)


if __name__ == "__main__":
    unittest.main()
