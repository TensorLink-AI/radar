import sys
import asyncio
import types
from pathlib import Path
from typing import List

import pytest

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.append(str(ROOT))

if "httpx" not in sys.modules:
    class _StubTimeout:
        def __init__(self, *args, **kwargs):
            pass

    class _StubAsyncClient:
        def __init__(self, *args, **kwargs):
            pass

        async def post(self, *args, **kwargs):  # pragma: no cover - stub
            raise NotImplementedError("httpx stub does not support network calls")

        async def aclose(self):  # pragma: no cover - stub
            pass

    class _StubHTTPStatusError(Exception):
        def __init__(self, *args, request=None, response=None):
            super().__init__(*args)
            self.request = request
            self.response = response

    sys.modules["httpx"] = types.SimpleNamespace(
        AsyncClient=_StubAsyncClient,
        Timeout=_StubTimeout,
        HTTPStatusError=_StubHTTPStatusError,
    )

from services.providers.config import AgentConfig
from services.providers.provider import ProviderAgent
from services.providers.state import AgentState


class DummyLLM:
    """Minimal LLM client stub used for unit tests."""

    @staticmethod
    def normalize(resp):
        return resp


def _make_agent(tool_fn, max_tool_rounds, **config_overrides):
    tools = tool_fn if isinstance(tool_fn, list) else [tool_fn]
    config = AgentConfig(
        max_tool_rounds=max_tool_rounds,
        max_tool_calls_per_round=10,
        max_tool_calls_total=10,
        **config_overrides,
    )
    return ProviderAgent(
        llm=DummyLLM(),
        tools=tools,
        model_name="test-model",
        config=config,
    )


def _tool_call_payload(name="test_tool"):
    return [
        {
            "id": "call_0",
            "type": "function",
            "function": {"name": name, "arguments": "{}"},
        }
    ]


def test_handle_tool_calls_allows_first_round_with_single_round_budget():
    call_log = []

    def test_tool():
        call_log.append(len(call_log))
        return {"calls": len(call_log)}

    agent = _make_agent(test_tool, max_tool_rounds=1)
    state = AgentState()
    messages = []
    tool_calls = _tool_call_payload(name=test_tool.__name__)

    asyncio.run(agent._handle_tool_calls(state, messages, tool_calls))

    assert state.tool_rounds == 1
    assert state.total_tool_calls == 1
    assert call_log == [0]
    assert not state.tools_budget_exhausted

    asyncio.run(agent._handle_tool_calls(state, messages, tool_calls))

    assert state.tool_rounds == 1
    assert state.total_tool_calls == 1
    assert state.tools_budget_exhausted is True
    assert call_log == [0]


def test_handle_tool_calls_runs_exact_configured_rounds():
    call_log = []

    def test_tool():
        call_log.append(len(call_log))
        return {"calls": len(call_log)}

    agent = _make_agent(test_tool, max_tool_rounds=2)
    state = AgentState()
    messages = []
    tool_calls = _tool_call_payload(name=test_tool.__name__)

    asyncio.run(agent._handle_tool_calls(state, messages, tool_calls))
    asyncio.run(agent._handle_tool_calls(state, messages, tool_calls))

    assert state.tool_rounds == 2
    assert state.total_tool_calls == 2
    assert call_log == [0, 1]
    assert not state.tools_budget_exhausted

    asyncio.run(agent._handle_tool_calls(state, messages, tool_calls))

    assert state.tool_rounds == 2
    assert state.total_tool_calls == 2
    assert state.tools_budget_exhausted is True
    assert call_log == [0, 1]


def test_handle_tool_calls_records_write_code_usage():
    write_log = []

    def fake_write_code(**kwargs):
        write_log.append(kwargs)
        return {"status": "ok"}

    fake_write_code.__name__ = "write_code_file"

    agent = _make_agent(fake_write_code, max_tool_rounds=2)
    state = AgentState()
    messages = []
    tool_calls = _tool_call_payload(name="write_code_file")

    asyncio.run(agent._handle_tool_calls(state, messages, tool_calls))

    assert state.write_code_calls == 1
    assert state.total_tool_calls == 1
    assert write_log


def test_require_write_code_injects_instruction_until_called():
    def fake_tool():
        return {"ok": True}

    agent = _make_agent(fake_tool, max_tool_rounds=2, require_write_code=True)
    state = AgentState()
    state.had_tool_round = True
    messages: List[dict] = []

    result = asyncio.run(
        agent._handle_no_tool_response(state, messages, "final", response_model=None)
    )

    assert result is None
    assert messages[-2]["role"] == "assistant"
    assert messages[-1]["role"] == "system"
    assert "write_code_file" in messages[-1]["content"]


def test_require_write_code_allows_final_response_after_call():
    def fake_tool():
        return {"ok": True}

    agent = _make_agent(fake_tool, max_tool_rounds=2, require_write_code=True)
    state = AgentState()
    state.had_tool_round = True
    state.write_code_calls = 1
    messages: List[dict] = []

    result = asyncio.run(
        agent._handle_no_tool_response(state, messages, "final", response_model=None)
    )

    assert result == "final"
