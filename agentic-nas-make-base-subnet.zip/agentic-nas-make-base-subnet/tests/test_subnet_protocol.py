"""Tests for subnet protocol types and commitment handling."""

import json
import pytest
from subnet.protocol.types import (
    Challenge,
    MinerSubmission,
    MinerCommitment,
    CandidateResult,
    EpochState,
    SubmissionStatus,
    EvalTier,
)
from subnet.protocol.commitment import (
    encode_commitment,
    decode_commitment,
)


class TestChallenge:
    """Test Challenge dataclass."""

    def test_default_values(self):
        """Challenge should have sensible defaults."""
        c = Challenge(task_name="test_task")
        assert c.task_name == "test_task"
        assert c.challenge_type == ""
        assert c.constraints == {}
        assert c.db_snapshot_url == ""
        assert c.epoch == 0

    def test_full_construction(self):
        """Challenge should accept all fields."""
        c = Challenge(
            task_name="time_series_foundation",
            challenge_type="long_range",
            constraints={"max_params": 10000000},
            db_snapshot_url="https://r2.example.com/snapshot.tar.gz",
            context="Some context",
            task_definition={"name": "ts"},
            scaffold_code="# scaffold",
            epoch=5,
        )
        assert c.task_name == "time_series_foundation"
        assert c.challenge_type == "long_range"
        assert c.constraints["max_params"] == 10000000
        assert c.db_snapshot_url == "https://r2.example.com/snapshot.tar.gz"


class TestMinerSubmission:
    """Test MinerSubmission dataclass."""

    def test_required_fields(self):
        """MinerSubmission requires hotkey, uid, model_code."""
        sub = MinerSubmission(
            hotkey="test_hotkey",
            uid=42,
            model_code="class Model: pass",
        )
        assert sub.hotkey == "test_hotkey"
        assert sub.uid == 42
        assert sub.model_code == "class Model: pass"
        assert sub.status == SubmissionStatus.SUCCEEDED

    def test_default_status(self):
        """Default status should be SUCCEEDED."""
        sub = MinerSubmission(hotkey="h", uid=1, model_code="c")
        assert sub.status == SubmissionStatus.SUCCEEDED


class TestCandidateResult:
    """Test CandidateResult dataclass."""

    def test_constraints_satisfied_defaults_false(self):
        """constraints_satisfied should default to False for safety."""
        result = CandidateResult(
            hotkey="h", uid=1, name="n", motivation="m", model_code="c"
        )
        assert result.constraints_satisfied is False

    def test_score_fields_default_none(self):
        """Score fields should default to None."""
        result = CandidateResult(
            hotkey="h", uid=1, name="n", motivation="m", model_code="c"
        )
        assert result.zero_cost_score is None
        assert result.train_loss is None
        assert result.test_loss is None
        assert result.final_score == 0.0


class TestSubmissionStatus:
    """Test SubmissionStatus enum."""

    def test_string_values(self):
        """Status enum should have string values."""
        assert SubmissionStatus.SUCCEEDED.value == "succeeded"
        assert SubmissionStatus.FAILED.value == "failed"
        assert SubmissionStatus.PENDING.value == "pending"

    def test_enum_comparison(self):
        """Status enum should be comparable."""
        assert SubmissionStatus.SUCCEEDED == SubmissionStatus.SUCCEEDED
        assert SubmissionStatus.SUCCEEDED != SubmissionStatus.FAILED


class TestEvalTier:
    """Test EvalTier enum."""

    def test_string_values(self):
        """EvalTier enum should have correct string values."""
        assert EvalTier.ZERO_COST.value == "zero_cost"
        assert EvalTier.SMALL_BUDGET.value == "small_budget"
        assert EvalTier.LARGE_BUDGET.value == "large_budget"


class TestCommitmentEncoding:
    """Test commitment serialization."""

    def test_encode_basic(self):
        """Basic encoding should produce valid JSON."""
        raw = encode_commitment("myimage:v1")
        data = json.loads(raw)
        assert data["docker_image"] == "myimage:v1"
        assert "metadata" not in data

    def test_encode_with_metadata(self):
        """Encoding with metadata should include it."""
        raw = encode_commitment(
            "myimage:v1",
            metadata={"version": "1.0", "gpu": True}
        )
        data = json.loads(raw)
        assert data["docker_image"] == "myimage:v1"
        assert data["metadata"]["version"] == "1.0"
        assert data["metadata"]["gpu"] is True

    def test_encode_compact(self):
        """Encoding should be compact (no extra whitespace)."""
        raw = encode_commitment("img", metadata={"k": "v"})
        assert " " not in raw  # No spaces
        assert "\n" not in raw  # No newlines


class TestCommitmentDecoding:
    """Test commitment deserialization."""

    def test_decode_valid(self):
        """Valid commitment should decode correctly."""
        raw = '{"docker_image":"myimage:v1"}'
        commitment = decode_commitment(raw, hotkey="hk1", uid=5, block=100)

        assert commitment is not None
        assert commitment.hotkey == "hk1"
        assert commitment.uid == 5
        assert commitment.docker_image == "myimage:v1"
        assert commitment.block_committed == 100

    def test_decode_with_metadata(self):
        """Commitment with metadata should decode correctly."""
        raw = '{"docker_image":"img:v2","metadata":{"foo":"bar"}}'
        commitment = decode_commitment(raw, hotkey="hk", uid=1, block=0)

        assert commitment is not None
        assert commitment.metadata == {"foo": "bar"}

    def test_decode_malformed_json(self):
        """Malformed JSON should return None."""
        commitment = decode_commitment("not json", hotkey="hk", uid=1, block=0)
        assert commitment is None

    def test_decode_missing_docker_image(self):
        """Missing docker_image should return None."""
        raw = '{"metadata":{"foo":"bar"}}'
        commitment = decode_commitment(raw, hotkey="hk", uid=1, block=0)
        assert commitment is None

    def test_decode_empty_docker_image(self):
        """Empty docker_image should return None."""
        raw = '{"docker_image":""}'
        commitment = decode_commitment(raw, hotkey="hk", uid=1, block=0)
        assert commitment is None

    def test_roundtrip(self):
        """Encode then decode should preserve data."""
        original_image = "registry.io/miner:latest"
        original_meta = {"gpu_type": "A100", "version": 3}

        encoded = encode_commitment(original_image, original_meta)
        decoded = decode_commitment(encoded, hotkey="hk", uid=10, block=500)

        assert decoded is not None
        assert decoded.docker_image == original_image
        assert decoded.metadata == original_meta


class TestEpochState:
    """Test EpochState dataclass."""

    def test_default_values(self):
        """EpochState should have empty defaults."""
        state = EpochState()
        assert state.epoch == 0
        assert state.challenge_type == ""
        assert state.constraints == {}
        assert state.commitments == []
        assert state.submissions == []
        assert state.results == []
        assert state.weights == {}

    def test_populated_state(self):
        """EpochState should hold all phase data."""
        state = EpochState(
            epoch=5,
            challenge_type="multi_scale",
            constraints={"max_params": 1000},
        )

        # Add some commitments
        state.commitments = [
            MinerCommitment(hotkey="h1", uid=1, docker_image="img1"),
        ]

        # Add submissions
        state.submissions = [
            MinerSubmission(hotkey="h1", uid=1, model_code="code"),
        ]

        # Add results
        state.results = [
            CandidateResult(
                hotkey="h1", uid=1, name="m1", motivation="", model_code="code"
            ),
        ]

        # Add weights
        state.weights = {1: 1.0}

        assert state.epoch == 5
        assert len(state.commitments) == 1
        assert len(state.submissions) == 1
        assert len(state.results) == 1
        assert state.weights[1] == 1.0
