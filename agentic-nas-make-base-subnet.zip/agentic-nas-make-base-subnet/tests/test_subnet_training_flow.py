"""
End-to-end test for the subnet training flow with live Basilica training.

This test script exercises the full validator epoch pipeline (Phases 1-4)
using real Basilica GPU pods for both proxy evaluation and deep training.

Phase 1 has two modes:
  - Default: synthetic MinerSubmission objects using the reference scaffold
  - --use-miner: sends Challenges to a real mock miner server that uses an
    LLM to evolve the scaffold into novel variants (see tests/test_subnet/)

Prerequisites:
    - BASILICA_API_TOKEN set in environment (or .env)
    - BASILICA_DOCKER_IMAGE (or DEEP_TRAIN_IMAGE) set to a pushed training image
    - ``pip install -e .`` (or requirements-minimal.txt + affinetes + httpx)
    - For --use-miner mode: CHUTES_API_KEY + MODEL_NAME set
    - Optionally: MongoDB running (cd database && docker compose up -d) for
      Phase 4 persistence; otherwise persistence is skipped gracefully.

Usage:
    # Quick smoke test: synthetic submissions + short training
    python tests/test_subnet_training_flow.py --skip-proxy --num-submissions 2

    # Full pipeline with LLM-evolved miner submissions (local server)
    python tests/test_subnet_training_flow.py --use-miner --num-submissions 3

    # Deploy miner on Basilica via affinetes (matches production miner_runner.py)
    python tests/test_subnet_training_flow.py --use-miner \
        --miner-image your-registry/test-miner:latest --num-submissions 3

    # Miner evolve + full two-stage training (short + long)
    python tests/test_subnet_training_flow.py --use-miner --full

    # Use a running miner server (local or Docker)
    python tests/test_subnet_training_flow.py --use-miner --miner-url http://localhost:9000

    # Skip proxy eval, only training
    python tests/test_subnet_training_flow.py --skip-proxy

    # Use local CPU proxy eval instead of Basilica pod
    python tests/test_subnet_training_flow.py --local-proxy

    # Custom number of synthetic submissions
    python tests/test_subnet_training_flow.py --num-submissions 5

    # Override Docker image for training pods
    python tests/test_subnet_training_flow.py --image your-registry/image:tag
"""

from __future__ import annotations

import argparse
import asyncio
import json
import logging
import os
import sys
import time
from pathlib import Path
from typing import Any, Dict, List, Optional

# ── Ensure project root is on sys.path ────────────────────────────────
PROJECT_ROOT = Path(__file__).resolve().parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

# Load .env before anything reads env vars
try:
    from dotenv import load_dotenv
    load_dotenv(PROJECT_ROOT / ".env")
except ImportError:
    pass

from subnet.config import SubnetConfig
from subnet.protocol.types import (
    CandidateResult,
    MinerSubmission,
    SubmissionStatus,
)
from subnet.validator.scoring import compute_weights

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(name)s %(levelname)s %(message)s",
)
logger = logging.getLogger("test_subnet_training_flow")


# ═══════════════════════════════════════════════════════════════════════
#  1. Synthetic submission factory
# ═══════════════════════════════════════════════════════════════════════


def _load_scaffold_code() -> str:
    """Load the reference scaffold model source code."""
    scaffold_path = PROJECT_ROOT / "scaffolds" / "ts_base_model.py"
    if not scaffold_path.exists():
        raise FileNotFoundError(
            f"Scaffold not found at {scaffold_path}. "
            "Run this from the repo root."
        )
    return scaffold_path.read_text(encoding="utf-8")


def make_synthetic_submissions(
    n: int = 3,
    scaffold_code: Optional[str] = None,
) -> List[MinerSubmission]:
    """Create N synthetic miner submissions using the scaffold model.

    Each submission uses the same scaffold code (the reference model),
    simulating N miners that all submitted the baseline architecture.
    In a real epoch, miners would submit evolved variants.
    """
    if scaffold_code is None:
        scaffold_code = _load_scaffold_code()

    submissions = []
    for i in range(n):
        sub = MinerSubmission(
            hotkey=f"5TestMiner{i:03d}",
            uid=i,
            model_code=scaffold_code,
            model_diff="",
            parent_id=None,
            motivation=f"Test submission {i} – reference scaffold baseline",
            name=f"scaffold_baseline_{i}",
            config={"d_model": 256, "n_layers": 6},
            metadata={"test": True},
            status=SubmissionStatus.SUCCEEDED,
        )
        submissions.append(sub)
    return submissions


# ═══════════════════════════════════════════════════════════════════════
#  1b. Phase 1: Live miner submissions via mock miner server
# ═══════════════════════════════════════════════════════════════════════


async def _start_local_miner_server(port: int = 9321) -> tuple:
    """Start the mock miner server in-process for convenience.

    Returns (process, url). The caller must terminate the process.
    """
    import subprocess

    env = os.environ.copy()
    env["PYTHONPATH"] = str(PROJECT_ROOT)

    proc = subprocess.Popen(
        [
            sys.executable, "-m", "uvicorn",
            "tests.test_subnet.miner_server:app",
            "--host", "127.0.0.1",
            "--port", str(port),
            "--log-level", "info",
        ],
        cwd=str(PROJECT_ROOT),
        env=env,
    )

    url = f"http://127.0.0.1:{port}"

    # Wait for server to be ready
    import httpx
    for attempt in range(30):
        await asyncio.sleep(1)
        try:
            async with httpx.AsyncClient() as client:
                resp = await client.get(f"{url}/health", timeout=3)
                if resp.status_code == 200:
                    logger.info("Local miner server ready at %s", url)
                    return proc, url
        except Exception:
            pass

    proc.terminate()
    raise RuntimeError(f"Miner server failed to start on port {port}")


async def _deploy_miner_on_basilica(miner_image: str) -> tuple:
    """Deploy the miner Docker image on Basilica via affinetes.

    This mirrors production miner_runner.py: the validator deploys the
    miner's container on Basilica, sends challenges via HTTP, and
    cleans up when done.

    Returns (env, url) where env is the affinetes environment object
    and url is the pod's HTTP endpoint.
    """
    try:
        import affinetes as af
    except ImportError:
        raise RuntimeError(
            "affinetes is not installed. Install with: pip install affinetes"
        )

    api_token = os.getenv("BASILICA_API_TOKEN", "")
    if not api_token:
        raise RuntimeError("BASILICA_API_TOKEN is required for Basilica miner deployment")

    # Forward LLM credentials + DATABASE_URL into the miner container
    env_vars: Dict[str, str] = {"PYTHONUNBUFFERED": "1"}
    for key in ("CHUTES_API_KEY", "MODEL_NAME", "DATABASE_URL",
                "MINER_MAX_EVOLVE_ATTEMPTS", "CHUTES_API_URL"):
        val = os.getenv(key, "")
        if val:
            env_vars[key] = val

    logger.info("Deploying miner image on Basilica: %s", miner_image)
    logger.info("  env_vars forwarded: %s", list(env_vars.keys()))

    # af.load_env is blocking — run in thread to avoid blocking the event loop
    def _sync_load():
        return af.load_env(
            mode="basilica",
            image=miner_image,
            api_token=api_token,
            env_vars=env_vars,
            # Miner doesn't need GPU — just CPU for LLM API calls + code validation
            gpu_count=0,
            memory=os.getenv("MINER_POD_MEMORY", "8Gi"),
            ttl_seconds=SubnetConfig.MINER_POD_TIMEOUT_SEC + 300,
            timeout=900,
        )

    env = await asyncio.to_thread(_sync_load)
    pod_url = env.url
    logger.info("Miner pod ready at %s", pod_url)

    # Health check
    import httpx
    for attempt in range(30):
        try:
            async with httpx.AsyncClient() as client:
                resp = await client.head(pod_url, timeout=5)
                if resp.status_code == 200:
                    logger.info("Miner pod health check passed")
                    return env, pod_url
        except Exception:
            pass
        await asyncio.sleep(2)

    # Clean up on health check failure
    try:
        if asyncio.iscoroutinefunction(env.cleanup):
            await env.cleanup()
        else:
            await asyncio.to_thread(env.cleanup)
    except Exception:
        pass
    raise RuntimeError(f"Miner pod at {pod_url} failed health checks")


async def run_phase1_miner_submissions(
    n: int,
    miner_url: str,
    scaffold_code: str,
    challenge_type: str = "",
) -> List[MinerSubmission]:
    """Send Challenges to the mock miner server and collect submissions.

    Args:
        n: Number of submissions to request (sequential calls with
           different challenge types if available).
        miner_url: Base URL of the mock miner server.
        scaffold_code: Reference scaffold source code.
        challenge_type: Specific challenge type, or "" for rotation.
    """
    import httpx

    challenge_categories = [
        "Long-Range Dependencies",
        "Multi-Scale & Frequency",
        "Non-Stationarity",
        "Scale-Free Generalization",
        "SNR Variability",
        "Computational Efficiency",
    ]

    constraints = SubnetConfig.get_constraints()
    submissions: List[MinerSubmission] = []

    async with httpx.AsyncClient(timeout=httpx.Timeout(300)) as client:
        for i in range(n):
            ct = challenge_type or challenge_categories[i % len(challenge_categories)]
            logger.info(
                "  [Phase 1] Requesting submission %d/%d (challenge=%s)...",
                i + 1, n, ct,
            )

            challenge_payload = {
                "task_name": SubnetConfig.TASK_NAME,
                "challenge_type": ct,
                "constraints": constraints,
                "db_snapshot_url": "",
                "context": "",
                "task_definition": {},
                "scaffold_code": scaffold_code,
                "epoch": 0,
            }

            try:
                resp = await client.post(
                    f"{miner_url}/challenge",
                    json=challenge_payload,
                )
                resp.raise_for_status()
                data = resp.json()

                sub = MinerSubmission(
                    hotkey=f"5TestMiner{i:03d}",
                    uid=i,
                    model_code=data.get("model_code", ""),
                    model_diff=data.get("model_diff", ""),
                    parent_id=data.get("parent_id"),
                    motivation=data.get("motivation", ""),
                    name=data.get("name", f"miner_{i}"),
                    config=data.get("config", {}),
                    metadata=data.get("metadata", {}),
                    status=SubmissionStatus.SUCCEEDED if data.get("model_code") else SubmissionStatus.FAILED,
                )
                submissions.append(sub)
                logger.info(
                    "    -> Received: %s (evolved=%s, %d bytes)",
                    sub.name,
                    sub.metadata.get("evolved", False),
                    len(sub.model_code),
                )

            except Exception as e:
                logger.error("    -> Miner request failed: %s", e)
                # Create a failed submission
                submissions.append(MinerSubmission(
                    hotkey=f"5TestMiner{i:03d}",
                    uid=i,
                    model_code="",
                    model_diff="",
                    parent_id=None,
                    motivation=f"Failed: {e}",
                    name=f"FAILED_{i}",
                    config={},
                    metadata={"error": str(e)},
                    status=SubmissionStatus.FAILED,
                ))

    # Filter out failed submissions
    valid = [s for s in submissions if s.status == SubmissionStatus.SUCCEEDED and s.model_code]
    logger.info("Phase 1 complete: %d/%d valid submissions", len(valid), n)
    return valid


# ═══════════════════════════════════════════════════════════════════════
#  2. Phase runners (wrappers around the real validator phases)
# ═══════════════════════════════════════════════════════════════════════


async def run_phase2_filtering(
    submissions: List[MinerSubmission],
    *,
    use_local_proxy: bool = False,
) -> List[CandidateResult]:
    """Run Phase 2: zero-cost proxy evaluation + constraint checking.

    Args:
        submissions: Synthetic miner submissions.
        use_local_proxy: If True, run proxy eval on CPU instead of
            deploying a Basilica pod (faster for debugging but no GPU).
    """
    from subnet.validator.filtering import run_filtering_phase

    # Override proxy eval mode if requested
    original_local = SubnetConfig.PROXY_EVAL_LOCAL
    if use_local_proxy:
        SubnetConfig.PROXY_EVAL_LOCAL = True

    try:
        constraints = SubnetConfig.get_constraints()
        logger.info(
            "Phase 2: Filtering %d submissions (constraints=%s, local=%s)",
            len(submissions), constraints, SubnetConfig.PROXY_EVAL_LOCAL,
        )

        results = await run_filtering_phase(submissions, constraints=constraints)

        logger.info("Phase 2 complete: %d/%d passed", len(results), len(submissions))
        for r in results:
            logger.info(
                "  uid=%d (%s): score=%.4f params=%s latency=%s satisfied=%s",
                r.uid, r.name,
                r.zero_cost_score or 0,
                r.param_count, r.inference_latency_ms,
                r.constraints_satisfied,
            )
        return results
    finally:
        SubnetConfig.PROXY_EVAL_LOCAL = original_local


async def run_phase3_training(
    candidates: List[CandidateResult],
    *,
    full: bool = False,
) -> List[CandidateResult]:
    """Run Phase 3: two-stage deep training funnel.

    Args:
        candidates: Proxy-filtered candidates from Phase 2.
        full: If True, run both short AND long training.
              If False, only run short training (faster).
    """
    from subnet.validator.training import run_training_phase

    if not candidates:
        logger.warning("No candidates for Phase 3")
        return []

    if full:
        # Full two-stage funnel (short + long)
        logger.info(
            "Phase 3 (full): Running two-stage funnel on %d candidates",
            len(candidates),
        )
        finalists = await run_training_phase(candidates)
    else:
        # Quick mode: only short training (small_budget)
        logger.info(
            "Phase 3 (quick): Running short training only on %d candidates",
            len(candidates),
        )
        from subnet.validator.training import _build_training_client

        client = _build_training_client(SubnetConfig.SHORT_TRAIN_TIMEOUT_SEC)
        use_streams = os.getenv("TRAINING_USE_STREAMS", "1") != "0"

        model_codes = [c.model_code for c in candidates]
        if use_streams:
            results = await client.batch_train_streams(
                model_codes,
                budget_tier="small",
                timeout_sec=float(SubnetConfig.SHORT_TRAIN_TIMEOUT_SEC),
                metadata={"task": SubnetConfig.TASK_NAME, "eval_type": "small_budget"},
            )
        else:
            from services.eval.remote_training.remote_types import (
                TrainingJobSpec,
                TrainingJobMetadata,
                TrainingStatus,
            )
            import uuid

            specs = [
                TrainingJobSpec(
                    metadata=TrainingJobMetadata(
                        task=SubnetConfig.TASK_NAME,
                        eval_type="small_budget",
                    ),
                    dataset_spec={},
                    model_code_content=c.model_code,
                    job_id=uuid.uuid4().hex,
                    budget_tier="small",
                    timeout_sec=float(SubnetConfig.SHORT_TRAIN_TIMEOUT_SEC),
                )
                for c in candidates
            ]
            results = await client.batch_train(
                specs,
                max_concurrency=SubnetConfig.MAX_CONCURRENT_TRAINING_PODS,
            )

        # Map results back to candidates
        from services.eval.remote_training.remote_types import TrainingStatus
        finalists = []
        for i, candidate in enumerate(candidates):
            if i < len(results):
                r = results[i]
                metrics = r.metrics.copy() if r.metrics else {}
                candidate.train_metrics = metrics
                candidate.train_loss = metrics.get("train_loss")
                candidate.test_loss = metrics.get("test_loss")
                if r.status == TrainingStatus.SUCCEEDED:
                    finalists.append(candidate)
                    logger.info(
                        "  uid=%d (%s): SUCCEEDED train=%.6f test=%.6f wall=%.1fs",
                        candidate.uid, candidate.name,
                        candidate.train_loss or float("inf"),
                        candidate.test_loss or float("inf"),
                        r.wall_time_sec,
                    )
                else:
                    logger.warning(
                        "  uid=%d (%s): %s – %s",
                        candidate.uid, candidate.name,
                        r.status.value,
                        (r.stdout_tail or "")[:200],
                    )
            else:
                logger.warning(
                    "  uid=%d (%s): no result returned",
                    candidate.uid, candidate.name,
                )

    logger.info("Phase 3 complete: %d finalists", len(finalists))
    for f in finalists:
        logger.info(
            "  uid=%d (%s): train=%.6f test=%.6f",
            f.uid, f.name,
            f.train_loss if f.train_loss is not None else float("inf"),
            f.test_loss if f.test_loss is not None else float("inf"),
        )
    return finalists


def run_phase4_scoring(finalists: List[CandidateResult]) -> Dict[int, float]:
    """Run Phase 4: EMA scoring + weight computation.

    Skips chain submission and DB persistence (no bittensor SDK needed).
    """
    if not finalists:
        logger.warning("No finalists for Phase 4")
        return {}

    ema_scores: Dict[int, float] = {}
    weights = compute_weights(results=finalists, ema_scores=ema_scores)

    logger.info("Phase 4 complete: weights for %d UIDs", len(weights))
    for uid, w in sorted(weights.items(), key=lambda x: -x[1]):
        # Find the candidate
        name = next((f.name for f in finalists if f.uid == uid), f"uid_{uid}")
        loss = next((f.test_loss for f in finalists if f.uid == uid), None)
        logger.info(
            "  uid=%d (%s): weight=%.6f test_loss=%s ema=%.6f",
            uid, name, w,
            f"{loss:.6f}" if loss is not None else "N/A",
            ema_scores.get(uid, 0),
        )

    return weights


# ═══════════════════════════════════════════════════════════════════════
#  3. Optional: persist results to MongoDB (best-effort)
# ═══════════════════════════════════════════════════════════════════════


async def try_persist_to_db(
    finalists: List[CandidateResult],
    weights: Dict[int, float],
) -> None:
    """Attempt to write results to the MongoDB REST API.

    Fails silently if the DB is not running.
    """
    import aiohttp
    from datetime import datetime

    db_url = SubnetConfig.DATABASE_URL.rstrip("/")

    try:
        async with aiohttp.ClientSession() as session:
            # Quick health check
            async with session.get(
                f"{db_url}/health",
                timeout=aiohttp.ClientTimeout(total=5),
            ) as resp:
                if resp.status != 200:
                    logger.info("MongoDB not reachable (%d) – skipping persistence", resp.status)
                    return
    except Exception:
        logger.info("MongoDB not reachable – skipping persistence")
        return

    logger.info("Persisting %d finalists to MongoDB at %s", len(finalists), db_url)
    try:
        async with aiohttp.ClientSession() as session:
            for f in finalists:
                # Schema must match DataElementRequest in database/mongodb_api.py
                element = {
                    "time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                    "name": f"[TEST] {f.name}",
                    "result": {
                        "train": f"train_loss={f.train_loss}",
                        "test": f"test_loss={f.test_loss}",
                        "train_metrics": f.train_metrics,
                    },
                    "program": f.model_code,
                    "motivation": f.motivation,
                    "analysis": json.dumps(f.analysis) if f.analysis else "",
                    "cognition": "",
                    "log": json.dumps(f.train_metrics),
                    "task": SubnetConfig.TASK_NAME,
                    "parent": f.parent_id,
                    "architecture_keywords": [],
                    "summary": f.motivation[:200] if f.motivation else "",
                }
                async with session.post(
                    f"{db_url}/elements",
                    json=element,
                    timeout=aiohttp.ClientTimeout(total=15),
                ) as resp:
                    if resp.status == 200:
                        logger.info("  Persisted uid=%d (%s)", f.uid, f.name)
                    else:
                        body = await resp.text()
                        logger.warning(
                            "  DB write failed for uid=%d: %d %s",
                            f.uid, resp.status, body[:200],
                        )
    except Exception:
        logger.exception("Failed to persist results to DB")


# ═══════════════════════════════════════════════════════════════════════
#  4. Main orchestrator
# ═══════════════════════════════════════════════════════════════════════


async def run_test_flow(args: argparse.Namespace) -> None:
    """Execute the full test flow: submissions → filtering → training → scoring."""

    start_time = time.time()
    miner_proc = None  # Track local miner server process for cleanup
    miner_env = None   # Track affinetes miner pod for cleanup

    # ── Environment validation ────────────────────────────────────────
    docker_image = args.image or os.getenv("DEEP_TRAIN_IMAGE") or os.getenv("BASILICA_DOCKER_IMAGE")
    if not docker_image:
        # Phase 3 training always needs a Docker image for Basilica pods,
        # even when proxy eval is skipped or run locally.
        logger.error(
            "No Docker image configured. Set DEEP_TRAIN_IMAGE or "
            "BASILICA_DOCKER_IMAGE, or pass --image."
        )
        sys.exit(1)

    # Make sure SubnetConfig sees the image
    SubnetConfig.DEEP_TRAIN_IMAGE = docker_image
    SubnetConfig.PROXY_EVAL_IMAGE = docker_image
    os.environ["DEEP_TRAIN_IMAGE"] = docker_image
    os.environ["BASILICA_DOCKER_IMAGE"] = docker_image

    api_token = os.getenv("BASILICA_API_TOKEN")
    if not api_token:
        # Phase 3 training always deploys on Basilica, so a token is required
        # regardless of proxy eval mode.
        logger.error(
            "BASILICA_API_TOKEN is required for Basilica training pods. "
            "Set it in your environment or .env file."
        )
        sys.exit(1)

    use_miner = getattr(args, "use_miner", False)
    miner_url = getattr(args, "miner_url", "")
    miner_image = getattr(args, "miner_image", "")

    logger.info("=" * 70)
    logger.info("SUBNET TRAINING FLOW TEST")
    logger.info("=" * 70)
    logger.info("  Docker image:     %s", docker_image or "(local CPU only)")
    logger.info("  Basilica token:   %s", "***" + api_token[-4:] if api_token else "(none)")
    logger.info("  Num submissions:  %d", args.num_submissions)
    logger.info("  Use miner:        %s", use_miner)
    logger.info("  Miner image:      %s", miner_image or "(none)")
    logger.info("  Miner URL:        %s", miner_url or "(auto)")
    logger.info("  Full training:    %s", args.full)
    logger.info("  Skip proxy:       %s", args.skip_proxy)
    logger.info("  Local proxy:      %s", args.local_proxy)
    logger.info("  Task:             %s", SubnetConfig.TASK_NAME)
    logger.info("  Max params:       %s", SubnetConfig.MAX_PARAMS)
    logger.info("  Max latency:      %sms", SubnetConfig.MAX_INFERENCE_LATENCY_MS)
    logger.info("=" * 70)

    scaffold_code = _load_scaffold_code()

    try:
        # ── Phase 1: Get submissions ──────────────────────────────────
        if use_miner:
            logger.info("\n[Phase 1] Getting LLM-evolved submissions from miner...")

            if miner_image and not miner_url:
                # Deploy miner on Basilica via affinetes (production-like)
                logger.info("  Deploying miner image on Basilica: %s", miner_image)
                miner_env, miner_url = await _deploy_miner_on_basilica(miner_image)
            elif not miner_url:
                # Auto-start local miner server (convenience for dev)
                logger.info("  Starting local miner server...")
                miner_proc, miner_url = await _start_local_miner_server()

            phase1_start = time.time()
            submissions = await run_phase1_miner_submissions(
                n=args.num_submissions,
                miner_url=miner_url,
                scaffold_code=scaffold_code,
                challenge_type=getattr(args, "challenge_type", ""),
            )
            logger.info("Phase 1 duration: %.1fs", time.time() - phase1_start)

            if not submissions:
                logger.error("No valid submissions from miner – aborting")
                sys.exit(1)
        else:
            # ── Phase 0: Build synthetic submissions ──────────────────
            logger.info("\n[Phase 0] Building %d synthetic submissions...", args.num_submissions)
            submissions = make_synthetic_submissions(args.num_submissions, scaffold_code)
            logger.info("Built %d submissions using scaffold model", len(submissions))

        # ── Phase 2: Filtering (proxy eval) ───────────────────────────
        if args.skip_proxy:
            logger.info("\n[Phase 2] SKIPPED (--skip-proxy)")
            # Convert submissions directly to CandidateResult
            candidates = [
                CandidateResult(
                    hotkey=s.hotkey,
                    uid=s.uid,
                    name=s.name,
                    motivation=s.motivation,
                    model_code=s.model_code,
                    parent_id=s.parent_id,
                    config=s.config,
                    constraints_satisfied=True,
                    zero_cost_score=1.0,
                )
                for s in submissions
            ]
        else:
            logger.info("\n[Phase 2] Running zero-cost proxy filtering...")
            phase2_start = time.time()
            candidates = await run_phase2_filtering(
                submissions,
                use_local_proxy=args.local_proxy,
            )
            logger.info("Phase 2 duration: %.1fs", time.time() - phase2_start)

        if not candidates:
            logger.error("No candidates passed Phase 2 filtering – aborting")
            sys.exit(1)

        # ── Phase 3: Training ─────────────────────────────────────────
        logger.info("\n[Phase 3] Running deep training...")
        phase3_start = time.time()
        finalists = await run_phase3_training(candidates, full=args.full)
        logger.info("Phase 3 duration: %.1fs", time.time() - phase3_start)

        if not finalists:
            logger.error("No finalists survived training – check logs above")
            sys.exit(1)

        # ── Phase 4: Scoring ──────────────────────────────────────────
        logger.info("\n[Phase 4] Computing weights...")
        weights = run_phase4_scoring(finalists)

        # ── Optional: DB persistence ──────────────────────────────────
        if not args.skip_db:
            logger.info("\n[Phase 4b] Persisting results to MongoDB (best-effort)...")
            await try_persist_to_db(finalists, weights)

        # ── Summary ───────────────────────────────────────────────────
        total_time = time.time() - start_time
        logger.info("\n" + "=" * 70)
        logger.info("TEST COMPLETE")
        logger.info("=" * 70)
        logger.info("  Total duration:    %.1fs", total_time)
        logger.info("  Submissions:       %d", len(submissions))
        logger.info("  Passed proxy:      %d", len(candidates))
        logger.info("  Finalists:         %d", len(finalists))
        logger.info("  Weights set:       %d UIDs", len(weights))
        if finalists:
            best = min(finalists, key=lambda f: f.test_loss if f.test_loss is not None else float("inf"))
            logger.info(
                "  Best model:        uid=%d (%s) test_loss=%.6f",
                best.uid, best.name,
                best.test_loss if best.test_loss is not None else float("inf"),
            )
        logger.info("=" * 70)

    finally:
        # Clean up local miner server if we started one
        if miner_proc is not None:
            logger.info("Shutting down local miner server (pid=%d)...", miner_proc.pid)
            miner_proc.terminate()
            try:
                miner_proc.wait(timeout=5)
            except Exception:
                miner_proc.kill()

        # Clean up Basilica miner pod if we deployed one
        if miner_env is not None:
            logger.info("Cleaning up Basilica miner pod...")
            try:
                if asyncio.iscoroutinefunction(miner_env.cleanup):
                    await miner_env.cleanup()
                else:
                    await asyncio.to_thread(miner_env.cleanup)
                logger.info("Miner pod cleaned up")
            except Exception:
                logger.warning("Failed to clean up miner pod (will expire via TTL)")


# ═══════════════════════════════════════════════════════════════════════
#  CLI
# ═══════════════════════════════════════════════════════════════════════


def main():
    parser = argparse.ArgumentParser(
        description="End-to-end test for subnet training flow with live Basilica training",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Synthetic submissions, skip proxy, short train (fastest)
  python tests/test_subnet_training_flow.py --skip-proxy --num-submissions 2

  # LLM-evolved miner submissions + full pipeline
  python tests/test_subnet_training_flow.py --use-miner --num-submissions 3

  # Miner + full two-stage funnel (short + long training)
  python tests/test_subnet_training_flow.py --use-miner --full

  # Point at a running miner server (local Docker or remote)
  python tests/test_subnet_training_flow.py --use-miner --miner-url http://localhost:9000

  # Local CPU proxy eval + short training
  python tests/test_subnet_training_flow.py --local-proxy

  # Full pipeline: proxy eval + short + long training
  python tests/test_subnet_training_flow.py --full --num-submissions 5

Miner Docker image:
  docker build -f tests/test_subnet/Dockerfile.miner -t test-miner .
  docker run -p 9000:8000 -e CHUTES_API_KEY=... -e MODEL_NAME=... test-miner

Required environment variables:
  BASILICA_API_TOKEN       API token for Basilica GPU cluster
  DEEP_TRAIN_IMAGE         Docker image for training containers (or BASILICA_DOCKER_IMAGE)

For --use-miner mode (additional):
  CHUTES_API_KEY           API key for the Chutes LLM provider
  MODEL_NAME               LLM model name (e.g. meta-llama/Llama-4-Scout-17B-16E-Instruct)
        """,
    )

    # Phase 1: Miner mode
    miner_group = parser.add_argument_group("Phase 1: Miner submissions")
    miner_group.add_argument(
        "--use-miner", action="store_true",
        help="Use mock miner server for Phase 1 (LLM-evolved submissions). "
             "Without this, uses synthetic scaffold copies.",
    )
    miner_group.add_argument(
        "--miner-url", type=str, default="",
        help="URL of a running miner server. If --use-miner is set without "
             "this or --miner-image, a local miner server is auto-started.",
    )
    miner_group.add_argument(
        "--miner-image", type=str, default="",
        help="Docker image to deploy on Basilica via affinetes (production-like). "
             "E.g. your-registry/test-miner:latest. Requires BASILICA_API_TOKEN.",
    )
    miner_group.add_argument(
        "--challenge-type", type=str, default="",
        help="Specific challenge type for all submissions (e.g. 'Long-Range Dependencies'). "
             "If not set, rotates through all categories.",
    )

    # Phase 2: Proxy filtering
    proxy_group = parser.add_argument_group("Phase 2: Proxy filtering")
    proxy_group.add_argument(
        "--skip-proxy", action="store_true",
        help="Skip Phase 2 proxy evaluation (go straight to training).",
    )
    proxy_group.add_argument(
        "--local-proxy", action="store_true",
        help="Run proxy eval locally on CPU instead of Basilica pod.",
    )

    # Phase 3: Training
    train_group = parser.add_argument_group("Phase 3: Training")
    train_group.add_argument(
        "--full", action="store_true",
        help="Run full two-stage training (short + long). Default: short only.",
    )

    # General
    parser.add_argument(
        "--skip-db", action="store_true",
        help="Skip MongoDB persistence (Phase 4b).",
    )
    parser.add_argument(
        "--num-submissions", type=int, default=3,
        help="Number of submissions to generate (default: 3).",
    )
    parser.add_argument(
        "--image", type=str, default="",
        help="Override Docker image for training containers.",
    )

    args = parser.parse_args()
    asyncio.run(run_test_flow(args))


if __name__ == "__main__":
    main()
