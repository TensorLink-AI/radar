import sys
from pathlib import Path

import pytest
import torch
import torch.fx as fx

sys.path.append(str(Path(__file__).resolve().parents[1]))

from tasks.ts_foundation.model_base import (
    TimeSeriesFoundationModel,
    validate_time_series_model,
)


class _BaseDummyModel(TimeSeriesFoundationModel):
    def __init__(self) -> None:
        super().__init__()
        self.cfg = {
            "constraints": {
                "input_length": 2,
                "forecast_length": 3,
                "target_dim": 1,
                "past_cov_dim": 0,
                "future_cov_dim": 0,
                "static_dim": 0,
            },
            "horizon": 3,
            "target_dim": 1,
            "past_cov_dim": 0,
            "future_cov_dim": 0,
            "static_dim": 0,
            "quantile_levels": (0.5,),
        }

    def _make_outputs(self, quantiles: torch.Tensor) -> dict:
        return {
            "quantiles": quantiles,
            "quantile_levels": torch.tensor(
                [0.5], device=quantiles.device, dtype=quantiles.dtype
            ),
        }

    @classmethod
    def from_config(cls, cfg: dict) -> "_BaseDummyModel":
        return cls()

    def to_config(self) -> dict:
        return dict(self.cfg)


class ModuleMismatchModel(_BaseDummyModel):
    def __init__(self) -> None:
        super().__init__()
        self.linear = torch.nn.Linear(4, 2)

    def forward(
        self,
        past_y: torch.Tensor,
        past_cov: torch.Tensor | None = None,
        future_cov: torch.Tensor | None = None,
        static: torch.Tensor | None = None,
        y_future_tf: torch.Tensor | None = None,
        *,
        forecast_length: int | None = None,
        input_length: int | None = None,
    ) -> dict:
        out = self.linear(past_y)
        return self._make_outputs(out)

    @torch.no_grad()
    def generate(
        self,
        past_y: torch.Tensor,
        past_cov: torch.Tensor | None = None,
        future_cov: torch.Tensor | None = None,
        static: torch.Tensor | None = None,
        *,
        forecast_length: int | None = None,
        input_length: int | None = None,
    ) -> dict:
        return self.forward(
            past_y,
            past_cov=past_cov,
            future_cov=future_cov,
            static=static,
            y_future_tf=None,
            forecast_length=forecast_length,
            input_length=input_length,
        )


class MethodMismatchModel(_BaseDummyModel):
    def forward(
        self,
        past_y: torch.Tensor,
        past_cov: torch.Tensor | None = None,
        future_cov: torch.Tensor | None = None,
        static: torch.Tensor | None = None,
        y_future_tf: torch.Tensor | None = None,
        *,
        forecast_length: int | None = None,
        input_length: int | None = None,
    ) -> dict:
        reshaped = past_y.view(past_y.shape[0], past_y.shape[1], 5)
        return self._make_outputs(reshaped)

    @torch.no_grad()
    def generate(
        self,
        past_y: torch.Tensor,
        past_cov: torch.Tensor | None = None,
        future_cov: torch.Tensor | None = None,
        static: torch.Tensor | None = None,
        *,
        forecast_length: int | None = None,
        input_length: int | None = None,
    ) -> dict:
        return self.forward(
            past_y,
            past_cov=past_cov,
            future_cov=future_cov,
            static=static,
            y_future_tf=None,
            forecast_length=forecast_length,
            input_length=input_length,
        )


def test_shape_prop_module_error_contains_context():
    model = ModuleMismatchModel()

    linear_graph = fx.Graph()
    past_y = linear_graph.placeholder("past_y")
    linear_graph.placeholder("past_cov")
    linear_graph.placeholder("future_cov")
    linear_graph.placeholder("static")
    linear_graph.placeholder("y_future_tf")
    linear_graph.placeholder("current_forecast_length")
    linear_graph.placeholder("current_input_length")
    linear_call = linear_graph.call_module("linear", (past_y,), {})
    linear_graph.output(linear_call)

    class LinearWrapper(torch.nn.Module):
        def __init__(self) -> None:
            super().__init__()
            self.linear = torch.nn.Linear(4, 2)

    linear_module = fx.GraphModule(LinearWrapper(), linear_graph)

    def _fake_make_fx(*args, **kwargs):
        return lambda *a, **k: linear_module

    with pytest.raises(RuntimeError) as excinfo:
        with pytest.MonkeyPatch().context() as mp:
            mp.setattr("tasks.ts_foundation.model_base.make_fx", _fake_make_fx)
            validate_time_series_model(model)

    chain = []
    err = excinfo.value
    while err is not None:
        chain.append(str(err))
        err = err.__cause__ or err.__context__

    assert any("call_module target=linear" in msg for msg in chain)
    assert any("operand shapes [arg0=" in msg for msg in chain)


def test_shape_prop_method_error_contains_context():
    model = MethodMismatchModel()

    method_graph = fx.Graph()
    past_y = method_graph.placeholder("past_y")
    method_graph.placeholder("past_cov")
    method_graph.placeholder("future_cov")
    method_graph.placeholder("static")
    method_graph.placeholder("y_future_tf")
    method_graph.placeholder("current_forecast_length")
    method_graph.placeholder("current_input_length")
    view_call = method_graph.call_method("view", (past_y, 2, 2, 5), {})
    method_graph.output(view_call)

    class ViewWrapper(torch.nn.Module):
        def forward(self, x):  # pragma: no cover - fx GraphModule requires forward
            return x

    view_module = fx.GraphModule(ViewWrapper(), method_graph)

    def _fake_make_fx(*args, **kwargs):
        return lambda *a, **k: view_module

    with pytest.raises(RuntimeError) as excinfo:
        with pytest.MonkeyPatch().context() as mp:
            mp.setattr("tasks.ts_foundation.model_base.make_fx", _fake_make_fx)
            validate_time_series_model(model)

    chain = []
    err = excinfo.value
    while err is not None:
        chain.append(str(err))
        err = err.__cause__ or err.__context__

    assert any("call_method target=view" in msg for msg in chain)
    assert any("operand shapes [arg0=" in msg for msg in chain)
