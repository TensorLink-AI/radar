"""Tests for deterministic lineage validation (subnet.validator.lineage)
and its integration into the filtering phase."""

from __future__ import annotations

import asyncio
import sys
import types
import unittest
from unittest.mock import patch

# ── Stub heavy modules so tests run without torch / aiohttp ──────────
_MOCK_MODULES = [
    "torch", "torch.nn", "torch.nn.functional", "torch.utils",
    "torch.utils.data", "torch.cuda", "torch.fx",
    "torch.fx.experimental", "torch.fx.experimental.proxy_tensor",
    "torch.amp", "torch.cuda.amp",
    "aiohttp",
    "affinetes",
]
for _mod_name in _MOCK_MODULES:
    if _mod_name not in sys.modules:
        _mock = types.ModuleType(_mod_name)
        sys.modules[_mod_name] = _mock


from subnet.validator.lineage import (
    LineageCheckResult,
    check_lineage,
    _text_similarity,
    _compute_line_stats,
    _extract_top_level_symbols,
    _compute_ast_similarity,
)
from subnet.config import SubnetConfig


# ── Sample code fixtures ──────────────────────────────────────────────

PARENT_CODE = '''\
import torch
import torch.nn as nn

class TimeSeriesFoundationModel(nn.Module):
    def __init__(self, d_model=256, n_layers=4):
        super().__init__()
        self.d_model = d_model
        self.n_layers = n_layers
        self.encoder = nn.Linear(1, d_model)
        self.layers = nn.ModuleList([
            nn.TransformerEncoderLayer(d_model, nhead=4)
            for _ in range(n_layers)
        ])
        self.decoder = nn.Linear(d_model, 9)

    def forward(self, past_y, **kwargs):
        x = self.encoder(past_y)
        for layer in self.layers:
            x = layer(x)
        return {"quantiles": self.decoder(x)}

def instantiate_model():
    return TimeSeriesFoundationModel()
'''

# Small incremental change: adds dropout
CHILD_INCREMENTAL = '''\
import torch
import torch.nn as nn

class TimeSeriesFoundationModel(nn.Module):
    def __init__(self, d_model=256, n_layers=4, dropout=0.1):
        super().__init__()
        self.d_model = d_model
        self.n_layers = n_layers
        self.dropout = nn.Dropout(dropout)
        self.encoder = nn.Linear(1, d_model)
        self.layers = nn.ModuleList([
            nn.TransformerEncoderLayer(d_model, nhead=4, dropout=dropout)
            for _ in range(n_layers)
        ])
        self.decoder = nn.Linear(d_model, 9)

    def forward(self, past_y, **kwargs):
        x = self.encoder(past_y)
        x = self.dropout(x)
        for layer in self.layers:
            x = layer(x)
        return {"quantiles": self.decoder(x)}

def instantiate_model():
    return TimeSeriesFoundationModel()
'''

# Total rewrite: completely different architecture, no shared code
CHILD_TOTAL_REWRITE = '''\
import numpy as np
from sklearn.linear_model import Ridge

class RidgeForecaster:
    def __init__(self, alpha=1.0):
        self.model = Ridge(alpha=alpha)

    def fit(self, X, y):
        self.model.fit(X, y)

    def predict(self, X):
        return self.model.predict(X)

def instantiate_model():
    return RidgeForecaster()
'''

# Identical copy
CHILD_IDENTICAL = PARENT_CODE


class TestTextSimilarity(unittest.TestCase):
    """Tests for difflib.SequenceMatcher similarity ratio."""

    def test_identical(self):
        ratio = _text_similarity(PARENT_CODE, CHILD_IDENTICAL)
        self.assertAlmostEqual(ratio, 1.0)

    def test_incremental_high_similarity(self):
        ratio = _text_similarity(PARENT_CODE, CHILD_INCREMENTAL)
        self.assertGreater(ratio, 0.6)

    def test_total_rewrite_low_similarity(self):
        ratio = _text_similarity(PARENT_CODE, CHILD_TOTAL_REWRITE)
        self.assertLess(ratio, 0.3)

    def test_empty_strings(self):
        ratio = _text_similarity("", "")
        self.assertAlmostEqual(ratio, 1.0)

    def test_one_empty(self):
        ratio = _text_similarity(PARENT_CODE, "")
        self.assertAlmostEqual(ratio, 0.0)


class TestLineStats(unittest.TestCase):
    """Tests for line-level diff statistics."""

    def test_identical_no_changes(self):
        result = LineageCheckResult()
        _compute_line_stats(PARENT_CODE, CHILD_IDENTICAL, result)
        self.assertEqual(result.lines_added, 0)
        self.assertEqual(result.lines_removed, 0)
        self.assertEqual(result.lines_unchanged, result.total_parent_lines)
        self.assertAlmostEqual(result.replacement_ratio, 0.0)

    def test_incremental_some_changes(self):
        result = LineageCheckResult()
        _compute_line_stats(PARENT_CODE, CHILD_INCREMENTAL, result)
        self.assertGreater(result.lines_unchanged, 0)
        self.assertGreater(result.lines_added, 0)
        self.assertLess(result.replacement_ratio, 0.5)

    def test_total_rewrite_high_replacement(self):
        result = LineageCheckResult()
        _compute_line_stats(PARENT_CODE, CHILD_TOTAL_REWRITE, result)
        self.assertGreater(result.replacement_ratio, 0.7)

    def test_empty_parent(self):
        result = LineageCheckResult()
        _compute_line_stats("", "some code\n", result)
        self.assertEqual(result.total_parent_lines, 0)
        self.assertAlmostEqual(result.replacement_ratio, 0.0)
        self.assertEqual(result.lines_added, 1)


class TestASTSimilarity(unittest.TestCase):
    """Tests for AST structural similarity (Jaccard of top-level symbols)."""

    def test_identical_ast(self):
        syms = _extract_top_level_symbols(PARENT_CODE)
        self.assertIsNotNone(syms)
        self.assertIn("TimeSeriesFoundationModel", syms)
        self.assertIn("instantiate_model", syms)

    def test_incremental_shares_symbols(self):
        result = LineageCheckResult()
        _compute_ast_similarity(PARENT_CODE, CHILD_INCREMENTAL, result)
        self.assertIsNotNone(result.ast_similarity)
        self.assertAlmostEqual(result.ast_similarity, 1.0)

    def test_total_rewrite_different_symbols(self):
        result = LineageCheckResult()
        _compute_ast_similarity(PARENT_CODE, CHILD_TOTAL_REWRITE, result)
        self.assertIsNotNone(result.ast_similarity)
        # Only instantiate_model is shared
        self.assertLess(result.ast_similarity, 0.5)

    def test_unparseable_code(self):
        bad_code = "def foo(\n  this is not valid python"
        syms = _extract_top_level_symbols(bad_code)
        self.assertIsNone(syms)

    def test_unparseable_falls_back(self):
        result = LineageCheckResult()
        _compute_ast_similarity("def foo(:", PARENT_CODE, result)
        self.assertIsNone(result.ast_similarity)


class TestCheckLineage(unittest.TestCase):
    """End-to-end tests for check_lineage()."""

    def test_incremental_passes(self):
        result = check_lineage(
            PARENT_CODE, CHILD_INCREMENTAL,
            min_similarity=0.10,
            max_replacement_ratio=0.95,
        )
        self.assertTrue(result.passed)
        self.assertEqual(len(result.rejection_reasons), 0)
        self.assertGreater(result.similarity_ratio, 0.5)

    def test_total_rewrite_fails_similarity(self):
        result = check_lineage(
            PARENT_CODE, CHILD_TOTAL_REWRITE,
            min_similarity=0.10,
            max_replacement_ratio=0.95,
        )
        self.assertFalse(result.passed)
        self.assertTrue(any("similarity_ratio" in r for r in result.rejection_reasons))

    def test_total_rewrite_fails_replacement(self):
        result = check_lineage(
            PARENT_CODE, CHILD_TOTAL_REWRITE,
            min_similarity=0.01,  # very lenient
            max_replacement_ratio=0.50,
        )
        self.assertFalse(result.passed)
        self.assertTrue(any("replacement_ratio" in r for r in result.rejection_reasons))

    def test_identical_passes(self):
        result = check_lineage(
            PARENT_CODE, CHILD_IDENTICAL,
            min_similarity=0.10,
            max_replacement_ratio=0.95,
        )
        self.assertTrue(result.passed)

    def test_strict_thresholds_reject_moderate_changes(self):
        result = check_lineage(
            PARENT_CODE, CHILD_INCREMENTAL,
            min_similarity=0.99,  # very strict
            max_replacement_ratio=0.01,  # very strict
        )
        self.assertFalse(result.passed)

    def test_uses_config_defaults(self):
        """check_lineage without explicit thresholds uses SubnetConfig."""
        with patch.object(SubnetConfig, "LINEAGE_MIN_SIMILARITY", 0.10), \
             patch.object(SubnetConfig, "LINEAGE_MAX_REPLACEMENT_RATIO", 0.95):
            result = check_lineage(PARENT_CODE, CHILD_INCREMENTAL)
            self.assertTrue(result.passed)

    def test_to_dict_serialisable(self):
        """LineageCheckResult.to_dict() returns JSON-safe types."""
        import json
        result = check_lineage(PARENT_CODE, CHILD_INCREMENTAL, min_similarity=0.1, max_replacement_ratio=0.95)
        d = result.to_dict()
        # Should not raise
        serialised = json.dumps(d)
        self.assertIn("similarity_ratio", serialised)
        self.assertIn("passed", serialised)


class TestFilteringIntegration(unittest.TestCase):
    """Test that lineage validation is wired into the filtering phase.

    Since run_filtering_phase now fetches parent codes from the DB
    via _fetch_parent_codes, and runs proxy eval via _batch_proxy_eval_local
    (when PROXY_EVAL_LOCAL=1), we mock both of those to isolate the
    lineage validation logic.
    """

    def _run(self, coro):
        """Helper to run an async coroutine."""
        loop = asyncio.new_event_loop()
        try:
            return loop.run_until_complete(coro)
        finally:
            loop.close()

    def _make_fake_proxy_eval(self, score=0.5, param_count=500, latency=2.0):
        """Create a mock _batch_proxy_eval_local that marks candidates as passing."""
        async def fake_batch_eval(submissions, constraints):
            for sub, result in submissions:
                result.zero_cost_score = 1.0
                result.param_count = param_count
                result.inference_latency_ms = latency
                result.zero_cost_details = {"status": "ok", "mock": True}
                result.constraints_satisfied = True
        return fake_batch_eval

    def test_filtering_rejects_rewrite_with_parent_id(self):
        """A submission claiming parent_id with a total rewrite should be rejected."""
        from subnet.protocol.types import MinerSubmission, SubmissionStatus

        sub = MinerSubmission(
            hotkey="hk_rewrite",
            uid=1,
            model_code=CHILD_TOTAL_REWRITE,
            parent_id=42,
            status=SubmissionStatus.SUCCEEDED,
        )

        async def fake_fetch_parents(parent_ids):
            return {pid: PARENT_CODE for pid in parent_ids}

        with patch.object(SubnetConfig, "LINEAGE_CHECK_ENABLED", True), \
             patch.object(SubnetConfig, "LINEAGE_MIN_SIMILARITY", 0.10), \
             patch.object(SubnetConfig, "LINEAGE_MAX_REPLACEMENT_RATIO", 0.95), \
             patch.object(SubnetConfig, "ZERO_COST_TOP_K", 10), \
             patch.object(SubnetConfig, "PROXY_EVAL_LOCAL", True), \
             patch("subnet.validator.filtering._fetch_parent_codes", side_effect=fake_fetch_parents), \
             patch("subnet.validator.filtering._batch_proxy_eval_local", side_effect=self._make_fake_proxy_eval()):
            from subnet.validator.filtering import run_filtering_phase

            results = self._run(
                run_filtering_phase(
                    [sub],
                    constraints={"max_params": 10_000_000},
                )
            )
            # Should be zero because the only submission failed lineage
            self.assertEqual(len(results), 0)

    def test_filtering_passes_incremental_with_parent_id(self):
        """A submission with incremental changes and parent_id should pass lineage."""
        from subnet.protocol.types import MinerSubmission, SubmissionStatus

        sub = MinerSubmission(
            hotkey="hk_good",
            uid=2,
            model_code=CHILD_INCREMENTAL,
            parent_id=42,
            status=SubmissionStatus.SUCCEEDED,
        )

        async def fake_fetch_parents(parent_ids):
            return {pid: PARENT_CODE for pid in parent_ids}

        with patch.object(SubnetConfig, "LINEAGE_CHECK_ENABLED", True), \
             patch.object(SubnetConfig, "LINEAGE_MIN_SIMILARITY", 0.10), \
             patch.object(SubnetConfig, "LINEAGE_MAX_REPLACEMENT_RATIO", 0.95), \
             patch.object(SubnetConfig, "ZERO_COST_TOP_K", 10), \
             patch.object(SubnetConfig, "PROXY_EVAL_LOCAL", True), \
             patch("subnet.validator.filtering._fetch_parent_codes", side_effect=fake_fetch_parents), \
             patch("subnet.validator.filtering._batch_proxy_eval_local", side_effect=self._make_fake_proxy_eval()):
            from subnet.validator.filtering import run_filtering_phase

            results = self._run(
                run_filtering_phase(
                    [sub],
                    constraints={"max_params": 10_000_000},
                )
            )
            self.assertEqual(len(results), 1)
            self.assertTrue(results[0].constraints_satisfied)
            self.assertIn("similarity_ratio", results[0].lineage_check)

    def test_filtering_skips_lineage_when_no_parent_id(self):
        """A submission with parent_id=None should skip lineage check entirely."""
        from subnet.protocol.types import MinerSubmission, SubmissionStatus

        sub = MinerSubmission(
            hotkey="hk_nop",
            uid=3,
            model_code=CHILD_TOTAL_REWRITE,
            parent_id=None,
            status=SubmissionStatus.SUCCEEDED,
        )

        async def fake_fetch_parents(parent_ids):
            return {}

        with patch.object(SubnetConfig, "LINEAGE_CHECK_ENABLED", True), \
             patch.object(SubnetConfig, "ZERO_COST_TOP_K", 10), \
             patch.object(SubnetConfig, "PROXY_EVAL_LOCAL", True), \
             patch("subnet.validator.filtering._fetch_parent_codes", side_effect=fake_fetch_parents), \
             patch("subnet.validator.filtering._batch_proxy_eval_local", side_effect=self._make_fake_proxy_eval()):
            from subnet.validator.filtering import run_filtering_phase

            results = self._run(
                run_filtering_phase(
                    [sub],
                    constraints={"max_params": 10_000_000},
                )
            )
            # Should pass: no parent_id claimed, so no lineage check
            self.assertEqual(len(results), 1)
            self.assertTrue(results[0].constraints_satisfied)
            self.assertEqual(results[0].lineage_check, {})

    def test_filtering_skips_lineage_when_disabled(self):
        """Lineage check disabled via config should pass everything."""
        from subnet.protocol.types import MinerSubmission, SubmissionStatus

        sub = MinerSubmission(
            hotkey="hk_disabled",
            uid=4,
            model_code=CHILD_TOTAL_REWRITE,
            parent_id=42,
            status=SubmissionStatus.SUCCEEDED,
        )

        async def fake_fetch_parents(parent_ids):
            return {pid: PARENT_CODE for pid in parent_ids}

        with patch.object(SubnetConfig, "LINEAGE_CHECK_ENABLED", False), \
             patch.object(SubnetConfig, "ZERO_COST_TOP_K", 10), \
             patch.object(SubnetConfig, "PROXY_EVAL_LOCAL", True), \
             patch("subnet.validator.filtering._fetch_parent_codes", side_effect=fake_fetch_parents), \
             patch("subnet.validator.filtering._batch_proxy_eval_local", side_effect=self._make_fake_proxy_eval()):
            from subnet.validator.filtering import run_filtering_phase

            results = self._run(
                run_filtering_phase(
                    [sub],
                    constraints={"max_params": 10_000_000},
                )
            )
            # Should pass: lineage check is disabled
            self.assertEqual(len(results), 1)
            self.assertTrue(results[0].constraints_satisfied)

    def test_filtering_skips_lineage_when_no_parent_code(self):
        """If parent_code is None in DB, lineage check should be skipped even with parent_id."""
        from subnet.protocol.types import MinerSubmission, SubmissionStatus

        sub = MinerSubmission(
            hotkey="hk_nocode",
            uid=5,
            model_code=CHILD_TOTAL_REWRITE,
            parent_id=42,
            status=SubmissionStatus.SUCCEEDED,
        )

        async def fake_fetch_parents(parent_ids):
            # Simulate parent not found in DB
            return {pid: None for pid in parent_ids}

        with patch.object(SubnetConfig, "LINEAGE_CHECK_ENABLED", True), \
             patch.object(SubnetConfig, "ZERO_COST_TOP_K", 10), \
             patch.object(SubnetConfig, "PROXY_EVAL_LOCAL", True), \
             patch("subnet.validator.filtering._fetch_parent_codes", side_effect=fake_fetch_parents), \
             patch("subnet.validator.filtering._batch_proxy_eval_local", side_effect=self._make_fake_proxy_eval()):
            from subnet.validator.filtering import run_filtering_phase

            results = self._run(
                run_filtering_phase(
                    [sub],
                    constraints={"max_params": 10_000_000},
                )
            )
            # Should pass: can't validate without parent_code
            self.assertEqual(len(results), 1)
            self.assertTrue(results[0].constraints_satisfied)


if __name__ == "__main__":
    unittest.main()
