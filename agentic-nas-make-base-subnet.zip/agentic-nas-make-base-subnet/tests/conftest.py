"""Test helpers and dependency stubs for offline environments."""
import sys
import types


def _install_httpx_stub() -> None:
    if "httpx" in sys.modules:
        return

    class _DummyResponse:
        def __init__(self, json_data=None, text: str = "") -> None:
            self._json = json_data
            self.text = text

        def json(self):
            return self._json

        def raise_for_status(self):  # pragma: no cover - stub only
            return None

    class _DummyAsyncClient:
        def __init__(self, *_, **__):
            pass

        async def post(self, *_, **__):  # pragma: no cover - stub only
            return _DummyResponse()

        async def get(self, *_, **__):  # pragma: no cover - stub only
            return _DummyResponse()

        async def aclose(self):  # pragma: no cover - stub only
            return None

    class _DummyHTTPStatusError(Exception):
        def __init__(self, response=None):
            super().__init__("httpx stub error")
            self.response = response or _DummyResponse()

    httpx_stub = types.SimpleNamespace(
        AsyncClient=_DummyAsyncClient,
        Timeout=lambda *_, **__: None,
        HTTPStatusError=_DummyHTTPStatusError,
    )
    sys.modules["httpx"] = httpx_stub


_install_httpx_stub()
