"""Tests for subnet.validator.miner_runner – challenge type selection and response parsing."""

from __future__ import annotations

import sys
import types
import unittest
from unittest.mock import patch

# Stub heavy modules so we can import miner_runner helpers without aiohttp
_MOCK_MODULES = ["aiohttp"]
for _mod in _MOCK_MODULES:
    if _mod not in sys.modules:
        sys.modules[_mod] = types.ModuleType(_mod)

from subnet.config import SubnetConfig
from subnet.validator.miner_runner import select_challenge_type, _parse_response
from subnet.protocol.types import Challenge, MinerCommitment, SubmissionStatus


class TestSelectChallengeType(unittest.TestCase):
    """Test challenge type selection logic."""

    def test_cycles_through_categories(self):
        """Should cycle through configured challenge categories by epoch."""
        cats = SubnetConfig.get_challenge_categories()
        if not cats:
            self.skipTest("No challenge categories configured")

        for i in range(len(cats) * 2):
            result = select_challenge_type(i)
            self.assertEqual(result, cats[i % len(cats)])

    def test_epoch_zero_returns_first_category(self):
        cats = SubnetConfig.get_challenge_categories()
        if not cats:
            self.skipTest("No challenge categories configured")
        self.assertEqual(select_challenge_type(0), cats[0])

    def test_deterministic_for_same_epoch(self):
        result1 = select_challenge_type(5)
        result2 = select_challenge_type(5)
        self.assertEqual(result1, result2)

    def test_empty_categories_returns_empty_string(self):
        with patch.object(SubnetConfig, "CHALLENGE_CATEGORIES", ""):
            result = select_challenge_type(0)
            self.assertEqual(result, "")


class TestParseResponse(unittest.TestCase):
    """Test _parse_response – miner pod JSON → MinerSubmission."""

    def _make_commitment(self, uid=1, hotkey="5Test"):
        return MinerCommitment(
            hotkey=hotkey,
            uid=uid,
            docker_image="test:latest",
        )

    def _make_challenge(self):
        return Challenge(
            task_name="time_series_foundation",
            challenge_type="long_range",
            constraints={"max_params": 1_000_000},
        )

    def test_valid_response(self):
        raw = {
            "model_code": "def instantiate_model(config=None): pass",
            "parent_id": 42,
            "motivation": "Test motivation",
            "name": "TestModel",
            "config": {"d_model": 64},
            "metadata": {"quality": 0.8},
            "model_diff": "--- old\n+++ new",
        }

        sub = _parse_response(raw, self._make_commitment(), self._make_challenge())

        self.assertEqual(sub.status, SubmissionStatus.SUCCEEDED)
        self.assertIn("instantiate_model", sub.model_code)
        self.assertEqual(sub.parent_id, 42)
        self.assertEqual(sub.name, "TestModel")
        self.assertEqual(sub.motivation, "Test motivation")
        self.assertEqual(sub.config, {"d_model": 64})

    def test_empty_model_code_raises(self):
        raw = {"model_code": ""}
        with self.assertRaises(ValueError):
            _parse_response(raw, self._make_commitment(), self._make_challenge())

    def test_missing_model_code_raises(self):
        raw = {"motivation": "no code"}
        with self.assertRaises(ValueError):
            _parse_response(raw, self._make_commitment(), self._make_challenge())

    def test_optional_fields_default(self):
        raw = {"model_code": "# some code"}
        sub = _parse_response(raw, self._make_commitment(), self._make_challenge())
        self.assertIsNone(sub.parent_id)
        self.assertEqual(sub.motivation, "")
        self.assertEqual(sub.name, "")
        self.assertEqual(sub.config, {})
        self.assertEqual(sub.model_diff, "")

    def test_preserves_commitment_uid_and_hotkey(self):
        raw = {"model_code": "# code"}
        commitment = self._make_commitment(uid=99, hotkey="5Specific")
        sub = _parse_response(raw, commitment, self._make_challenge())
        self.assertEqual(sub.uid, 99)
        self.assertEqual(sub.hotkey, "5Specific")


if __name__ == "__main__":
    unittest.main()
