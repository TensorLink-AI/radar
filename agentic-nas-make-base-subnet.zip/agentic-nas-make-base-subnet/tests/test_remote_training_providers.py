from services.eval.remote_training.remote_types import (
    Provider,
    TrainingStatus,
    build_training_job_spec,
)
from services.eval.remote_training.client import RunpodTrainingClient


def test_build_training_job_spec_defaults_provider():
    spec = build_training_job_spec({
        "metadata": {"task": "foo", "eval_type": "bar"},
        "dataset_spec": {},
        "model_code_content": "print('hi')",
    })
    assert spec.provider == Provider.TARGON


def test_build_training_job_spec_coerces_provider():
    spec = build_training_job_spec({
        "metadata": {"task": "foo", "eval_type": "bar"},
        "dataset_spec": {},
        "model_code_content": "print('hi')",
        "provider": "runpod",
    })
    assert spec.provider == Provider.RUNPOD


def test_runpod_status_mapping():
    mapper = RunpodTrainingClient.map_runpod_status

    assert mapper("IN_PROGRESS") == TrainingStatus.RUNNING
    assert mapper("running") == TrainingStatus.RUNNING
    assert mapper("COMPLETED") == TrainingStatus.SUCCEEDED
    assert mapper("FAILED") == TrainingStatus.FAILED
    assert mapper("QUEUED") == TrainingStatus.PENDING
