"""Tests for subnet.validator.validator – EMA persistence and helpers."""

from __future__ import annotations

import json
import math
import os
import sys
import tempfile
import types
import unittest
from pathlib import Path
from unittest.mock import patch

# Stub heavy modules so we can import the EMA helpers
_MOCK_MODULES = [
    "torch", "torch.nn", "torch.nn.functional",
    "torch.utils", "torch.utils.data",
    "torch.fx", "torch.fx.experimental",
    "torch.fx.experimental.proxy_tensor",
    "torch.amp", "torch.cuda.amp", "torch.cuda",
    "aiohttp",
    "affinetes",
]
for _mod in _MOCK_MODULES:
    if _mod not in sys.modules:
        sys.modules[_mod] = types.ModuleType(_mod)

from subnet.validator.validator import _load_ema_scores, _save_ema_scores


class TestEMAPersistence(unittest.TestCase):
    """Test _load_ema_scores and _save_ema_scores round-trip."""

    def setUp(self):
        self._tmpdir = tempfile.mkdtemp()

    def tearDown(self):
        import shutil
        shutil.rmtree(self._tmpdir, ignore_errors=True)

    def test_load_missing_file_returns_empty(self):
        scores = _load_ema_scores(self._tmpdir)
        self.assertEqual(scores, {})

    def test_save_and_load_roundtrip(self):
        original = {1: 0.5, 2: 0.8, 99: 0.123}
        _save_ema_scores(original, self._tmpdir)
        loaded = _load_ema_scores(self._tmpdir)
        self.assertEqual(loaded, original)

    def test_load_converts_string_keys_to_int(self):
        """JSON serialises keys as strings – ensure they're converted back."""
        path = Path(self._tmpdir) / "ema_scores.json"
        path.parent.mkdir(parents=True, exist_ok=True)
        with open(path, "w") as f:
            json.dump({"10": 0.5, "20": 0.9}, f)

        loaded = _load_ema_scores(self._tmpdir)
        self.assertIn(10, loaded)
        self.assertIn(20, loaded)
        self.assertNotIn("10", loaded)

    def test_skips_corrupt_entries(self):
        """Corrupt entries (NaN, negative, non-numeric) should be skipped."""
        path = Path(self._tmpdir) / "ema_scores.json"
        path.parent.mkdir(parents=True, exist_ok=True)
        with open(path, "w") as f:
            json.dump({
                "1": 0.5,
                "2": -0.1,    # negative
                "3": "bad",   # non-numeric
                "4": 0.8,
            }, f)

        loaded = _load_ema_scores(self._tmpdir)
        self.assertEqual(loaded, {1: 0.5, 4: 0.8})

    def test_load_corrupt_json_returns_empty(self):
        """Totally corrupt JSON should return empty dict."""
        path = Path(self._tmpdir) / "ema_scores.json"
        path.parent.mkdir(parents=True, exist_ok=True)
        with open(path, "w") as f:
            f.write("{invalid json")

        loaded = _load_ema_scores(self._tmpdir)
        self.assertEqual(loaded, {})

    def test_save_creates_directory(self):
        nested = os.path.join(self._tmpdir, "deep", "nested")
        _save_ema_scores({1: 0.5}, nested)
        loaded = _load_ema_scores(nested)
        self.assertEqual(loaded, {1: 0.5})

    def test_empty_scores_roundtrip(self):
        _save_ema_scores({}, self._tmpdir)
        loaded = _load_ema_scores(self._tmpdir)
        self.assertEqual(loaded, {})


if __name__ == "__main__":
    unittest.main()
