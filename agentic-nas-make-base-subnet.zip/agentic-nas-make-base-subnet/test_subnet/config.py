"""
Test configuration for subnet functional testing.

Provides configuration classes and preset scenarios for running
the validator pipeline in isolation.
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional


class TestScenario(str, Enum):
    """Pre-defined test scenarios."""

    # Basic scenarios
    HAPPY_PATH = "happy_path"  # All miners succeed, good quality
    SINGLE_MINER = "single_miner"  # Just one miner
    EMPTY_SUBMISSIONS = "empty_submissions"  # No successful submissions

    # Realistic scenarios
    REALISTIC = "realistic"  # Mix of success/failure, varied quality
    HIGH_VOLUME = "high_volume"  # Many miners (stress test)

    # Edge cases
    ALL_FAIL = "all_fail"  # All miners fail
    ALL_INVALID = "all_invalid"  # All submit invalid code
    CONSTRAINT_VIOLATIONS = "constraint_violations"  # Models exceed constraints

    # Adversarial scenarios
    ADVERSARIAL = "adversarial"  # Mix of adversarial behaviors

    # Live / partially-live scenarios
    LIVE_EVOLVE = "live_evolve"  # Real LLM evolution, mock training
    LIVE_FULL = "live_full"  # Real LLM evolution + local training

    # Basilica (remote GPU) scenarios
    BASILICA_PROXY = "basilica_proxy"  # Real proxy eval on Basilica, mock training
    BASILICA_FULL = "basilica_full"  # Real proxy eval + training on Basilica


@dataclass
class TestConfig:
    """Configuration for a subnet functional test run.

    This class mirrors SubnetConfig but with test-friendly defaults
    and additional test-specific settings.

    Example:
        config = TestConfig(
            n_miners=10,
            n_epochs=2,
            scenario=TestScenario.REALISTIC,
        )
        harness = TestHarness(config)
        harness.run()
    """

    # ── Test identity ────────────────────────────────────────────────────
    test_name: str = "subnet_functional_test"
    scenario: TestScenario = TestScenario.HAPPY_PATH

    # ── Miner configuration ──────────────────────────────────────────────
    n_miners: int = 5
    miner_success_rate: float = 1.0
    quality_distribution: str = "uniform"  # uniform, normal, bimodal
    random_seed: int = 42

    # ── Epoch configuration ──────────────────────────────────────────────
    n_epochs: int = 1
    # Set to 0 for instant tests (no sleep between epochs)
    epoch_duration_sec: float = 0.0

    # ── Phase configuration ──────────────────────────────────────────────
    # Phase 2: Filtering
    zero_cost_top_k: int = 4
    max_params: int = 50_000_000  # 50M (generous for testing)
    max_inference_latency_ms: float = 500.0  # 500ms (generous for testing)

    # Phase 3: Training
    deep_train_top_l: int = 2
    training_failure_rate: float = 0.0
    base_test_loss: float = 0.3
    loss_variance: float = 0.1

    # Phase 4: Scoring
    ema_alpha: float = 0.1
    softmax_temperature: float = 1.0
    penalty_exponent: float = 2.5

    # ── File-based miner submissions ─────────────────────────────────────
    # Paths to .py files or directories of .py files to use as miner code.
    # These are loaded from disk and submitted alongside generated mock miners.
    # Pass file paths or directory paths; directories are scanned for *.py.
    miner_code_paths: List[str] = field(default_factory=list)

    # ── Mock behavior ────────────────────────────────────────────────────
    # Skip actual model loading/validation (faster but less realistic)
    skip_zero_cost_eval: bool = False
    # Skip deep training (faster but less realistic)
    skip_deep_training: bool = False
    # Use minimal model code instead of full scaffold
    use_minimal_models: bool = False

    # ── Live mode (partially-live testing) ────────────────────────────
    # Use real LLM (Chutes) to evolve models instead of mock scaffold variations.
    # Requires CHUTES_API_KEY and MODEL_NAME environment variables.
    live_evolve: bool = False
    # Number of independent LLM evolution agents per epoch
    live_evolve_agents: int = 3
    # Max LLM retry attempts per agent on validation failure
    live_evolve_max_attempts: int = 3
    # Whether to do full runtime validation on LLM-evolved code (slower but safer)
    live_evolve_validate_runtime: bool = True

    # Use real local training (universal_trainer) instead of mock losses.
    # Requires torch. Much slower but produces real training metrics.
    local_training: bool = False
    # Budget tier for local training: "small" or "large"
    local_training_budget: str = "small"
    # Override step count for local training (None = use budget tier defaults)
    local_training_max_steps: Optional[int] = None
    # Batch size for local training (lower for CPU)
    local_training_batch_size: int = 8
    # Device for local training: "cpu", "cuda", or None (auto-detect)
    local_training_device: Optional[str] = None

    # ── Basilica mode (real remote GPU) ───────────────────────────────
    # Run zero-cost proxy eval on a real Basilica GPU pod instead of
    # local CPU.  Requires BASILICA_API_TOKEN + DEEP_TRAIN_IMAGE env vars
    # (or PROXY_EVAL_IMAGE).
    basilica_proxy: bool = False
    # Run deep training on real Basilica GPU pods.
    # Requires BASILICA_API_TOKEN + DEEP_TRAIN_IMAGE env vars.
    basilica_training: bool = False

    # ── Database simulation ──────────────────────────────────────────────
    # Mock DB snapshot URL for challenges
    mock_db_snapshot_url: str = "https://r2.example.com/test-snapshot.tar.gz"
    # Mock context string for challenges
    mock_context: str = "# Test context: Previous experiments showed promising results."

    # ── Output configuration ─────────────────────────────────────────────
    output_dir: str = "test_subnet_runs"
    verbose: bool = True
    log_level: str = "INFO"

    # ── Override settings ────────────────────────────────────────────────
    # These override SubnetConfig values during tests
    task_name: str = "time_series_foundation"
    challenge_categories: List[str] = field(
        default_factory=lambda: [
            "long_range",
            "multi_scale",
            "non_stationary",
            "efficiency",
        ]
    )

    def __post_init__(self):
        """Apply scenario-specific defaults."""
        self._apply_scenario_defaults()

    def _apply_scenario_defaults(self):
        """Override settings based on scenario."""
        if self.scenario == TestScenario.HAPPY_PATH:
            self.miner_success_rate = 1.0
            self.quality_distribution = "uniform"
            self.training_failure_rate = 0.0

        elif self.scenario == TestScenario.SINGLE_MINER:
            self.n_miners = 1
            self.miner_success_rate = 1.0
            self.zero_cost_top_k = 1
            self.deep_train_top_l = 1

        elif self.scenario == TestScenario.EMPTY_SUBMISSIONS:
            self.miner_success_rate = 0.0

        elif self.scenario == TestScenario.REALISTIC:
            self.n_miners = 10
            self.miner_success_rate = 0.8
            self.quality_distribution = "normal"
            self.training_failure_rate = 0.1

        elif self.scenario == TestScenario.HIGH_VOLUME:
            self.n_miners = 50
            self.miner_success_rate = 0.9
            self.zero_cost_top_k = 16
            self.deep_train_top_l = 4

        elif self.scenario == TestScenario.ALL_FAIL:
            self.miner_success_rate = 0.0

        elif self.scenario == TestScenario.ALL_INVALID:
            self.miner_success_rate = 1.0
            # Handled by miner factory setting all variations to "invalid"

        elif self.scenario == TestScenario.CONSTRAINT_VIOLATIONS:
            # Set very tight constraints
            self.max_params = 100_000  # 100K - very tight
            self.max_inference_latency_ms = 10.0  # 10ms - very tight

        elif self.scenario == TestScenario.ADVERSARIAL:
            self.n_miners = 15
            self.miner_success_rate = 0.6
            self.quality_distribution = "bimodal"
            self.training_failure_rate = 0.2

        elif self.scenario == TestScenario.LIVE_EVOLVE:
            # Real LLM evolution, mock training
            self.live_evolve = True
            self.live_evolve_agents = 3
            self.n_miners = 0  # no mock miners, only live agents
            self.skip_deep_training = True  # mock training

        elif self.scenario == TestScenario.LIVE_FULL:
            # Real LLM evolution + local training
            self.live_evolve = True
            self.live_evolve_agents = 2  # fewer agents (training is slow)
            self.n_miners = 0
            self.local_training = True
            self.local_training_budget = "small"

        elif self.scenario == TestScenario.BASILICA_PROXY:
            # Real Basilica proxy eval, mock training
            self.basilica_proxy = True
            self.skip_zero_cost_eval = False
            self.skip_deep_training = True

        elif self.scenario == TestScenario.BASILICA_FULL:
            # Real Basilica proxy eval + real Basilica training
            self.basilica_proxy = True
            self.basilica_training = True
            self.skip_zero_cost_eval = False
            self.skip_deep_training = False

    def get_constraints(self) -> Dict[str, Any]:
        """Return constraints dict for Challenge objects."""
        return {
            "max_params": self.max_params,
            "max_inference_latency_ms": self.max_inference_latency_ms,
            "required_quantile_levels": [0.1, 0.5, 0.9],
        }

    def to_dict(self) -> Dict[str, Any]:
        """Convert config to dictionary."""
        d = {
            "test_name": self.test_name,
            "scenario": self.scenario.value,
            "n_miners": self.n_miners,
            "miner_success_rate": self.miner_success_rate,
            "quality_distribution": self.quality_distribution,
            "n_epochs": self.n_epochs,
            "zero_cost_top_k": self.zero_cost_top_k,
            "deep_train_top_l": self.deep_train_top_l,
            "random_seed": self.random_seed,
            "live_evolve": self.live_evolve,
            "local_training": self.local_training,
            "basilica_proxy": self.basilica_proxy,
            "basilica_training": self.basilica_training,
        }
        if self.live_evolve:
            d["live_evolve_agents"] = self.live_evolve_agents
        if self.local_training:
            d["local_training_budget"] = self.local_training_budget
            d["local_training_max_steps"] = self.local_training_max_steps
        return d


# ── Preset configurations ────────────────────────────────────────────────


def quick_test_config() -> TestConfig:
    """Configuration for quick smoke tests (< 1 minute)."""
    return TestConfig(
        test_name="quick_smoke_test",
        scenario=TestScenario.HAPPY_PATH,
        n_miners=3,
        n_epochs=1,
        zero_cost_top_k=2,
        deep_train_top_l=1,
        skip_zero_cost_eval=True,
        skip_deep_training=True,
        use_minimal_models=True,
    )


def standard_test_config() -> TestConfig:
    """Configuration for standard functional tests."""
    return TestConfig(
        test_name="standard_functional_test",
        scenario=TestScenario.REALISTIC,
        n_miners=10,
        n_epochs=2,
        zero_cost_top_k=4,
        deep_train_top_l=2,
    )


def integration_test_config() -> TestConfig:
    """Configuration for full integration tests (longer running)."""
    return TestConfig(
        test_name="integration_test",
        scenario=TestScenario.REALISTIC,
        n_miners=20,
        n_epochs=3,
        zero_cost_top_k=8,
        deep_train_top_l=4,
        skip_zero_cost_eval=False,
        skip_deep_training=False,
    )


def stress_test_config() -> TestConfig:
    """Configuration for stress testing with many miners."""
    return TestConfig(
        test_name="stress_test",
        scenario=TestScenario.HIGH_VOLUME,
        n_miners=100,
        n_epochs=1,
        zero_cost_top_k=20,
        deep_train_top_l=5,
        skip_zero_cost_eval=True,
        skip_deep_training=True,
    )


def live_evolve_config(n_agents: int = 3) -> TestConfig:
    """Configuration for live LLM evolution with mock training.

    Requires CHUTES_API_KEY and MODEL_NAME env vars.
    """
    return TestConfig(
        test_name="live_evolve_test",
        scenario=TestScenario.LIVE_EVOLVE,
        live_evolve_agents=n_agents,
    )


def live_full_config(
    n_agents: int = 2,
    training_steps: Optional[int] = 20,
) -> TestConfig:
    """Configuration for live LLM evolution + local training.

    Requires CHUTES_API_KEY, MODEL_NAME, and torch.
    """
    return TestConfig(
        test_name="live_full_test",
        scenario=TestScenario.LIVE_FULL,
        live_evolve_agents=n_agents,
        local_training_max_steps=training_steps,
    )


def basilica_proxy_config(n_miners: int = 5) -> TestConfig:
    """Configuration for real Basilica proxy eval with mock training.

    Requires BASILICA_API_TOKEN + DEEP_TRAIN_IMAGE (or PROXY_EVAL_IMAGE) env vars.
    """
    return TestConfig(
        test_name="basilica_proxy_test",
        scenario=TestScenario.BASILICA_PROXY,
        n_miners=n_miners,
    )


def basilica_full_config(n_miners: int = 5) -> TestConfig:
    """Configuration for real Basilica proxy eval + training.

    Requires BASILICA_API_TOKEN + DEEP_TRAIN_IMAGE env vars.
    """
    return TestConfig(
        test_name="basilica_full_test",
        scenario=TestScenario.BASILICA_FULL,
        n_miners=n_miners,
    )
