"""
Mock Basilica / affinetes clients for isolated testing.

Provides mock implementations of:
- MockAffinetesEnv (affinetes environment for miner pods and training)
- MockBasilicaTrainingClient (deep training jobs)

These mocks allow running the full validator pipeline without
requiring access to real GPU clusters or the affinetes library.
"""

from __future__ import annotations

import asyncio
import logging
import random
import time
import uuid
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Dict, List, Optional

logger = logging.getLogger(__name__)


# ── Mock affinetes environment ───────────────────────────────────────────


@dataclass
class MockAffinetesEnv:
    """Mock ``affinetes`` environment object.

    Simulates the environment returned by ``af.load_env(mode="basilica")``.
    Provides ``.url`` for HTTP access and ``.cleanup()`` for teardown.
    """

    url: str
    image: str
    status: str = "running"
    created_at: float = field(default_factory=time.time)
    _cleaned_up: bool = False

    async def cleanup(self) -> None:
        """Tear down the environment."""
        self._cleaned_up = True
        self.status = "deleted"
        logger.debug("MockAffinetesEnv %s cleaned up", self.url)


def mock_load_env(
    mode: str = "basilica",
    image: str = "",
    api_token: str = "",
    env_vars: Optional[Dict[str, str]] = None,
    gpu_count: int = 1,
    min_gpu_memory_gb: int = 16,
    memory: str = "16Gi",
    ttl_seconds: int = 3600,
    timeout: int = 900,
    **kwargs,
) -> MockAffinetesEnv:
    """Drop-in replacement for ``af.load_env()`` in tests.

    Returns a ``MockAffinetesEnv`` with a generated mock URL.
    """
    pod_id = uuid.uuid4().hex[:8]
    mock_url = f"http://mock-pod-{pod_id}:8000"

    logger.info(
        "mock_load_env: mode=%s image=%s url=%s",
        mode, image, mock_url,
    )
    return MockAffinetesEnv(url=mock_url, image=image)


# ── MockAffinetesModule ─────────────────────────────────────────────────


class MockAffinetesModule:
    """Mock ``affinetes`` module for use in tests.

    Provides ``load_env`` as a callable attribute so code that does
    ``import affinetes as af; af.load_env(...)`` can be patched:

        mock_af = MockAffinetesModule()
        with patch("subnet.validator.miner_runner.af", mock_af):
            ...
    """

    def __init__(
        self,
        failure_images: Optional[List[str]] = None,
    ):
        self.failure_images = failure_images or []
        self._envs_created: List[MockAffinetesEnv] = []

    def load_env(self, **kwargs) -> MockAffinetesEnv:
        """Create a mock environment."""
        image = kwargs.get("image", "")
        if image in self.failure_images:
            raise RuntimeError(
                f"MockAffinetesModule: load_env failed for image {image}"
            )
        env = mock_load_env(**kwargs)
        self._envs_created.append(env)
        return env

    def get_envs_created(self) -> List[MockAffinetesEnv]:
        """Return all environments created for verification."""
        return self._envs_created.copy()


# ── Mock Training Client ─────────────────────────────────────────────────


# Import TrainingStatus from the real module to ensure compatibility
try:
    from services.eval.remote_training.remote_types import TrainingStatus
except ImportError:
    # Fallback if the real module isn't available
    class TrainingStatus(str, Enum):
        """Training job status enum."""
        PENDING = "pending"
        RUNNING = "running"
        SUCCEEDED = "succeeded"
        FAILED = "failed"
        TIMED_OUT = "timed_out"


@dataclass
class MockTrainingResult:
    """Mock training result object.

    Simulates the TrainingResult returned by BasilicaTrainingClient.
    """

    job_id: str
    status: TrainingStatus
    metrics: Dict[str, Any] = field(default_factory=dict)
    wall_time_sec: float = 0.0
    stdout_tail: str = ""


class MockBasilicaTrainingClient:
    """Mock BasilicaTrainingClient for deep training testing.

    Simulates the behavior of the training client used in Phase 3:
    - train(): Submits a mock training job and returns results
    - Results can be configured to simulate various scenarios

    The mock can be configured to:
    - Return specific metrics based on model code quality
    - Simulate training failures
    - Control training duration

    Example:
        client = MockBasilicaTrainingClient(
            base_loss=0.5,
            loss_variance=0.1,
        )

        spec = TrainingJobSpec(...)
        result = await client.train(spec)
        print(result.metrics["test_loss"])  # ~0.5 +/- 0.1
    """

    def __init__(
        self,
        api_token: str = "mock_token",
        docker_image: str = "mock/trainer:latest",
        gpu_type: Optional[str] = None,
        gpu_count: int = 1,
        gpu_memory_gb: int = 16,
        memory: str = "16Gi",
        ttl_small: int = 3600,
        ttl_large: int = 14400,
        max_poll_seconds: int = 7200,
        validate_credentials: bool = False,
        # Mock-specific config
        base_loss: float = 0.5,
        loss_variance: float = 0.2,
        failure_rate: float = 0.0,
        train_duration_sec: float = 0.1,
        quality_extractor: Optional[Callable[[str], float]] = None,
        seed: int = 42,
    ):
        """Initialize mock training client.

        Args:
            api_token: Simulated API token.
            docker_image: Training image (not used in mock).
            gpu_type: GPU type (not used in mock).
            gpu_count: Number of GPUs (not used in mock).
            gpu_memory_gb: GPU memory (not used in mock).
            memory: Container memory (not used in mock).
            ttl_small: TTL for small jobs (not used in mock).
            ttl_large: TTL for large jobs (not used in mock).
            max_poll_seconds: Max polling time (not used in mock).
            validate_credentials: Whether to validate credentials (not used).
            base_loss: Base loss value for mock results.
            loss_variance: Variance in mock loss values.
            failure_rate: Probability of training failure (0.0-1.0).
            train_duration_sec: Simulated training duration.
            quality_extractor: Function to extract quality from model code.
            seed: Random seed for reproducibility.
        """
        self.api_token = api_token
        self.docker_image = docker_image
        self.base_loss = base_loss
        self.loss_variance = loss_variance
        self.failure_rate = failure_rate
        self.train_duration_sec = train_duration_sec
        self._quality_extractor = quality_extractor or self._default_quality_extractor
        self._rng = random.Random(seed)
        self._job_count = 0
        self._job_history: List[MockTrainingResult] = []

    def _default_quality_extractor(self, model_code: str) -> float:
        """Extract a quality signal from model code.

        Looks for patterns that suggest quality:
        - Larger d_model = better quality
        - More layers = better quality
        - Invalid code = very low quality
        """
        if "raise ValueError" in model_code or "Invalid" in model_code:
            return 0.0

        quality = 0.5  # baseline

        # Check for d_model variations
        if '"d_model":        384' in model_code or "'d_model': 384" in model_code:
            quality += 0.15
        elif '"d_model":        128' in model_code or "'d_model': 128" in model_code:
            quality -= 0.15

        # Check for n_layers variations
        if '"n_layers":       9' in model_code or "'n_layers': 9" in model_code:
            quality += 0.1
        elif '"n_layers":       3' in model_code or "'n_layers': 3" in model_code:
            quality -= 0.1

        # Check for wider models
        if '"n_heads":        16' in model_code:
            quality += 0.05

        # Quality metadata in comments
        if "Quality target:" in model_code:
            try:
                # Extract quality from metadata comment
                import re
                match = re.search(r"Quality target: ([\d.]+)", model_code)
                if match:
                    quality = float(match.group(1))
            except (ValueError, AttributeError):
                pass

        return max(0.0, min(1.0, quality))

    async def train(self, spec: Any) -> MockTrainingResult:
        """Run mock training and return results.

        Args:
            spec: TrainingJobSpec object containing model code.

        Returns:
            MockTrainingResult with simulated metrics.
        """
        self._job_count += 1
        job_id = spec.job_id if hasattr(spec, 'job_id') else uuid.uuid4().hex

        # Simulate training duration
        if self.train_duration_sec > 0:
            await asyncio.sleep(self.train_duration_sec)

        # Check for injected failure
        if self._rng.random() < self.failure_rate:
            result = MockTrainingResult(
                job_id=job_id,
                status=TrainingStatus.FAILED,
                metrics={"train_loss": None, "test_loss": None, "error": "training_failed"},
                wall_time_sec=self.train_duration_sec,
                stdout_tail="Training failed: Simulated failure",
            )
            self._job_history.append(result)
            return result

        # Extract quality from model code
        model_code = getattr(spec, 'model_code_content', '') or ''
        quality = self._quality_extractor(model_code)

        # Generate loss based on quality (lower quality = higher loss)
        noise = self._rng.gauss(0, self.loss_variance)
        test_loss = self.base_loss + (1.0 - quality) * 0.5 + noise
        train_loss = test_loss * 0.9 + self._rng.gauss(0, 0.02)  # Train loss typically lower

        # Ensure losses are positive
        test_loss = max(0.01, test_loss)
        train_loss = max(0.01, train_loss)

        metrics = {
            "train_loss": train_loss,
            "test_loss": test_loss,
            "quality": quality,
            "epochs": 10,
            "best_epoch": 8,
            "learning_rate": 1e-4,
        }

        result = MockTrainingResult(
            job_id=job_id,
            status=TrainingStatus.SUCCEEDED,
            metrics=metrics,
            wall_time_sec=self.train_duration_sec,
            stdout_tail=f"Training completed. Final test loss: {test_loss:.4f}",
        )
        self._job_history.append(result)

        logger.info(
            "MockBasilicaTrainingClient.train: job_id=%s quality=%.2f test_loss=%.4f",
            job_id, quality, test_loss,
        )
        return result

    async def batch_train_streams(
        self,
        model_codes: List[str],
        *,
        budget_tier: str = "small",
        timeout_sec: float = 3600,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> List[MockTrainingResult]:
        """Mock batch training via CUDA streams (single pod).

        Trains all model codes concurrently and returns one result per code.
        Used by Phase 3 when TRAINING_USE_STREAMS=1 (the default).
        """
        results: List[MockTrainingResult] = []
        for i, code in enumerate(model_codes):
            # Create a mock spec-like object
            mock_spec = type("Spec", (), {
                "job_id": uuid.uuid4().hex,
                "model_code_content": code,
            })()
            result = await self.train(mock_spec)
            results.append(result)

        logger.info(
            "MockBasilicaTrainingClient.batch_train_streams: %d models, budget=%s",
            len(model_codes), budget_tier,
        )
        return results

    async def batch_train(
        self,
        specs: List[Any],
        *,
        max_concurrency: int = 4,
    ) -> List[MockTrainingResult]:
        """Mock batch training via multiple pods (one per candidate).

        Trains each spec as a separate job and returns results.
        Used by Phase 3 when TRAINING_USE_STREAMS=0.
        """
        results: List[MockTrainingResult] = []
        for spec in specs:
            result = await self.train(spec)
            results.append(result)

        logger.info(
            "MockBasilicaTrainingClient.batch_train: %d specs, max_concurrency=%d",
            len(specs), max_concurrency,
        )
        return results

    async def batch_proxy_eval(
        self,
        model_codes: List[str],
        *,
        input_length: int = 512,
        forecast_length: int = 64,
        batch_size: int = 4,
        num_variants: int = 7,
        max_params: Optional[int] = None,
        max_inference_latency_ms: Optional[float] = None,
        timeout_sec: float = 600,
    ) -> List[Dict[str, Any]]:
        """Mock batch proxy evaluation on a Basilica pod.

        Returns a list of proxy result dicts (one per model code).
        Used by Phase 2 (_batch_proxy_eval_basilica).
        """
        results: List[Dict[str, Any]] = []
        for i, code in enumerate(model_codes):
            noise = self._rng.gauss(0, 0.05)
            quality = self._quality_extractor(code)

            param_count = int(1_000_000 * (0.5 + quality))
            latency = 5.0 + self._rng.gauss(0, 1)

            results.append({
                "status": "ok",
                "proxy_status": "PASS",
                "param_count": param_count,
                "trainable_params": param_count,
                "inference_latency_ms": max(0.1, latency),
                "eff_rank": 50 + noise * 10,
                "deep_collapse_ratio": 0.1 + noise,
                "saliency_per_param": 0.01 + noise * 0.001,
                "sensitivity_log_norm": 3.0 + noise,
                "grad_coherence": 0.7 + noise * 0.1,
                "state_velocity": 0.5 + noise * 0.1,
                "local_contrast": 0.3 + noise * 0.05,
                "deep_rep_source": "spectral",
                "sensitivity_ok_rate": 0.8 + noise * 0.05,
            })

        logger.info(
            "MockBasilicaTrainingClient.batch_proxy_eval: %d models",
            len(model_codes),
        )
        return results

    def get_job_count(self) -> int:
        """Return total number of training jobs submitted."""
        return self._job_count

    def get_job_history(self) -> List[MockTrainingResult]:
        """Return all training results for verification."""
        return self._job_history.copy()


# ── Factory helpers ──────────────────────────────────────────────────────


def create_reliable_training_client(
    base_loss: float = 0.3,
    variance: float = 0.1,
) -> MockBasilicaTrainingClient:
    """Create a training client that always succeeds."""
    return MockBasilicaTrainingClient(
        base_loss=base_loss,
        loss_variance=variance,
        failure_rate=0.0,
        train_duration_sec=0.05,
    )


def create_flaky_training_client(
    failure_rate: float = 0.2,
) -> MockBasilicaTrainingClient:
    """Create a training client with occasional failures."""
    return MockBasilicaTrainingClient(
        failure_rate=failure_rate,
        train_duration_sec=0.05,
    )


def create_fast_training_client() -> MockBasilicaTrainingClient:
    """Create a training client with minimal delay for fast tests."""
    return MockBasilicaTrainingClient(
        train_duration_sec=0.0,
        failure_rate=0.0,
    )
