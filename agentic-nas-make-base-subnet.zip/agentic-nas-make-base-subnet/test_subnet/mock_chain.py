"""
Mock chain interface for isolated subnet testing.

Provides mock implementations of:
- ChainInterface (read_commitments, get_metagraph, set_weights)
- Metagraph (hotkeys, n, block)
- Wallet/Keypair (for Epistula signing)

These mocks allow running the full validator pipeline without
connecting to a real Bittensor chain.
"""

from __future__ import annotations

import hashlib
import logging
import time
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from subnet.protocol.types import MinerCommitment

logger = logging.getLogger(__name__)


# ── Mock Wallet / Keypair ────────────────────────────────────────────────


@dataclass
class MockKeypair:
    """Mock bittensor Keypair for Epistula signing.

    Provides a minimal interface that matches what the validator needs:
    - ss58_address: The hotkey address
    - sign(): Returns a mock signature
    """

    ss58_address: str = "5MockValidatorHotkey000000000000000000000000"
    _seed: bytes = field(default_factory=lambda: b"mock_seed_for_testing")

    def sign(self, message: bytes) -> bytes:
        """Return a deterministic mock signature."""
        # Use HMAC-like construction for deterministic signatures
        h = hashlib.sha256(self._seed + message)
        return h.digest()


@dataclass
class MockWallet:
    """Mock bittensor Wallet.

    Attributes:
        name: Wallet name
        hotkey_str: Hotkey name
        hotkey: MockKeypair instance for signing
    """

    name: str = "test_wallet"
    hotkey_str: str = "test_hotkey"
    _hotkey: Optional[MockKeypair] = None

    @property
    def hotkey(self) -> MockKeypair:
        if self._hotkey is None:
            self._hotkey = MockKeypair(
                ss58_address=f"5Mock{self.name}{self.hotkey_str}000000000000000"[:48]
            )
        return self._hotkey


# ── Mock Metagraph ───────────────────────────────────────────────────────


@dataclass
class MockMetagraph:
    """Mock bittensor Metagraph.

    Simulates the metagraph data structure returned by subtensor.metagraph().
    Only includes fields actually used by the validator.

    Attributes:
        n: Number of UIDs (as a tensor-like object with .item())
        block: Current block number (as a tensor-like object with .item())
        hotkeys: List of hotkey addresses indexed by UID
        stakes: List of stake amounts indexed by UID
    """

    _n_uids: int = 256
    _block: int = 1000000
    hotkeys: List[str] = field(default_factory=list)
    stakes: List[float] = field(default_factory=list)

    def __post_init__(self):
        # Generate hotkeys if not provided
        if not self.hotkeys:
            self.hotkeys = [
                f"5Miner{i:03d}000000000000000000000000000000000000"[:48]
                for i in range(self._n_uids)
            ]
        # Initialize stakes if not provided
        if not self.stakes:
            self.stakes = [100.0 for _ in range(self._n_uids)]

    @property
    def n(self):
        """Return number of UIDs as tensor-like."""
        return _TensorLike(self._n_uids)

    @property
    def block(self):
        """Return block number as tensor-like."""
        return _TensorLike(self._block)


class _TensorLike:
    """Minimal tensor mock with .item() and .tolist() methods."""

    def __init__(self, value):
        self._value = value

    def item(self):
        return self._value

    def tolist(self):
        """Return value as a list (for tensors containing lists)."""
        if isinstance(self._value, list):
            return self._value
        return [self._value]


# ── Mock Subtensor ───────────────────────────────────────────────────────


class MockSubtensor:
    """Mock bittensor Subtensor.

    Provides minimal interface for:
    - metagraph(netuid) -> MockMetagraph
    - get_commitment(netuid, uid) -> commitment data
    - set_weights(netuid, wallet, uids, weights) -> (success, msg)
    """

    def __init__(
        self,
        network: str = "test",
        chain_endpoint: Optional[str] = None,
        metagraph: Optional[MockMetagraph] = None,
        commitments: Optional[Dict[int, Dict[str, Any]]] = None,
    ):
        self.network = network
        self.chain_endpoint = chain_endpoint
        self._metagraph = metagraph or MockMetagraph()
        self._commitments = commitments or {}
        self._submitted_weights: List[Dict[str, Any]] = []

        logger.info(
            "MockSubtensor initialized: network=%s, %d UIDs",
            network, self._metagraph._n_uids,
        )

    def metagraph(self, netuid: int):
        """Return the mock metagraph."""
        return self._metagraph

    def get_commitment(self, netuid: int, uid: int) -> Optional[str]:
        """Return commitment data for a UID, if any."""
        if uid in self._commitments:
            import json
            return json.dumps(self._commitments[uid])
        return None

    def set_weights(
        self,
        netuid: int,
        wallet: Any,
        uids: Any,
        weights: Any,
        wait_for_inclusion: bool = True,
    ) -> tuple:
        """Record weight submission and return success.

        Args:
            netuid: Subnet UID
            wallet: Wallet for signing
            uids: Tensor of UIDs
            weights: Tensor of weights
            wait_for_inclusion: Whether to wait for on-chain inclusion

        Returns:
            (success: bool, message: str)
        """
        # Convert tensors to lists for storage
        uid_list = uids.tolist() if hasattr(uids, 'tolist') else list(uids)
        weight_list = weights.tolist() if hasattr(weights, 'tolist') else list(weights)

        submission = {
            "netuid": netuid,
            "uids": uid_list,
            "weights": weight_list,
            "timestamp": time.time(),
        }
        self._submitted_weights.append(submission)

        logger.info(
            "MockSubtensor.set_weights: netuid=%d, %d UIDs, sum=%.4f",
            netuid, len(uid_list), sum(weight_list),
        )
        return True, "Mock weight submission succeeded"

    def get_submitted_weights(self) -> List[Dict[str, Any]]:
        """Return all weight submissions for verification."""
        return self._submitted_weights.copy()


# ── Mock ChainInterface ──────────────────────────────────────────────────


class MockChainInterface:
    """Drop-in replacement for subnet.validator.chain.ChainInterface.

    Provides the same interface but backed by mock implementations.
    All chain operations are simulated locally.

    Example:
        # Configure mock miners
        commitments = [
            MinerCommitment(
                hotkey="5Miner001...",
                uid=1,
                docker_image="test/miner:v1",
            ),
            ...
        ]

        # Create mock chain
        chain = MockChainInterface(commitments=commitments)

        # Use in validator
        validator = Validator()
        validator.chain = chain  # Inject mock
    """

    def __init__(
        self,
        commitments: Optional[List[MinerCommitment]] = None,
        n_uids: int = 256,
        wallet_name: str = "test_wallet",
        hotkey_name: str = "test_hotkey",
    ):
        """Initialize mock chain interface.

        Args:
            commitments: Pre-configured miner commitments. If None,
                read_commitments() returns an empty list.
            n_uids: Number of UIDs in the mock metagraph.
            wallet_name: Name for the mock wallet.
            hotkey_name: Hotkey name for the mock wallet.
        """
        self._commitments = commitments or []

        # Build commitment dict for subtensor
        commitment_dict = {}
        for c in self._commitments:
            commitment_dict[c.uid] = {
                "docker_image": c.docker_image,
                "metadata": c.metadata,
            }

        # Build hotkeys list
        hotkeys = [f"5Empty{i:03d}{'0' * 36}"[:48] for i in range(n_uids)]
        for c in self._commitments:
            if 0 <= c.uid < n_uids:
                hotkeys[c.uid] = c.hotkey

        self._metagraph = MockMetagraph(_n_uids=n_uids, hotkeys=hotkeys)
        self._subtensor = MockSubtensor(
            metagraph=self._metagraph,
            commitments=commitment_dict,
        )
        self._wallet = MockWallet(name=wallet_name, hotkey_str=hotkey_name)

    @property
    def subtensor(self):
        """Return the mock subtensor."""
        return self._subtensor

    @property
    def wallet(self):
        """Return the mock wallet."""
        return self._wallet

    def read_commitments(self) -> List[MinerCommitment]:
        """Return the configured miner commitments."""
        logger.debug("MockChainInterface.read_commitments: %d miners", len(self._commitments))
        return self._commitments.copy()

    def get_metagraph(self):
        """Return the mock metagraph."""
        return self._metagraph

    def set_weights(self, uids: List[int], weights: List[float]) -> bool:
        """Submit weights via mock subtensor."""
        # Use _TensorLike to avoid torch dependency in tests
        success, msg = self._subtensor.set_weights(
            netuid=0,  # Use default netuid
            wallet=self._wallet,
            uids=_TensorLike(uids),
            weights=_TensorLike(weights),
            wait_for_inclusion=True,
        )
        return success

    def get_submitted_weights(self) -> List[Dict[str, Any]]:
        """Return all weight submissions for test verification."""
        return self._subtensor.get_submitted_weights()


# ── Factory helpers ──────────────────────────────────────────────────────


def create_mock_commitments(
    n_miners: int,
    docker_image: str = "test/miner:latest",
    uid_offset: int = 0,
) -> List[MinerCommitment]:
    """Generate a list of mock miner commitments.

    Args:
        n_miners: Number of miners to create.
        docker_image: Docker image to use for all miners.
        uid_offset: Starting UID (miners get UIDs uid_offset, uid_offset+1, ...).

    Returns:
        List of MinerCommitment objects.
    """
    commitments = []
    for i in range(n_miners):
        uid = uid_offset + i
        hotkey = f"5Miner{uid:03d}000000000000000000000000000000000000"[:48]
        commitments.append(
            MinerCommitment(
                hotkey=hotkey,
                uid=uid,
                docker_image=docker_image,
                metadata={"test": True, "index": i},
                block_committed=1000000 + i,
            )
        )
    return commitments
