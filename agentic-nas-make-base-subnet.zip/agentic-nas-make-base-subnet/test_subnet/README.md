# Subnet Functional Test Harness

Functional testing for the Bittensor subnet validator with **configurable realism** —
from fully mocked (instant, no deps) to partially live (real LLM evolution + real local training).

## Testing Modes

| Mode | Phase 1 (Generation) | Phase 2 (Proxy Eval) | Phase 3 (Training) | Requires |
|------|---------------------|---------------------|---------------------|----------|
| **Full mock** (default) | Scaffold variations | Mock | Synthetic losses | Nothing |
| **Live evolve** | LLM via Chutes | Local CPU | Synthetic losses | `CHUTES_API_KEY`, `MODEL_NAME` |
| **Local training** | Scaffold variations | Local CPU | Real universal_trainer | PyTorch |
| **Basilica proxy** | Scaffold variations | Basilica GPU pod | Synthetic losses | `BASILICA_API_TOKEN`, `DEEP_TRAIN_IMAGE` |
| **Basilica full** | Scaffold variations | Basilica GPU pod | Basilica GPU pods | `BASILICA_API_TOKEN`, `DEEP_TRAIN_IMAGE` |
| **Live full** | LLM via Chutes | Local CPU | Real universal_trainer | `CHUTES_API_KEY`, `MODEL_NAME`, PyTorch |
| **File-based** | Your .py files | Configurable | Configurable | Depends on mode |

## Quick Start

```bash
# Full mock (fast, no deps)
python -m test_subnet.harness --miners 5 --skip-eval --skip-training

# Real filtering + scoring, mock generation + training
python -m test_subnet.harness --miners 5 --epochs 1

# Live LLM evolution with mock training
export CHUTES_API_KEY=your-key MODEL_NAME=meta-llama/Llama-4-Scout-17B-16E-Instruct
python -m test_subnet.harness --live-evolve --live-agents 3 --skip-training

# Live LLM evolution + real local training
python -m test_subnet.harness --live-evolve --local-training --training-steps 20

# Real proxy eval on Basilica + mock training
export BASILICA_API_TOKEN=your-token DEEP_TRAIN_IMAGE=your-registry/image:latest
python -m test_subnet.harness --miners 5 --basilica-proxy --skip-training

# Full Basilica: real proxy eval + real training
python -m test_subnet.harness --miners 5 --basilica-proxy --basilica-training

# Use preset scenarios
python -m test_subnet.harness --scenario live_evolve
python -m test_subnet.harness --scenario basilica_full
```

## What Gets Tested (Real)

| Component | What's Tested | Requires |
|-----------|---------------|----------|
| **Phase 1 Generation** (live) | LLM code evolution, AST validation, runtime contract check | `CHUTES_API_KEY`, `MODEL_NAME` |
| **Phase 2 Filtering** | `load_candidate_model()`, FX shape validation, `count_parameters()`, `measure_inference_latency()` | PyTorch |
| **Phase 3 Training** (local) | `train_model()` with ts-foundation callables, real loss/eval | PyTorch, HF datasets |
| **Phase 4 Scoring** | `compute_weights()` with EMA, penalty exponent, softmax normalization | None |
| **Protocol Types** | `Challenge`, `MinerSubmission`, `CandidateResult` serialization | None |

## What Gets Mocked (Always)

- **Chain/metagraph**: No Bittensor connection needed
- **Basilica pods**: No GPU cluster for miner containers

## Dependencies

- **Minimal (full mock)**: No extra dependencies
- **Real filtering (local)**: `pip install torch` (CPU version sufficient)
- **Live evolve**: `CHUTES_API_KEY` + `MODEL_NAME` env vars, `aiohttp`
- **Local training**: `pip install torch`, HuggingFace `datasets`
- **Basilica proxy/training**: `BASILICA_API_TOKEN` + `DEEP_TRAIN_IMAGE` env vars, `affinetes` package

## Architecture

```
test_subnet/
├── __init__.py          # Package exports
├── harness.py           # Main test harness runner (CLI entry)
├── config.py            # TestConfig and preset scenarios
├── fixtures.py          # Sample data and verification helpers
├── mock_chain.py        # Mock ChainInterface, Metagraph, Wallet
├── mock_miners.py       # Mock miner submission factory
├── mock_basilica.py     # Mock Basilica pod and training clients
├── live_agent.py        # LiveMinerAgent: real LLM evolution via Chutes
├── local_training.py    # LocalTrainingClient: real training on local hardware
└── README.md            # This file
```

## Live Evolution (`--live-evolve`)

Uses the Chutes LLM provider to generate model code, mimicking a real miner's
evolution pipeline. Each "live agent" independently:

1. Takes the scaffold (or parent) code + challenge context
2. Asks the LLM to make ONE focused architectural change
3. Validates the result (syntax + runtime contract)
4. Retries up to N times on failure
5. Falls back to scaffold if all attempts fail

```bash
# Required env vars
export CHUTES_API_KEY=your-key
export MODEL_NAME=meta-llama/Llama-4-Scout-17B-16E-Instruct

# 3 LLM agents, each producing one evolved model
python -m test_subnet.harness --live-evolve --live-agents 3 --skip-training

# Mix live agents with mock miners
python -m test_subnet.harness --live-evolve --live-agents 2 --miners 5
```

### Programmatic usage

```python
from test_subnet.config import TestConfig, TestScenario, live_evolve_config

# Using preset
config = live_evolve_config(n_agents=3)

# Or manual
config = TestConfig(
    live_evolve=True,
    live_evolve_agents=3,
    live_evolve_max_attempts=3,
    live_evolve_validate_runtime=True,
    n_miners=0,          # no mock miners
    skip_deep_training=True,  # mock training
)
```

## Local Training (`--local-training`)

Trains candidate models on the local machine using the real universal trainer
with ts-foundation loss/eval callables. Produces real loss metrics instead of
synthetic mock values.

```bash
# Local training with default small budget (20 steps)
python -m test_subnet.harness --miners 5 --local-training

# Override step count (faster iteration)
python -m test_subnet.harness --miners 3 --local-training --training-steps 10

# Force CPU even if GPU available
python -m test_subnet.harness --miners 3 --local-training --training-device cpu

# Full live: LLM evolve + local train
python -m test_subnet.harness --live-evolve --local-training --training-steps 20
```

### Programmatic usage

```python
from test_subnet.config import TestConfig, live_full_config

# Using preset
config = live_full_config(n_agents=2, training_steps=20)

# Or manual
config = TestConfig(
    local_training=True,
    local_training_budget="small",
    local_training_max_steps=20,
    local_training_batch_size=8,
    local_training_device="cpu",
)
```

## Basilica GPU Testing (`--basilica-proxy`, `--basilica-training`)

Runs the real Basilica infrastructure path — same as production validators.
Proxy eval deploys a single GPU pod and batch-evaluates all candidates.
Training deploys pods and runs the real two-stage training funnel (Phase 3a short + 3b long).

```bash
# Required env vars
export BASILICA_API_TOKEN=your-token
export DEEP_TRAIN_IMAGE=your-registry/agentic-nas-basilica:latest

# Proxy eval only (uses Basilica pod for zero-cost eval, mock training)
python -m test_subnet.harness --miners 5 --basilica-proxy --skip-training

# Full Basilica: real proxy eval + real training on GPU pods
python -m test_subnet.harness --miners 5 --basilica-proxy --basilica-training

# Combine with live evolve: LLM generates models, Basilica evaluates and trains
python -m test_subnet.harness --live-evolve --live-agents 3 \
    --basilica-proxy --basilica-training

# Use preset scenarios
python -m test_subnet.harness --scenario basilica_proxy
python -m test_subnet.harness --scenario basilica_full
```

### Programmatic usage

```python
from test_subnet.config import TestConfig, TestScenario, basilica_full_config

# Using preset
config = basilica_full_config(n_miners=5)

# Or manual
config = TestConfig(
    basilica_proxy=True,           # proxy eval on Basilica GPU pod
    basilica_training=True,        # training on Basilica GPU pods
    skip_zero_cost_eval=False,     # actually run proxy eval
    skip_deep_training=False,      # actually run training
    n_miners=5,
)
```

### Environment variables for Basilica

| Variable | Required | Purpose |
|----------|----------|---------|
| `BASILICA_API_TOKEN` | Yes | API authentication for Basilica |
| `DEEP_TRAIN_IMAGE` | Yes | Docker image for training pods |
| `PROXY_EVAL_IMAGE` | No | Override image for proxy eval (defaults to `DEEP_TRAIN_IMAGE`) |
| `BASILICA_GPU_TYPE` | No | GPU type (A4000, A100, etc.) — auto-selected if omitted |
| `BASILICA_GPU_COUNT` | No | GPUs per container (default: 1) |
| `BASILICA_GPU_MEMORY_GB` | No | Min GPU VRAM in GB (default: 16) |
| `BASILICA_MEMORY` | No | Container memory (default: 16Gi) |

## CLI Options

```
usage: python -m test_subnet.harness [-h] [--miners MINERS] [--epochs EPOCHS]
                                      [--scenario SCENARIO] [--success-rate RATE]
                                      [--skip-eval] [--skip-training]
                                      [--miner-code FILE] [--miner-dir DIR]
                                      [--live-evolve] [--live-agents N]
                                      [--local-training] [--training-steps N]
                                      [--training-device DEVICE]
                                      [--output FILE] [--verbose] [--seed SEED]

Core options:
  --miners, -m          Number of mock miners (default: 5)
  --epochs, -e          Number of epochs to run (default: 1)
  --scenario, -s        Test scenario (default: happy_path)
  --success-rate        Miner success rate 0.0-1.0 (default: 1.0)
  --skip-eval           Skip real zero-cost evaluation (mock instead)
  --skip-training       Skip real training (mock instead)
  --miner-code          Path to a .py file to submit as a miner (repeatable)
  --miner-dir           Path to a directory of .py files (repeatable)

Live testing:
  --live-evolve         Use real LLM (Chutes) to evolve models
  --live-agents N       Number of LLM agents (default: 3)
  --local-training      Train locally using universal_trainer
  --training-steps N    Override training step count
  --training-device D   Device: cpu, cuda (default: auto-detect)

Basilica (remote GPU):
  --basilica-proxy      Run proxy eval on a Basilica GPU pod
  --basilica-training   Run training on Basilica GPU pods

Output:
  --output, -o          Save results to JSON file
  --verbose, -v         Enable debug logging
  --seed                Random seed for reproducibility (default: 42)
```

## Test Scenarios

| Scenario | Description |
|----------|-------------|
| `happy_path` | All miners succeed with varied quality |
| `single_miner` | Just one miner (edge case) |
| `empty_submissions` | No successful submissions |
| `realistic` | 80% success rate, normal quality distribution |
| `high_volume` | 50+ miners (stress test) |
| `all_fail` | All miners fail |
| `adversarial` | Mixed adversarial behaviors |
| **`live_evolve`** | Real LLM evolution, mock training |
| **`live_full`** | Real LLM evolution + local training |
| **`basilica_proxy`** | Real Basilica proxy eval, mock training |
| **`basilica_full`** | Real Basilica proxy eval + Basilica training |

## Example Test Runs

### Quick Smoke Test

```bash
python -m test_subnet.harness --miners 3 --skip-eval --skip-training
```

### Realistic Integration Test

```bash
python -m test_subnet.harness \
    --miners 15 \
    --epochs 3 \
    --scenario realistic \
    --output integration_results.json
```

### Live Evolution Test

```bash
export CHUTES_API_KEY=your-key
export MODEL_NAME=meta-llama/Llama-4-Scout-17B-16E-Instruct

python -m test_subnet.harness \
    --live-evolve \
    --live-agents 3 \
    --skip-training \
    --output live_evolve_results.json \
    --verbose
```

### Full Live Test (evolution + training)

```bash
python -m test_subnet.harness \
    --live-evolve \
    --live-agents 2 \
    --local-training \
    --training-steps 20 \
    --output live_full_results.json \
    --verbose
```

### Mixed: Live agents + mock miners + file-based

```bash
python -m test_subnet.harness \
    --live-evolve \
    --live-agents 2 \
    --miners 3 \
    --miner-code my_custom_model.py \
    --local-training \
    --training-steps 10
```

## Programmatic Usage

### Running Custom Tests

```python
import asyncio
from test_subnet.harness import TestHarness
from test_subnet.config import TestConfig, TestScenario

# Custom configuration
config = TestConfig(
    test_name="custom_test",
    n_miners=8,
    n_epochs=2,
    miner_success_rate=0.9,
    zero_cost_top_k=6,
    deep_train_top_l=3,
    base_test_loss=0.25,
)

# Run
harness = TestHarness(config)
results = harness.run()

# Analyze
for epoch in results.epochs:
    print(f"Epoch {epoch.epoch}: {epoch.n_trained} finalists")
    for uid, weight in epoch.weights.items():
        print(f"  UID {uid}: {weight:.4f}")
```

### Testing Individual Phases

```python
from test_subnet.mock_chain import MockChainInterface, create_mock_commitments
from test_subnet.mock_miners import MockMinerFactory
from test_subnet.fixtures import create_sample_challenge
from subnet.validator.filtering import run_filtering_phase
from subnet.validator.scoring import compute_weights

# Setup
factory = MockMinerFactory(n_miners=5)
challenge = create_sample_challenge()
submissions = factory.generate_submissions(challenge)

# Test Phase 2 (filtering)
results = asyncio.run(run_filtering_phase(
    [s for s in submissions if s.status.value == "succeeded"],
    constraints={"max_params": 10_000_000, "max_inference_latency_ms": 50.0},
))

# Test Phase 4 (scoring)
ema_scores = {}
weights = compute_weights(results=results, ema_scores=ema_scores)
print(f"Weights: {weights}")
```

## Troubleshooting

### Import Errors

Ensure you're running from the project root:

```bash
cd /path/to/agentic-nas
python -m test_subnet.harness
```

### Live evolve not producing code

Check that env vars are set:
```bash
echo $CHUTES_API_KEY  # should be non-empty
echo $MODEL_NAME      # e.g. meta-llama/Llama-4-Scout-17B-16E-Instruct
```

### Local training OOM

Reduce batch size or step count:
```bash
python -m test_subnet.harness --local-training --training-steps 5 --training-device cpu
```

### Debugging

Use verbose mode for detailed logs:

```bash
python -m test_subnet.harness --verbose
```
