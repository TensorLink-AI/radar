"""
Local training client for partially-live subnet testing.

Replaces ``MockBasilicaTrainingClient`` when ``--local-training`` is
passed to the harness.  Trains candidate models on the local machine
(CPU or GPU) using the real universal trainer + ts-foundation callables.

This lets you verify that evolved models actually learn, rather than
relying on synthetic mock losses.

Requirements:
    torch (CPU is sufficient but slow; GPU recommended for non-trivial budgets).
"""

from __future__ import annotations

import logging
import os
import tempfile
import time
import uuid
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


@dataclass
class LocalTrainingResult:
    """Result from a local training run."""

    job_id: str
    status: str  # "succeeded" | "failed"
    metrics: Dict[str, Any] = field(default_factory=dict)
    wall_time_sec: float = 0.0
    stdout_tail: str = ""


class LocalTrainingClient:
    """Train candidate models locally using the universal trainer.

    Mirrors the interface of ``MockBasilicaTrainingClient`` so the harness
    can swap between mock and local training transparently.

    Args:
        budget_tier: ``"small"`` or ``"large"`` — controls step count.
        device: ``"cpu"``, ``"cuda"``, or ``None`` (auto-detect).
        max_steps_override: If set, overrides the budget tier step count.
        batch_size: Training batch size (lower for CPU).
        run_dir: Base directory for training artifacts.
    """

    def __init__(
        self,
        budget_tier: str = "small",
        device: Optional[str] = None,
        max_steps_override: Optional[int] = None,
        batch_size: int = 8,
        run_dir: Optional[str] = None,
    ):
        self.budget_tier = budget_tier
        self._device_str = device
        self.max_steps_override = max_steps_override
        self.batch_size = batch_size
        self.run_dir = run_dir or tempfile.mkdtemp(prefix="test_subnet_train_")
        self._job_count = 0
        self._job_history: List[LocalTrainingResult] = []

    def _resolve_device(self) -> "torch.device":
        import torch

        if self._device_str:
            return torch.device(self._device_str)
        return torch.device("cuda" if torch.cuda.is_available() else "cpu")

    def _get_training_config(self) -> "TrainingConfig":
        from core.training.universal_trainer import TrainingConfig

        device = self._resolve_device()

        if self.max_steps_override is not None:
            steps = self.max_steps_override
        elif self.budget_tier == "large":
            steps = 200  # shortened for testing; real large_budget is 6000
        else:
            steps = 20  # shortened small_budget

        return TrainingConfig(
            max_steps=steps,
            eval_interval=max(1, steps // 4),
            batch_size=self.batch_size,
            warmup_steps=min(5, steps // 4),
            lr_scheduler="cosine" if steps > 50 else "constant",
            max_val_batches=10,
            device=str(device),
        )

    def _build_datasets(self) -> Any:
        """Build ts-foundation data loaders."""
        from tasks.ts_foundation.task import TimeSeriesFoundationTask

        task = TimeSeriesFoundationTask()
        bundle = task.build_datasets({"batch_size": self.batch_size})
        return bundle

    def _train_single(
        self, model_code: str, job_id: str
    ) -> LocalTrainingResult:
        """Train a single candidate model locally."""
        import torch
        from tasks.ts_foundation.model_base import load_candidate_model
        from tasks.ts_foundation.metrics import (
            make_eval_fn,
            make_forward_fn,
            make_loss_fn,
        )
        from core.training.universal_trainer import train_model

        t0 = time.time()

        # Write code to temp file
        job_dir = Path(self.run_dir) / job_id
        job_dir.mkdir(parents=True, exist_ok=True)
        code_path = job_dir / "candidate.py"
        code_path.write_text(model_code, encoding="utf-8")

        try:
            # Build datasets (cached across calls in a real scenario)
            bundle = self._build_datasets()
            device = self._resolve_device()

            model = load_candidate_model(
                str(code_path),
                device,
                input_length=bundle.input_length,
                forecast_length=bundle.forecast_length,
            )

            config = self._get_training_config()

            ts_loss_fn = make_loss_fn()
            ts_forward_fn = make_forward_fn(bundle.forecast_length, bundle.input_length)
            mase_scale = getattr(bundle, "mase_scale", 1.0)
            ts_eval_fn = make_eval_fn(
                bundle.forecast_length,
                bundle.input_length,
                mase_scale,
                max_batches=10,
            )

            result = train_model(
                model=model,
                train_loader=bundle.train,
                loss_fn=ts_loss_fn,
                config=config,
                val_loader=bundle.val,
                eval_fn=ts_eval_fn,
                forward_fn=ts_forward_fn,
                run_dir=str(job_dir),
                eval_type=self.budget_tier,
            )

            wall_time = time.time() - t0
            metrics = result.metrics
            metrics.setdefault("steps_completed", result.steps_completed)

            return LocalTrainingResult(
                job_id=job_id,
                status="succeeded",
                metrics=metrics,
                wall_time_sec=wall_time,
                stdout_tail=f"Local training completed in {wall_time:.1f}s",
            )

        except Exception as e:
            wall_time = time.time() - t0
            logger.error("Local training failed for %s: %s", job_id, e, exc_info=True)
            return LocalTrainingResult(
                job_id=job_id,
                status="failed",
                metrics={"error": str(e)},
                wall_time_sec=wall_time,
                stdout_tail=f"Training failed: {e}",
            )

    async def train(self, spec: Any) -> LocalTrainingResult:
        """Train a single candidate (async interface matching mock client)."""
        import asyncio

        self._job_count += 1
        job_id = getattr(spec, "job_id", None) or uuid.uuid4().hex
        model_code = getattr(spec, "model_code_content", "") or ""

        # Run training in a thread to avoid blocking the event loop
        result = await asyncio.to_thread(self._train_single, model_code, job_id)
        self._job_history.append(result)
        return result

    async def batch_train_streams(
        self,
        model_codes: List[str],
        *,
        budget_tier: str = "small",
        timeout_sec: float = 3600,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> List[LocalTrainingResult]:
        """Train multiple models sequentially on the local machine.

        (Real Basilica would run them on CUDA streams concurrently;
         locally we just iterate.)
        """
        results: List[LocalTrainingResult] = []
        for code in model_codes:
            mock_spec = type("Spec", (), {
                "job_id": uuid.uuid4().hex,
                "model_code_content": code,
            })()
            result = await self.train(mock_spec)
            results.append(result)
        return results

    async def batch_train(
        self,
        specs: List[Any],
        *,
        max_concurrency: int = 1,
    ) -> List[LocalTrainingResult]:
        """Train each spec as a separate local job."""
        results = []
        for spec in specs:
            result = await self.train(spec)
            results.append(result)
        return results

    def get_job_count(self) -> int:
        return self._job_count

    def get_job_history(self) -> List[LocalTrainingResult]:
        return self._job_history.copy()
