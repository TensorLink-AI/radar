"""
Functional test harness for subnet validator - REAL component testing.

This harness tests the actual validator components with real PyTorch
model loading, FX validation, parameter counting, and scoring logic.

Only external infrastructure is mocked:
- Chain/metagraph (no Bittensor connection)
- affinetes pod deployment (no GPU cluster)
- HTTP calls to external services

Real components tested:
- Phase 2: load_candidate_model(), count_parameters(), measure_inference_latency()
- Phase 4: compute_weights() with EMA, penalties, softmax

Usage:
    # Quick test with mock filtering (no torch required)
    python -m test_subnet.harness --miners 5 --skip-eval

    # Full test with real filtering (requires torch)
    python -m test_subnet.harness --miners 5 --epochs 1

    # Submit your own miner code
    python -m test_subnet.harness --miners 0 --miner-code my_model.py --skip-eval
"""

from __future__ import annotations

import argparse
import asyncio
import json
import logging
import os
import sys
import tempfile
import time
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple
from unittest.mock import patch, MagicMock, AsyncMock

# Ensure project root is in path
project_root = Path(__file__).parent.parent
if str(project_root) not in sys.path:
    sys.path.insert(0, str(project_root))

from test_subnet.config import TestConfig, TestScenario
from test_subnet.mock_chain import (
    MockChainInterface,
    MockWallet,
    create_mock_commitments,
)
from test_subnet.mock_miners import (
    MockMinerFactory,
    load_miner_code_files,
    create_file_based_submissions,
)
from test_subnet.mock_basilica import (
    MockAffinetesModule,
    MockBasilicaTrainingClient,
    TrainingStatus,
)
from test_subnet.fixtures import (
    create_sample_challenge,
    verify_candidate_result,
    verify_weights,
    SAMPLE_PARENT_CONTEXT,
)
from test_subnet.live_agent import LiveMinerAgent
from test_subnet.local_training import LocalTrainingClient

from subnet.protocol.types import (
    Challenge,
    MinerCommitment,
    MinerSubmission,
    CandidateResult,
    EpochState,
    SubmissionStatus,
)
from subnet.validator.scoring import compute_weights

# Import miner_runner for challenge type selection
from subnet.validator.miner_runner import select_challenge_type

logger = logging.getLogger(__name__)


# ── Result tracking ──────────────────────────────────────────────────────


@dataclass
class PhaseMetrics:
    """Metrics from a single phase."""
    name: str
    duration_sec: float
    input_count: int
    output_count: int
    success: bool
    error: Optional[str] = None
    details: Dict[str, Any] = field(default_factory=dict)


@dataclass
class EpochResult:
    """Results from a single epoch."""

    epoch: int
    challenge_type: str
    n_commitments: int
    n_submissions: int
    n_filtered: int
    n_trained: int
    weights: Dict[int, float]
    ema_scores: Dict[int, float]
    duration_sec: float
    phase_metrics: Dict[str, PhaseMetrics] = field(default_factory=dict)
    errors: List[str] = field(default_factory=list)

    # Detailed results for verification
    filtering_results: List[Dict[str, Any]] = field(default_factory=list)
    training_results: List[Dict[str, Any]] = field(default_factory=list)


@dataclass
class TestResults:
    """Complete results from a test run."""

    config: TestConfig
    start_time: str
    end_time: str
    duration_sec: float
    epochs: List[EpochResult]
    final_weights: Dict[int, float]
    final_ema_scores: Dict[int, float]
    verification: Dict[str, Any]
    success: bool

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for serialization."""
        return {
            "config": self.config.to_dict(),
            "start_time": self.start_time,
            "end_time": self.end_time,
            "duration_sec": self.duration_sec,
            "n_epochs": len(self.epochs),
            "epochs": [
                {
                    "epoch": e.epoch,
                    "challenge_type": e.challenge_type,
                    "n_submissions": e.n_submissions,
                    "n_filtered": e.n_filtered,
                    "n_trained": e.n_trained,
                    "n_weights": len(e.weights),
                    "duration_sec": e.duration_sec,
                    "phase_metrics": {
                        k: {"duration": v.duration_sec, "success": v.success}
                        for k, v in e.phase_metrics.items()
                    },
                    "errors": e.errors,
                }
                for e in self.epochs
            ],
            "final_weights": self.final_weights,
            "verification": self.verification,
            "success": self.success,
        }

    def save(self, path: str) -> None:
        """Save results to JSON file."""
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        with open(path, "w") as f:
            json.dump(self.to_dict(), f, indent=2)


# ── Test Harness ─────────────────────────────────────────────────────────


class TestHarness:
    """Functional test harness for subnet validator.

    Tests real validator components:
    - Phase 2 (Filtering): Real model loading, FX validation, param counting
    - Phase 4 (Scoring): Real EMA, penalty, softmax computation

    Mocks only external infrastructure:
    - Chain/metagraph operations
    - affinetes pod deployment (af.load_env)
    - Remote training (optionally uses local training)
    """

    def __init__(self, config: Optional[TestConfig] = None):
        """Initialize test harness.

        Args:
            config: Test configuration. Uses defaults if None.
        """
        self.config = config or TestConfig()
        self._setup_mocks()

        # State tracking
        self.epoch = 0
        self.ema_scores: Dict[int, float] = {}
        self._epoch_results: List[EpochResult] = []

    def _setup_mocks(self) -> None:
        """Initialize all mock/live objects based on config."""
        # Load file-based miner code if paths provided
        self._file_based_code: list = []
        if self.config.miner_code_paths:
            self._file_based_code = load_miner_code_files(self.config.miner_code_paths)
            logger.info(
                "Loaded %d file-based miner submission(s)", len(self._file_based_code)
            )

        # ── Phase 1: Live LLM agent or mock miners ───────────────────
        self.live_agent: Optional[LiveMinerAgent] = None
        if self.config.live_evolve:
            self.live_agent = LiveMinerAgent(
                n_agents=self.config.live_evolve_agents,
                max_attempts=self.config.live_evolve_max_attempts,
                validate_runtime=self.config.live_evolve_validate_runtime,
            )
            logger.info(
                "Live evolve enabled: %d LLM agents per epoch",
                self.config.live_evolve_agents,
            )

        # Create miner factory for generated mock miners (may have 0 miners)
        self.miner_factory = MockMinerFactory(
            n_miners=self.config.n_miners,
            success_rate=self.config.miner_success_rate,
            quality_distribution=self.config.quality_distribution,
            seed=self.config.random_seed,
            use_scaffold=not self.config.use_minimal_models,
        )

        # Create mock chain with commitments for all sources
        commitments = self.miner_factory.get_commitments()

        # Add commitments for live agents
        if self.live_agent:
            live_commitments = self.live_agent.get_commitments()
            # Shift UIDs to avoid collisions with mock miners
            live_uid_offset = self.config.n_miners
            for c in live_commitments:
                commitments.append(
                    MinerCommitment(
                        hotkey=c.hotkey,
                        uid=live_uid_offset + c.uid,
                        docker_image=c.docker_image,
                        metadata=c.metadata,
                        block_committed=c.block_committed,
                    )
                )

        # Add commitments for file-based miners
        file_uid_offset = self.config.n_miners + (
            self.config.live_evolve_agents if self.config.live_evolve else 0
        )
        for i, entry in enumerate(self._file_based_code):
            uid = file_uid_offset + i
            hotkey = f"5FileMiner{uid:03d}000000000000000000000000000000"[:48]
            commitments.append(
                MinerCommitment(
                    hotkey=hotkey,
                    uid=uid,
                    docker_image=f"file/{entry['name']}:latest",
                    metadata={"source": "file", "path": entry["path"]},
                    block_committed=1000000 + uid,
                )
            )

        total_miners = len(commitments)
        self.mock_chain = MockChainInterface(
            commitments=commitments,
            n_uids=max(256, total_miners + 10),
        )

        # ── Phase 3: Local training or mock training ─────────────────
        self.local_training_client: Optional[LocalTrainingClient] = None
        if self.config.local_training:
            self.local_training_client = LocalTrainingClient(
                budget_tier=self.config.local_training_budget,
                device=self.config.local_training_device,
                max_steps_override=self.config.local_training_max_steps,
                batch_size=self.config.local_training_batch_size,
            )
            logger.info(
                "Local training enabled: budget=%s, device=%s",
                self.config.local_training_budget,
                self.config.local_training_device or "auto",
            )

        # Create mock affinetes module and (possibly mock) training client
        self.mock_af = MockAffinetesModule()
        self.mock_basilica_training = MockBasilicaTrainingClient(
            base_loss=self.config.base_test_loss,
            loss_variance=self.config.loss_variance,
            failure_rate=self.config.training_failure_rate,
            train_duration_sec=0.01,
        )

    def run(self) -> TestResults:
        """Run the full test harness.

        Executes n_epochs epochs of the validator pipeline.

        Returns:
            TestResults with complete test run data.
        """
        start_time = datetime.now()
        logger.info(
            "Starting test harness: %s (scenario=%s, miners=%d, epochs=%d)",
            self.config.test_name,
            self.config.scenario.value,
            self.config.n_miners,
            self.config.n_epochs,
        )

        try:
            for epoch_num in range(self.config.n_epochs):
                self.epoch = epoch_num
                epoch_result = asyncio.run(self._run_epoch())
                self._epoch_results.append(epoch_result)

                logger.info(
                    "[Epoch %d] Complete: %d submissions -> %d filtered -> %d trained",
                    epoch_num,
                    epoch_result.n_submissions,
                    epoch_result.n_filtered,
                    epoch_result.n_trained,
                )

                if self.config.epoch_duration_sec > 0 and epoch_num < self.config.n_epochs - 1:
                    time.sleep(self.config.epoch_duration_sec)

            success = True

        except Exception as e:
            logger.exception("Test harness failed")
            success = False

        end_time = datetime.now()
        duration = (end_time - start_time).total_seconds()

        verification = self._verify_results()

        results = TestResults(
            config=self.config,
            start_time=start_time.isoformat(),
            end_time=end_time.isoformat(),
            duration_sec=duration,
            epochs=self._epoch_results,
            final_weights=self._epoch_results[-1].weights if self._epoch_results else {},
            final_ema_scores=self.ema_scores.copy(),
            verification=verification,
            success=success and verification.get("all_passed", False),
        )

        logger.info(
            "Test harness complete: success=%s, duration=%.2fs",
            results.success, duration,
        )
        return results

    async def _run_epoch(self) -> EpochResult:
        """Run a single epoch of the validator pipeline."""
        epoch_start = time.time()
        phase_metrics: Dict[str, PhaseMetrics] = {}
        errors: List[str] = []

        # Pre-phase: Select challenge type
        challenge_type = select_challenge_type(self.epoch)

        # Create challenge
        challenge = create_sample_challenge(
            epoch=self.epoch,
            challenge_type=challenge_type,
            context=self.config.mock_context or SAMPLE_PARENT_CONTEXT,
            constraints=self.config.get_constraints(),
        )

        # ── Phase 1: Generation (live agents + mocked + file-based) ──────
        phase_start = time.time()
        commitments = self.mock_chain.read_commitments()
        submissions = []

        # 1a. Mock miner submissions (if any)
        if self.config.n_miners > 0:
            mock_subs = self.miner_factory.generate_submissions(challenge)
            submissions.extend(mock_subs)
            logger.info(
                "[Epoch %d] Generated %d mock submission(s)",
                self.epoch, len(mock_subs),
            )

        # 1b. Live LLM agent submissions (if enabled)
        if self.live_agent:
            live_subs = await self.live_agent.generate_submissions(challenge)
            # Shift UIDs to match commitments
            live_uid_offset = self.config.n_miners
            for sub in live_subs:
                sub.uid = live_uid_offset + sub.uid
            submissions.extend(live_subs)
            logger.info(
                "[Epoch %d] Generated %d live-evolved submission(s)",
                self.epoch, len(live_subs),
            )

        # 1c. File-based submissions (if any)
        if self._file_based_code:
            file_uid_offset = self.config.n_miners + (
                self.config.live_evolve_agents if self.config.live_evolve else 0
            )
            file_submissions = create_file_based_submissions(
                self._file_based_code,
                challenge,
                uid_offset=file_uid_offset,
            )
            submissions.extend(file_submissions)
            logger.info(
                "[Epoch %d] Added %d file-based submission(s)",
                self.epoch, len(file_submissions),
            )

        successful_submissions = [
            s for s in submissions if s.status == SubmissionStatus.SUCCEEDED
        ]

        phase_metrics["generation"] = PhaseMetrics(
            name="generation",
            duration_sec=time.time() - phase_start,
            input_count=len(commitments),
            output_count=len(successful_submissions),
            success=True,
        )

        logger.debug(
            "[Epoch %d] Phase 1: %d/%d submissions succeeded",
            self.epoch, len(successful_submissions), len(commitments),
        )

        if not successful_submissions:
            logger.warning("[Epoch %d] No successful submissions", self.epoch)
            return EpochResult(
                epoch=self.epoch,
                challenge_type=challenge_type,
                n_commitments=len(commitments),
                n_submissions=0,
                n_filtered=0,
                n_trained=0,
                weights={},
                ema_scores=self.ema_scores.copy(),
                duration_sec=time.time() - epoch_start,
                phase_metrics=phase_metrics,
                errors=["No successful submissions"],
            )

        # ── Phase 2: Filtering (REAL or mocked) ──────────────────────────
        phase_start = time.time()
        filtering_results: List[Dict[str, Any]] = []

        if self.config.skip_zero_cost_eval:
            # Mock filtering - no torch required
            filtered_results = self._mock_filtering(successful_submissions)
        else:
            # REAL filtering -- configure SubnetConfig for Basilica vs local
            if self.config.basilica_proxy:
                self._configure_subnet_for_basilica_proxy()
            else:
                self._configure_subnet_for_local_proxy()
            filtered_results = await self._run_real_filtering(
                successful_submissions,
                self.config.get_constraints()
            )

        # Collect filtering metrics for verification
        for r in filtered_results:
            filtering_results.append({
                "uid": r.uid,
                "name": r.name,
                "zero_cost_score": r.zero_cost_score,
                "param_count": r.param_count,
                "inference_latency_ms": r.inference_latency_ms,
                "constraints_satisfied": r.constraints_satisfied,
            })

        # Apply top-K cutoff
        filtered_results = filtered_results[: self.config.zero_cost_top_k]

        filtering_mode = "mock"
        if not self.config.skip_zero_cost_eval:
            filtering_mode = "basilica" if self.config.basilica_proxy else "local"

        phase_metrics["filtering"] = PhaseMetrics(
            name="filtering",
            duration_sec=time.time() - phase_start,
            input_count=len(successful_submissions),
            output_count=len(filtered_results),
            success=True,
            details={
                "mode": filtering_mode,
                "top_k": self.config.zero_cost_top_k,
            },
        )

        logger.debug(
            "[Epoch %d] Phase 2: %d -> %d candidates (real=%s)",
            self.epoch, len(successful_submissions), len(filtered_results),
            not self.config.skip_zero_cost_eval,
        )

        if not filtered_results:
            logger.warning("[Epoch %d] No candidates passed filtering", self.epoch)
            return EpochResult(
                epoch=self.epoch,
                challenge_type=challenge_type,
                n_commitments=len(commitments),
                n_submissions=len(successful_submissions),
                n_filtered=0,
                n_trained=0,
                weights={},
                ema_scores=self.ema_scores.copy(),
                duration_sec=time.time() - epoch_start,
                phase_metrics=phase_metrics,
                errors=["No candidates passed filtering"],
                filtering_results=filtering_results,
            )

        # ── Phase 3: Training (mock / local / basilica / remote-mock) ─────
        phase_start = time.time()
        training_results: List[Dict[str, Any]] = []

        if self.config.skip_deep_training:
            trained_results = self._mock_training(filtered_results)
        elif self.config.basilica_training:
            trained_results = await self._run_basilica_training(filtered_results)
        elif self.config.local_training and self.local_training_client:
            trained_results = await self._run_local_training(filtered_results)
        else:
            trained_results = await self._run_training_with_mocks(filtered_results)

        # Collect training metrics
        for r in trained_results:
            training_results.append({
                "uid": r.uid,
                "name": r.name,
                "train_loss": r.train_loss,
                "test_loss": r.test_loss,
            })

        # Apply top-L cutoff
        trained_results.sort(
            key=lambda r: r.test_loss if r.test_loss is not None else float("inf")
        )
        finalists = trained_results[: self.config.deep_train_top_l]

        training_mode = "mock"
        if self.config.basilica_training:
            training_mode = "basilica"
        elif self.config.local_training:
            training_mode = "local"
        elif not self.config.skip_deep_training:
            training_mode = "remote_mock"

        phase_metrics["training"] = PhaseMetrics(
            name="training",
            duration_sec=time.time() - phase_start,
            input_count=len(filtered_results),
            output_count=len(finalists),
            success=True,
            details={
                "mode": training_mode,
                "top_l": self.config.deep_train_top_l,
            },
        )

        logger.debug(
            "[Epoch %d] Phase 3: %d -> %d finalists",
            self.epoch, len(filtered_results), len(finalists),
        )

        # ── Phase 4: Scoring (REAL) ──────────────────────────────────────
        phase_start = time.time()

        # REAL scoring - compute_weights is a pure function
        weights = compute_weights(
            results=finalists,
            ema_scores=self.ema_scores,
        )

        phase_metrics["scoring"] = PhaseMetrics(
            name="scoring",
            duration_sec=time.time() - phase_start,
            input_count=len(finalists),
            output_count=len(weights),
            success=True,
            details={
                "ema_alpha": self.config.ema_alpha,
            },
        )

        # Record weight submission
        if weights:
            uid_list = list(weights.keys())
            weight_list = list(weights.values())
            self.mock_chain.set_weights(uid_list, weight_list)

        logger.debug(
            "[Epoch %d] Phase 4: Weights computed for %d UIDs",
            self.epoch, len(weights),
        )

        return EpochResult(
            epoch=self.epoch,
            challenge_type=challenge_type,
            n_commitments=len(commitments),
            n_submissions=len(successful_submissions),
            n_filtered=len(filtered_results),
            n_trained=len(finalists),
            weights=weights,
            ema_scores=self.ema_scores.copy(),
            duration_sec=time.time() - epoch_start,
            phase_metrics=phase_metrics,
            errors=errors,
            filtering_results=filtering_results,
            training_results=training_results,
        )

    async def _run_real_filtering(
        self,
        submissions: List[MinerSubmission],
        constraints: Dict[str, Any],
    ) -> List[CandidateResult]:
        """Run REAL filtering with actual model loading.

        This actually:
        - Writes model code to temp files
        - Loads models via load_candidate_model() (FX validation)
        - Counts parameters
        - Measures inference latency
        """
        from subnet.validator.filtering import run_filtering_phase

        # Run real filtering - this calls _zero_cost_eval which does
        # actual PyTorch model loading and measurement
        return await run_filtering_phase(submissions, constraints)

    def _mock_filtering(
        self, submissions: List[MinerSubmission]
    ) -> List[CandidateResult]:
        """Create mock filtering results without real evaluation."""
        import random
        rng = random.Random(self.config.random_seed)

        results = []
        for sub in submissions:
            quality = sub.metadata.get("quality", 0.5)
            score = quality + rng.gauss(0, 0.1)
            score = max(0.0, min(1.0, score))

            result = CandidateResult(
                hotkey=sub.hotkey,
                uid=sub.uid,
                name=sub.name,
                motivation=sub.motivation,
                model_code=sub.model_code,
                parent_id=sub.parent_id,
                config=sub.config,
                model_diff=sub.model_diff,
                zero_cost_score=score,
                zero_cost_details={"mock": True, "quality": quality},
                param_count=int(5_000_000 * (1 + quality)),
                inference_latency_ms=20.0 + quality * 10,
                constraints_satisfied=True,
            )
            results.append(result)

        results.sort(key=lambda r: r.zero_cost_score or 0, reverse=True)
        return results

    def _mock_training(
        self, candidates: List[CandidateResult]
    ) -> List[CandidateResult]:
        """Create mock training results without real training."""
        import random
        rng = random.Random(self.config.random_seed + self.epoch)

        for candidate in candidates:
            quality = candidate.zero_cost_details.get("quality", 0.5)

            base_loss = self.config.base_test_loss
            test_loss = base_loss + (1.0 - quality) * 0.3 + rng.gauss(0, self.config.loss_variance)
            train_loss = test_loss * 0.9

            candidate.train_loss = max(0.01, train_loss)
            candidate.test_loss = max(0.01, test_loss)
            candidate.train_metrics = {
                "train_loss": candidate.train_loss,
                "test_loss": candidate.test_loss,
                "epochs": 10,
            }

        return candidates

    async def _run_training_with_mocks(
        self, candidates: List[CandidateResult]
    ) -> List[CandidateResult]:
        """Run training phase with mock Basilica client."""
        # Patch the training client builder to return our mock
        with patch("subnet.validator.training._build_training_client") as mock_builder:
            mock_builder.return_value = self.mock_basilica_training

            from subnet.validator.training import run_training_phase
            return await run_training_phase(candidates)

    async def _run_local_training(
        self, candidates: List[CandidateResult]
    ) -> List[CandidateResult]:
        """Train candidates locally using the universal trainer.

        This actually trains each model on real data, producing real
        loss metrics instead of synthetic ones.
        """
        assert self.local_training_client is not None

        for candidate in candidates:
            logger.info(
                "[Epoch %d] Local training: uid=%d name=%s",
                self.epoch, candidate.uid, candidate.name,
            )
            mock_spec = type("Spec", (), {
                "job_id": f"local_{candidate.uid}_{self.epoch}",
                "model_code_content": candidate.model_code,
            })()

            result = await self.local_training_client.train(mock_spec)

            if result.status == "succeeded":
                candidate.train_loss = result.metrics.get("train_loss")
                candidate.test_loss = result.metrics.get("test_loss")
                candidate.train_metrics = result.metrics
                logger.info(
                    "[Epoch %d] Local training succeeded: uid=%d test_loss=%.4f (%.1fs)",
                    self.epoch,
                    candidate.uid,
                    candidate.test_loss or float("nan"),
                    result.wall_time_sec,
                )
            else:
                # Training failed — assign worst-case loss
                candidate.train_loss = float("inf")
                candidate.test_loss = float("inf")
                candidate.train_metrics = result.metrics
                logger.warning(
                    "[Epoch %d] Local training FAILED: uid=%d error=%s",
                    self.epoch, candidate.uid, result.metrics.get("error", "?"),
                )

        return candidates

    async def _run_basilica_training(
        self, candidates: List[CandidateResult]
    ) -> List[CandidateResult]:
        """Train candidates on real Basilica GPU pods.

        Calls the real ``run_training_phase`` from ``subnet.validator.training``
        without mocking the training client.  Requires ``BASILICA_API_TOKEN``
        and ``DEEP_TRAIN_IMAGE`` environment variables.
        """
        from subnet.validator.training import run_training_phase

        logger.info(
            "[Epoch %d] Basilica training: %d candidates",
            self.epoch, len(candidates),
        )
        return await run_training_phase(candidates)

    # ── SubnetConfig helpers for proxy eval mode ──────────────────────

    @staticmethod
    def _configure_subnet_for_basilica_proxy() -> None:
        """Set SubnetConfig to dispatch proxy eval to a Basilica pod.

        Validates that the required env vars are present.
        """
        from subnet.config import SubnetConfig

        SubnetConfig.PROXY_EVAL_LOCAL = False

        if not SubnetConfig.PROXY_EVAL_IMAGE:
            raise RuntimeError(
                "Basilica proxy eval requires PROXY_EVAL_IMAGE (or DEEP_TRAIN_IMAGE) "
                "env var pointing to the trusted Docker image."
            )
        if not SubnetConfig.BASILICA_API_TOKEN:
            raise RuntimeError(
                "Basilica proxy eval requires BASILICA_API_TOKEN env var."
            )

        logger.info(
            "Proxy eval configured for Basilica: image=%s",
            SubnetConfig.PROXY_EVAL_IMAGE,
        )

    @staticmethod
    def _configure_subnet_for_local_proxy() -> None:
        """Set SubnetConfig to run proxy eval on local CPU."""
        from subnet.config import SubnetConfig
        SubnetConfig.PROXY_EVAL_LOCAL = True

    def _verify_results(self) -> Dict[str, Any]:
        """Verify test results meet expectations."""
        checks = {}

        # Check epoch count
        checks["epoch_count"] = {
            "expected": self.config.n_epochs,
            "actual": len(self._epoch_results),
            "passed": len(self._epoch_results) == self.config.n_epochs,
        }

        # Check weights were computed
        if self._epoch_results:
            last_epoch = self._epoch_results[-1]
            checks["weights_computed"] = {
                "n_weights": len(last_epoch.weights),
                "passed": len(last_epoch.weights) > 0 or self.config.miner_success_rate == 0,
            }

            # Verify weight normalization
            if last_epoch.weights:
                weight_verify = verify_weights(last_epoch.weights)
                checks["weights_valid"] = {
                    "issues": weight_verify["issues"],
                    "passed": weight_verify["valid"],
                }
            else:
                checks["weights_valid"] = {"passed": True, "note": "No weights to verify"}

            # Verify filtering ran correctly
            if not self.config.skip_zero_cost_eval:
                checks["real_filtering"] = {
                    "ran": True,
                    "results_count": len(last_epoch.filtering_results),
                    "passed": len(last_epoch.filtering_results) > 0,
                }

        # Check chain submissions
        chain_submissions = self.mock_chain.get_submitted_weights()
        expected_submissions = sum(1 for e in self._epoch_results if e.n_trained > 0)
        checks["chain_submissions"] = {
            "count": len(chain_submissions),
            "expected": expected_submissions,
            "passed": len(chain_submissions) == expected_submissions,
        }

        checks["all_passed"] = all(c.get("passed", True) for c in checks.values())

        return checks


# ── CLI ──────────────────────────────────────────────────────────────────


def main():
    """Command-line entry point."""
    parser = argparse.ArgumentParser(
        description="Run subnet functional tests with REAL component testing",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )

    parser.add_argument("--miners", "-m", type=int, default=5, help="Number of mock miners")
    parser.add_argument("--epochs", "-e", type=int, default=1, help="Number of epochs to run")
    parser.add_argument(
        "--scenario", "-s",
        type=str,
        choices=[s.value for s in TestScenario],
        default="happy_path",
        help="Test scenario to run",
    )
    parser.add_argument("--success-rate", type=float, default=1.0, help="Miner success rate (0.0-1.0)")
    parser.add_argument("--skip-eval", action="store_true", help="Skip real zero-cost evaluation (mock instead)")
    parser.add_argument("--skip-training", action="store_true", help="Skip real training (mock instead)")
    parser.add_argument(
        "--miner-code", type=str, action="append", default=[],
        help="Path to a .py file to submit as a miner (repeatable)",
    )
    parser.add_argument(
        "--miner-dir", type=str, action="append", default=[],
        help="Path to a directory of .py files to submit as miners (repeatable)",
    )

    # Live testing options
    live_group = parser.add_argument_group("live testing", "Options for partially-live testing")
    live_group.add_argument(
        "--live-evolve", action="store_true",
        help="Use real LLM (Chutes) to evolve models (requires CHUTES_API_KEY + MODEL_NAME)",
    )
    live_group.add_argument(
        "--live-agents", type=int, default=3,
        help="Number of LLM agents for live evolution (default: 3)",
    )
    live_group.add_argument(
        "--local-training", action="store_true",
        help="Train models locally using universal_trainer (requires torch)",
    )
    live_group.add_argument(
        "--training-steps", type=int, default=None,
        help="Override training step count for local training",
    )
    live_group.add_argument(
        "--training-device", type=str, default=None,
        help="Device for local training: cpu, cuda (default: auto-detect)",
    )

    # Basilica (remote GPU) options
    basilica_group = parser.add_argument_group(
        "basilica", "Options for real remote GPU testing via Basilica"
    )
    basilica_group.add_argument(
        "--basilica-proxy", action="store_true",
        help="Run zero-cost proxy eval on a real Basilica GPU pod "
             "(requires BASILICA_API_TOKEN + DEEP_TRAIN_IMAGE)",
    )
    basilica_group.add_argument(
        "--basilica-training", action="store_true",
        help="Run deep training on real Basilica GPU pods "
             "(requires BASILICA_API_TOKEN + DEEP_TRAIN_IMAGE)",
    )

    parser.add_argument("--output", "-o", type=str, help="Output file for results JSON")
    parser.add_argument("--verbose", "-v", action="store_true", help="Verbose logging")
    parser.add_argument("--seed", type=int, default=42, help="Random seed for reproducibility")

    args = parser.parse_args()

    log_level = logging.DEBUG if args.verbose else logging.INFO
    logging.basicConfig(
        level=log_level,
        format="%(asctime)s %(name)s %(levelname)s %(message)s",
    )

    # Collect miner code paths from --miner-code and --miner-dir
    miner_code_paths = list(args.miner_code) + list(args.miner_dir)

    config = TestConfig(
        n_miners=args.miners,
        n_epochs=args.epochs,
        scenario=TestScenario(args.scenario),
        miner_success_rate=args.success_rate,
        skip_zero_cost_eval=args.skip_eval,
        skip_deep_training=args.skip_training,
        miner_code_paths=miner_code_paths,
        random_seed=args.seed,
        verbose=args.verbose,
        # Live testing options
        live_evolve=args.live_evolve,
        live_evolve_agents=args.live_agents,
        local_training=args.local_training,
        local_training_max_steps=args.training_steps,
        local_training_device=args.training_device,
        # Basilica options
        basilica_proxy=args.basilica_proxy,
        basilica_training=args.basilica_training,
    )

    harness = TestHarness(config)
    results = harness.run()

    print("\n" + "=" * 60)
    print("TEST RESULTS")
    print("=" * 60)
    print(f"Success: {results.success}")
    print(f"Duration: {results.duration_sec:.2f}s")
    print(f"Epochs: {len(results.epochs)}")
    if config.live_evolve:
        print(f"Live evolve: {config.live_evolve_agents} LLM agents")
    if config.basilica_proxy:
        print("Proxy eval: Basilica GPU pod")
    if config.basilica_training:
        print("Training: Basilica GPU pods")
    elif config.local_training:
        print(f"Local training: budget={config.local_training_budget}, steps={config.local_training_max_steps or 'default'}")
    if miner_code_paths:
        print(f"File-based miners: {len(miner_code_paths)} path(s)")

    for epoch in results.epochs:
        print(f"\n  Epoch {epoch.epoch}:")
        print(f"    Challenge: {epoch.challenge_type}")
        print(f"    Submissions: {epoch.n_submissions}")
        print(f"    Filtered: {epoch.n_filtered}")
        print(f"    Trained: {epoch.n_trained}")
        print(f"    Weights: {len(epoch.weights)}")

        # Show phase metrics
        for phase_name, metrics in epoch.phase_metrics.items():
            print(f"    {phase_name}: {metrics.duration_sec:.3f}s, {metrics.input_count}->{metrics.output_count}")

        if epoch.errors:
            print(f"    Errors: {epoch.errors}")

    print(f"\nVerification: {results.verification}")

    if results.final_weights:
        print(f"\nFinal weights ({len(results.final_weights)} UIDs):")
        for uid, weight in sorted(results.final_weights.items(), key=lambda x: -x[1])[:5]:
            print(f"  UID {uid}: {weight:.4f}")

    if args.output:
        results.save(args.output)
        print(f"\nResults saved to: {args.output}")

    sys.exit(0 if results.success else 1)


if __name__ == "__main__":
    main()
