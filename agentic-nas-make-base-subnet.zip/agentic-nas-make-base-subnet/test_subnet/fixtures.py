"""
Test fixtures for subnet functional testing.

Provides sample data and factory functions for creating
test objects used across the test harness.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, List, Optional

from subnet.protocol.types import (
    Challenge,
    MinerCommitment,
    MinerSubmission,
    CandidateResult,
    SubmissionStatus,
)


# ── Sample parent context ────────────────────────────────────────────────

SAMPLE_PARENT_CONTEXT = """
# EXPERIMENTAL EVIDENCE PORTFOLIO

## Parent: DecoderOnlyTSFM_v1
- Architecture: 6-layer decoder-only transformer with learned position embeddings
- Motivation: Baseline decoder-only architecture for time-series forecasting
- Result: {"train_loss": 0.45, "test_loss": 0.52, "param_count": 8500000}

## Reference: WaveletMamba_v2
- Architecture: Wavelet decomposition + Mamba SSM backbone
- Motivation: Multi-scale frequency decomposition for capturing periodic patterns
- Result: {"train_loss": 0.38, "test_loss": 0.48, "param_count": 6200000}

## Reference: SparseAttentionTSFM_v1
- Architecture: Sparse attention patterns for long-range dependencies
- Motivation: Efficient attention for very long sequences (>1024 tokens)
- Result: {"train_loss": 0.42, "test_loss": 0.50, "param_count": 7100000}

## Task Focus Areas (hints for exploration)
The task evaluates models on quantile loss across multiple time-series datasets.
Models are scored purely on test_loss - lower is better.
"""


# ── Sample task definition ───────────────────────────────────────────────

def get_sample_task_definition() -> Dict[str, Any]:
    """Return a sample TaskDefinition dict for testing."""
    return {
        "name": "time_series_foundation",
        "description": (
            "Time-series forecasting task using quantile regression. "
            "Models must predict future values given historical observations."
        ),
        "hf_repo_id": "tensorlink-dev/time-series-six-datasets",
        "primary_metric": "quantile_loss",
        "direction": "minimize",
        "max_params": 10_000_000,
        "budgets": {
            "zero_cost": {"max_epochs": 0, "timeout_sec": 60},
            "small_budget": {"max_epochs": 10, "timeout_sec": 3600},
            "large_budget": {"max_epochs": 50, "timeout_sec": 14400},
        },
        "model_contract": {
            "base_class": "TimeSeriesFoundationModel",
            "required_methods": ["forward", "generate", "from_config", "to_config"],
            "input_signature": {
                "past_y": "[B, T, C_y]",
                "past_cov": "[B, T, C_p] or None",
                "future_cov": "[B, H, C_f] or None",
                "static": "[B, C_s] or None",
                "y_future_tf": "[B, H, C_y] or None",
            },
            "output_signature": {
                "quantiles": "[B, H, Q]",
                "quantile_levels": "[Q]",
            },
        },
        # Focus areas are hints for miners, NOT separate scoring dimensions.
        # All models are scored on the same task metrics (test_loss).
        "focus_areas": [
            {
                "id": "long_range",
                "name": "Long-Range Dependencies",
                "description": "Capture dependencies across 512+ timesteps",
            },
            {
                "id": "multi_scale",
                "name": "Multi-Scale Frequency",
                "description": "Handle multiple periodic patterns simultaneously",
            },
            {
                "id": "non_stationary",
                "name": "Non-Stationary Series",
                "description": "Adapt to distribution shifts and trends",
            },
            {
                "id": "efficiency",
                "name": "Efficiency",
                "description": "Minimize parameter count while maintaining quality",
            },
        ],
    }


# ── Challenge factory ────────────────────────────────────────────────────

def create_sample_challenge(
    epoch: int = 0,
    challenge_type: str = "long_range",
    db_snapshot_url: str = "https://r2.example.com/db-snapshot.tar.gz",
    context: Optional[str] = None,
    constraints: Optional[Dict[str, Any]] = None,
) -> Challenge:
    """Create a sample Challenge object for testing.

    Note: challenge_type is just a hint for miners about what aspect to
    focus on. Scoring is always based on task-level metrics (test_loss),
    NOT per-challenge-type metrics.

    Args:
        epoch: Epoch number.
        challenge_type: Focus area hint for miners (not a scoring dimension).
        db_snapshot_url: R2 URL for the experiment DB snapshot.
        context: Experimental evidence context.
        constraints: Hard constraints (max_params, latency) for filtering.

    Returns:
        Challenge object.
    """
    if constraints is None:
        constraints = {
            "max_params": 10_000_000,
            "max_inference_latency_ms": 50.0,
            "required_quantile_levels": [0.1, 0.5, 0.9],
        }

    # Load scaffold code for reference
    scaffold_code: Optional[str] = None
    scaffold_path = Path(__file__).parent.parent / "scaffolds" / "ts_base_model.py"
    if scaffold_path.exists():
        scaffold_code = scaffold_path.read_text()

    return Challenge(
        task_name="time_series_foundation",
        challenge_type=challenge_type,
        constraints=constraints,
        db_snapshot_url=db_snapshot_url,
        context=context or SAMPLE_PARENT_CONTEXT,
        task_definition=get_sample_task_definition(),
        scaffold_code=scaffold_code,
        epoch=epoch,
    )


# ── Mock database responses ──────────────────────────────────────────────

def get_mock_db_parent_response() -> List[Dict[str, Any]]:
    """Return mock response for parent sampling from DB."""
    return [
        {
            "index": 1,
            "name": "DecoderOnlyTSFM_v1",
            "motivation": "Baseline decoder-only architecture",
            "result": {"train_loss": 0.45, "test_loss": 0.52},
            "program": "# Scaffold code here...",
            "rank": 1,
        }
    ]


def get_mock_db_reference_response() -> List[Dict[str, Any]]:
    """Return mock response for reference sampling from DB."""
    return [
        {
            "index": 2,
            "name": "WaveletMamba_v2",
            "motivation": "Multi-scale wavelet decomposition",
            "result": {"train_loss": 0.38, "test_loss": 0.48},
            "program": "# Reference code...",
            "rank": 15,
        },
        {
            "index": 3,
            "name": "SparseAttentionTSFM_v1",
            "motivation": "Sparse attention for efficiency",
            "result": {"train_loss": 0.42, "test_loss": 0.50},
            "program": "# Reference code...",
            "rank": 22,
        },
    ]


# ── Result verification ──────────────────────────────────────────────────

def verify_candidate_result(
    result: CandidateResult,
    expect_valid: bool = True,
) -> Dict[str, Any]:
    """Verify a CandidateResult meets basic expectations.

    Args:
        result: The CandidateResult to verify.
        expect_valid: Whether we expect the result to be valid.

    Returns:
        Dict with verification results and any issues found.
    """
    issues = []

    # Check required fields
    if not result.hotkey:
        issues.append("Missing hotkey")
    if result.uid < 0:
        issues.append(f"Invalid UID: {result.uid}")
    if not result.model_code and expect_valid:
        issues.append("Missing model_code")

    # Check zero-cost results if populated
    if result.zero_cost_score is not None:
        if not (0.0 <= result.zero_cost_score <= 1.0):
            issues.append(f"Invalid zero_cost_score: {result.zero_cost_score}")

    # Check constraint satisfaction
    if expect_valid and not result.constraints_satisfied:
        issues.append("Constraints not satisfied")

    # Check training results if populated
    if result.test_loss is not None:
        if result.test_loss < 0:
            issues.append(f"Invalid test_loss: {result.test_loss}")

    return {
        "valid": len(issues) == 0,
        "issues": issues,
        "result_summary": {
            "uid": result.uid,
            "name": result.name,
            "zero_cost_score": result.zero_cost_score,
            "test_loss": result.test_loss,
            "constraints_satisfied": result.constraints_satisfied,
        },
    }


def verify_weights(
    weights: Dict[int, float],
    expected_uids: Optional[List[int]] = None,
) -> Dict[str, Any]:
    """Verify computed weights meet requirements.

    Args:
        weights: Dict mapping UID -> weight.
        expected_uids: Optional list of UIDs that should have weights.

    Returns:
        Dict with verification results.
    """
    issues = []

    # Check weights sum to ~1.0
    total = sum(weights.values())
    if abs(total - 1.0) > 0.001:
        issues.append(f"Weights sum to {total}, expected 1.0")

    # Check all weights are non-negative
    for uid, w in weights.items():
        if w < 0:
            issues.append(f"Negative weight for UID {uid}: {w}")

    # Check expected UIDs if provided
    if expected_uids:
        missing = set(expected_uids) - set(weights.keys())
        if missing:
            issues.append(f"Missing weights for UIDs: {missing}")

    return {
        "valid": len(issues) == 0,
        "issues": issues,
        "weight_summary": {
            "n_uids": len(weights),
            "total": total,
            "max_weight": max(weights.values()) if weights else 0,
            "min_weight": min(weights.values()) if weights else 0,
        },
    }
