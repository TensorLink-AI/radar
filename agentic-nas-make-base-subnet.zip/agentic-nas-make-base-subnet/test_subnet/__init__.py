"""
Functional test harness for subnet validator.

This package provides mock implementations and live components for testing
the subnet validator pipeline at varying levels of realism:

- **Full mock** (default): All components mocked, no external deps
- **Live evolve** (``--live-evolve``): Real LLM generates model code
- **Local training** (``--local-training``): Real training on local hardware
- **File-based**: Submit your own .py model files for evaluation

Usage:
    # Full mock (fast)
    python -m test_subnet.harness --miners 5 --epochs 2

    # Live LLM evolution with mock training
    python -m test_subnet.harness --live-evolve --live-agents 3 --skip-training

    # Full live: LLM evolution + local training
    python -m test_subnet.harness --live-evolve --local-training --training-steps 20
"""

from test_subnet.mock_chain import MockChainInterface, MockMetagraph, MockWallet
from test_subnet.mock_miners import (
    MockMinerFactory,
    generate_mock_submissions,
    load_miner_code_files,
    create_file_based_submissions,
)
from test_subnet.mock_basilica import (
    MockAffinetesEnv,
    MockAffinetesModule,
    mock_load_env,
    MockBasilicaTrainingClient,
)
from test_subnet.config import TestConfig
from test_subnet.live_agent import LiveMinerAgent
from test_subnet.local_training import LocalTrainingClient

__all__ = [
    "MockChainInterface",
    "MockMetagraph",
    "MockWallet",
    "MockMinerFactory",
    "generate_mock_submissions",
    "load_miner_code_files",
    "create_file_based_submissions",
    "MockAffinetesEnv",
    "MockAffinetesModule",
    "mock_load_env",
    "MockBasilicaTrainingClient",
    "TestConfig",
    "LiveMinerAgent",
    "LocalTrainingClient",
]
