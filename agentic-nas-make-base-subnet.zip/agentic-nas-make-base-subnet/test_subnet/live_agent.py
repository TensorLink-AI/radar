"""
Live miner agent for partially-live subnet testing.

Uses an LLM (via Chutes) to evolve model code, just like a real miner
would.  This replaces the mechanical scaffold-variation approach of
``MockMinerFactory`` when ``--live-evolve`` is passed to the harness.

The evolution logic is a condensed version of
``tests/test_subnet/miner_server.py`` adapted for in-process use.

Requirements:
    CHUTES_API_KEY and MODEL_NAME environment variables must be set.
"""

from __future__ import annotations

import ast
import difflib
import logging
import os
import tempfile
import traceback
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from subnet.protocol.types import (
    Challenge,
    MinerCommitment,
    MinerSubmission,
    SubmissionStatus,
)

logger = logging.getLogger(__name__)

# ── Evolution system prompt ──────────────────────────────────────────────

EVOLVE_SYSTEM_PROMPT = """\
You are a neural architecture evolution agent for time-series forecasting.

You will receive:
1. A parent model source code (either scaffold or a DB-sampled model)
2. A challenge type describing what to improve
3. Constraints the model must satisfy
4. Experimental context from previous models

Your job: produce a COMPLETE, VALID Python file that is an improved variant of the parent.

CRITICAL CONTRACT REQUIREMENTS:
- Class must be named `TimeSeriesFoundationModel` and subclass `BaseTSFM`
- Must implement forward(), generate(), from_config(), to_config()
- Must define instantiate_model() that calls validate_time_series_model()
- forward/generate return {"quantiles": [B,H,Q], "quantile_levels": [Q]}
- All Linear layer dims must match d_model (typically 256) — no hardcoded 64/128
- Causal masks applied BEFORE softmax
- from_config() accepts dict with unknown keys; to_config() returns JSON-serializable values
- Set training_style = TrainingStyle.TEACHER_FORCED or TrainingStyle.DIRECT

RULES:
- Output ONLY the complete Python file content — no markdown fences, no prose
- Make ONE focused architectural change (not a rewrite)
- Keep the change small enough to be testable but meaningful
- Preserve all imports and the factory pattern
- The code must parse as valid Python (no syntax errors)

GOOD CHANGES (pick one per evolution):
- Replace vanilla attention with linear attention or sparse attention
- Add a state-space model (SSM/Mamba) layer alongside or replacing transformer blocks
- Add RevIN (Reversible Instance Normalization) for scale-free generalization
- Add multi-resolution temporal convolutions before the transformer
- Replace the positional encoding scheme (rotary, ALiBi, learnable)
- Add a gating mechanism (GLU, SwiGLU) in the feed-forward blocks
- Modify the quantile head (mixture density, copula, etc.)
- Add residual connections or skip connections across distant layers
- Add adaptive layer normalization conditioned on input statistics
"""


# ── Helpers ──────────────────────────────────────────────────────────────


def _strip_markdown_fences(text: str) -> str:
    """Remove ```python ... ``` fences if present."""
    text = text.strip()
    if text.startswith("```"):
        lines = text.splitlines()
        lines = lines[1:]  # drop opening fence
        if lines and lines[-1].strip() == "```":
            lines = lines[:-1]
        text = "\n".join(lines)
    return text


def _get_scaffold_code() -> str:
    scaffold_path = Path(__file__).parent.parent / "scaffolds" / "ts_base_model.py"
    if scaffold_path.exists():
        return scaffold_path.read_text(encoding="utf-8")
    raise FileNotFoundError(f"Scaffold not found: {scaffold_path}")


def _validate_syntax(code: str) -> Tuple[bool, str]:
    """Fast syntax + AST contract check (no runtime import)."""
    try:
        tree = ast.parse(code)
    except SyntaxError as e:
        return False, f"Syntax error: {e}"

    class_names = [
        node.name for node in ast.walk(tree) if isinstance(node, ast.ClassDef)
    ]
    if "TimeSeriesFoundationModel" not in class_names:
        return False, "Missing class 'TimeSeriesFoundationModel'"

    func_names = [
        node.name for node in ast.walk(tree) if isinstance(node, ast.FunctionDef)
    ]
    if "instantiate_model" not in func_names:
        return False, "Missing function 'instantiate_model'"

    for cls_node in ast.walk(tree):
        if isinstance(cls_node, ast.ClassDef) and cls_node.name == "TimeSeriesFoundationModel":
            method_names = {
                node.name
                for node in cls_node.body
                if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))
            }
            required = {"forward", "generate", "from_config", "to_config"}
            missing = required - method_names
            if missing:
                return False, f"Missing methods: {missing}"
            break

    return True, "OK"


def _validate_runtime(code: str) -> Tuple[bool, str]:
    """Write to temp file, try to load_candidate_model on CPU."""
    fd, tmp_path = tempfile.mkstemp(suffix=".py", prefix="live_validate_")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            f.write(code)
        try:
            from tasks.ts_foundation.model_base import load_candidate_model
            import torch

            load_candidate_model(
                tmp_path,
                torch.device("cpu"),
                input_length=512,
                forecast_length=96,
            )
            return True, "OK"
        except Exception as e:
            return False, f"Runtime validation failed: {e}"
    finally:
        try:
            os.unlink(tmp_path)
        except OSError:
            pass


# ── Core LLM evolution ───────────────────────────────────────────────────


async def _evolve_once(
    parent_code: str,
    challenge_type: str,
    constraints: Dict[str, Any],
    context: str,
    parent_name: str,
) -> Tuple[str, str, str]:
    """Single LLM evolution attempt.  Returns (code, motivation, name)."""
    from services.providers.clients.chutes_client import ChutesClient

    model_name = os.getenv("MODEL_NAME", "")
    if not model_name:
        raise RuntimeError("MODEL_NAME env var required for live evolve")

    user_prompt = f"""## Challenge Type
{challenge_type or "Open-ended — pick any improvement you think will help."}

## Constraints
- Max parameters: {constraints.get('max_params', 125_000_000)}
- Max inference latency: {constraints.get('max_inference_latency_ms', 50)}ms
- Required quantile levels: {constraints.get('required_quantile_levels', [0.1, 0.5, 0.9])}

## Experimental Context
{context[:3000] if context else "No prior experiments available."}

## Parent Model: {parent_name}
```python
{parent_code}
```

Produce the complete evolved Python file now. Remember: ONE focused change, valid Python, full contract compliance."""

    client = ChutesClient()
    messages = [
        {"role": "system", "content": EVOLVE_SYSTEM_PROMPT},
        {"role": "user", "content": user_prompt},
    ]
    raw = await client.chat(model=model_name, messages=messages)
    normalized = client.normalize(raw)
    text: str = normalized.get("text_response", "")
    code = _strip_markdown_fences(text)

    # Ask LLM for name + motivation
    diff_lines = list(
        difflib.unified_diff(
            parent_code.splitlines(), code.splitlines(), lineterm="", n=3
        )
    )
    diff_text = "\n".join(diff_lines[:100])

    meta_msgs = [
        {
            "role": "system",
            "content": (
                "You are naming a neural architecture variant. "
                "Reply with EXACTLY two lines:\n"
                "NAME: <short_name_no_spaces>\n"
                "MOTIVATION: <one sentence explaining the architectural change>"
            ),
        },
        {"role": "user", "content": f"Diff from parent:\n{diff_text}"},
    ]
    raw2 = await client.chat(model=model_name, messages=meta_msgs)
    normalized2 = client.normalize(raw2)
    meta_text = normalized2.get("text_response", "")

    name = "EvolvedModel"
    motivation = "LLM-evolved variant"
    for line in meta_text.strip().splitlines():
        if line.upper().startswith("NAME:"):
            name = line.split(":", 1)[1].strip().replace(" ", "_")[:50]
        elif line.upper().startswith("MOTIVATION:"):
            motivation = line.split(":", 1)[1].strip()[:500]

    return code, motivation, name


# ── Public interface ─────────────────────────────────────────────────────


class LiveMinerAgent:
    """Generates miner submissions using a real LLM (Chutes).

    Drop-in replacement for ``MockMinerFactory`` when partially-live
    testing is desired.  Each submission is produced by asking an LLM
    to evolve the scaffold (or a parent code) with a focused
    architectural change, then validating the result.

    Args:
        n_agents: Number of independent LLM evolution attempts per epoch.
        max_attempts: Retry budget per agent on validation failure.
        validate_runtime: If True, do full ``load_candidate_model`` check
            (requires torch). If False, only do AST checks (faster).
    """

    def __init__(
        self,
        n_agents: int = 3,
        max_attempts: int = 3,
        validate_runtime: bool = True,
    ):
        self.n_agents = n_agents
        self.max_attempts = max_attempts
        self.validate_runtime = validate_runtime
        self._scaffold_code: Optional[str] = None

    def _scaffold(self) -> str:
        if self._scaffold_code is None:
            self._scaffold_code = _get_scaffold_code()
        return self._scaffold_code

    def get_commitments(self) -> List[MinerCommitment]:
        """Return mock commitments for each live agent."""
        commitments = []
        for i in range(self.n_agents):
            hotkey = f"5LiveAgent{i:03d}00000000000000000000000000000"[:48]
            commitments.append(
                MinerCommitment(
                    hotkey=hotkey,
                    uid=i,
                    docker_image=f"live/agent-{i}:latest",
                    metadata={"live": True, "agent_index": i},
                    block_committed=1000000 + i,
                )
            )
        return commitments

    async def generate_submissions(
        self,
        challenge: Challenge,
    ) -> List[MinerSubmission]:
        """Evolve N independent model variants via LLM.

        Each agent gets its own LLM call with the same challenge.
        Failed evolutions fall back to the scaffold.
        """
        parent_code = challenge.scaffold_code or self._scaffold()
        parent_name = "scaffold"

        submissions: List[MinerSubmission] = []
        for i in range(self.n_agents):
            uid = i
            hotkey = f"5LiveAgent{i:03d}00000000000000000000000000000"[:48]

            code, motivation, name = await self._evolve_single(
                parent_code=parent_code,
                challenge=challenge,
                parent_name=parent_name,
                agent_index=i,
            )

            diff = "\n".join(
                difflib.unified_diff(
                    parent_code.splitlines(),
                    code.splitlines(),
                    fromfile=f"parent ({parent_name})",
                    tofile="evolved",
                    lineterm="",
                )
            )

            submissions.append(
                MinerSubmission(
                    hotkey=hotkey,
                    uid=uid,
                    model_code=code,
                    model_diff=diff,
                    parent_id=None,
                    motivation=motivation,
                    name=name,
                    config={},
                    metadata={
                        "live": True,
                        "agent_index": i,
                        "evolved": True,
                    },
                    status=SubmissionStatus.SUCCEEDED,
                )
            )

        return submissions

    async def _evolve_single(
        self,
        parent_code: str,
        challenge: Challenge,
        parent_name: str,
        agent_index: int,
    ) -> Tuple[str, str, str]:
        """Run LLM evolution with retry.  Falls back to scaffold."""
        for attempt in range(1, self.max_attempts + 1):
            logger.info(
                "[LiveAgent %d] Evolution attempt %d/%d",
                agent_index, attempt, self.max_attempts,
            )
            try:
                code, motivation, name = await _evolve_once(
                    parent_code=parent_code,
                    challenge_type=challenge.challenge_type,
                    constraints=challenge.constraints,
                    context=challenge.context,
                    parent_name=parent_name,
                )

                # Validate
                ok, err = _validate_syntax(code)
                if not ok:
                    logger.warning(
                        "[LiveAgent %d] Syntax check failed (attempt %d): %s",
                        agent_index, attempt, err,
                    )
                    continue

                if self.validate_runtime:
                    ok, err = _validate_runtime(code)
                    if not ok:
                        logger.warning(
                            "[LiveAgent %d] Runtime check failed (attempt %d): %s",
                            agent_index, attempt, err,
                        )
                        continue

                logger.info(
                    "[LiveAgent %d] Evolution succeeded: %s", agent_index, name
                )
                return code, motivation, name

            except Exception as e:
                logger.error(
                    "[LiveAgent %d] LLM call failed (attempt %d): %s",
                    agent_index, attempt, e,
                )
                traceback.print_exc()

        # Fallback
        logger.warning(
            "[LiveAgent %d] All attempts failed — using scaffold fallback",
            agent_index,
        )
        return (
            f"# Fallback (LiveAgent {agent_index})\n{self._scaffold()}",
            "Fallback: scaffold baseline (live evolve failed)",
            f"FallbackBaseline_agent{agent_index}",
        )
