"""
Mock miner factory for generating test submissions.

Provides utilities to generate configurable MinerSubmission objects
using variations of the scaffold model code. This allows testing the
full validator pipeline with realistic model code without running
actual miner containers.

Supports two modes:
- Generated mock miners: Automatic scaffold variations (default)
- File-based miners: Load real .py model files from disk
"""

from __future__ import annotations

import logging
import random
import hashlib
import textwrap
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional, Callable

from subnet.protocol.types import (
    Challenge,
    MinerCommitment,
    MinerSubmission,
    SubmissionStatus,
)

logger = logging.getLogger(__name__)


# ── Scaffold code templates ──────────────────────────────────────────────

def _get_scaffold_code() -> str:
    """Load the actual scaffold code from the repo."""
    scaffold_path = Path(__file__).parent.parent / "scaffolds" / "ts_base_model.py"
    if scaffold_path.exists():
        return scaffold_path.read_text()
    # Fallback minimal model if scaffold not found
    return _MINIMAL_MODEL_CODE


_MINIMAL_MODEL_CODE = '''
"""Minimal time-series model for testing."""
from __future__ import annotations
from typing import Any, Dict, Optional
import math
import torch
import torch.nn as nn

from tasks.ts_foundation.model_base import (
    TimeSeriesFoundationModel as BaseTSFM,
    validate_time_series_model,
)

DEFAULT_CONFIG = {
    "d_model": 64,
    "n_layers": 2,
    "n_heads": 4,
    "dropout": 0.1,
    "horizon": 96,
    "quantile_levels": (0.1, 0.5, 0.9),
}


class TimeSeriesFoundationModel(BaseTSFM):
    def __init__(self, cfg: Dict[str, Any]):
        super().__init__()
        self.cfg = {**DEFAULT_CONFIG, **(cfg or {})}
        d = self.cfg["d_model"]
        self.proj = nn.Linear(1, d)
        self.layers = nn.ModuleList([
            nn.TransformerEncoderLayer(d, self.cfg["n_heads"], d * 4, self.cfg["dropout"], batch_first=True)
            for _ in range(self.cfg["n_layers"])
        ])
        self.head = nn.Linear(d, len(self.cfg["quantile_levels"]))
        self.register_buffer(
            "quantile_levels",
            torch.tensor(self.cfg["quantile_levels"], dtype=torch.float32),
        )

    def forward(
        self,
        past_y: torch.Tensor,
        past_cov: Optional[torch.Tensor] = None,
        future_cov: Optional[torch.Tensor] = None,
        static: Optional[torch.Tensor] = None,
        y_future_tf: Optional[torch.Tensor] = None,
        *,
        forecast_length: Optional[int] = None,
        input_length: Optional[int] = None,
    ) -> Dict[str, torch.Tensor]:
        H = forecast_length or self.cfg["horizon"]
        B, T, C = past_y.shape
        x = self.proj(past_y)
        for layer in self.layers:
            x = layer(x)
        out = self.head(x[:, -H:, :])
        q0 = out[..., :1]
        inc = torch.relu(out[..., 1:])
        quantiles = torch.cat([q0, q0 + torch.cumsum(inc, dim=-1)], dim=-1)
        return {
            "quantiles": quantiles,
            "quantile_levels": self.quantile_levels.to(quantiles.device),
        }

    @torch.no_grad()
    def generate(self, past_y, past_cov=None, future_cov=None, static=None, *, forecast_length=None, input_length=None):
        return self.forward(past_y, past_cov, future_cov, static, forecast_length=forecast_length, input_length=input_length)

    @classmethod
    def from_config(cls, cfg: Dict[str, Any]) -> "TimeSeriesFoundationModel":
        return cls(cfg)

    def to_config(self) -> Dict[str, Any]:
        return dict(self.cfg)


def instantiate_model(config: Optional[Dict[str, Any]] = None) -> BaseTSFM:
    model = TimeSeriesFoundationModel.from_config(config or {})
    return validate_time_series_model(model)
'''


# ── Model variations ─────────────────────────────────────────────────────

def _make_smaller_model(base_code: str, factor: float = 0.5) -> str:
    """Create a smaller variant by reducing d_model."""
    # Simple string replacement for testing
    return base_code.replace(
        '"d_model":        256',
        f'"d_model":        {int(256 * factor)}'
    ).replace(
        '"n_layers":       6',
        f'"n_layers":       {int(6 * factor)}'
    )


def _make_larger_model(base_code: str, factor: float = 1.5) -> str:
    """Create a larger variant by increasing d_model."""
    return base_code.replace(
        '"d_model":        256',
        f'"d_model":        {int(256 * factor)}'
    ).replace(
        '"n_layers":       6',
        f'"n_layers":       {int(6 * factor)}'
    )


def _make_wider_model(base_code: str) -> str:
    """Create a wider variant with more heads."""
    return base_code.replace(
        '"n_heads":        8',
        '"n_heads":        16'
    ).replace(
        '"d_ff":           1024',
        '"d_ff":           2048'
    )


def _add_comment_variation(base_code: str, seed: int) -> str:
    """Add a unique comment to make code distinct."""
    comment = f"\n# Variation seed: {seed}, hash: {hashlib.md5(str(seed).encode()).hexdigest()[:8]}\n"
    return comment + base_code


# ── File-based miner loading ─────────────────────────────────────────────


def load_miner_code_files(
    paths: List[str],
) -> List[Dict[str, Any]]:
    """Load model code from .py files on disk.

    Accepts a mix of file paths and directory paths. Directories are
    scanned for ``*.py`` files (non-recursive). Each file becomes one
    miner submission.

    Args:
        paths: List of file or directory paths to load code from.

    Returns:
        List of dicts with keys ``name``, ``code``, ``path`` for each
        successfully loaded file.
    """
    loaded: List[Dict[str, Any]] = []

    for raw_path in paths:
        p = Path(raw_path).resolve()
        if p.is_file() and p.suffix == ".py":
            loaded.append(_load_single_file(p))
        elif p.is_dir():
            py_files = sorted(p.glob("*.py"))
            if not py_files:
                logger.warning("No .py files found in directory: %s", p)
            for f in py_files:
                loaded.append(_load_single_file(f))
        else:
            logger.warning("Skipping invalid path (not a .py file or directory): %s", raw_path)

    logger.info("Loaded %d miner code file(s) from %d path(s)", len(loaded), len(paths))
    return loaded


def _load_single_file(path: Path) -> Dict[str, Any]:
    """Read a single .py file and return metadata."""
    code = path.read_text(encoding="utf-8")
    name = path.stem  # filename without extension
    return {"name": name, "code": code, "path": str(path)}


def create_file_based_submissions(
    code_files: List[Dict[str, Any]],
    challenge: Challenge,
    uid_offset: int = 0,
) -> List[MinerSubmission]:
    """Create MinerSubmission objects from loaded code files.

    Args:
        code_files: Output of ``load_miner_code_files()``.
        challenge: The challenge to associate submissions with.
        uid_offset: Starting UID for file-based miners.

    Returns:
        List of MinerSubmission objects (all with SUCCEEDED status).
    """
    submissions = []
    for i, entry in enumerate(code_files):
        uid = uid_offset + i
        hotkey = f"5FileMiner{uid:03d}000000000000000000000000000000"[:48]

        # File-based miners claim parent_id=1 by default (first DB entry)
        parent_id = 1

        submissions.append(
            MinerSubmission(
                hotkey=hotkey,
                uid=uid,
                model_code=entry["code"],
                model_diff="",
                parent_id=parent_id,
                motivation=f"File-based submission from {entry['path']}",
                name=entry["name"],
                config={},
                metadata={"source": "file", "path": entry["path"]},
                status=SubmissionStatus.SUCCEEDED,
            )
        )

    return submissions


# ── Miner submission factory ─────────────────────────────────────────────


@dataclass
class MinerProfile:
    """Configuration for a mock miner's behavior.

    Attributes:
        success_rate: Probability of successful submission (0.0-1.0).
        quality: Base quality level affecting model performance (0.0-1.0).
        variation_type: Type of model variation to apply.
        response_delay_ms: Simulated response delay in milliseconds.
    """
    success_rate: float = 1.0
    quality: float = 0.5
    variation_type: str = "default"  # "default", "smaller", "larger", "wider", "invalid"
    response_delay_ms: int = 0


@dataclass
class MockMinerFactory:
    """Factory for generating mock miner submissions.

    Configurable factory that creates MinerSubmission objects with
    various model code variations for testing different scenarios.

    Example:
        factory = MockMinerFactory(
            n_miners=10,
            success_rate=0.8,  # 80% submit successfully
            quality_distribution="uniform",
        )

        challenge = Challenge(task_name="time_series_foundation", ...)
        commitments = factory.get_commitments()
        submissions = factory.generate_submissions(challenge)
    """

    n_miners: int = 5
    success_rate: float = 1.0
    quality_distribution: str = "uniform"  # "uniform", "normal", "bimodal"
    base_uid_offset: int = 0
    use_scaffold: bool = True
    seed: int = 42

    # Per-miner profiles (if empty, generated from class defaults)
    miner_profiles: Dict[int, MinerProfile] = field(default_factory=dict)

    def __post_init__(self):
        self._rng = random.Random(self.seed)

        # Generate default profiles if not provided
        if not self.miner_profiles:
            for i in range(self.n_miners):
                uid = self.base_uid_offset + i
                quality = self._sample_quality()
                self.miner_profiles[uid] = MinerProfile(
                    success_rate=self.success_rate,
                    quality=quality,
                    variation_type=self._sample_variation_type(quality),
                )

    def _sample_quality(self) -> float:
        """Sample a quality value based on distribution."""
        if self.quality_distribution == "uniform":
            return self._rng.uniform(0.1, 0.9)
        elif self.quality_distribution == "normal":
            return max(0.1, min(0.9, self._rng.gauss(0.5, 0.2)))
        elif self.quality_distribution == "bimodal":
            # Either good or bad
            if self._rng.random() < 0.5:
                return self._rng.uniform(0.1, 0.3)
            else:
                return self._rng.uniform(0.7, 0.9)
        return 0.5

    def _sample_variation_type(self, quality: float) -> str:
        """Choose variation type based on quality."""
        if quality < 0.2:
            return self._rng.choice(["invalid", "smaller"])
        elif quality < 0.4:
            return "smaller"
        elif quality < 0.6:
            return "default"
        elif quality < 0.8:
            return self._rng.choice(["default", "wider"])
        else:
            return self._rng.choice(["wider", "larger"])

    def get_commitments(self) -> List[MinerCommitment]:
        """Generate MinerCommitment objects for all mock miners."""
        commitments = []
        for i in range(self.n_miners):
            uid = self.base_uid_offset + i
            hotkey = f"5MockMiner{uid:03d}000000000000000000000000000000"[:48]
            commitments.append(
                MinerCommitment(
                    hotkey=hotkey,
                    uid=uid,
                    docker_image=f"test/miner-{uid}:latest",
                    metadata={"test": True, "profile": uid},
                    block_committed=1000000 + i,
                )
            )
        return commitments

    def generate_submissions(
        self,
        challenge: Challenge,
    ) -> List[MinerSubmission]:
        """Generate mock submissions for all miners.

        Args:
            challenge: The challenge sent to miners.

        Returns:
            List of MinerSubmission objects (some may have FAILED status).
        """
        submissions = []
        base_code = _get_scaffold_code() if self.use_scaffold else _MINIMAL_MODEL_CODE

        for i in range(self.n_miners):
            uid = self.base_uid_offset + i
            profile = self.miner_profiles.get(uid, MinerProfile())

            # Determine if this miner succeeds
            if self._rng.random() > profile.success_rate:
                submissions.append(
                    MinerSubmission(
                        hotkey=f"5MockMiner{uid:03d}000000000000000000000000000000"[:48],
                        uid=uid,
                        model_code="",
                        status=SubmissionStatus.FAILED,
                    )
                )
                continue

            # Generate model code variation
            model_code = self._generate_model_code(base_code, profile, i)

            # Mock miners pick a random parent_id from the DB
            parent_id = self._rng.randint(1, 10)

            # Generate submission
            name = f"MockModel_uid{uid}_v{i}"
            motivation = self._generate_motivation(profile)

            submissions.append(
                MinerSubmission(
                    hotkey=f"5MockMiner{uid:03d}000000000000000000000000000000"[:48],
                    uid=uid,
                    model_code=model_code,
                    model_diff="",
                    parent_id=parent_id,
                    motivation=motivation,
                    name=name,
                    config=self._generate_config(profile),
                    metadata={"quality": profile.quality, "variation": profile.variation_type},
                    status=SubmissionStatus.SUCCEEDED,
                )
            )

        return submissions

    def _generate_model_code(
        self, base_code: str, profile: MinerProfile, index: int
    ) -> str:
        """Generate model code based on profile."""
        code = base_code

        if profile.variation_type == "smaller":
            code = _make_smaller_model(code)
        elif profile.variation_type == "larger":
            code = _make_larger_model(code)
        elif profile.variation_type == "wider":
            code = _make_wider_model(code)
        elif profile.variation_type == "invalid":
            # Return invalid code that will fail validation
            return "# Invalid model code\ndef instantiate_model(config=None): raise ValueError('Invalid')"

        # Add unique variation
        code = _add_comment_variation(code, self.seed + index)
        return code

    def _generate_motivation(self, profile: MinerProfile) -> str:
        """Generate a motivation string based on profile."""
        motivations = {
            "default": "Applied standard architecture with baseline configuration.",
            "smaller": "Reduced model size for faster inference and lower memory usage.",
            "larger": "Increased model capacity to capture more complex patterns.",
            "wider": "Expanded attention heads and feed-forward dimension for better representation.",
            "invalid": "Test invalid submission.",
        }
        base = motivations.get(profile.variation_type, "Architecture modification.")
        return f"{base} Quality target: {profile.quality:.2f}"

    def _generate_config(self, profile: MinerProfile) -> Dict[str, Any]:
        """Generate config dict based on profile."""
        base_config = {
            "d_model": 256,
            "n_layers": 6,
            "n_heads": 8,
            "d_ff": 1024,
            "dropout": 0.1,
        }

        if profile.variation_type == "smaller":
            base_config["d_model"] = 128
            base_config["n_layers"] = 3
        elif profile.variation_type == "larger":
            base_config["d_model"] = 384
            base_config["n_layers"] = 9
        elif profile.variation_type == "wider":
            base_config["n_heads"] = 16
            base_config["d_ff"] = 2048

        return base_config


# ── Convenience function ─────────────────────────────────────────────────


def generate_mock_submissions(
    challenge: Challenge,
    n_miners: int = 5,
    success_rate: float = 1.0,
    quality_distribution: str = "uniform",
    seed: int = 42,
) -> List[MinerSubmission]:
    """Convenience function to generate mock submissions.

    Args:
        challenge: The challenge sent to miners.
        n_miners: Number of mock miners.
        success_rate: Probability each miner succeeds.
        quality_distribution: How quality is distributed ("uniform", "normal", "bimodal").
        seed: Random seed for reproducibility.

    Returns:
        List of MinerSubmission objects.
    """
    factory = MockMinerFactory(
        n_miners=n_miners,
        success_rate=success_rate,
        quality_distribution=quality_distribution,
        seed=seed,
    )
    return factory.generate_submissions(challenge)


# ── Preset scenarios ─────────────────────────────────────────────────────


def create_happy_path_miners(n: int = 5) -> MockMinerFactory:
    """Create miners that all succeed with varying quality."""
    return MockMinerFactory(
        n_miners=n,
        success_rate=1.0,
        quality_distribution="uniform",
    )


def create_realistic_miners(n: int = 10) -> MockMinerFactory:
    """Create miners with realistic success/failure distribution."""
    return MockMinerFactory(
        n_miners=n,
        success_rate=0.8,
        quality_distribution="normal",
    )


def create_adversarial_miners(n: int = 5) -> MockMinerFactory:
    """Create miners with many failures and low quality."""
    factory = MockMinerFactory(
        n_miners=n,
        success_rate=0.5,
        quality_distribution="bimodal",
    )
    # Override some profiles with invalid submissions
    for uid in list(factory.miner_profiles.keys())[:n // 3]:
        factory.miner_profiles[uid].variation_type = "invalid"
    return factory
