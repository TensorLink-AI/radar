# Validator container image.
#
# Build:
#   docker build -f subnet/docker/validator.Dockerfile -t agentic-nas-validator:latest .
#
# Run:
#   docker run --rm \
#     -e SUBNET_NETUID=<your-netuid> \
#     -e SUBTENSOR_NETWORK=finney \
#     -e BASILICA_API_TOKEN=<token> \
#     -v ~/.bittensor:/root/.bittensor \
#     agentic-nas-validator:latest

FROM python:3.11-slim

WORKDIR /app

# System deps
RUN apt-get update && apt-get install -y --no-install-recommends \
    git curl && \
    rm -rf /var/lib/apt/lists/*

# Python deps
COPY requirements-minimal.txt .
RUN pip install --no-cache-dir -r requirements-minimal.txt && \
    pip install --no-cache-dir bittensor aiohttp

# Application code
COPY . .
RUN pip install --no-cache-dir -e .

ENTRYPOINT ["python", "-m", "subnet.validator.validator"]
