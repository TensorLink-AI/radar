"""
Subnet configuration.

All tuneable parameters for the Bittensor subnet live here.
Environment variables override class defaults where noted.
"""

import os


class SubnetConfig:
    # ── Chain / identity ────────────────────────────────────────────────
    NETUID: int = int(os.getenv("SUBNET_NETUID", "0"))
    SUBTENSOR_NETWORK: str = os.getenv("SUBTENSOR_NETWORK", "test")  # local | test | finney
    SUBTENSOR_ADDRESS: str = os.getenv("SUBTENSOR_ADDRESS", "")      # custom endpoint, if any
    WALLET_NAME: str = os.getenv("WALLET_NAME", "default")
    HOTKEY_NAME: str = os.getenv("HOTKEY_NAME", "default")

    # ── Task ────────────────────────────────────────────────────────────
    TASK_NAME: str = os.getenv("SUBNET_TASK_NAME", "time_series_foundation")

    # ── Epoch timing ────────────────────────────────────────────────────
    EPOCH_LENGTH_SECONDS: int = int(os.getenv("EPOCH_LENGTH_SECONDS", "86400"))  # 24 h

    # ── Phase 1 – Generation (miner pod execution) ──────────────────────
    MINER_POD_TIMEOUT_SEC: int = int(os.getenv("MINER_POD_TIMEOUT_SEC", "1800"))  # 30 min
    MAX_CONCURRENT_MINER_PODS: int = int(os.getenv("MAX_CONCURRENT_MINER_PODS", "8"))

    # How many reference experiments to sample for context.
    PARENT_POOL_SIZE: int = int(os.getenv("PARENT_POOL_SIZE", "5"))

    # R2 URL where the experiment DB snapshot is published for miners.
    # Miners download this and query it locally via Mongita.
    DB_SNAPSHOT_URL: str = os.getenv("DB_SNAPSHOT_URL", "")

    # ── Challenge constraints (defaults sent to every miner) ────────────
    # These are the *hard* limits miners must respect.  Candidates that
    # violate them are rejected during Phase 2 filtering.
    # NOTE: Must match the task definition's max_params (125M for ts_foundation)
    MAX_PARAMS: int = int(os.getenv("MAX_PARAMS", "125000000"))  # 125 M
    MAX_INFERENCE_LATENCY_MS: float = float(os.getenv("MAX_INFERENCE_LATENCY_MS", "50"))
    REQUIRED_QUANTILE_LEVELS: str = os.getenv(
        "REQUIRED_QUANTILE_LEVELS", "0.1,0.5,0.9"
    )  # comma-separated floats

    # Challenge categories available for this task.  The validator cycles
    # or randomly selects one per epoch.  Keys match the task's
    # ``get_challenge_categories()`` output.
    CHALLENGE_CATEGORIES: str = os.getenv(
        "CHALLENGE_CATEGORIES",
        "Long-Range Dependencies,Multi-Scale & Frequency,Non-Stationarity,"
        "Scale-Free Generalization,SNR Variability,Computational Efficiency",
    )  # comma-separated, must match task definition's challenge_categories

    # ── Phase 2 – Filtering (zero-cost proxy) ───────────────────────────
    ZERO_COST_TOP_K: int = int(os.getenv("ZERO_COST_TOP_K", "16"))

    # Proxy eval runs on the same Basilica image as deep training.
    # Override with PROXY_EVAL_IMAGE only if you need a separate image.
    # No automatic fallback to local CPU -- set PROXY_EVAL_LOCAL=1 to opt in.
    PROXY_EVAL_IMAGE: str = os.getenv(
        "PROXY_EVAL_IMAGE",
        os.getenv("DEEP_TRAIN_IMAGE", ""),
    )
    PROXY_EVAL_TIMEOUT_SEC: int = int(os.getenv("PROXY_EVAL_TIMEOUT_SEC", "600"))  # 10 min
    PROXY_EVAL_LOCAL: bool = os.getenv("PROXY_EVAL_LOCAL", "0") == "1"

    # ── Phase 2 – Lineage validation (diff checks) ───────────────────
    LINEAGE_CHECK_ENABLED: bool = os.getenv("LINEAGE_CHECK_ENABLED", "1") == "1"
    LINEAGE_MIN_SIMILARITY: float = float(os.getenv("LINEAGE_MIN_SIMILARITY", "0.10"))
    LINEAGE_MAX_REPLACEMENT_RATIO: float = float(os.getenv("LINEAGE_MAX_REPLACEMENT_RATIO", "0.95"))

    # ── Phase 3 – Validation (two-stage deep training) ─────────────────
    #
    # Phase 3a: Short training round – cheap elimination of candidates
    # that blow up or plateau early.  Top SHORT_TRAIN_TOP_M + best
    # absolute parent advance to Phase 3b.
    SHORT_TRAIN_TOP_M: int = int(os.getenv("SHORT_TRAIN_TOP_M", "19"))
    SHORT_TRAIN_TIMEOUT_SEC: int = int(os.getenv("SHORT_TRAIN_TIMEOUT_SEC", "3600"))  # 1 h
    #
    # Phase 3b: Long training round – full training on survivors.
    # Top DEEP_TRAIN_TOP_L + best absolute parent are scored in Phase 4.
    DEEP_TRAIN_TOP_L: int = int(os.getenv("DEEP_TRAIN_TOP_L", "3"))
    DEEP_TRAIN_TIMEOUT_SEC: int = int(os.getenv("DEEP_TRAIN_TIMEOUT_SEC", "14400"))  # 4 h (>= TaskDefinition.large_budget_timeout_sec)
    #
    # The best absolute parent (from the DB) is injected into both
    # training rounds as a baseline.  It competes with miner submissions
    # but does NOT receive weight — it only serves as a reference point.
    # Set to 0 to disable parent injection.
    INJECT_BEST_PARENT: bool = os.getenv("INJECT_BEST_PARENT", "1") == "1"
    DEEP_TRAIN_IMAGE: str = os.getenv(
        "DEEP_TRAIN_IMAGE", ""
    )  # validator's trusted training image
    MAX_CONCURRENT_TRAINING_PODS: int = int(os.getenv("MAX_CONCURRENT_TRAINING_PODS", "4"))

    # ── Phase 4 – Scoring & consensus ───────────────────────────────────
    EMA_ALPHA: float = float(os.getenv("EMA_ALPHA", "0.1"))
    SOFTMAX_TEMPERATURE: float = float(os.getenv("SOFTMAX_TEMPERATURE", "1.0"))
    PENALTY_EXPONENT: float = float(os.getenv("PENALTY_EXPONENT", "2.5"))

    # ── Basilica (compute cluster for miner/eval pods) ──────────────────
    BASILICA_API_TOKEN: str = os.getenv("BASILICA_API_TOKEN", "")
    BASILICA_GPU_TYPE: str = os.getenv("BASILICA_GPU_TYPE", "")
    BASILICA_GPU_COUNT: int = int(os.getenv("BASILICA_GPU_COUNT", "1"))
    BASILICA_GPU_MEMORY_GB: int = int(os.getenv("BASILICA_GPU_MEMORY_GB", "16"))
    BASILICA_MEMORY: str = os.getenv("BASILICA_MEMORY", "16Gi")

    # ── External services ───────────────────────────────────────────────
    DATABASE_URL: str = os.getenv("DATABASE_URL", "http://localhost:8001")
    COGNITION_BASE_URL: str = os.getenv("COGNITION_BASE_URL", "http://localhost:5000")
    CHUTES_API_KEY: str = os.getenv("CHUTES_API_KEY", "")

    # ── Epistula auth ───────────────────────────────────────────────────
    EPISTULA_FRESHNESS_SEC: int = int(os.getenv("EPISTULA_FRESHNESS_SEC", "60"))

    # ── Helpers ─────────────────────────────────────────────────────────

    @classmethod
    def get_constraints(cls) -> dict:
        """Build the constraints dict sent inside every Challenge."""
        return {
            "max_params": cls.MAX_PARAMS,
            "max_inference_latency_ms": cls.MAX_INFERENCE_LATENCY_MS,
            "required_quantile_levels": [
                float(q) for q in cls.REQUIRED_QUANTILE_LEVELS.split(",") if q.strip()
            ],
        }

    @classmethod
    def get_challenge_categories(cls) -> list:
        """Return the list of challenge category IDs."""
        return [c.strip() for c in cls.CHALLENGE_CATEGORIES.split(",") if c.strip()]
