"""
Shared data types for validator ↔ miner ↔ chain communication.

These types define the wire format for every phase of the epoch.
The two critical contracts are:

    Challenge       (Validator -> Miner)   – what the miner must solve.
    MinerSubmission (Miner -> Validator)   – the miner's evolved model.

Any field added here becomes part of the public interface that miners
will read from ``validator.py`` to build their agents.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional


# ── Enums ───────────────────────────────────────────────────────────────


class SubmissionStatus(str, Enum):
    """Status of a miner submission through the evaluation pipeline.

    Currently used statuses:
        - SUCCEEDED: Miner returned a valid submission.
        - FAILED: Miner failed to produce a submission.

    Reserved for future use (lifecycle tracking):
        - PENDING: Submission queued but not yet processed.
        - RUNNING: Submission currently being evaluated.
        - TIMED_OUT: Submission exceeded time limit.
    """

    PENDING = "pending"
    RUNNING = "running"
    SUCCEEDED = "succeeded"
    FAILED = "failed"
    TIMED_OUT = "timed_out"


class EvalTier(str, Enum):
    """Evaluation budget tiers for candidate training.

    Use this enum for type-safe eval tier references instead of raw strings.
    Example: ``EvalTier.SMALL_BUDGET.value`` returns ``"small_budget"``.
    """

    ZERO_COST = "zero_cost"
    SMALL_BUDGET = "small_budget"
    LARGE_BUDGET = "large_budget"


# ── Chain-level types ───────────────────────────────────────────────────


@dataclass
class MinerCommitment:
    """On-chain commitment read from ``subtensor.get_commitment()``.

    Miners commit a JSON blob containing their Docker image reference
    and an optional metadata dict.  The validator parses this during
    Phase 1 to know which container to spin up.
    """

    hotkey: str
    uid: int
    docker_image: str  # e.g. "registry.example.com/miner-agent:v3"
    metadata: Dict[str, Any] = field(default_factory=dict)
    block_committed: int = 0


# ── Phase 1 – Generation ───────────────────────────────────────────────


@dataclass
class Challenge:
    """Task request sent from the validator to a miner pod.

    This is the **full contract** the miner's agent receives.  The
    validator constructs this from the current epoch state and POSTs
    it as JSON to the miner container's ``/challenge`` endpoint.

    Wire format (JSON)::

        {
            "task_name": "time_series_foundation",
            "challenge_type": "long_range_dependency",
            "constraints": {
                "max_params": 10000000,
                "max_inference_latency_ms": 50,
                "required_quantile_levels": [0.1, 0.5, 0.9]
            },
            "db_snapshot_url": "https://r2.example.com/db-snapshot.tar.gz",
            "context": "## EXPERIMENTAL EVIDENCE PORTFOLIO ...",
            "task_definition": {
                "name": "time_series_foundation",
                "description": "Long-range univariate ...",
                "hf_repo_id": "tensorlink-dev/time-series-six-datasets",
                "primary_metric": "MASE",
                "direction": "minimize",
                ...
            },
            "scaffold_code": "class TimeSeriesFoundation...",
            "epoch": 7
        }
    """

    # ── Required ────────────────────────────────────────────────────
    task_name: str  # Registered task, e.g. "time_series_foundation"

    # ── Challenge specification ─────────────────────────────────────
    challenge_type: str = ""
    """One of the challenge categories for this task (e.g.
    ``"long_range_dependency"``, ``"multi_scale_frequency"``).
    Empty string means "open-ended / miner's choice"."""

    constraints: Dict[str, Any] = field(default_factory=dict)
    """Hard constraints the candidate must satisfy.  Common keys:

    - ``max_params`` (int): Maximum trainable parameter count.
    - ``max_inference_latency_ms`` (float): Latency budget for a
      single forward pass on the evaluation GPU.
    - ``required_quantile_levels`` (List[float]): Quantile levels
      the model's output must cover.
    - ``min_forecast_length`` (int): Minimum forecast horizon.
    """

    # ── Parent / lineage context ────────────────────────────────────
    db_snapshot_url: str = ""
    """R2 URL where miners can download a Mongita-compatible snapshot
    of the experiment database.  Miners query it locally to browse
    all existing models and pick any parent they want to evolve from.
    The chosen parent index is reported as ``MinerSubmission.parent_id``."""

    context: str = ""
    """DB-sampled context: experimental evidence portfolio, reference
    experiments.  Provided so the miner's agent can make informed
    architecture decisions without needing to download the full DB."""

    # ── Task definition (full contract for the miner) ──────────────
    task_definition: Dict[str, Any] = field(default_factory=dict)
    """Serialised ``TaskDefinition`` for this task.  Contains the
    complete specification: description, dataset info, model contract,
    metrics, training budgets, and challenge categories.  This gives
    miners everything they need to build a compliant model without
    reading the validator source code."""

    scaffold_code: Optional[str] = None
    """Source code of the reference scaffold model.  Miners can use
    this as a starting point or reference for the expected class
    structure and interface."""

    # ── Epoch bookkeeping ───────────────────────────────────────────
    epoch: int = 0


@dataclass
class MinerSubmission:
    """Response returned by a miner pod after running its agent.

    The miner's container must return this as JSON from its
    ``/challenge`` endpoint.  The validator parses it and feeds it
    into Phase 2 (filtering).

    Wire format (JSON)::

        {
            "parent_id": 34,
            "model_code": "class TimeSeriesFoundation...",
            "model_diff": "@@ -120,6 +120,12 @@ ...",
            "motivation": "Added multi-scale wavelet ...",
            "name": "WaveletMamba_v2",
            "config": {"d_model": 256, "n_layers": 6},
            "metadata": {}
        }
    """

    # ── Identity (set by validator, not miner) ──────────────────────
    hotkey: str
    uid: int

    # ── Model artefacts ─────────────────────────────────────────────
    model_code: str
    """Full candidate source code.  Must define ``instantiate_model()``
    and a class subclassing ``TimeSeriesFoundationModel``."""

    model_diff: str = ""
    """Unified diff (``diff -u``) from the parent to this candidate.
    Optional but useful for the Analyzer agent to understand the delta.
    If empty, the validator can reconstruct it by looking up the parent
    from the DB using ``parent_id``."""

    # ── Lineage ─────────────────────────────────────────────────────
    parent_id: Optional[int] = None
    """Index of the parent model the miner evolved from (any valid
    index in the experiment DB, or ``None`` if the miner started
    from scratch).  Miners browse the DB snapshot to pick a parent."""

    # ── Explanation ──────────────────────────────────────────────────
    motivation: str = ""
    """Free-text explanation of what the miner changed and why.
    Used by the Analyzer and MotivationChecker agents."""

    name: str = ""
    """Human-readable candidate name (e.g. ``"WaveletMamba_v2"``)."""

    # ── Hyperparameters ─────────────────────────────────────────────
    config: Dict[str, Any] = field(default_factory=dict)
    """Model hyperparameters as a JSON-serialisable dict.  Must match
    the values used inside ``instantiate_model()``.  Common keys:

    - ``d_model`` (int)
    - ``n_layers`` (int)
    - ``n_heads`` (int)
    - ``dropout`` (float)
    - ``forecast_length`` (int)
    - ``input_length`` (int)
    """

    # ── Catch-all ───────────────────────────────────────────────────
    metadata: Dict[str, Any] = field(default_factory=dict)
    """Arbitrary extra fields the miner wants to attach (ignored by
    the validator's scoring but persisted in the DB)."""

    status: SubmissionStatus = SubmissionStatus.SUCCEEDED


# ── Phase 2 & 3 – Evaluation results ───────────────────────────────────


@dataclass
class CandidateResult:
    """Evaluation result for a single candidate across all tiers.

    Populated progressively: zero-cost score first, then deep-train
    metrics for candidates that survive filtering.
    """

    hotkey: str
    uid: int
    name: str
    motivation: str
    model_code: str

    # Lineage
    parent_id: Optional[int] = None
    config: Dict[str, Any] = field(default_factory=dict)

    # Training style declared by the model (populated during zero-cost eval)
    training_style: Optional[str] = None

    # Phase 2 – zero-cost proxy
    zero_cost_score: Optional[float] = None
    zero_cost_details: Dict[str, Any] = field(default_factory=dict)

    # Constraint compliance (populated during filtering)
    # NOTE: Default is False for safety - must be explicitly set True after validation passes
    param_count: Optional[int] = None
    inference_latency_ms: Optional[float] = None
    constraints_satisfied: bool = False

    # Lineage validation (populated during filtering when parent_id is set)
    lineage_check: Dict[str, Any] = field(default_factory=dict)

    # Phase 3 – deep training
    train_metrics: Dict[str, Any] = field(default_factory=dict)
    train_loss: Optional[float] = None
    test_loss: Optional[float] = None

    # Phase 4 – analysis
    analysis: Dict[str, Any] = field(default_factory=dict)
    model_diff: str = ""

    # Final composite score used for weight setting
    final_score: float = 0.0


# ── Epoch-level aggregate ──────────────────────────────────────────────


@dataclass
class EpochState:
    """Full state for a single validator epoch.

    Tracks every miner commitment, submission, and result so the
    scoring and weight-setting logic can operate on a complete snapshot.
    """

    epoch: int = 0
    challenge_type: str = ""
    constraints: Dict[str, Any] = field(default_factory=dict)
    commitments: List[MinerCommitment] = field(default_factory=list)
    submissions: List[MinerSubmission] = field(default_factory=list)
    results: List[CandidateResult] = field(default_factory=list)
    weights: Dict[int, float] = field(default_factory=dict)  # uid -> weight
