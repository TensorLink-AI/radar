"""
Epistula HTTP signing and verification.

Bittensor's Epistula protocol replaces the deprecated axon/dendrite
system.  Every HTTP request between validator and miner carries three
headers that prove the caller's identity and freshness:

    X-Epistula-Timestamp  – UNIX epoch seconds (int)
    X-Epistula-Signature  – sr25519 signature of the timestamp bytes
    X-Epistula-Hotkey     – ss58 address of the signing hotkey

Validators MUST verify:
  1. Timestamp is within ``FRESHNESS_SEC`` of local time.
  2. Signature is valid for the claimed hotkey.
  3. Hotkey is registered on the metagraph with sufficient stake
     (for validator→miner calls, the miner checks the caller is a
     validator; for miner→validator calls, the validator checks the
     caller is a registered miner).
"""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass
from typing import Dict, Optional, Tuple

from subnet.config import SubnetConfig

logger = logging.getLogger(__name__)


HEADER_TIMESTAMP = "X-Epistula-Timestamp"
HEADER_SIGNATURE = "X-Epistula-Signature"
HEADER_HOTKEY = "X-Epistula-Hotkey"


@dataclass
class EpistulaAuth:
    timestamp: int
    signature: str
    hotkey: str


def build_headers(keypair) -> Dict[str, str]:
    """Create Epistula headers for an outgoing request.

    Args:
        keypair: A ``bittensor.Keypair`` (or compatible) object that
                 exposes ``.sign()`` and ``.ss58_address``.

    Returns:
        Dict with the three Epistula headers ready to merge into a
        request's header map.
    """
    ts = str(int(time.time()))
    signature = keypair.sign(ts.encode()).hex()
    return {
        HEADER_TIMESTAMP: ts,
        HEADER_SIGNATURE: signature,
        HEADER_HOTKEY: keypair.ss58_address,
    }


def verify_headers(
    headers: Dict[str, str],
    *,
    freshness_sec: Optional[int] = None,
) -> Tuple[bool, str, Optional[EpistulaAuth]]:
    """Verify incoming Epistula headers.

    Args:
        headers: HTTP request headers (case-insensitive dict).
        freshness_sec: Max age in seconds (default from config).

    Returns:
        ``(valid, reason, auth)`` – *auth* is populated only when
        *valid* is ``True``.
    """
    freshness = freshness_sec or SubnetConfig.EPISTULA_FRESHNESS_SEC

    ts_str = headers.get(HEADER_TIMESTAMP)
    sig_hex = headers.get(HEADER_SIGNATURE)
    hotkey = headers.get(HEADER_HOTKEY)

    if not all([ts_str, sig_hex, hotkey]):
        return False, "missing epistula headers", None

    # Freshness check
    try:
        ts = int(ts_str)
    except (TypeError, ValueError):
        return False, "invalid timestamp", None

    if abs(time.time() - ts) > freshness:
        return False, "timestamp too old", None

    # Signature verification (requires bittensor.Keypair)
    try:
        from bittensor import Keypair  # type: ignore[import-untyped]

        kp = Keypair(ss58_address=hotkey)
        if not kp.verify(ts_str.encode(), bytes.fromhex(sig_hex)):
            return False, "invalid signature", None
    except ImportError:
        # bittensor SDK not installed - this is a security risk in production
        import os
        if os.getenv("EPISTULA_ALLOW_UNVERIFIED", "0") == "1":
            # Explicitly opted into unverified mode (dev/test only)
            logger.warning(
                "bittensor SDK not installed and EPISTULA_ALLOW_UNVERIFIED=1 – "
                "skipping signature verification. THIS IS UNSAFE FOR PRODUCTION."
            )
        else:
            # Production mode: fail closed
            logger.error(
                "bittensor SDK not installed – cannot verify Epistula signatures. "
                "Install bittensor or set EPISTULA_ALLOW_UNVERIFIED=1 for dev/test."
            )
            return False, "bittensor SDK not installed - cannot verify signature", None
    except Exception as exc:
        return False, f"signature check failed: {exc}", None

    return True, "ok", EpistulaAuth(timestamp=ts, signature=sig_hex, hotkey=hotkey)
