"""
Chain commitment helpers.

Miners commit connection info (Docker image, metadata) to the
Bittensor chain via ``subtensor.set_commitment()``.  This module
provides serialisation / deserialisation for those commitments and
helpers for reading them from the metagraph.

Chain commitment limit: **1 per 100 blocks (~20 min)**.  Miners
should commit storage locations or image references, not individual
data items.
"""

from __future__ import annotations

import json
import logging
import re
from typing import Any, Dict, List, Optional

from subnet.protocol.types import MinerCommitment

logger = logging.getLogger(__name__)

# Matches standard Docker image references:
#   registry.example.com/org/image:tag
#   org/image:tag
#   org/image
#   image:tag
#   image
# Rejects obviously invalid values (spaces, special chars, etc.)
_DOCKER_IMAGE_RE = re.compile(
    r"^[a-zA-Z0-9]"                   # must start with alphanumeric
    r"[a-zA-Z0-9._\-/]*"              # body: alphanumeric, dots, dashes, slashes
    r"(:[a-zA-Z0-9._\-]+)?$"          # optional :tag
)


# ── Serialisation ───────────────────────────────────────────────────────

def encode_commitment(docker_image: str, metadata: Optional[Dict[str, Any]] = None) -> str:
    """Encode a miner commitment into the JSON string stored on-chain."""
    payload = {"docker_image": docker_image}
    if metadata:
        payload["metadata"] = metadata
    return json.dumps(payload, separators=(",", ":"))


def decode_commitment(raw: str, hotkey: str, uid: int, block: int = 0) -> Optional[MinerCommitment]:
    """Parse a raw on-chain commitment string into a ``MinerCommitment``.

    Returns ``None`` (and logs a warning) if the blob is malformed.
    """
    try:
        data = json.loads(raw)
    except (json.JSONDecodeError, TypeError):
        logger.warning("Malformed commitment from uid=%d hotkey=%s", uid, hotkey)
        return None

    docker_image = data.get("docker_image")
    if not docker_image:
        logger.warning("Commitment missing docker_image: uid=%d hotkey=%s", uid, hotkey)
        return None

    if not _DOCKER_IMAGE_RE.match(docker_image) or len(docker_image) > 255:
        logger.warning(
            "Invalid docker_image format from uid=%d hotkey=%s: %.80s",
            uid, hotkey, docker_image,
        )
        return None

    return MinerCommitment(
        hotkey=hotkey,
        uid=uid,
        docker_image=docker_image,
        metadata=data.get("metadata", {}),
        block_committed=block,
    )


# ── Chain reads ─────────────────────────────────────────────────────────


def _read_commitments_batch(subtensor, netuid: int, uids: List[int]) -> Dict[int, Optional[str]]:
    """Batch-read commitments for multiple UIDs to reduce RPC calls.

    Tries multiple approaches:
    1. subtensor.query_batch (if available) for efficient multi-query
    2. Substrate batch query via query_multi
    3. Falls back to individual queries

    Returns dict mapping uid -> raw commitment string (or None if no commitment).
    """
    results: Dict[int, Optional[str]] = {uid: None for uid in uids}

    # Try substrate query_multi (most efficient batch method)
    substrate = getattr(subtensor, "substrate", None)
    if substrate is not None and hasattr(substrate, "query_multi"):
        try:
            # Build storage keys for all UIDs
            storage_keys = []
            for uid in uids:
                storage_keys.append(
                    substrate.create_storage_key(
                        "Commitments", "CommitmentOf", [netuid, uid]
                    )
                )

            # Execute batch query
            batch_results = substrate.query_multi(storage_keys)

            for uid, (_, result) in zip(uids, batch_results):
                if result and result.value:
                    val = result.value
                    if isinstance(val, bytes):
                        results[uid] = val.decode("utf-8", errors="replace")
                    elif isinstance(val, str):
                        results[uid] = val

            logger.debug("Batch-read %d commitments via query_multi", len(uids))
            return results
        except Exception as e:
            logger.debug("query_multi not available or failed: %s", e)

    # Fallback: individual queries (still needed for SDK compatibility)
    logger.debug("Falling back to individual commitment queries for %d UIDs", len(uids))
    for uid in uids:
        results[uid] = _read_commitment_for_uid(subtensor, netuid, uid)

    return results


def _read_commitment_for_uid(subtensor, netuid: int, uid: int) -> Optional[str]:
    """Read a single commitment from chain, trying multiple SDK API patterns.

    The bittensor SDK API varies across versions:
    - ``subtensor.get_commitment(netuid, uid)`` (v6+)
    - ``subtensor.query_subtensor("Commitments", ...)`` (older versions)
    - Direct substrate query as fallback

    Returns the raw commitment string, or ``None`` if no commitment exists.
    """
    # Try the high-level API first (bittensor >= 6.x)
    if hasattr(subtensor, "get_commitment"):
        try:
            raw = subtensor.get_commitment(netuid=netuid, uid=uid)
            if raw:
                return raw
        except Exception:
            pass

    # Fallback: query the Commitments storage map directly
    try:
        result = subtensor.query_module(
            module="Commitments",
            name="CommitmentOf",
            params=[netuid, uid],
        )
        if result and hasattr(result, "value"):
            val = result.value
            # The value may be bytes or a hex-encoded string
            if isinstance(val, bytes):
                return val.decode("utf-8", errors="replace")
            if isinstance(val, str):
                return val
    except Exception:
        pass

    # Final fallback: substrate.query via subtensor.substrate
    try:
        substrate = getattr(subtensor, "substrate", None)
        if substrate is not None:
            result = substrate.query(
                module="Commitments",
                storage_function="CommitmentOf",
                params=[netuid, uid],
            )
            if result and result.value:
                val = result.value
                if isinstance(val, bytes):
                    return val.decode("utf-8", errors="replace")
                return str(val)
    except Exception:
        pass

    return None


def read_miner_commitments(subtensor, netuid: int) -> List[MinerCommitment]:
    """Read all miner commitments from the metagraph.

    Uses batch queries where possible to minimize chain RPC calls
    (reduces N+1 query pattern to ~1-2 queries total).

    Args:
        subtensor: A ``bittensor.Subtensor`` instance.
        netuid: The subnet UID to query.

    Returns:
        List of parsed ``MinerCommitment`` objects (skips malformed).
    """
    commitments: List[MinerCommitment] = []
    try:
        metagraph = subtensor.metagraph(netuid=netuid)
    except Exception:
        logger.exception("Failed to fetch metagraph for netuid=%d", netuid)
        return commitments

    n_uids = metagraph.n.item()
    block_num = metagraph.block.item()
    all_uids = list(range(n_uids))

    # Batch-read all commitments to avoid N+1 query pattern
    raw_commitments = _read_commitments_batch(subtensor, netuid, all_uids)

    for uid in all_uids:
        hotkey = metagraph.hotkeys[uid]
        raw = raw_commitments.get(uid)
        if not raw:
            continue

        commitment = decode_commitment(
            raw,
            hotkey=hotkey,
            uid=uid,
            block=block_num,
        )
        if commitment is not None:
            commitments.append(commitment)

    logger.info(
        "Read %d valid commitments from %d UIDs on netuid=%d",
        len(commitments), n_uids, netuid,
    )
    return commitments
