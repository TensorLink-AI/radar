"""
Bittensor chain interface.

Thin wrapper around ``bittensor.Subtensor`` for the operations the
validator needs: reading the metagraph, fetching miner commitments,
and setting weights.
"""

from __future__ import annotations

import logging
from typing import Dict, List, Optional

from subnet.config import SubnetConfig
from subnet.protocol.commitment import read_miner_commitments
from subnet.protocol.types import MinerCommitment

logger = logging.getLogger(__name__)


class ChainInterface:
    """Lazy-initialised Bittensor chain connection.

    Attributes:
        subtensor: The underlying ``bittensor.Subtensor`` instance
                   (created on first access).
        wallet:    The validator's ``bittensor.Wallet``.
    """

    def __init__(self) -> None:
        self._subtensor = None
        self._wallet = None

    # ── lazy properties ─────────────────────────────────────────────

    @property
    def subtensor(self):
        if self._subtensor is None:
            import bittensor as bt  # type: ignore[import-untyped]

            network = SubnetConfig.SUBTENSOR_NETWORK
            address = SubnetConfig.SUBTENSOR_ADDRESS or None
            self._subtensor = bt.Subtensor(network=network, chain_endpoint=address)
            logger.info("Connected to subtensor network=%s", network)
        return self._subtensor

    @property
    def wallet(self):
        if self._wallet is None:
            import bittensor as bt  # type: ignore[import-untyped]

            self._wallet = bt.Wallet(
                name=SubnetConfig.WALLET_NAME,
                hotkey=SubnetConfig.HOTKEY_NAME,
            )
        return self._wallet

    # ── reads ───────────────────────────────────────────────────────

    def read_commitments(self) -> List[MinerCommitment]:
        """Fetch all miner commitments from chain for our netuid."""
        return read_miner_commitments(self.subtensor, SubnetConfig.NETUID)

    def get_metagraph(self):
        """Return the current metagraph snapshot."""
        return self.subtensor.metagraph(netuid=SubnetConfig.NETUID)

    # ── writes ──────────────────────────────────────────────────────

    def set_weights(self, uids: List[int], weights: List[float]) -> bool:
        """Submit normalised weights to chain (blocking).

        Args:
            uids: Miner UIDs.
            weights: Corresponding weights (must sum to 1.0).

        Returns:
            ``True`` if the extrinsic succeeded.

        Note:
            This is a blocking call (``wait_for_inclusion=True``).
            Use ``set_weights_async`` from async contexts to avoid
            blocking the event loop.
        """
        import torch

        success, msg = self.subtensor.set_weights(
            netuid=SubnetConfig.NETUID,
            wallet=self.wallet,
            uids=torch.tensor(uids, dtype=torch.int64),
            weights=torch.tensor(weights, dtype=torch.float32),
            wait_for_inclusion=True,
        )
        if success:
            logger.info("Weights committed: %d UIDs", len(uids))
        else:
            logger.error("Weight submission failed: %s", msg)
        return success

    async def set_weights_async(self, uids: List[int], weights: List[float]) -> bool:
        """Async wrapper around ``set_weights`` that offloads the
        blocking chain call to a thread pool.
        """
        import asyncio

        return await asyncio.to_thread(self.set_weights, uids, weights)
