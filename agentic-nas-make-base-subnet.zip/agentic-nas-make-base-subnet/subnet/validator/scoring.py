"""
Scoring and weight computation.

Converts per-epoch ``CandidateResult`` metrics into normalised
weights suitable for ``subtensor.set_weights()``.

Design principles (from CLAUDE.md § 11):
  - EMA for reputation over time.
  - Softmax normalisation with tuneable temperature.
  - Penalty exponent to exponentially discourage failures.
  - Weights sum to 1.0.
  - Only active UIDs receive weights (stale UIDs are pruned).
"""

from __future__ import annotations

import math
import logging
from typing import Dict, List, Set

from subnet.config import SubnetConfig
from subnet.protocol.types import CandidateResult

logger = logging.getLogger(__name__)

# Maximum epochs a UID can be absent before being pruned from EMA tracking
MAX_ABSENT_EPOCHS = 10


def compute_weights(
    results: List[CandidateResult],
    ema_scores: Dict[int, float],
    absent_counts: Dict[int, int] | None = None,
) -> Dict[int, float]:
    """Compute normalised weights from this epoch's results.

    Args:
        results: Finalist candidates with populated ``test_loss``.
        ema_scores: Mutable dict of uid → EMA score, updated in-place.
            Scores are stored as *positive* values where higher = better.
        absent_counts: Mutable dict tracking consecutive absent epochs per UID.
            UIDs exceeding MAX_ABSENT_EPOCHS are pruned. If None, pruning is disabled.

    Returns:
        Dict mapping uid → weight (summing to 1.0).
        Only includes UIDs that participated this epoch.
    """
    alpha = SubnetConfig.EMA_ALPHA

    # 1. Compute raw epoch score per uid
    # Transform loss to positive score: score = 1 / (1 + loss)
    # This maps loss ∈ [0, ∞) to score ∈ (0, 1] where lower loss = higher score
    epoch_scores: Dict[int, float] = {}
    active_uids: Set[int] = set()

    for r in results:
        loss = r.test_loss if r.test_loss is not None else float("inf")
        if math.isfinite(loss) and loss >= 0:
            # Transform to positive score: better loss (lower) -> higher score
            score = 1.0 / (1.0 + loss)
        else:
            # Invalid/infinite loss gets minimum score
            score = 1e-8
        epoch_scores[r.uid] = score
        r.final_score = score
        active_uids.add(r.uid)

    # 2. EMA update for active UIDs
    for uid, score in epoch_scores.items():
        prev = ema_scores.get(uid, score)  # Initialize with current score if new
        ema_scores[uid] = alpha * score + (1.0 - alpha) * prev

    # Reset absent count for active UIDs
    if absent_counts is not None:
        for uid in active_uids:
            absent_counts[uid] = 0

    # 3. Decay absent UIDs and track absence duration
    absent_uids = set(ema_scores.keys()) - active_uids
    if absent_uids:
        decay_factor = 1.0 - alpha
        uids_to_prune: List[int] = []

        for uid in absent_uids:
            ema_scores[uid] *= decay_factor

            if absent_counts is not None:
                absent_counts[uid] = absent_counts.get(uid, 0) + 1
                if absent_counts[uid] > MAX_ABSENT_EPOCHS:
                    uids_to_prune.append(uid)

        # Prune UIDs that have been absent too long
        for uid in uids_to_prune:
            del ema_scores[uid]
            if absent_counts is not None:
                del absent_counts[uid]

        if uids_to_prune:
            logger.info(
                "Pruned %d stale UIDs (absent > %d epochs)",
                len(uids_to_prune), MAX_ABSENT_EPOCHS,
            )

        logger.debug(
            "Decayed EMA for %d absent UIDs (factor=%.3f)",
            len(absent_uids) - len(uids_to_prune), decay_factor,
        )

    # 4. Only compute weights for ACTIVE UIDs this epoch
    # This prevents stale miners from diluting weight allocation
    if not active_uids:
        logger.warning("No active UIDs this epoch - returning empty weights")
        return {}

    active_ema = {uid: ema_scores[uid] for uid in active_uids if uid in ema_scores}

    # 5. Compute log-scores and apply penalty exponent as a scaling factor.
    # Using log(ema) * exp / temp as the softmax input avoids the confounded
    # double-nonlinear of ema^exp followed by softmax.  The penalty exponent
    # now acts as a sharpening factor on the log-scale, making its
    # interaction with temperature explicit: effective_sharpness = exp / temp.
    exp = SubnetConfig.PENALTY_EXPONENT
    temp = SubnetConfig.SOFTMAX_TEMPERATURE

    if not active_ema:
        return {}

    log_scores: Dict[int, float] = {}
    for uid, ema in active_ema.items():
        log_scores[uid] = math.log(max(ema, 1e-10)) * exp / temp

    # 6. Softmax normalisation
    max_val = max(log_scores.values())
    exp_vals = {uid: math.exp(v - max_val) for uid, v in log_scores.items()}
    total = sum(exp_vals.values()) or 1.0
    weights = {uid: v / total for uid, v in exp_vals.items()}

    logger.info(
        "Weights computed for %d active UIDs (max=%.4f, min=%.4f)",
        len(weights),
        max(weights.values(), default=0),
        min(weights.values(), default=0),
    )
    return weights
