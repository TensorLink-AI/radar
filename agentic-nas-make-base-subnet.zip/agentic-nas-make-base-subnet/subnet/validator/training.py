"""
Phase 3 – Validation: two-stage deep training funnel.

Each surviving candidate from Phase 2 goes through two training rounds
on the validator's **trusted image** (never the miner's container):

    Phase 3a  Short training   – cheap elimination round.  All proxy-
              filtered candidates are batch-trained with ``small_budget``.
              Top M survivors (by test loss) advance.

    Phase 3b  Long training    – full training round.  Phase 3a survivors
              are batch-trained with ``large_budget``.  Top L finalists
              (by test loss) advance to Phase 4 scoring.

The **best absolute parent** (the highest-ranked existing model from the
DB) is injected into both rounds as a baseline.  It trains alongside
miner submissions but is excluded from weight allocation — it serves
only as a reference point so we can tell whether new submissions
actually improve on the state of the art.

All candidates in each round are trained **concurrently on a single GPU**
using CUDA streams (``batch_train_streams``).  Falls back to multi-pod
training if ``TRAINING_USE_STREAMS=0``.
"""

from __future__ import annotations

import logging
import os
import uuid
from typing import Any, Dict, List, Optional

from subnet.config import SubnetConfig
from subnet.protocol.types import CandidateResult

logger = logging.getLogger(__name__)

# Sentinel UID for the injected parent baseline.
# Uses a negative UID so it never collides with real miner UIDs.
_PARENT_BASELINE_UID = -1
_PARENT_BASELINE_HOTKEY = "__parent_baseline__"


# ── Public entry ──────────────────────────────────────────────────────


async def run_training_phase(
    candidates: List[CandidateResult],
    *,
    parent_code: Optional[str] = None,
    parent_name: Optional[str] = None,
) -> List[CandidateResult]:
    """Two-stage training funnel: short round then long round.

    Args:
        candidates: Proxy-filtered candidates from Phase 2.
        parent_code: Source code of the best absolute parent from the
            DB.  Injected as a baseline into both rounds when
            ``INJECT_BEST_PARENT`` is enabled.
        parent_name: Human-readable name for the parent baseline.

    Returns:
        Top L finalists (excluding the parent baseline) for Phase 4.
    """
    if not candidates:
        return []

    # Build parent baseline candidate (if configured)
    parent_baseline: Optional[CandidateResult] = None
    if SubnetConfig.INJECT_BEST_PARENT and parent_code:
        parent_baseline = CandidateResult(
            hotkey=_PARENT_BASELINE_HOTKEY,
            uid=_PARENT_BASELINE_UID,
            name=parent_name or "parent_baseline",
            motivation="Best absolute parent – injected as baseline",
            model_code=parent_code,
        )
        logger.info(
            "Injecting parent baseline (%s) into training rounds",
            parent_baseline.name,
        )

    # ── Phase 3a: Short training round ────────────────────────────────
    logger.info(
        "[Phase 3a] Short training: %d candidates (budget=small_budget)",
        len(candidates),
    )
    short_survivors = await _run_training_round(
        candidates=candidates,
        parent_baseline=parent_baseline,
        budget="small_budget",
        budget_tier="small",
        timeout_sec=SubnetConfig.SHORT_TRAIN_TIMEOUT_SEC,
        top_n=SubnetConfig.SHORT_TRAIN_TOP_M,
        round_label="3a-short",
    )

    if not short_survivors:
        logger.warning("No candidates survived short training")
        return []

    # ── Phase 3b: Long training round ─────────────────────────────────
    logger.info(
        "[Phase 3b] Long training: %d candidates (budget=large_budget)",
        len(short_survivors),
    )
    finalists = await _run_training_round(
        candidates=short_survivors,
        parent_baseline=parent_baseline,
        budget="large_budget",
        budget_tier="large",
        timeout_sec=SubnetConfig.DEEP_TRAIN_TIMEOUT_SEC,
        top_n=SubnetConfig.DEEP_TRAIN_TOP_L,
        round_label="3b-long",
    )

    logger.info(
        "Training funnel: %d → %d → %d finalists",
        len(candidates), len(short_survivors), len(finalists),
    )
    return finalists


# ── Single training round ─────────────────────────────────────────────


async def _run_training_round(
    candidates: List[CandidateResult],
    parent_baseline: Optional[CandidateResult],
    budget: str,
    budget_tier: str,
    timeout_sec: int,
    top_n: int,
    round_label: str,
) -> List[CandidateResult]:
    """Train a batch of candidates and return top N by test loss.

    The parent baseline (if provided) is included in training but
    excluded from the returned list — it only participates to
    establish a reference loss level.
    """
    from services.eval.remote_training.remote_types import TrainingStatus

    # Build the full batch: candidates + optional parent baseline
    batch = list(candidates)
    parent_idx: Optional[int] = None
    if parent_baseline is not None:
        parent_idx = len(batch)
        batch.append(parent_baseline)

    client = _build_training_client(timeout_sec)
    use_streams = os.getenv("TRAINING_USE_STREAMS", "1") != "0"

    if use_streams:
        results = await _batch_train_via_streams(
            client, batch, budget, budget_tier, timeout_sec,
        )
    else:
        results = await _batch_train_via_pods(
            client, batch, budget, budget_tier, timeout_sec,
        )

    # Map results back to candidates
    if len(results) != len(batch):
        logger.warning(
            "[%s] Training returned %d results for %d candidates – "
            "missing candidates will be marked as failed",
            round_label, len(results), len(batch),
        )

    trained: List[CandidateResult] = []
    parent_loss: Optional[float] = None

    for i, candidate in enumerate(batch):
        if i < len(results):
            result = results[i]
        else:
            # Basilica returned fewer results than expected –
            # treat this candidate as a failure rather than silently dropping it
            from services.eval.remote_training.remote_types import TrainingResult
            logger.error(
                "[%s] uid=%d (%s) has no result from training backend "
                "(index %d >= %d results returned)",
                round_label, candidate.uid, candidate.name,
                i, len(results),
            )
            result = TrainingResult(
                job_id="",
                status=TrainingStatus.FAILED,
                metrics={},
                stdout_tail="No result returned from training backend",
                budget_tier=budget_tier,
                wall_time_sec=0.0,
            )
        metrics: Dict[str, Any] = result.metrics.copy() if result.metrics else {}

        if result.status != TrainingStatus.SUCCEEDED:
            logger.warning(
                "[%s] uid=%d (%s) did not succeed: %s (logs: %s)",
                round_label, candidate.uid, candidate.name,
                result.status.value,
                (result.stdout_tail or "")[:300],
            )
            metrics.setdefault("train_loss", None)
            metrics.setdefault("test_loss", None)
            metrics["training_status"] = result.status.value
            metrics["stdout_tail"] = result.stdout_tail
        else:
            logger.info(
                "[%s] uid=%d (%s): status=%s wall=%.1fs test_loss=%s",
                round_label, candidate.uid, candidate.name,
                result.status.value, result.wall_time_sec,
                metrics.get("test_loss", "?"),
            )
            metrics.setdefault("train_loss", None)
            metrics.setdefault("test_loss", None)

        candidate.train_metrics = metrics
        candidate.train_loss = metrics.get("train_loss")
        candidate.test_loss = metrics.get("test_loss")

        # Track parent baseline loss separately
        if i == parent_idx:
            parent_loss = candidate.test_loss
            logger.info(
                "[%s] Parent baseline test_loss=%.6f",
                round_label,
                parent_loss if parent_loss is not None else float("inf"),
            )
        else:
            trained.append(candidate)

    # Sort by test loss ascending (lower = better)
    trained.sort(
        key=lambda r: r.test_loss if r.test_loss is not None else float("inf"),
    )

    # Keep top N
    top = trained[:top_n]

    best_loss = top[0].test_loss if top and top[0].test_loss is not None else float("inf")
    logger.info(
        "[%s] %d → %d survivors (best=%.6f, parent=%.6f)",
        round_label, len(trained), len(top),
        best_loss,
        parent_loss if parent_loss is not None else float("inf"),
    )
    return top


# ── Training strategies ────────────────────────────────────────────────


async def _batch_train_via_streams(
    client: Any,
    candidates: List[CandidateResult],
    budget: str,
    budget_tier: str,
    timeout_sec: int,
) -> list:
    """Deploy one pod and train all candidates via CUDA streams."""
    model_codes = [c.model_code for c in candidates]

    logger.info(
        "Submitting CUDA-streams batch training for %d candidates "
        "(budget=%s) on a single pod",
        len(candidates), budget,
    )

    return await client.batch_train_streams(
        model_codes,
        budget_tier=budget_tier,
        timeout_sec=float(timeout_sec),
        metadata={
            "task": SubnetConfig.TASK_NAME,
            "eval_type": budget,
        },
    )


async def _batch_train_via_pods(
    client: Any,
    candidates: List[CandidateResult],
    budget: str,
    budget_tier: str,
    timeout_sec: int,
) -> list:
    """Deploy N pods (one per candidate) via ``batch_train``."""
    from services.eval.remote_training.remote_types import (
        TrainingJobSpec,
        TrainingJobMetadata,
    )

    specs = []
    for candidate in candidates:
        spec = TrainingJobSpec(
            metadata=TrainingJobMetadata(
                task=SubnetConfig.TASK_NAME,
                eval_type=budget,
            ),
            dataset_spec={},
            model_code_content=candidate.model_code,
            job_id=uuid.uuid4().hex,
            budget_tier=budget_tier,
            timeout_sec=float(timeout_sec),
        )
        specs.append(spec)

    logger.info(
        "Submitting multi-pod batch training for %d candidates (budget=%s, "
        "max_concurrent=%d)",
        len(candidates), budget, SubnetConfig.MAX_CONCURRENT_TRAINING_PODS,
    )

    return await client.batch_train(
        specs,
        max_concurrency=SubnetConfig.MAX_CONCURRENT_TRAINING_PODS,
    )


# ── Client construction ───────────────────────────────────────────────


def _build_training_client(timeout_sec: int | None = None) -> Any:
    """Construct a BasilicaTrainingClient for deep training."""
    from services.eval.remote_training.client import BasilicaTrainingClient

    docker_image = SubnetConfig.DEEP_TRAIN_IMAGE
    if not docker_image:
        raise RuntimeError(
            "DEEP_TRAIN_IMAGE must be set to the validator's trusted training "
            "Docker image.  Build and push the image from "
            "services/eval/remote_training/basilica/Dockerfile, then set "
            "the DEEP_TRAIN_IMAGE environment variable."
        )

    effective_timeout = timeout_sec or SubnetConfig.DEEP_TRAIN_TIMEOUT_SEC

    return BasilicaTrainingClient(
        api_token=SubnetConfig.BASILICA_API_TOKEN or None,
        docker_image=docker_image,
        gpu_type=SubnetConfig.BASILICA_GPU_TYPE or None,
        gpu_count=SubnetConfig.BASILICA_GPU_COUNT,
        gpu_memory_gb=SubnetConfig.BASILICA_GPU_MEMORY_GB,
        memory=SubnetConfig.BASILICA_MEMORY,
        ttl_small=effective_timeout,
        ttl_large=int(effective_timeout * 1.2),
        max_poll_seconds=effective_timeout + 600,
        validate_credentials=True,
    )
