"""
Main validator – 24-hour epoch loop.

This is the single entry-point that orchestrates the four phases
described in the subnet design:

    Phase 1  Generation   – select challenge, spin up miner pods,
                            collect submissions.
    Phase 2  Filtering    – lineage check (CPU) + AZNAS proxy eval
                            (Basilica pod), keep top K.
    Phase 3a Short train  – small_budget training, keep top M.
    Phase 3b Long train   – large_budget training, keep top L.
             (best absolute parent injected as baseline in both rounds)
    Phase 4  Profiling    – analyse results, write to DB / R2,
                            set weights on chain.

Usage:
    python -m subnet.validator.validator
"""

from __future__ import annotations

import asyncio
import json
import logging
import math
import os
import time
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

import aiohttp

from subnet.config import SubnetConfig
from subnet.protocol.types import (
    CandidateResult,
    EpochState,
    MinerCommitment,
    MinerSubmission,
)
from subnet.validator.chain import ChainInterface
from subnet.validator.miner_runner import run_generation_phase, select_challenge_type
from subnet.validator.filtering import run_filtering_phase
from subnet.validator.training import run_training_phase
from subnet.validator.scoring import compute_weights
from subnet.validator.weights import set_weights_on_chain

logger = logging.getLogger(__name__)

# ── EMA persistence ────────────────────────────────────────────────────

_EMA_STATE_DIR = os.getenv("VALIDATOR_STATE_DIR", "validator_state")
_EMA_STATE_FILE = "ema_scores.json"


def _load_ema_scores(state_dir: str = _EMA_STATE_DIR) -> Dict[int, float]:
    """Load EMA scores from disk.  Returns empty dict if missing/corrupt."""
    path = Path(state_dir) / _EMA_STATE_FILE
    if not path.exists():
        return {}
    try:
        with open(path, "r", encoding="utf-8") as f:
            raw = json.load(f)
        # JSON keys are strings – convert back to int.
        # Parse entries individually so one corrupt entry doesn't
        # reset all scores.
        scores: Dict[int, float] = {}
        skipped = 0
        for k, v in raw.items():
            try:
                uid = int(k)
                score = float(v)
                if not (math.isfinite(score) and score >= 0):
                    skipped += 1
                    continue
                scores[uid] = score
            except (ValueError, TypeError):
                skipped += 1
        if skipped:
            logger.warning(
                "Skipped %d corrupt entries while loading EMA scores from %s",
                skipped, path,
            )
        return scores
    except Exception:
        logger.warning("Could not load EMA scores from %s – starting fresh", path)
        return {}


def _save_ema_scores(
    scores: Dict[int, float], state_dir: str = _EMA_STATE_DIR
) -> None:
    """Persist EMA scores to disk."""
    path = Path(state_dir) / _EMA_STATE_FILE
    path.parent.mkdir(parents=True, exist_ok=True)
    try:
        with open(path, "w", encoding="utf-8") as f:
            json.dump({str(k): v for k, v in scores.items()}, f, indent=2)
    except Exception:
        logger.exception("Failed to save EMA scores to %s", path)


class Validator:
    """Orchestrates the full epoch loop.

    Lifecycle:
        1. ``__init__``  – connect to chain, load metagraph.
        2. ``run``       – infinite loop, one epoch per iteration.
        3. Each epoch    – phases 1-4, then sleep until next epoch.
    """

    def __init__(self) -> None:
        self.chain = ChainInterface()
        self.epoch: int = 0
        # uid -> EMA score (persisted across epochs)
        self.ema_scores: Dict[int, float] = _load_ema_scores()
        if self.ema_scores:
            logger.info(
                "Loaded EMA scores for %d UIDs from disk", len(self.ema_scores)
            )

    # ── public entry ────────────────────────────────────────────────

    async def run(self) -> None:
        """Run the validator indefinitely (one epoch per iteration)."""
        logger.info("Validator starting on netuid=%d", SubnetConfig.NETUID)

        while True:
            epoch_start = time.time()
            try:
                await self._run_epoch()
            except Exception:
                logger.exception("Epoch %d failed", self.epoch)

            self.epoch += 1
            elapsed = time.time() - epoch_start
            sleep_sec = max(0, SubnetConfig.EPOCH_LENGTH_SECONDS - elapsed)
            if sleep_sec > 0:
                logger.info("Epoch done. Sleeping %.0fs until next epoch.", sleep_sec)
                await asyncio.sleep(sleep_sec)

    # ── private epoch logic ─────────────────────────────────────────

    async def _run_epoch(self) -> None:
        state = EpochState(epoch=self.epoch)

        # ── Pre-phase: select challenge type + sample parent pool ──
        challenge_type = select_challenge_type(self.epoch)
        state.challenge_type = challenge_type
        state.constraints = SubnetConfig.get_constraints()

        best_parent_code, best_parent_name, context = await self._sample_best_parent()

        # Load the task definition and scaffold so miners receive the
        # full task contract rather than just a task name string.
        task_definition, scaffold_code = self._load_task_spec()

        logger.info(
            "[Epoch %d] Challenge: %s | Constraints: %s | Best parent: %s",
            self.epoch,
            challenge_type or "(open)",
            state.constraints,
            best_parent_name or "(none)",
        )

        # ── Phase 1: Generation ────────────────────────────────────
        logger.info("[Epoch %d] Phase 1: Generation", self.epoch)
        commitments: List[MinerCommitment] = self.chain.read_commitments()
        state.commitments = commitments

        submissions: List[MinerSubmission] = await run_generation_phase(
            commitments=commitments,
            epoch=self.epoch,
            keypair=self.chain.wallet.hotkey,
            challenge_type=challenge_type,
            context=context,
            task_definition=task_definition,
            scaffold_code=scaffold_code,
        )
        state.submissions = submissions
        logger.info(
            "Received %d submissions from %d miners",
            len(submissions), len(commitments),
        )

        if not submissions:
            logger.warning("No submissions this epoch -- skipping phases 2-4")
            return

        # ── Phase 2: Filtering (zero-cost proxy + constraints) ─────
        logger.info(
            "[Epoch %d] Phase 2: Filtering (%d candidates)",
            self.epoch, len(submissions),
        )
        results: List[CandidateResult] = await run_filtering_phase(
            submissions, constraints=state.constraints,
        )
        state.results = results  # Preserve Phase 2 results (all filtered candidates)
        logger.info(
            "Filtered to %d candidates after zero-cost proxy",
            len(results),
        )

        if not results:
            logger.warning("No candidates passed zero-cost filter")
            return

        # ── Phase 3: Validation (two-stage deep training) ─────────
        logger.info(
            "[Epoch %d] Phase 3: Validation (top %d, short→long funnel)",
            self.epoch, len(results),
        )
        finalists: List[CandidateResult] = await run_training_phase(
            results,
            parent_code=best_parent_code,
            parent_name=best_parent_name,
        )
        logger.info("%d finalists after deep training", len(finalists))

        # ── Phase 4: Profiling & Consensus ─────────────────────────
        logger.info("[Epoch %d] Phase 4: Profiling & consensus", self.epoch)

        # 4a. Analyse finalists (Analyzer agent + Chutes/Desearch)
        await self._analyse_finalists(finalists, context)

        # 4b. Write results to DB / R2
        await self._persist_results(finalists, state)

        # 4c. Compute and submit weights
        weights = compute_weights(
            results=finalists,
            ema_scores=self.ema_scores,
        )
        state.weights = weights

        # Persist EMA scores after every epoch
        _save_ema_scores(self.ema_scores)

        await set_weights_on_chain(
            chain=self.chain,
            weights=weights,
        )
        logger.info("Weights set for %d UIDs", len(weights))

    # ── Helper: parent pool sampling ────────────────────────────────

    async def _sample_best_parent(self) -> tuple:
        """Fetch the best parent model and reference context from the DB.

        The best parent is used for baseline injection in Phase 3
        (training).  Reference experiments are sampled for the
        challenge context sent to miners.

        Returns:
            (best_parent_code, best_parent_name, context) where:
            - best_parent_code: source code of the top-ranked model
            - best_parent_name: human-readable name
            - context: experimental evidence portfolio
        """
        logger.debug("Sampling best parent + context (pool_size=%d)", SubnetConfig.PARENT_POOL_SIZE)

        db_url = SubnetConfig.DATABASE_URL.rstrip("/")
        pool_size = SubnetConfig.PARENT_POOL_SIZE
        task_name = SubnetConfig.TASK_NAME

        try:
            async with aiohttp.ClientSession() as session:
                # Fetch top-ranked model (for baseline injection)
                async with session.get(
                    f"{db_url}/sample",
                    params={
                        "rank_start": 1,
                        "rank_end": 10,
                        "count": 1,
                        "task": task_name,
                    },
                    timeout=aiohttp.ClientTimeout(total=30),
                ) as resp:
                    if resp.status == 200:
                        parent_candidates = await resp.json()
                    else:
                        logger.warning(
                            "DB parent sample returned %d", resp.status
                        )
                        parent_candidates = []

                # Fetch reference experiments for context
                async with session.get(
                    f"{db_url}/sample",
                    params={
                        "rank_start": 1,
                        "rank_end": 50,
                        "count": pool_size,
                        "task": task_name,
                    },
                    timeout=aiohttp.ClientTimeout(total=30),
                ) as resp:
                    if resp.status == 200:
                        ref_elements = await resp.json()
                    else:
                        ref_elements = []

        except Exception:
            logger.exception("Failed to sample best parent from DB")
            return None, None, ""

        # Extract best parent for baseline injection
        best_parent_code: Optional[str] = None
        best_parent_name: Optional[str] = None
        context_parts: List[str] = []

        if parent_candidates:
            parent = parent_candidates[0]
            best_parent_code = parent.get("program")
            best_parent_name = parent.get("name", "unknown")
            context_parts.append(
                f"## Best model: {best_parent_name}\n"
                f"Motivation: {parent.get('motivation', '')}\n"
                f"Result: {json.dumps(parent.get('result', {}))}\n"
            )

        for ref in ref_elements:
            context_parts.append(
                f"## Reference: {ref.get('name', 'unknown')}\n"
                f"Motivation: {ref.get('motivation', '')}\n"
                f"Result: {json.dumps(ref.get('result', {}))}\n"
            )

        context = "\n".join(context_parts)
        return best_parent_code, best_parent_name, context

    # ── Helper: load task specification for miners ──────────────────

    def _load_task_spec(self) -> tuple:
        """Load the TaskDefinition and scaffold source for the active task.

        Returns:
            (task_definition_dict, scaffold_code) where:
            - task_definition_dict: serialised TaskDefinition (or empty dict)
            - scaffold_code: scaffold file contents (or None)
        """
        task_definition: Dict[str, Any] = {}
        scaffold_code: Optional[str] = None

        try:
            from core.tasks.registry import get_task

            task = get_task(SubnetConfig.TASK_NAME)
            task_definition = task.definition.to_dict()

            # Use get_scaffold_path() which resolves the relative path
            # to an absolute location (task subclasses may override).
            scaffold_path = task.get_scaffold_path()
            if scaffold_path:
                try:
                    with open(scaffold_path, "r", encoding="utf-8") as f:
                        scaffold_code = f.read()
                except FileNotFoundError:
                    logger.warning(
                        "Scaffold file not found at %s", scaffold_path,
                    )
        except Exception:
            logger.warning(
                "Could not load TaskDefinition for %s – "
                "miners will receive an empty task_definition",
                SubnetConfig.TASK_NAME,
                exc_info=True,
            )

        return task_definition, scaffold_code

    # ── Helper: Phase 4a – analysis ─────────────────────────────────

    async def _analyse_finalists(
        self,
        finalists: List[CandidateResult],
        context: str,
    ) -> None:
        """Run analysis on each finalist via the services analyse module.

        Populates ``finalist.analysis`` with structured JSON
        (metrics summary, recommendations, challenge coverage).

        Falls back to basic metrics dict if the services analyse module
        is unavailable (e.g. missing LLM API key).
        """
        for f in finalists:
            logger.debug("Analysing finalist uid=%d (%s)", f.uid, f.name)
            try:
                from services.analyse.interface import analyse as pipeline_analyse
                from services.eval import EvaluationArtifacts
                from core.tasks.registry import get_task

                task = get_task(SubnetConfig.TASK_NAME)

                # Build evaluation artifacts from candidate result
                artifacts = EvaluationArtifacts(
                    result={
                        "train": f"train_loss={f.train_loss}",
                        "test": f"test_loss={f.test_loss}",
                    },
                    logs=json.dumps(f.train_metrics),
                    candidate_code_path="",
                )

                data_element = await pipeline_analyse(
                    name=f.name or f"uid_{f.uid}",
                    motivation=f.motivation or "No motivation provided",
                    context=context,
                    parent=f.parent_id,
                    eval_type="large_budget",
                    run_id=None,
                    task=task,
                    evaluation_artifacts=artifacts,
                    program_text=f.model_code,
                )

                f.analysis = {
                    "analysis": data_element.analysis,
                    "cognition": data_element.cognition,
                    "challenges_addressed": data_element.challenges_addressed,
                    "summary": data_element.summary,
                }

            except ImportError as import_err:
                # Only catch the specific case where services.analyse is missing,
                # not import errors from transitive dependencies
                is_analyse_missing = (
                    "services.analyse" in str(import_err)
                    or (hasattr(import_err, "name") and import_err.name and "analyse" in import_err.name)
                )
                if is_analyse_missing:
                    logger.warning(
                        "services.analyse not available – using basic analysis "
                        "for uid=%d", f.uid,
                    )
                else:
                    # Re-raise import errors from other modules (real bugs)
                    raise
                f.analysis = {
                    "status": "basic",
                    "motivation": f.motivation,
                    "train_loss": f.train_loss,
                    "test_loss": f.test_loss,
                }
            except Exception:
                logger.exception(
                    "Analysis failed for uid=%d (%s) – using basic fallback",
                    f.uid, f.name,
                )
                f.analysis = {
                    "status": "error",
                    "motivation": f.motivation,
                    "train_loss": f.train_loss,
                    "test_loss": f.test_loss,
                }

    # ── Helper: Phase 4b – DB persistence ───────────────────────────

    async def _persist_results(
        self,
        finalists: List[CandidateResult],
        state: EpochState,
    ) -> None:
        """Write finalist models, logs, and analysis to the database.

        Posts each finalist as a DataElement-compatible dict to the
        MongoDB REST API at ``SubnetConfig.DATABASE_URL``.
        """
        logger.info(
            "Persisting %d finalists to DB (epoch=%d)",
            len(finalists), state.epoch,
        )

        db_url = SubnetConfig.DATABASE_URL.rstrip("/")

        try:
            async with aiohttp.ClientSession() as session:
                for f in finalists:
                    # Use per-finalist timestamp for accurate write times
                    current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                    # Schema must match DataElementRequest in database/mongodb_api.py
                    element = {
                        "time": current_time,
                        "name": f.name or f"uid_{f.uid}_epoch_{state.epoch}",
                        "result": {
                            "train": f"train_loss={f.train_loss}",
                            "test": f"test_loss={f.test_loss}",
                            "train_metrics": f.train_metrics,
                        },
                        "program": f.model_code,
                        "motivation": f.motivation or "",
                        "analysis": json.dumps(f.analysis) if f.analysis else "",
                        "cognition": "",
                        "log": json.dumps(f.train_metrics),
                        "task": SubnetConfig.TASK_NAME,
                        "parent": f.parent_id,
                        "architecture_keywords": [],
                        "summary": (f.motivation or "")[:200],
                    }

                    try:
                        async with session.post(
                            f"{db_url}/elements",
                            json=element,
                            timeout=aiohttp.ClientTimeout(total=30),
                        ) as resp:
                            if resp.status == 200:
                                logger.debug(
                                    "Persisted uid=%d (%s)", f.uid, f.name
                                )
                            else:
                                body = await resp.text()
                                logger.warning(
                                    "DB write failed for uid=%d: %d %s",
                                    f.uid, resp.status, body[:200],
                                )
                    except Exception:
                        logger.exception(
                            "HTTP error persisting uid=%d", f.uid
                        )
        except Exception:
            logger.exception("Failed to open DB session for persistence")


# ── CLI entry ───────────────────────────────────────────────────────────

def main() -> None:
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s %(name)s %(levelname)s %(message)s",
    )
    validator = Validator()
    asyncio.run(validator.run())


if __name__ == "__main__":
    main()
