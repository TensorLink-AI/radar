"""Subnet validator package.

Provides lazy access to ``Validator`` so that importing lightweight
sub-modules (``scoring``, ``lineage``, etc.) does not pull in heavy
dependencies like ``torch`` or ``aiohttp``.
"""

__all__ = ["Validator"]


def __getattr__(name: str):
    if name == "Validator":
        from subnet.validator.validator import Validator
        return Validator
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
