"""
Phase 4 – Weight submission to Bittensor chain.

After scoring, the validator submits normalised weights via
``subtensor.set_weights()``.  Weights must sum to 1.0 and respect
the chain's rate limit (``weights_rate_limit`` blocks between
successive submissions).
"""

from __future__ import annotations

import logging
from typing import Dict

from subnet.validator.chain import ChainInterface

logger = logging.getLogger(__name__)


async def set_weights_on_chain(
    chain: ChainInterface,
    weights: Dict[int, float],
) -> bool:
    """Submit weights to the Bittensor chain.

    Uses ``chain.set_weights_async`` to avoid blocking the event loop
    (``set_weights`` calls ``wait_for_inclusion=True`` which is
    a long-running synchronous chain RPC).

    Args:
        chain: Initialised ``ChainInterface``.
        weights: uid → weight mapping (must sum to ~1.0).

    Returns:
        ``True`` if the extrinsic succeeded.
    """
    if not weights:
        logger.warning("No weights to set – skipping chain submission")
        return False

    uids = sorted(weights.keys())
    vals = [weights[uid] for uid in uids]

    # Sanity: renormalise to exactly 1.0 in case of float drift
    total = sum(vals)
    if total > 0:
        vals = [v / total for v in vals]

    return await chain.set_weights_async(uids=uids, weights=vals)
