"""
Phase 1 – Generation: spin up miner pods and collect submissions.

For each active miner commitment the validator:
  1. Reads the challenge spec (type, constraints, parent pool) from config.
  2. Launches the miner's Docker image on Basilica via ``affinetes``.
  3. POSTs a ``Challenge`` (task + parent context + constraints).
  4. Waits for the miner agent to return a ``MinerSubmission``.
  5. Cleans up the environment.

Miner code is **never** executed locally.  All compute cost sits with
the miner's container on the Basilica cluster.

Pod lifecycle is managed by ``affinetes`` (``af.load_env`` /
``env.cleanup``) rather than the raw ``basilica-sdk``.
"""

from __future__ import annotations

import asyncio
import logging
from typing import Any, Dict, List, Optional

import aiohttp

from subnet.config import SubnetConfig
from subnet.protocol.epistula import build_headers
from subnet.protocol.types import (
    Challenge,
    MinerCommitment,
    MinerSubmission,
    SubmissionStatus,
)

logger = logging.getLogger(__name__)


# ── Public entry ────────────────────────────────────────────────────────


async def run_generation_phase(
    commitments: List[MinerCommitment],
    epoch: int,
    keypair: Any = None,
    challenge_type: str = "",
    context: str = "",
    task_definition: Optional[Dict[str, Any]] = None,
    scaffold_code: Optional[str] = None,
) -> List[MinerSubmission]:
    """Execute Phase 1 for all miners concurrently (bounded).

    Args:
        commitments: Active miner commitments from the metagraph.
        epoch: Current epoch number.
        keypair: The validator's ``bittensor.Keypair`` for Epistula
            signing.  Required for authenticating challenge requests
            to miner pods.
        challenge_type: Selected challenge category for this epoch
            (e.g. ``"long_range"``).  Empty = miner's choice.
        context: DB-sampled experimental evidence portfolio.
        task_definition: Serialised ``TaskDefinition`` dict giving
            miners the full task specification (description, metrics,
            budgets, dataset info, challenge categories, etc.).
        scaffold_code: Source code of the reference scaffold model
            so miners know the expected class structure and interface.

    Returns:
        List of successful ``MinerSubmission`` objects.
    """
    if keypair is None:
        raise ValueError(
            "keypair is required for Epistula-signed challenge requests. "
            "Pass chain.wallet.hotkey from the Validator."
        )

    sem = asyncio.Semaphore(SubnetConfig.MAX_CONCURRENT_MINER_PODS)

    # Build the challenge template (same for all miners this epoch)
    challenge_template = Challenge(
        task_name=SubnetConfig.TASK_NAME,
        challenge_type=challenge_type,
        constraints=SubnetConfig.get_constraints(),
        db_snapshot_url=SubnetConfig.DB_SNAPSHOT_URL,
        context=context,
        task_definition=task_definition or {},
        scaffold_code=scaffold_code,
        epoch=epoch,
    )

    # Create a shared HTTP session for all miners (more efficient than per-miner sessions)
    connector = aiohttp.TCPConnector(limit=SubnetConfig.MAX_CONCURRENT_MINER_PODS)
    async with aiohttp.ClientSession(connector=connector) as session:
        tasks = [
            _run_single_miner(commitment, challenge_template, sem, keypair, session)
            for commitment in commitments
        ]
        results = await asyncio.gather(*tasks, return_exceptions=True)

    submissions: List[MinerSubmission] = []
    for r in results:
        if isinstance(r, MinerSubmission) and r.status == SubmissionStatus.SUCCEEDED:
            submissions.append(r)
        elif isinstance(r, Exception):
            logger.error("Miner pod error: %s", r)
    logger.info(
        "Generation phase: %d/%d miners submitted successfully",
        len(submissions), len(commitments),
    )
    return submissions


def select_challenge_type(epoch: int) -> str:
    """Pick a challenge category for this epoch.

    Cycles through the configured categories deterministically
    (based on epoch number) so miners see a predictable rotation.
    Returns empty string if no categories are configured.
    """
    categories = SubnetConfig.get_challenge_categories()
    if not categories:
        return ""
    return categories[epoch % len(categories)]


# ── Single-miner lifecycle ──────────────────────────────────────────────


async def _run_single_miner(
    commitment: MinerCommitment,
    challenge: Challenge,
    sem: asyncio.Semaphore,
    keypair: Any = None,
    session: Optional[aiohttp.ClientSession] = None,
) -> MinerSubmission:
    """Spin up one miner pod, send challenge, collect result, tear down."""
    async with sem:
        env = None
        try:
            # 1. Launch miner container on Basilica via affinetes
            env = await _load_miner_env(commitment)

            # 2. POST challenge -> miner container
            raw = await _send_challenge(env.url, challenge, commitment, keypair, session)

            # 3. Parse + validate response
            submission = _parse_response(raw, commitment, challenge)
            return submission

        except Exception as exc:
            logger.warning(
                "Miner uid=%d hotkey=%s failed: %s",
                commitment.uid, commitment.hotkey, exc,
            )
            return MinerSubmission(
                hotkey=commitment.hotkey,
                uid=commitment.uid,
                model_code="",
                status=SubmissionStatus.FAILED,
            )
        finally:
            if env is not None:
                await _cleanup_env(env, commitment)


# ── Pod lifecycle (affinetes) ─────────────────────────────────────────


async def _load_miner_env(commitment: MinerCommitment) -> Any:
    """Deploy a miner container via ``affinetes`` and return the env.

    Uses the miner's committed Docker image.  The returned env object
    provides ``.url`` for HTTP access and ``.cleanup()`` for teardown.

    NOTE: af.load_env is a blocking call (network I/O), so we run it
    in a thread pool to avoid blocking the event loop.

    Args:
        commitment: Miner's on-chain commitment containing docker_image.

    Returns:
        An ``affinetes`` environment object.
    """
    try:
        import affinetes as af  # type: ignore[import-untyped]
    except ImportError:
        raise RuntimeError(
            "affinetes is not installed. Install with: pip install affinetes"
        )

    token = SubnetConfig.BASILICA_API_TOKEN
    if not token:
        raise RuntimeError(
            "BASILICA_API_TOKEN is required for miner pod management. "
            "Set it in your environment or .env file."
        )

    # Build env_vars to forward into the miner container
    env_vars: Dict[str, str] = {
        "PYTHONUNBUFFERED": "1",
    }
    if SubnetConfig.CHUTES_API_KEY:
        env_vars["CHUTES_API_KEY"] = SubnetConfig.CHUTES_API_KEY

    logger.info(
        "Loading miner env for uid=%d image=%s",
        commitment.uid, commitment.docker_image,
    )

    # af.load_env is synchronous/blocking - run in thread to avoid blocking event loop
    def _sync_load_env():
        return af.load_env(
            mode="basilica",
            image=commitment.docker_image,
            api_token=token,
            env_vars=env_vars,
            gpu_count=SubnetConfig.BASILICA_GPU_COUNT,
            min_gpu_memory_gb=SubnetConfig.BASILICA_GPU_MEMORY_GB,
            memory=SubnetConfig.BASILICA_MEMORY,
            ttl_seconds=SubnetConfig.MINER_POD_TIMEOUT_SEC + 300,
            timeout=900,
        )

    env = await asyncio.to_thread(_sync_load_env)

    logger.info("Miner env ready for uid=%d at %s", commitment.uid, env.url)
    return env


async def _cleanup_env(env: Any, commitment: MinerCommitment) -> None:
    """Tear down a miner environment after collecting its submission."""
    logger.debug("Cleaning up env for uid=%d", commitment.uid)
    try:
        # env.cleanup() may be sync or async - handle both
        if asyncio.iscoroutinefunction(env.cleanup):
            await env.cleanup()
        else:
            await asyncio.to_thread(env.cleanup)
        logger.debug("Env cleaned up for uid=%d", commitment.uid)
    except Exception:
        logger.warning(
            "Failed to clean up env for uid=%d (will expire via TTL)",
            commitment.uid,
            exc_info=True,
        )


# ── Challenge / response ────────────────────────────────────────────────


_CHALLENGE_MAX_RETRIES = 3
_CHALLENGE_RETRY_BACKOFF = [2, 4, 8]  # seconds


async def _send_challenge(
    pod_url: str,
    challenge: Challenge,
    commitment: MinerCommitment,
    keypair: Any = None,
    session: Optional[aiohttp.ClientSession] = None,
) -> Dict[str, Any]:
    """POST the challenge to the miner pod and return raw JSON.

    Uses Epistula headers so the miner can verify the caller is a
    registered validator.  Retries up to ``_CHALLENGE_MAX_RETRIES``
    times with exponential backoff on transient network errors.

    Args:
        pod_url: The miner pod's HTTP endpoint.
        challenge: The challenge to send.
        commitment: Miner commitment (for logging).
        keypair: Validator keypair for Epistula signing.
        session: Optional shared aiohttp session (more efficient).
    """
    payload = {
        "task_name": challenge.task_name,
        "challenge_type": challenge.challenge_type,
        "constraints": challenge.constraints,
        "db_snapshot_url": challenge.db_snapshot_url,
        "context": challenge.context,
        "task_definition": challenge.task_definition,
        "scaffold_code": challenge.scaffold_code,
        "epoch": challenge.epoch,
    }

    headers = build_headers(keypair)  # signs with validator hotkey
    timeout = aiohttp.ClientTimeout(total=SubnetConfig.MINER_POD_TIMEOUT_SEC)

    async def _do_post(s: aiohttp.ClientSession) -> Dict[str, Any]:
        async with s.post(
            f"{pod_url}/challenge",
            json=payload,
            headers=headers,
            timeout=timeout,
        ) as resp:
            resp.raise_for_status()
            return await resp.json()

    last_exc: Optional[Exception] = None
    for attempt in range(_CHALLENGE_MAX_RETRIES + 1):
        try:
            if session is not None:
                return await _do_post(session)
            else:
                async with aiohttp.ClientSession() as temp_session:
                    return await _do_post(temp_session)
        except (aiohttp.ClientConnectionError, asyncio.TimeoutError) as exc:
            last_exc = exc
            if attempt < _CHALLENGE_MAX_RETRIES:
                delay = _CHALLENGE_RETRY_BACKOFF[attempt]
                logger.warning(
                    "Challenge to uid=%d failed (attempt %d/%d): %s – "
                    "retrying in %ds",
                    commitment.uid, attempt + 1, _CHALLENGE_MAX_RETRIES + 1,
                    exc, delay,
                )
                await asyncio.sleep(delay)
            else:
                raise
    # Should not reach here, but satisfy type checker
    raise last_exc  # type: ignore[misc]


def _parse_response(
    raw: Dict[str, Any],
    commitment: MinerCommitment,
    challenge: Challenge,
) -> MinerSubmission:
    """Parse the miner pod's JSON response into a ``MinerSubmission``.

    Validates that ``model_code`` is non-empty.  The miner may claim
    any ``parent_id`` from the experiment DB — lineage is validated
    in Phase 2 by looking up the parent code from the validator's DB.
    """
    model_code = raw.get("model_code", "")
    if not model_code:
        raise ValueError(f"Miner uid={commitment.uid} returned empty model_code")

    parent_id = raw.get("parent_id")

    return MinerSubmission(
        hotkey=commitment.hotkey,
        uid=commitment.uid,
        model_code=model_code,
        model_diff=raw.get("model_diff", ""),
        parent_id=parent_id,
        motivation=raw.get("motivation", ""),
        name=raw.get("name", ""),
        config=raw.get("config", {}),
        metadata=raw.get("metadata", {}),
        status=SubmissionStatus.SUCCEEDED,
    )
