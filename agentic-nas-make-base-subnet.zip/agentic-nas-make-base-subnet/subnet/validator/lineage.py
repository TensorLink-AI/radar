"""
Deterministic lineage validation for miner submissions.

Checks that a miner claiming a ``parent_id`` has actually *evolved* from
that parent rather than submitting a 100% rewrite.  All checks are
deterministic (stdlib only — ``difflib``, ``ast``) and run on the
validator's CPU, so they add negligible overhead to Phase 2 filtering.

Three independent signals are computed:

    1. **Text similarity** (``difflib.SequenceMatcher.ratio()``):
       How much of the parent code survives verbatim in the submission.
    2. **Line-level diff statistics**: Added / removed / unchanged lines
       and the replacement ratio (removed ÷ parent lines).
    3. **AST structural similarity** (best-effort): Compares top-level
       class and function names across parent and child.  Falls back
       gracefully if either file cannot be parsed.

A submission is flagged when it claims lineage (``parent_id is not None``)
but the code shows no meaningful overlap with the parent.
"""

from __future__ import annotations

import ast
import difflib
import logging
from dataclasses import dataclass, field
from typing import Dict, List, Optional

from subnet.config import SubnetConfig

logger = logging.getLogger(__name__)


# ── Result container ──────────────────────────────────────────────────


@dataclass
class LineageCheckResult:
    """Outcome of a deterministic lineage validation."""

    passed: bool = True
    """Whether the submission passes lineage checks."""

    # Text-level similarity (SequenceMatcher)
    similarity_ratio: float = 0.0
    """``difflib.SequenceMatcher.ratio()`` between parent and child.
    Range [0, 1] where 1.0 means identical."""

    # Line-level diff statistics
    lines_added: int = 0
    lines_removed: int = 0
    lines_unchanged: int = 0
    total_parent_lines: int = 0
    total_child_lines: int = 0
    replacement_ratio: float = 0.0
    """Fraction of parent lines that were removed (removed / parent_lines).
    A ratio of 1.0 means the entire parent was deleted."""

    # AST structural similarity (best-effort)
    ast_similarity: Optional[float] = None
    """Jaccard similarity of top-level class/function names.
    ``None`` if either file could not be parsed."""
    parent_symbols: List[str] = field(default_factory=list)
    child_symbols: List[str] = field(default_factory=list)

    # Rejection details
    rejection_reasons: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict:
        """Serialise for inclusion in ``CandidateResult.zero_cost_details``."""
        return {
            "passed": self.passed,
            "similarity_ratio": round(self.similarity_ratio, 4),
            "lines_added": self.lines_added,
            "lines_removed": self.lines_removed,
            "lines_unchanged": self.lines_unchanged,
            "total_parent_lines": self.total_parent_lines,
            "total_child_lines": self.total_child_lines,
            "replacement_ratio": round(self.replacement_ratio, 4),
            "ast_similarity": (
                round(self.ast_similarity, 4)
                if self.ast_similarity is not None
                else None
            ),
            "parent_symbols": self.parent_symbols,
            "child_symbols": self.child_symbols,
            "rejection_reasons": self.rejection_reasons,
        }


# ── Public API ────────────────────────────────────────────────────────


def check_lineage(
    parent_code: str,
    child_code: str,
    *,
    min_similarity: Optional[float] = None,
    max_replacement_ratio: Optional[float] = None,
) -> LineageCheckResult:
    """Run deterministic lineage checks comparing *parent_code* to *child_code*.

    Args:
        parent_code: Source code of the parent model.
        child_code: Source code submitted by the miner.
        min_similarity: Override ``SubnetConfig.LINEAGE_MIN_SIMILARITY``.
        max_replacement_ratio: Override ``SubnetConfig.LINEAGE_MAX_REPLACEMENT_RATIO``.

    Returns:
        A ``LineageCheckResult`` indicating whether the submission is a
        legitimate evolution of the parent.
    """
    if min_similarity is None:
        min_similarity = SubnetConfig.LINEAGE_MIN_SIMILARITY
    if max_replacement_ratio is None:
        max_replacement_ratio = SubnetConfig.LINEAGE_MAX_REPLACEMENT_RATIO

    result = LineageCheckResult()

    # ── 1. Text similarity ────────────────────────────────────────
    result.similarity_ratio = _text_similarity(parent_code, child_code)

    # ── 2. Line-level diff statistics ─────────────────────────────
    _compute_line_stats(parent_code, child_code, result)

    # ── 3. AST structural similarity ─────────────────────────────
    _compute_ast_similarity(parent_code, child_code, result)

    # ── 4. Apply thresholds ──────────────────────────────────────
    if result.similarity_ratio < min_similarity:
        result.rejection_reasons.append(
            f"similarity_ratio {result.similarity_ratio:.4f} "
            f"< min_similarity {min_similarity}"
        )

    if result.replacement_ratio > max_replacement_ratio:
        result.rejection_reasons.append(
            f"replacement_ratio {result.replacement_ratio:.4f} "
            f"> max_replacement_ratio {max_replacement_ratio}"
        )

    result.passed = len(result.rejection_reasons) == 0
    return result


# ── Internal helpers ──────────────────────────────────────────────────


def _text_similarity(a: str, b: str) -> float:
    """Compute SequenceMatcher ratio between two code strings."""
    return difflib.SequenceMatcher(None, a, b).ratio()


def _compute_line_stats(
    parent_code: str, child_code: str, result: LineageCheckResult
) -> None:
    """Populate line-level diff statistics on *result*."""
    parent_lines = parent_code.splitlines(keepends=True)
    child_lines = child_code.splitlines(keepends=True)

    result.total_parent_lines = len(parent_lines)
    result.total_child_lines = len(child_lines)

    added = 0
    removed = 0
    unchanged = 0

    for tag, i1, i2, j1, j2 in difflib.SequenceMatcher(
        None, parent_lines, child_lines
    ).get_opcodes():
        if tag == "equal":
            unchanged += i2 - i1
        elif tag == "insert":
            added += j2 - j1
        elif tag == "delete":
            removed += i2 - i1
        elif tag == "replace":
            removed += i2 - i1
            added += j2 - j1

    result.lines_added = added
    result.lines_removed = removed
    result.lines_unchanged = unchanged
    result.replacement_ratio = (
        removed / result.total_parent_lines
        if result.total_parent_lines > 0
        else 0.0
    )


def _extract_top_level_symbols(code: str) -> Optional[List[str]]:
    """Return sorted list of top-level class and function names, or None on parse failure."""
    try:
        tree = ast.parse(code)
    except SyntaxError:
        return None

    symbols = []
    for node in ast.iter_child_nodes(tree):
        if isinstance(node, (ast.ClassDef, ast.FunctionDef, ast.AsyncFunctionDef)):
            symbols.append(node.name)
    return sorted(symbols)


def _compute_ast_similarity(
    parent_code: str, child_code: str, result: LineageCheckResult
) -> None:
    """Compute Jaccard similarity of top-level symbols (best-effort)."""
    parent_syms = _extract_top_level_symbols(parent_code)
    child_syms = _extract_top_level_symbols(child_code)

    if parent_syms is not None:
        result.parent_symbols = parent_syms
    if child_syms is not None:
        result.child_symbols = child_syms

    if parent_syms is None or child_syms is None:
        result.ast_similarity = None
        return

    parent_set = set(parent_syms)
    child_set = set(child_syms)

    union = parent_set | child_set
    if not union:
        result.ast_similarity = 1.0  # both empty → trivially identical
        return

    result.ast_similarity = len(parent_set & child_set) / len(union)
