"""
Phase 2 – Filtering: signal-aware zero-cost proxy evaluation + constraint checking.

Lineage / AST / diff checks run on the **validator's CPU** (cheap, safe,
no untrusted code execution).

AZNAS proxy evaluation (model loading, FX shape validation, 7 signal-aware
proxies) runs on a **Basilica GPU pod** via ``PROXY_EVAL_IMAGE`` (defaults
to ``DEEP_TRAIN_IMAGE``).  All candidate model codes are sent as a single
batch to the pod's ``POST /proxy-eval-batch`` endpoint, avoiding
per-candidate pod overhead.  There is **no automatic fallback** to local
CPU -- set ``PROXY_EVAL_LOCAL=1`` to explicitly opt into that mode.

Individual proxy metrics are computed per candidate, then a Borda-count
(rank-sum) is used to produce a single composite score across all
candidates.  This relative ranking rewards diverse architectural strengths
rather than a single naive heuristic.

Candidates that violate the challenge constraints (param count,
inference latency) are rejected before scoring.

Only the top-K candidates advance to Phase 3 (deep training).
"""

from __future__ import annotations

import asyncio
import logging
import math
import os
import tempfile
from typing import Any, Dict, List, Optional, Tuple

from subnet.config import SubnetConfig
from subnet.protocol.types import CandidateResult, MinerSubmission
from subnet.validator.lineage import check_lineage

# Imported lazily inside _batch_proxy_eval_basilica / _zero_cost_eval_local
# to avoid pulling torch at module level (allows lightweight tests to import
# _check_constraints and other pure-Python helpers without GPU deps).
# from tasks.ts_foundation.model_base import DEFAULT_FORECAST_LENGTH, DEFAULT_INPUT_LENGTH

logger = logging.getLogger(__name__)

# Zero-cost eval timeout in seconds (per-candidate, for local fallback)
ZERO_COST_TIMEOUT_SEC = 120


# ── Public entry ────────────────────────────────────────────────────────


async def run_filtering_phase(
    submissions: List[MinerSubmission],
    constraints: Optional[Dict[str, Any]] = None,
) -> List[CandidateResult]:
    """Evaluate all submissions with signal-aware proxies and return top K.

    Steps:
      1. For each submission, run lineage validation on validator CPU.
         When a miner claims a ``parent_id``, the parent's source code
         is fetched from the validator's DB for comparison.
      2. Batch all passing submissions to a Basilica pod for AZNAS
         proxy evaluation (or fall back to local CPU eval).
      3. Check hard constraints (max_params, inference latency).
      4. Reject candidates that fail constraints or lineage checks.
      5. Re-rank survivors via Borda count, return top K.

    Args:
        submissions: Successful miner submissions from Phase 1.
        constraints: Hard constraints dict from the Challenge.  If
            ``None``, uses ``SubnetConfig.get_constraints()``.
    """
    if constraints is None:
        constraints = SubnetConfig.get_constraints()

    # Phase 2a: Lineage validation (runs on validator CPU, per-submission DB lookup)
    submissions_to_eval: List[Tuple[MinerSubmission, CandidateResult]] = []
    rejected_results: List[CandidateResult] = []

    # Pre-fetch parent codes for all unique parent_ids claimed by miners.
    # This avoids redundant DB calls when multiple miners pick the same parent.
    unique_parent_ids = {
        sub.parent_id for sub in submissions
        if sub.parent_id is not None
    }
    parent_code_cache: Dict[int, Optional[str]] = {}
    if unique_parent_ids:
        parent_code_cache = await _fetch_parent_codes(unique_parent_ids)

    for sub in submissions:
        result = CandidateResult(
            hotkey=sub.hotkey,
            uid=sub.uid,
            name=sub.name,
            motivation=sub.motivation,
            model_code=sub.model_code,
            parent_id=sub.parent_id,
            config=sub.config,
            model_diff=sub.model_diff,
            # NOTE: constraints_satisfied defaults to False, will be set True if all checks pass
        )

        # Look up parent code for the claimed parent_id
        parent_code: Optional[str] = None
        if sub.parent_id is not None:
            parent_code = parent_code_cache.get(sub.parent_id)

        # Lineage validation (before spending GPU time on proxy eval)
        if not _run_lineage_check(sub, result, parent_code):
            rejected_results.append(result)
            continue

        submissions_to_eval.append((sub, result))

    # Phase 2b: AZNAS proxy evaluation
    if SubnetConfig.PROXY_EVAL_LOCAL:
        # Explicit opt-in to local CPU evaluation (PROXY_EVAL_LOCAL=1)
        logger.info("PROXY_EVAL_LOCAL=1: running proxy eval on validator CPU")
        await _batch_proxy_eval_local(submissions_to_eval, constraints)
    elif SubnetConfig.PROXY_EVAL_IMAGE:
        # Default path: batch all candidates to a single Basilica pod
        await _batch_proxy_eval_basilica(submissions_to_eval, constraints)
    else:
        raise RuntimeError(
            "No proxy evaluation backend configured. Set PROXY_EVAL_IMAGE "
            "(or DEEP_TRAIN_IMAGE) to the Basilica Docker image, or set "
            "PROXY_EVAL_LOCAL=1 to explicitly opt into local CPU evaluation."
        )

    # Collect all results
    results: List[CandidateResult] = list(rejected_results)
    for _, result in submissions_to_eval:
        results.append(result)

    # Separate passing and failing candidates
    passing = [r for r in results if r.constraints_satisfied]
    failing = [r for r in results if not r.constraints_satisfied]
    if failing:
        logger.info(
            "Constraint check: %d/%d candidates rejected",
            len(failing), len(results),
        )

    # Re-rank passing candidates via Borda count across proxy dimensions
    passing = _borda_rerank(passing)

    # Keep top K
    top_k = passing[: SubnetConfig.ZERO_COST_TOP_K]
    logger.info(
        "Zero-cost filter: %d -> %d candidates (threshold=%.4f)",
        len(results),
        len(top_k),
        top_k[-1].zero_cost_score if top_k else 0.0,
    )
    return top_k


# ── Basilica batch proxy evaluation ──────────────────────────────────


async def _batch_proxy_eval_basilica(
    submissions: List[Tuple[MinerSubmission, CandidateResult]],
    constraints: Dict[str, Any],
) -> None:
    """Send all candidates to a Basilica pod for AZNAS proxy evaluation.

    Deploys a single pod, POSTs all model codes to ``/proxy-eval-batch``,
    and maps results back to the ``CandidateResult`` objects.
    """
    if not submissions:
        return

    from services.eval.remote_training.client import BasilicaTrainingClient
    from tasks.ts_foundation.model_base import (
        DEFAULT_FORECAST_LENGTH,
        DEFAULT_INPUT_LENGTH,
    )

    model_codes = [sub.model_code for sub, _ in submissions]

    client = BasilicaTrainingClient(
        docker_image=SubnetConfig.PROXY_EVAL_IMAGE,
        api_token=SubnetConfig.BASILICA_API_TOKEN or None,
        gpu_count=SubnetConfig.BASILICA_GPU_COUNT,
        gpu_memory_gb=SubnetConfig.BASILICA_GPU_MEMORY_GB,
        memory=SubnetConfig.BASILICA_MEMORY,
        ttl_small=SubnetConfig.PROXY_EVAL_TIMEOUT_SEC,
        ttl_large=SubnetConfig.PROXY_EVAL_TIMEOUT_SEC,
        validate_credentials=True,
    )

    logger.info(
        "Dispatching %d candidates to Basilica proxy eval pod (image=%s)",
        len(model_codes), SubnetConfig.PROXY_EVAL_IMAGE,
    )

    proxy_results = await client.batch_proxy_eval(
        model_codes,
        input_length=DEFAULT_INPUT_LENGTH,
        forecast_length=DEFAULT_FORECAST_LENGTH,
        batch_size=4,
        num_variants=7,
        max_params=constraints.get("max_params"),
        max_inference_latency_ms=constraints.get("max_inference_latency_ms"),
        timeout_sec=float(SubnetConfig.PROXY_EVAL_TIMEOUT_SEC),
    )

    # Map results back to CandidateResult objects
    for i, (sub, result) in enumerate(submissions):
        if i < len(proxy_results):
            proxy = proxy_results[i]
        else:
            proxy = {"status": "error", "error": "Missing from results"}

        _apply_proxy_result(result, proxy, constraints)


async def _batch_proxy_eval_local(
    submissions: List[Tuple[MinerSubmission, CandidateResult]],
    constraints: Dict[str, Any],
) -> None:
    """Run AZNAS proxy evaluation locally on validator CPU.

    Falls back to this when ``PROXY_EVAL_IMAGE`` is not configured.
    Uses bounded concurrency to avoid memory exhaustion.
    """
    if not submissions:
        return

    max_concurrent = int(os.getenv("MAX_CONCURRENT_ZERO_COST_EVALS", "4"))
    sem = asyncio.Semaphore(max_concurrent)

    async def _eval_one(sub: MinerSubmission, result: CandidateResult) -> None:
        async with sem:
            try:
                proxy = await asyncio.wait_for(
                    _zero_cost_eval_local(sub),
                    timeout=ZERO_COST_TIMEOUT_SEC,
                )
            except asyncio.TimeoutError:
                logger.warning(
                    "Zero-cost eval timed out for uid=%d (%s) after %ds",
                    sub.uid, sub.name, ZERO_COST_TIMEOUT_SEC,
                )
                proxy = {"status": "error", "error": "timeout"}
            except Exception as exc:
                logger.warning(
                    "Zero-cost eval failed for uid=%d (%s): %s",
                    sub.uid, sub.name, exc,
                )
                proxy = {"status": "error", "error": str(exc)}

            _apply_proxy_result(result, proxy, constraints)

    tasks = [_eval_one(sub, result) for sub, result in submissions]
    await asyncio.gather(*tasks, return_exceptions=True)


def _apply_proxy_result(
    result: CandidateResult,
    proxy: Dict[str, Any],
    constraints: Dict[str, Any],
) -> None:
    """Map a proxy eval result dict onto a CandidateResult."""
    if proxy.get("status") == "ok":
        result.zero_cost_details = proxy
        result.param_count = proxy.get("param_count")
        result.inference_latency_ms = proxy.get("inference_latency_ms")
        result.training_style = proxy.get("training_style")
        # Use a placeholder score -- Borda reranking will replace it
        result.zero_cost_score = 1.0
        result.constraints_satisfied = _check_constraints(result, constraints)
    else:
        result.zero_cost_score = 0.0
        result.zero_cost_details = proxy
        result.constraints_satisfied = False


# ── Local fallback evaluation ──────────────────────────────────────────


async def _zero_cost_eval_local(submission: MinerSubmission) -> Dict[str, Any]:
    """Run AZNAS proxy evaluation locally on the validator CPU.

    Writes the miner's model code to a temp file, loads it via the
    task's model_base module (FX shape validation + param counting),
    measures inference latency, then runs all architecture-agnostic
    proxies.
    """

    def _run_eval(code: str) -> Dict[str, Any]:
        import torch
        from tasks.ts_foundation.model_base import (
            load_candidate_model,
            DEFAULT_FORECAST_LENGTH,
            DEFAULT_INPUT_LENGTH,
        )
        from core.training.universal_evaluator import (
            count_parameters,
            measure_inference_latency,
        )
        from tasks.ts_foundation.zero_cost_proxies import evaluate_candidate

        fd, tmp_path = tempfile.mkstemp(suffix=".py", prefix="zc_eval_")
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as f:
                f.write(code)

            device = torch.device("cpu")
            input_length = DEFAULT_INPUT_LENGTH
            forecast_length = DEFAULT_FORECAST_LENGTH

            # load_candidate_model runs FX shape validation internally
            model = load_candidate_model(
                tmp_path, device,
                input_length=input_length,
                forecast_length=forecast_length,
            )

            param_count = count_parameters(model, trainable_only=True)

            # Inference latency
            sample_batch = {
                "past_y": torch.zeros((1, input_length, 1), device=device),
                "y_future_tf": torch.zeros((1, forecast_length, 1), device=device),
                "forecast_length": forecast_length,
                "input_length": input_length,
            }
            latency_ms = measure_inference_latency(
                model, sample_batch, device,
                warmup_iters=2,
                measure_iters=5,
            )

            # Weight L2 norm
            weight_sq = sum(
                float(torch.sum(p.detach().float() ** 2).item())
                for p in model.parameters() if p.requires_grad
            )
            weight_l2 = math.sqrt(max(weight_sq, 0.0))

            # Training style
            training_style = getattr(model, "training_style", None)
            training_style_str = str(training_style) if training_style is not None else None

            # AZNAS proxy evaluation
            proxy = evaluate_candidate(
                model,
                input_length=input_length,
                forecast_length=forecast_length,
                batch_size=4,
                num_variants=7,
                device=device,
                name=f"uid_{submission.uid}",
            )

            return {
                **proxy.to_dict(),
                "status": "ok",
                "param_count": param_count,
                "inference_latency_ms": latency_ms,
                "weight_l2_norm": weight_l2,
                "shape_valid": True,
                "training_style": training_style_str,
                "constraints_satisfied": True,
                "proxy_status": proxy.status,
            }
        finally:
            os.unlink(tmp_path)

    return await asyncio.to_thread(_run_eval, submission.model_code)


# ── Borda re-ranking ──────────────────────────────────────────────────


def _borda_rerank(passing: List[CandidateResult]) -> List[CandidateResult]:
    """Re-rank passing candidates using Borda count over proxy metrics.

    Reads the proxy details stored in ``zero_cost_details`` by the
    proxy eval (Basilica or local) and applies rank-sum scoring.
    Updates each result's ``zero_cost_score`` with the normalised
    Borda score.
    """
    if len(passing) <= 1:
        return passing

    from tasks.ts_foundation.zero_cost_proxies import (
        ProxyResult,
        borda_rank,
        normalise_borda_scores,
    )

    # Build ProxyResult objects from stored details
    proxy_results: List[ProxyResult] = []

    for idx, r in enumerate(passing):
        d = r.zero_cost_details or {}
        pr = ProxyResult(
            name=r.name or f"uid_{r.uid}",
            status=d.get("proxy_status", "PASS"),
            eff_rank=float(d.get("eff_rank", 0.0)),
            deep_collapse_ratio=float(d.get("deep_collapse_ratio", 0.0)),
            saliency_per_param=float(d.get("saliency_per_param", 0.0)),
            sensitivity_log_norm=float(d.get("sensitivity_log_norm", 0.0)),
            grad_coherence=float(d.get("grad_coherence", 0.0)),
            state_velocity=float(d.get("state_velocity", 0.0)),
            local_contrast=float(d.get("local_contrast", 0.0)),
            deep_rep_source=str(d.get("deep_rep_source", "none")),
            sensitivity_ok_rate=float(d.get("sensitivity_ok_rate", 0.0)),
            param_count=int(d.get("param_count", r.param_count or 0)),
            trainable_params=int(d.get("trainable_params", r.param_count or 0)),
        )
        proxy_results.append(pr)

    # Borda rank + normalise to [0, 1]
    ranked = borda_rank(proxy_results)
    normalised = normalise_borda_scores(ranked)

    # Map normalised scores back to CandidateResults via object identity
    proxy_to_score: Dict[int, float] = {}
    for pr, score in normalised:
        proxy_to_score[id(pr)] = score

    for idx, r in enumerate(passing):
        pr = proxy_results[idx]
        score = proxy_to_score.get(id(pr))
        if score is not None:
            r.zero_cost_score = score
            if r.zero_cost_details is None:
                r.zero_cost_details = {}
            r.zero_cost_details["borda_score"] = score

    # Sort descending by updated score
    passing.sort(key=lambda r: r.zero_cost_score or 0.0, reverse=True)
    return passing


# ── Constraint validation ──────────────────────────────────────────────


def _check_constraints(result: CandidateResult, constraints: Dict[str, Any]) -> bool:
    """Check a candidate against hard constraints.

    Returns ``True`` if all constraints are satisfied.
    """
    max_params = constraints.get("max_params")
    if max_params is not None and result.param_count is not None:
        if result.param_count > max_params:
            logger.info(
                "uid=%d (%s) exceeds max_params: %d > %d",
                result.uid, result.name, result.param_count, max_params,
            )
            return False

    max_latency = constraints.get("max_inference_latency_ms")
    if max_latency is not None and result.inference_latency_ms is not None:
        if result.inference_latency_ms > max_latency:
            logger.info(
                "uid=%d (%s) exceeds latency: %.1fms > %.1fms",
                result.uid, result.name, result.inference_latency_ms, max_latency,
            )
            return False

    return True


# ── Parent code lookup ─────────────────────────────────────────────────


async def _fetch_parent_codes(
    parent_ids: set,
) -> Dict[int, Optional[str]]:
    """Fetch parent source code from the validator's DB concurrently.

    Miners can now claim any ``parent_id`` from the experiment DB.
    This function looks up the actual source code for each unique
    parent_id so we can validate lineage on the validator CPU.

    All requests are dispatched in parallel via ``asyncio.gather``
    to avoid the N+1 sequential-request pattern.

    Returns:
        Mapping of parent_id → source code (or None if not found).
    """
    import aiohttp

    db_url = SubnetConfig.DATABASE_URL.rstrip("/")
    result: Dict[int, Optional[str]] = {}

    async def _fetch_one(
        session: aiohttp.ClientSession, pid: int,
    ) -> tuple:
        try:
            async with session.get(
                f"{db_url}/get",
                params={"index": pid},
                timeout=aiohttp.ClientTimeout(total=15),
            ) as resp:
                if resp.status == 200:
                    data = await resp.json()
                    return pid, data.get("program")
                else:
                    logger.warning(
                        "DB lookup for parent_id=%d returned %d",
                        pid, resp.status,
                    )
                    return pid, None
        except Exception:
            logger.warning(
                "Failed to fetch parent_id=%d from DB", pid,
                exc_info=True,
            )
            return pid, None

    try:
        async with aiohttp.ClientSession() as session:
            fetches = [_fetch_one(session, pid) for pid in parent_ids]
            responses = await asyncio.gather(*fetches, return_exceptions=True)
            for resp in responses:
                if isinstance(resp, Exception):
                    logger.warning("Parent fetch task failed: %s", resp)
                    continue
                pid, code = resp
                result[pid] = code
    except Exception:
        logger.exception("Failed to open DB session for parent lookup")

    # Ensure all requested IDs have an entry (None if not fetched)
    for pid in parent_ids:
        result.setdefault(pid, None)

    return result


# ── Lineage validation ─────────────────────────────────────────────────


def _run_lineage_check(
    sub: MinerSubmission,
    result: CandidateResult,
    parent_code: Optional[str],
) -> bool:
    """Run lineage validation if applicable.

    Returns ``True`` if the candidate should proceed to proxy eval,
    ``False`` if it should be rejected (``constraints_satisfied`` is set
    to ``False`` on the result).

    Lineage checks (text similarity, replacement ratio, AST comparison)
    run on the **validator CPU** -- they are pure string/AST operations
    with no untrusted code execution.
    """
    if not SubnetConfig.LINEAGE_CHECK_ENABLED:
        return True

    # Only check lineage when the miner claims a parent
    if sub.parent_id is None:
        return True

    # If parent_code could not be fetched from the DB, skip the check
    if not parent_code:
        logger.warning(
            "uid=%d claims parent_id=%s but parent not found in DB – "
            "skipping lineage check",
            sub.uid, sub.parent_id,
        )
        return True

    lc = check_lineage(parent_code, sub.model_code)
    result.lineage_check = lc.to_dict()

    if not lc.passed:
        logger.info(
            "uid=%d (%s) failed lineage check (parent_id=%s): %s",
            sub.uid, sub.name, sub.parent_id, "; ".join(lc.rejection_reasons),
        )
        result.constraints_satisfied = False
        result.zero_cost_score = 0.0
        return False

    logger.debug(
        "uid=%d lineage OK: similarity=%.3f replacement=%.3f ast=%.3f",
        sub.uid,
        lc.similarity_ratio,
        lc.replacement_ratio,
        lc.ast_similarity if lc.ast_similarity is not None else -1,
    )
    return True
