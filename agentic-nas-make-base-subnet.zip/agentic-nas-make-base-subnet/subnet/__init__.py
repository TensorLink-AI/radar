# Bittensor subnet: Agentic NAS for time-series forecasting.
