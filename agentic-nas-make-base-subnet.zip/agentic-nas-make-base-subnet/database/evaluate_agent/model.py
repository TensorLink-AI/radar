from pydantic import BaseModel
from services.providers.provider import ProviderAgent
from services.database.element import DataElement

class JudgerOutput(BaseModel):
    """Defines the structured output for the Judger agent."""
    performance_score: int
    innovation_score: int
    complexity_score: int
    weighted_final_score: float
    judgement_reason: str

JUDGER_INSTRUCTIONS = """You are the final adjudicator for agent-submitted architectures. Score each candidate strictly according to the task-supplied rubric (see Task Contract section of the prompt) and the observed evidence (code, logs, analysis, cognition).

**Evaluation Posture**
1. **Anchor to the Task Contract** – Treat the Task Contract section as the governing specification. Extract baseline references and performance thresholds from there. Only reward improvements that are demonstrably better than those task-defined anchors.
2. **Demand Quantification** – When discussing performance, compute deltas or ratios against the baselines provided in the Task Contract. For efficiency, reason about implied complexity (O(N), chunked, recurrent) using the code snippet.
3. **Reward Real Innovation** – Credit candidates that introduce new inductive biases (state-space hybrids, spectral modules, adaptive horizons) and penalize minor parameter tweaks masquerading as breakthroughs.
4. **Complexity Accountability** – High complexity must be justified by measurable gains; otherwise, lower the complexity score.

**Scoring Dimensions (1–10 each, include decimals if needed):**
- **Performance (30%)** – Empirical accuracy/quality vs. the rubric metrics defined in the Task Contract. Reference exact metrics or log excerpts.
- **Innovation (25%)** – Degree of novelty and how well the motivation is implemented in code (cite functions, layers, or equations).
- **Complexity (45%)** – Computational and implementation cost: mask discipline, state tracking overhead, hyperparameter explosion, and clarity of the provided config.

**Output Requirements:**
- Emit the three scores, the weighted final score `(0.3 * performance) + (0.25 * innovation) + (0.45 * complexity)`, and a detailed justification string tying each score to evidence.
- Mention any contract violations (missing validate call, incorrect outputs, etc.) if observed—they should directly lower the relevant scores.
- Respond using the structured JSON schema only. No markdown, bullets, or prose outside the schema.
"""

class Judger(ProviderAgent):
    """
    An agent that provides a quantitative and qualitative judgment on a model's
    performance, innovation, and complexity compared to a baseline.
    """
    name = "Model Judger"
    instructions = JUDGER_INSTRUCTIONS
    tools: list = []

    def _prepare_user_prompt(self, element: DataElement, task_prompt: str = "", **kwargs) -> str:
        """Create the full prompt for the Judger agent with optional task context."""

        def _section(title: str, body: str) -> str:
            return f"## {title}\n{body.strip()}\n"

        sections = []
        if task_prompt and task_prompt.strip():
            sections.append(_section("Task Contract", task_prompt))

        overview = f"""**Model Name**: {element.name}
**Task**: {element.task}
**Architecture Keywords**: {', '.join(element.architecture_keywords) if element.architecture_keywords else '—'}
"""
        sections.append(_section("Candidate Overview", overview))

        sections.append(
            _section(
                "Implementation",
                f"```python\n{element.program}\n```"
            )
        )

        if element.motivation:
            sections.append(_section("Motivation", element.motivation))
        if element.analysis:
            sections.append(_section("Analysis", element.analysis))
        if element.cognition:
            sections.append(_section("Cognition", element.cognition))
        if element.log:
            sections.append(_section("Run Log", element.log))

        results = [
            f"**Training Progression**:\n{element.result.get('train', '')}",
            f"**Evaluation Results**:\n{element.result.get('test', '')}",
        ]
        sections.append(_section("Observed Metrics", "\n\n".join(results)))

        return "\n".join(sections).strip()
