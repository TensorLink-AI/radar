from __future__ import annotations

import json
from typing import Any, Dict, List, Optional

import csv
import io
import logging


# -----------------------------
# DataElement (refactored schema)
# -----------------------------
from services.database.element import DataElement


# -----------------------------
# CSV evaluation helpers (unchanged behavior)
# -----------------------------
logger = logging.getLogger(__name__)


def _evaluate_loss(result: dict) -> float:
    """Return final training loss from CSV in result['train'] (header + one row)."""
    if not result or not result.get("train"):
        logger.warning("training loss result is an empty string")
        return 0.0
    try:
        f = io.StringIO(result["train"])
        reader = csv.reader(f)
        _ = next(reader)  # header
        row = next(reader)  # data row
        last_value = row[-1]
        if not str(last_value).strip():
            logger.warning("Loss value of the last step is empty")
            return 0.0
        return float(last_value)
    except StopIteration:
        logger.warning("CSV data is incomplete, missing data row")
        return 0.0
    except Exception as e:
        logger.error(f"An error occurred while processing CSV data: {e}")
        return 0.0


def _evaluate_result(result: dict) -> float:
    """
    Average of numeric values in result['test'] data row, skipping column 0 (typically a model/name column).
    """
    if not result or not result.get("test"):
        logger.warning("benchmark evaluation result is an empty string")
        return 0.0
    try:
        f = io.StringIO(result["test"])
        reader = csv.reader(f)
        _ = next(reader)  # header
        row = next(reader)  # data row

        scores: List[float] = []
        for value in row[1:]:  # skip first column
            v = str(value).strip()
            if not v:
                continue
            try:
                scores.append(float(v))
            except (ValueError, TypeError):
                logger.warning(f"Cannot convert '{value}' to float, ignored in mean calculation")

        if not scores:
            logger.warning(f"No valid numerical values found in result string: '{result}'")
            return 0.0
        return sum(scores) / len(scores)
    except StopIteration:
        logger.warning("CSV data is incomplete, missing data row")
        return 0.0
    except Exception as e:
        logger.error(f"Error in processing CSV data: {e}")
        return 0.0


def _has_data_rows(csv_string: str) -> bool:
    """Check if CSV string has at least one data row beyond the header."""
    if not isinstance(csv_string, str) or not csv_string.strip():
        return False
    with io.StringIO(csv_string) as f:
        try:
            reader = csv.reader(f)
            _ = next(reader)  # header
            _ = next(reader)  # first data row
            return True
        except StopIteration:
            return False
        except Exception:
            # Be permissive on parse errors: treat as present
            return True
