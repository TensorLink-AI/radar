import logging
import os
from typing import List, Optional, Sequence

import requests


class EmbeddingService:
    """Embedding service client for Chutes.ai (OpenAI-compatible embeddings)."""

    def __init__(
        self,
        api_key: Optional[str] = None,
        *,
        base_url: Optional[str] = None,
        model: Optional[str] = None,
        timeout: float = 30.0,
    ):
        """
        Args:
            api_key: Chutes API key. If not provided, reads from CHUTES_API_KEY.
            base_url: Embeddings endpoint. Defaults to https://llm.chutes.ai/v1/embeddings
                      (OpenAI-compatible). If you run a custom TEI chute, point to its
                      /v1/embeddings route.
            model: Model identifier/slug. Some deployments ignore this, but it's required
                   by the OpenAI schema. Can also be set via CHUTES_EMBEDDING_MODEL.
            timeout: Request timeout in seconds.
        """
        self.api_key = api_key or os.getenv("CHUTES_API_KEY")
        if not self.api_key:
            raise ValueError(
                "Please set CHUTES_API_KEY or provide api_key to EmbeddingService()"
            )

        # Default OpenAI-compatible embeddings route on Chutes; override if you have a custom chute
        self.base_url = (
            base_url
            or os.getenv("CHUTES_EMBEDDINGS_URL", "https://llm.chutes.ai/v1/embeddings")
        )
        # Pick a reasonable default, but prefer env/arg; for custom chutes this may be your chute slug
        self.model = model or os.getenv("CHUTES_EMBEDDING_MODEL", "bge-base-en-v1.5")

        self.timeout = timeout
        self.logger = logging.getLogger(__name__)

    def _post(self, payload: dict) -> dict:
        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {self.api_key}",
        }
        resp = requests.post(
            self.base_url, headers=headers, json=payload, timeout=self.timeout
        )
        resp.raise_for_status()
        return resp.json()

    def get_embeddings(self, texts: Sequence[str]) -> List[List[float]]:
        """
        Get embedding vectors for a batch of texts.

        Returns:
            List of vectors (one per input text).
        """
        if not texts:
            return []

        # OpenAI-compatible request body (works with Chutes + TEI OpenAI shim)
        body = {
            "model": self.model,
            "input": list(texts),
            # Many providers accept this; harmless if ignored. Remove if your chute requires otherwise.
            "encoding_format": "float",
        }

        try:
            result = self._post(body)

            # Expect: {"data": [{"index": i, "embedding": [...]}, ...], ...}
            items = result.get("data", [])
            if not isinstance(items, list):
                raise KeyError("Response 'data' is not a list")

            # Sort by index to preserve input order
            items.sort(key=lambda x: x.get("index", 0))
            embeddings: List[List[float]] = []
            for item in items:
                emb = item.get("embedding")
                if not isinstance(emb, list):
                    raise KeyError("Missing 'embedding' in response item")
                embeddings.append(emb)

            self.logger.info("Obtained embeddings for %d texts", len(embeddings))
            return embeddings

        except requests.exceptions.RequestException as e:
            self.logger.error("Embedding API request failed: %s", e)
            raise
        except KeyError as e:
            # Log the full payload for easier debugging if schema differs
            self.logger.error("Unexpected embeddings response schema: %s", e)
            raise
        except Exception as e:
            self.logger.error("Failed to get embeddings: %s", e)
            raise

    def get_single_embedding(self, text: str) -> List[float]:
        """Get an embedding for a single text."""
        vecs = self.get_embeddings([text])
        return vecs[0] if vecs else []


# Global instance for convenience
_embedding_service: Optional[EmbeddingService] = None

def get_embedding_service() -> EmbeddingService:
    """Get global EmbeddingService configured for Chutes.ai."""
    global _embedding_service
    if _embedding_service is None:
        _embedding_service = EmbeddingService()
    return _embedding_service
