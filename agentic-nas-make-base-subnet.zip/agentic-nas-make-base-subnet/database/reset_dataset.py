import requests
from datetime import datetime

# API Configuration
API_BASE_URL = "http://localhost:8001"


def add_element_via_api(element_data):
    """Adds a data element via the API"""
    url = f"{API_BASE_URL}/elements"
    headers = {"Content-Type": "application/json"}

    try:
        response = requests.post(url, headers=headers, json=element_data)
        response.raise_for_status()
        result = response.json()
        print(f"✅ Successfully added: {result}")
        return True
    except requests.exceptions.RequestException as e:
        print(f"❌ Failed to add: {e}")
        if hasattr(e, "response") and e.response is not None:
            try:
                error_detail = e.response.json()
                print(f"Error details: {error_detail}")
            except Exception:
                print(f"Response content: {e.response.text}")
        return False


# Prepare the data
current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

full_train_data = """step,100,200,300,400,500,600,700,800,900,1000,1100,1200,1300,1400,1500,1600,1700,1800,1900,2000\nloss,10.2629,8.9712,7.6769,6.9779,6.5788,6.2249,6.0558,5.8544,5.7071,5.5044,5.3517,5.2153,5.1558,4.9783,4.9156,4.9054,4.7193,4.6739,4.6408,4.5787"""

full_test_data = """Model,ARC Challenge,ARC Easy,BoolQ,FDA,HellaSwag,LAMBDA OpenAI,OpenBookQA,PIQA,Social IQA,SQuAD Completion,SWDE,WinoGrande,Average\nreference_baseline,0.168,0.324,0.364,0.000,0.296,0.002,0.136,0.526,0.354,0.002,0.008,0.504,0.224"""

program_code = '''python
import torch
import torch.nn as nn


class ReferenceSequenceModel(nn.Module):
    """Minimal reference implementation for time-series forecasting."""

    def __init__(self, input_dim: int = 1, hidden_dim: int = 256, horizon: int = 96):
        super().__init__()
        self.input_dim = input_dim
        self.hidden_dim = hidden_dim
        self.horizon = horizon
        self.encoder = nn.GRU(input_dim, hidden_dim, batch_first=True)
        self.decoder = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, horizon),
        )

    def forward(self, past_y, *_, forecast_length=None, **__):
        length = forecast_length or self.horizon
        _, state = self.encoder(past_y)
        preds = self.decoder(state[-1]).unsqueeze(-1)
        quantiles = torch.stack([
            preds * 0.9,
            preds,
            preds * 1.1,
        ], dim=-1)
        return {
            "quantiles": quantiles[..., :length, :],
            "quantile_levels": torch.tensor([0.1, 0.5, 0.9], device=past_y.device),
        }

    def generate(self, past_y, *_, forecast_length=None, **__):
        return self.forward(past_y, forecast_length=forecast_length)
'''

motivation = '''
**Core Insights:**
- Build a lightweight reference model that satisfies the time-series task contract without assuming any bespoke architecture.
- Emphasize clarity, causal masking, and quantile-aware decoding so future candidates have a clean baseline to compare against.
- Provide thorough logging of training/evaluation outputs so downstream agents can reason about improvements quantitatively.
'''

analysis = '''
**Performance Summary:**
- Acts as a sanity-check baseline for forecasting quality (MASE/CRPS) while remaining O(n) in sequence length.
- Serves as the canonical reference when computing percentage gains for planner, debugger, and judger agents.
- Highlights the need for better long-range state tracking, adaptive horizons, and uncertainty calibration.
'''

cognition = """
Baseline established for the time_series_foundation task. Use task-specific prompts to steer agent behavior.
"""

element_data = {
    "time": current_time,
    "name": "reference_sequence_model",
    "task": "time_series_foundation",
    "result": {
        "train": full_train_data,
        "test": full_test_data,
    },
    "program": program_code,
    "analysis": analysis,
    "cognition": cognition,
    "log": "",
    "motivation": motivation,
}

print("🗑️ Deleting all existing data...")
delete_url = f"{API_BASE_URL}/elements/all"
try:
    delete_response = requests.delete(delete_url)
    delete_response.raise_for_status()
    print("✅ Old data deleted successfully!")
except requests.exceptions.RequestException as e:
    print(f"❌ Failed to delete old data: {e}")
    if hasattr(e, "response") and e.response is not None:
        try:
            error_detail = e.response.json()
            print(f"Error details: {error_detail}")
        except Exception:
            print(f"Response content: {e.response.text}")

print("Starting to add reference experiment data...")
print(f"Time: {current_time}")
print(f"Target API: {API_BASE_URL}")

success = add_element_via_api(element_data)
if success:
    print("\n🎉 Data addition complete!")
    print("\nVerifying data...")
    try:
        stats_response = requests.get(f"{API_BASE_URL}/stats")
        if stats_response.status_code == 200:
            stats = stats_response.json()
            print(f"📊 Current database statistics: {stats['total_records']} records")
        else:
            print("Failed to retrieve database statistics")
    except Exception as e:
        print(f"Failed to get statistics: {e}")

    print("\nAttempting to add index=1 to the candidate set...")
    add_candidate_url = f"{API_BASE_URL}/candidates/1/add"
    try:
        add_response = requests.post(add_candidate_url)
        add_response.raise_for_status()
        add_result = add_response.json()
        print(f"✅ Successfully added index 1 to candidate set: {add_result}")
    except requests.exceptions.RequestException as e:
        print(f"❌ Failed to add to candidate set: {e}")
        if hasattr(e, "response") and e.response is not None:
            try:
                error_detail = e.response.json()
                print(f"Error details: {error_detail}")
            except Exception:
                print(f"Response content: {e.response.text}")
else:
    print("\n❌ Data addition failed! Please check if the API service is running correctly")
