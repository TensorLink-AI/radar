# Changelog

## Unreleased
- Added `einops` to the core requirements so it is installed across all environments.
