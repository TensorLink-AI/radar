# CLAUDE.md

## 1) What this repo is

- **Agentic NAS** (Neural Architecture Search): Automated pipeline for evolving and evaluating time-series forecasting models, designed as a **Bittensor subnet**.
- **Experiment loop**: Sample → Evolve (LLM-generated candidates) → Evaluate → Analyze → Store results in MongoDB
- **Architecture**: "Thin Task, Fat Core" – tasks declare a `TaskDefinition`; shared infrastructure in `core/` handles training, evaluation, and data loading.
- **Core subsystems**:
  - `core/` – shared infrastructure: universal trainer, evaluator, HF streaming dataloaders, model base contract
  - `services/` – orchestration: evolve, eval, analyse interfaces with LLM-backed agents; universal harness packager
  - `tasks/ts_foundation/` – thin time-series forecasting task (TaskDefinition + metrics + dataloader)
  - `subnet/` – Bittensor subnet: validator epoch loop, scoring, chain integration, Epistula protocol
  - `scaffolds/ts_base_model.py` – reference model implementation agents modify
  - `database/` – MongoDB REST API + FAISS embeddings for similarity search
  - `cognition_base/` – OpenSearch RAG service for research paper context

## 2) Fast start (the "do this first" checklist)

### Local Python setup

```bash
python -m venv .venv
source .venv/bin/activate
pip install -e .
# Or: pip install -r requirements-minimal.txt
```

GPU users (CUDA required for mamba-ssm/flash-attn):
```bash
pip install -r requirements-gpu.txt
```

Verified in: `pyproject.toml:13-31`, `requirements-minimal.txt`, `requirements-gpu.txt`

### Bring up backend services (Docker required)

```bash
# MongoDB + Mongo Express
cd database && docker compose up -d

# OpenSearch + Dashboards (for RAG)
cd cognition_base && docker compose up -d
```

### Start API services

```bash
# MongoDB REST API (terminal 1)
cd database && uvicorn mongodb_api:app --host 0.0.0.0 --port 8001 --reload

# RAG service (terminal 2)
cd cognition_base && python rag_api.py
```

Verified in: `docs/TESTING_PIPELINE.md:16-63`

## 3) Commands you will actually use

| Task | Command | Notes | Verified in |
|------|---------|-------|-------------|
| Install | `pip install -e .` | Editable install | `pyproject.toml` |
| Run pipeline | `python -m services.pipeline_v2` | Single experiment loop (miner-side; not in validator repo) | – |
| Manual training | `python manual_train_cli.py --code-path <file> --run-dir <dir>` | CLI entry for training | `manual_train_cli.py`, `pyproject.toml:34` |
| Tests | `pytest tests/` | Unit tests | `tests/` directory |
| Eval (zero_cost) | `bash tasks/ts_foundation/evaluate.sh <name> zero_cost <run_dir>` | Quick proxy | `tasks/ts_foundation/evaluate.sh` |
| Eval (small_budget) | `bash tasks/ts_foundation/evaluate.sh <name> small_budget <run_dir>` | Short training | `tasks/ts_foundation/evaluate.sh` |
| Eval (large_budget) | `bash tasks/ts_foundation/evaluate.sh <name> large_budget <run_dir>` | Full training | `tasks/ts_foundation/evaluate.sh` |
| MongoDB API | `uvicorn database.mongodb_api:app --port 8001` | REST interface | `database/mongodb_api.py` |
| RAG API | `python cognition_base/rag_api.py` | Flask on port 5000 | `cognition_base/rag_api.py` |

## 4) Repo map (where things live)

```
├── core/                        # Shared "Fat Core" infrastructure
│   ├── tasks/
│   │   ├── contracts.py        # BaseTask, TaskDefinition dataclass
│   │   └── registry.py         # @register_task decorator, get_task()
│   ├── models/
│   │   └── base_contract.py    # BaseModel ABC, instantiate_candidate()
│   ├── training/
│   │   ├── universal_trainer.py # Task-agnostic train loop (TrainingConfig, train_model)
│   │   └── universal_evaluator.py # evaluate_model(), count_parameters(), measure_inference_latency()
│   └── data/
│       └── hf_streaming.py     # StreamingWindowDataset, build_hf_dataloaders()
├── services/                    # Orchestration layer (validator-side)
│   ├── config.py               # Config class: URLs, eval tiers, retry limits
│   ├── packager.py             # build_universal_harness() for remote execution
│   ├── eval/                   # Evaluation: Trainer, Debugger, remote training
│   │   └── remote_training/    # Targon/RunPod/Basilica serverless workers
│   ├── analyse/                # Analyzer agent for result interpretation
│   ├── providers/              # LLM client abstraction (Chutes, etc.)
│   └── database/               # MongoDB interface (DataElement CRUD)
├── tasks/
│   └── ts_foundation/          # Thin time-series forecasting task
│       ├── task.py             # TimeSeriesFoundationTask + TASK_DEFINITION
│       ├── model_base.py       # Abstract contract + validate + load_candidate_model
│       ├── metrics.py          # Quantile loss, CRPS, callable factories (loss_fn, eval_fn, forward_fn)
│       ├── dataloader.py       # DatasetBundle, sliding windows, HF streaming
│       ├── zero_cost_proxies.py # Signal-aware zero-cost proxy screening (AZ-NAS inspired)
│       ├── task_prompts.py     # Prompt constants for LLM agents
│       └── evaluate.sh         # Bash dispatcher for eval tiers
├── subnet/                      # Bittensor subnet
│   ├── config.py               # SubnetConfig (env-var overrides)
│   ├── validator/              # Validator epoch loop (4 phases)
│   │   ├── validator.py        # Main epoch orchestrator
│   │   ├── miner_runner.py     # Phase 1: Generation (challenge → Basilica pods)
│   │   ├── filtering.py        # Phase 2: Signal-aware proxy filtering + Borda ranking
│   │   ├── training.py         # Phase 3: Deep training
│   │   ├── scoring.py          # Phase 4: EMA + softmax weight computation
│   │   ├── weights.py          # Submit weights to chain
│   │   └── chain.py            # ChainInterface (bittensor.Subtensor wrapper)
│   ├── protocol/               # Wire format + chain communication
│   │   ├── types.py            # Challenge, MinerSubmission, CandidateResult, EpochState
│   │   ├── epistula.py         # Epistula HTTP signing/verification
│   │   └── commitment.py       # Chain commitment encode/decode
│   └── docker/                 # Deployment
│       ├── validator.Dockerfile
│       └── docker-compose.yml  # Validator + Watchtower
├── scaffolds/
│   └── ts_base_model.py        # Reference implementation agents modify
├── database/                   # MongoDB service
│   ├── mongodb_api.py          # FastAPI REST endpoints
│   ├── docker-compose.yml      # MongoDB + Mongo Express
│   └── candidate_manager.py    # FAISS + embedding logic
├── cognition_base/             # RAG service
│   ├── rag_api.py              # Flask endpoints (port 5000)
│   ├── rag_service.py          # OpenSearch indexing
│   └── docker-compose.yml      # OpenSearch + Dashboards
├── tests/                      # pytest tests
├── manual_train_cli.py         # CLI training entrypoint
└── pyproject.toml              # Package definition
```

## 5) Architecture + data flow (agent mental model)

```
┌─────────────────────────────────────────────────────────────────────────┐
│                          EXPERIMENT LOOP                                 │
│                                                                          │
│  1. program_sample()  ──→  Fetch parent candidate from MongoDB           │
│         ↓                                                                │
│  2. evolve()          ──→  Planner agent writes new code to scaffold     │
│         │                  MotivationChecker ensures novelty             │
│         │                  CodeChecker validates syntax/contract         │
│         ↓                                                                │
│  3. evaluation()      ──→  Load model via instantiate_model()            │
│         │                  Run zero_cost / small_budget / large_budget   │
│         │                  Debugger agent fixes runtime errors           │
│         ↓                                                                │
│  4. analyse()         ──→  Analyzer agent interprets metrics             │
│         │                  RAG provides research paper context           │
│         ↓                                                                │
│  5. update()          ──→  Store DataElement in MongoDB                  │
└─────────────────────────────────────────────────────────────────────────┘
```

### Key contracts and interfaces

| Contract | Location | Purpose |
|----------|----------|---------|
| `TaskDefinition` | `core/tasks/contracts.py` | Declarative task config (thin-task pattern) |
| `BaseTask` | `core/tasks/contracts.py` | Abstract task interface |
| `BaseModel` | `core/models/base_contract.py` | Universal model ABC (`forward`, `from_config`, `to_config`) |
| `TrainingConfig` / `train_model()` | `core/training/universal_trainer.py` | Task-agnostic training loop with pluggable `LossFn`, `EvalFn`, `ForwardFn` |
| `TimeSeriesFoundationModel` | `tasks/ts_foundation/model_base.py` | TS-specific model contract (extends `BaseModel`) |
| `validate_time_series_model()` | `tasks/ts_foundation/model_base.py` | Shape validation via FX tracing |
| `load_candidate_model()` | `tasks/ts_foundation/model_base.py` | Load, validate, and return a candidate model |
| `make_loss_fn()` / `make_eval_fn()` / `make_forward_fn()` | `tasks/ts_foundation/metrics.py` | Callable factories for the universal trainer |
| `instantiate_model()` | Scaffold files | Factory function every candidate must define |
| `evaluate_candidate()` / `borda_rank()` | `tasks/ts_foundation/zero_cost_proxies.py` | Signal-aware zero-cost proxy screening + Borda ranking |
| `Challenge` / `MinerSubmission` | `subnet/protocol/types.py` | Validator↔miner wire format |
| `DataElement` | `services/database/element.py` | DB record schema |

### Forward/generate signature (non-negotiable)

```python
def forward(
    self,
    past_y: Tensor,           # [B, T, C_y]
    past_cov=None,            # [B, T, C_p] or None
    future_cov=None,          # [B, H, C_f] or None
    static=None,              # [B, C_s] or None
    y_future_tf=None,         # [B, H, C_y] teacher forcing
    *, forecast_length=None, input_length=None
) -> Dict[str, Tensor]:
    # Must return: {"quantiles": [B,H,Q], "quantile_levels": [Q]}
```

Verified in: `tasks/ts_foundation/model_base.py:23-50`, `scaffolds/ts_base_model.py:393-445`

## 6) Configuration + environment variables

### Core env vars

| Variable | Required | Default | Purpose | Referenced in |
|----------|----------|---------|---------|---------------|
| `MODEL_NAME` | Yes (for agents) | – | LLM model for provider agents | `services/providers/provider.py:335` |
| `CHUTES_API_KEY` | Yes (for Chutes) | – | API key for Chutes LLM | `services/providers/clients/chutes_client.py:18` |
| `CHUTES_API_URL` | No | `https://llm.chutes.ai` | Chutes endpoint | `services/providers/clients/chutes_client.py:16` |
| `TRAINING_BACKEND` | No | `targon` | Remote training provider (`targon`, `runpod`, or `basilica`) | `services/eval/interface.py:192` |

### Remote training (RunPod/R2)

| Variable | Purpose | Referenced in |
|----------|---------|---------------|
| `RUNPOD_ENDPOINT_ID` | RunPod serverless endpoint | `services/eval/remote_training/client.py:99` |
| `RUNPOD_API_KEY` | RunPod authentication | `services/eval/remote_training/client.py:100` |
| `R2_ENDPOINT_URL` | Cloudflare R2 endpoint | `services/eval/remote_training/job_store.py:79` |
| `R2_ACCESS_KEY_ID` | R2 credentials | `services/eval/remote_training/job_store.py:80` |
| `R2_SECRET_ACCESS_KEY` | R2 credentials | `services/eval/remote_training/job_store.py:81` |
| `R2_BUCKET` | R2 bucket name | `services/eval/remote_training/job_store.py:82` |
| `R2_PREFIX` | Job storage prefix | `services/eval/remote_training/job_store.py:83` |

### GiftEval Pretrain data source

Set `TRAINING_DATA_SOURCE=gifteval_pretrain` to stream training data from pre-windowed Parquet shards on R2 instead of HuggingFace. Requires R2 credentials above.

| Variable | Required | Default | Purpose | Referenced in |
|----------|----------|---------|---------|---------------|
| `TRAINING_DATA_SOURCE` | No | `hf` | Data source (`hf`, `gifteval_pretrain`, `local`) | `tasks/ts_foundation/task.py` |
| `GIFTEVAL_PRETRAIN_BUCKET` | No | `giftevalpretrain` | R2 bucket for pretrain shards | `tasks/ts_foundation/gifteval_pretrain_loader.py` |
| `GIFTEVAL_PRETRAIN_PREFIX` | No | `gifteval_pretrain_flat_1024x256/` | Key prefix for shard files | `tasks/ts_foundation/gifteval_pretrain_loader.py` |
| `GIFTEVAL_PRETRAIN_ENV_PREFIX` | No | `R2` | Env var prefix for S3 credentials | `tasks/ts_foundation/gifteval_pretrain_loader.py` |

### Remote training (Basilica/Affinetes)

Basilica is an alternative GPU cloud platform using Affinetes for container orchestration. Set `TRAINING_BACKEND=basilica` to use it.

| Variable | Required | Default | Purpose | Referenced in |
|----------|----------|---------|---------|---------------|
| `BASILICA_API_TOKEN` | Yes (for Basilica) | – | API authentication token | `services/eval/remote_training/client.py` |
| `BASILICA_DOCKER_IMAGE` | Yes (for Basilica) | – | Docker image for training | `services/eval/remote_training/client.py` |
| `BASILICA_GPU_TYPE` | No | auto | GPU type (e.g., A4000, A100). Auto-normalized to SDK format (NVIDIA-RTX-A4000). If unset, Basilica auto-selects | `services/eval/remote_training/client.py` |
| `BASILICA_GPU_COUNT` | No | `1` | Number of GPUs per container | `services/eval/remote_training/client.py` |
| `BASILICA_GPU_MEMORY_GB` | No | `16` | Minimum GPU VRAM in GB | `services/eval/remote_training/client.py` |
| `BASILICA_MEMORY` | No | `16Gi` | Container memory | `services/eval/remote_training/client.py` |
| `BASILICA_TTL_SMALL` | No | `3600` | TTL for small training (1 hour) | `services/eval/remote_training/client.py` |
| `BASILICA_TTL_LARGE` | No | `14400` | TTL for large training (4 hours) | `services/eval/remote_training/client.py` |
| `BASILICA_DEPLOYMENT_NAME` | No | `agentic-nas-trainer` | Deployment name prefix | `services/eval/remote_training/client.py` |

Example Basilica setup:
```bash
# Build and push Docker image first
docker build -f services/eval/remote_training/basilica/Dockerfile -t your-registry/agentic-nas-basilica:latest .
docker push your-registry/agentic-nas-basilica:latest

# Required: Configure Basilica
export BASILICA_API_TOKEN=your-token-here
export BASILICA_DOCKER_IMAGE=your-registry/agentic-nas-basilica:latest
export TRAINING_BACKEND=basilica

# Optional: Configure resources (GPU type auto-selected if not specified)
export BASILICA_GPU_TYPE=A100  # or omit for auto-selection
export BASILICA_MEMORY=32Gi
```

### Agent tuning

| Variable | Default | Purpose | Referenced in |
|----------|---------|---------|---------------|
| `AGENT_MAX_TOOL_ROUNDS` | 4 | Max tool rounds | `services/providers/config.py:94` |
| `AGENT_MAX_TOOL_CALLS_PER_ROUND` | 8 | Calls per round | `services/providers/config.py:96` |
| `AGENT_MAX_TOOL_CALLS_TOTAL` | 32 | Total call budget | `services/providers/config.py:98` |

### Per-agent model configuration

Each agent can use a different LLM model. Set `<AGENT>_MODEL` to override, or fall back to `MODEL_NAME`.
Model selection is implemented by `get_agent_model()` in `services/providers/config.py:11-31`.

**Validator-side agents** (present in this repo):

| Variable | Default | Purpose | Referenced in |
|----------|---------|---------|---------------|
| `ANALYZER_MODEL` | `MODEL_NAME` | Model for Analyzer agent | `services/analyse/interface.py:33` |
| `SUMMARIZER_MODEL` | `MODEL_NAME` | Model for Summarizer agent | `services/analyse/interface.py:34` |
| `DEBUGGER_MODEL` | `MODEL_NAME` | Model for Debugger agent | `services/eval/interface.py` |

**Miner-side agents** (moved to `miner.providers.agents`, not in this repo):

| Variable | Default | Purpose |
|----------|---------|---------|
| `PLANNER_MODEL` | `MODEL_NAME` | Model for Planner agent |
| `DEDUPLICATOR_MODEL` | `MODEL_NAME` | Model for Deduplicator agent |
| `MOTIVATION_CHECKER_MODEL` | `MODEL_NAME` | Model for MotivationChecker agent |
| `CODE_CHECKER_MODEL` | `MODEL_NAME` | Model for CodeChecker agent |

Example usage:
```bash
export MODEL_NAME=meta-llama/Llama-4-Scout-17B-16E-Instruct
export ANALYZER_MODEL=deepseek-ai/DeepSeek-V3
```

### Subnet configuration

| Variable | Default | Purpose | Referenced in |
|----------|---------|---------|---------------|
| `SUBNET_NETUID` | `0` | Bittensor network UID | `subnet/config.py` |
| `SUBNET_TASK_NAME` | `time_series_foundation` | Active task name | `subnet/config.py` |
| `EPOCH_LENGTH_SECONDS` | `86400` | Epoch duration | `subnet/config.py` |
| `PARENT_POOL_SIZE` | `5` | Parents sampled per epoch | `subnet/config.py` |
| `MAX_PARAMS` | `125000000` | Model parameter budget (125M) | `subnet/config.py` |
| `MAX_INFERENCE_LATENCY_MS` | `50` | Latency constraint (ms) | `subnet/config.py` |
| `ZERO_COST_TOP_K` | `16` | Candidates after proxy filtering | `subnet/config.py` |
| `SHORT_TRAIN_TOP_M` | `19` | Candidates after short training | `subnet/config.py` |
| `DEEP_TRAIN_TOP_L` | `3` | Candidates for long training | `subnet/config.py` |
| `INJECT_BEST_PARENT` | `1` | Inject DB best parent as baseline | `subnet/config.py` |
| `SHORT_TRAIN_TIMEOUT_SEC` | `3600` | Phase 3a timeout (1 h) | `subnet/config.py` |
| `DEEP_TRAIN_TIMEOUT_SEC` | `14400` | Phase 3b timeout (4 h) | `subnet/config.py` |
| `EMA_ALPHA` | `0.1` | Score EMA decay | `subnet/config.py` |
| `SOFTMAX_TEMPERATURE` | `1.0` | Weight softmax temperature | `subnet/config.py` |
| `PENALTY_EXPONENT` | `2.5` | Verification penalty exponent | `subnet/config.py` |
| `PROXY_EVAL_IMAGE` | `DEEP_TRAIN_IMAGE` | Docker image for proxy eval | `subnet/config.py` |
| `PROXY_EVAL_TIMEOUT_SEC` | `600` | Proxy eval pod timeout | `subnet/config.py` |
| `PROXY_EVAL_LOCAL` | `0` | Use local CPU for proxy eval | `subnet/config.py` |
| `LINEAGE_CHECK_ENABLED` | `1` | Enable lineage diff checks | `subnet/config.py` |
| `LINEAGE_MIN_SIMILARITY` | `0.10` | Minimum parent-child similarity | `subnet/config.py` |
| `LINEAGE_MAX_REPLACEMENT_RATIO` | `0.95` | Max parent line replacement | `subnet/config.py` |

### Service URLs

```python
# services/config.py
Config.RAG = "http://localhost:5000"       # RAG service (rag_api.py runs on 5000)
Config.DATABASE = "http://localhost:8001"  # MongoDB REST API

# subnet/config.py
SubnetConfig.COGNITION_BASE_URL = "http://localhost:13142"  # ⚠ Mismatch: should be 5000
SubnetConfig.DATABASE_URL = "http://localhost:8001"
```

**Note**: `subnet/config.py` defaults `COGNITION_BASE_URL` to port 13142 but `rag_api.py` listens on port 5000. Set `COGNITION_BASE_URL=http://localhost:5000` in your environment or update `subnet/config.py`.

## 7) How to make changes safely (guardrails)

### Don't break these invariants

1. **Model contract**: Class must be named `TimeSeriesFoundationModel`, subclass `BaseTSFM`, implement `forward()`, `generate()`, `from_config()`, `to_config()`
2. **Factory pattern**: `instantiate_model()` must call `validate_time_series_model(model)` before returning
3. **Output shape**: `forward()`/`generate()` must return `{"quantiles": [B,H,Q], "quantile_levels": [Q]}`
4. **Quantile levels**: Must be 1D tensor with strictly increasing values in (0, 1)
5. **No future leakage**: Apply causal masks BEFORE softmax in attention
6. **d_model consistency**: All Linear layers must match `d_model` (typically 256) – don't hardcode 64/128

Verified in: `tasks/ts_foundation/model_base.py`, `scaffolds/ts_base_model.py`

### Common pitfalls to avoid

| Pitfall | Symptom | Fix |
|---------|---------|-----|
| Shape mismatch in matmul | `shapes cannot be multiplied (2x256 and 64x256)` | Use `d_model` from config, not hardcoded dims |
| Missing `validate_time_series_model()` | Validation errors at runtime | Always call in `instantiate_model()` |
| Hardcoded forecast length | Output shape differs from `forecast_length` arg | Use `forecast_length` parameter dynamically |
| Mask applied after softmax | Future information leaks | Build mask, apply BEFORE softmax |
| Non-JSON-serializable config | `to_config()` fails | Return only primitive types |

### Before committing

```bash
# Run tests
pytest tests/

# Verify model contract (quick check)
python -c "from scaffolds.ts_base_model import instantiate_model; m = instantiate_model(); print(m)"
```

### Adding new tasks (thin-task pattern)

1. Create `tasks/<task_name>/` directory
2. Define a `TaskDefinition` in `task.py` (name, hf_repo_id, max_params, metrics, budgets, etc.)
3. Subclass `BaseTask` in `task.py`, implement the `definition` property, and use `@register_task("<task_name>")`
4. Provide `model_base.py` with the abstract model contract (subclass `core.models.base_contract.BaseModel`)
5. Provide `metrics.py` with callable factories: `make_loss_fn()`, `make_eval_fn()`, `make_forward_fn()`, `row_to_sample()`
6. Create scaffold in `scaffolds/`
7. Wire `train_and_eval()` to use `core.training.universal_trainer.train_model()` with your callables

See `tasks/ts_foundation/` for the reference implementation.

## 8) Debugging playbook

### Top failure modes

| Failure | Where to look | Resolution |
|---------|---------------|------------|
| `instantiate_model() must return TimeSeriesFoundationModel` | Check scaffold imports | Ensure class inherits from `BaseTSFM` |
| `'quantiles' expected shape [B, H, Q]` | `validate_time_series_model()` in model_base.py | Fix output dimensions in forward/generate |
| `ShapeProp failed at call_function` | FX tracing in validation | Check Linear layer dims, avoid dynamic control flow |
| Import errors in candidate | `load_candidate_model()` in model_base.py | Verify all imports exist in candidate file |
| MongoDB connection refused | `database/mongodb_api.py` | Start Docker: `cd database && docker compose up -d` |
| RAG 404/connection error | `cognition_base/rag_api.py` | Start OpenSearch + RAG: `cd cognition_base && docker compose up -d && python rag_api.py` |

### Key log locations

- Run artifacts: `./runs/<run_id>/` (metrics, logs, candidate code)
- Eval runs: `./eval_runs/`
- MongoDB logs: `docker compose logs mongodb`
- Training history: `<run_dir>/<eval_type>_history.json`

Verified in: `services/config.py:9-10`

### Shape debugging

The validator uses FX tracing (`torch.fx.experimental.proxy_tensor.make_fx`) to catch shape errors before training. If shape prop fails:

1. Check the error message for `target=` and `operand shapes`
2. Look for mismatched dimensions in Linear layers
3. Verify `d_model` is used consistently, not hardcoded values

Verified in: `tasks/ts_foundation/model_base.py:220-415`

### Thread safety / async caveats

- Validator filtering runs zero-cost eval in `asyncio.to_thread()` to avoid blocking the event loop (`subnet/validator/filtering.py`)
- Remote training jobs are dispatched asynchronously via `services/eval/remote_training/`
- LLM agent calls use async provider clients (`services/providers/`)

## 9) PR / commit expectations

### Checklist

- [ ] Tests pass: `pytest tests/`
- [ ] Model contract preserved (if touching scaffolds/tasks)
- [ ] No hardcoded dimensions (use config values)
- [ ] Config changes documented in this file
- [ ] New env vars added to section 6

### CI

**TODO**: No `.github/workflows/` directory found. Consider adding:
- `pytest` job for tests
- Lint/format checks (ruff/black)

### Commit style

Keep commits focused. Reference issue numbers if applicable.

## 10) TODOs / missing docs you noticed

| Gap | Where to add | Suggestion |
|-----|--------------|------------|
| No CI/CD pipeline | `.github/workflows/ci.yml` | Add pytest + lint workflow |
| No lint/format config | `pyproject.toml` or `ruff.toml` | Add ruff/black configuration |
| `SubnetConfig.COGNITION_BASE_URL` port mismatch | `subnet/config.py:77` | Default is 13142 but `rag_api.py` listens on 5000; align one way or the other |
| ~~No `.env.example`~~ | `.env.example` | ✅ Added – copy to `.env` and fill in values |
| Missing `requirements.txt` at root | Repo root | Currently only `requirements-minimal.txt` and `requirements-gpu.txt` |
| Database init script missing | `database/init-mongo.js` | Referenced in docker-compose but file does not exist |
| No type checking config | `pyproject.toml` | Add mypy or pyright configuration |
| Subnet validator not yet wired to real chain | `subnet/validator/` | Phase stubs need Basilica + bittensor SDK integration |
| No subnet tests | `tests/test_subnet_*.py` | Add unit tests for scoring, filtering, protocol |
| Miner-side agents moved | `services/providers/agents/` | Planner, CodeChecker, Debugger have moved to `miner.providers.agents` (separate repo) |

## 11) Bittensor subnet design rules and recommendations

Reference: [unconst/Chi](https://github.com/unconst/Chi) – canonical subnet design knowledge base.

### Non-negotiable invariants

1. **Only write validator code, NEVER write miner code.** Validators define the game rules; miners discover optimal strategies by reading `validator.py`.
2. **One-sentence clarity.** A subnet must answer "What am I actually measuring?" in a single sentence. If the answer contains "and" or "various things depending on task", the design is wrong.
3. **No secret evaluation sets.** They ALWAYS leak. Validators running their own miners will share answers → those miners get perfect scores → honest miners lose. This attack is invisible and certain on valuable subnets.
4. **Validators are NOT individually trustworthy.** Assume validators share eval data with their own miners and manipulate weights. Stake-weighted consensus is the only mitigation.
5. **Coldkeys are NOT sybil-proof.** Anyone can create unlimited coldkeys. Never rely on coldkey deduplication for sybil resistance.
6. **Push compute costs to miners, NOT validators.** Miners host endpoints; validators make API calls. Never have validators download and run models locally.

### Communication protocol

- **Axon/dendrite/synapse is deprecated.** Use HTTP REST APIs with Epistula signing.
- Miners commit connection info (endpoints, storage URLs, docker images) to chain via `subtensor.set_commitment()`.
- Chain commitment limit: **1 per 100 blocks (~20 min)**. Commit storage locations, not individual data items.
- Epistula headers: `X-Epistula-Timestamp`, `X-Epistula-Signature`, `X-Epistula-Hotkey`. Validate timestamp freshness (within 60s), verify signature via keypair, confirm caller holds validator status.

### Trust model – what CAN and CANNOT be trusted

| Trustworthy | NOT trustworthy |
|-------------|-----------------|
| External third-party APIs | Individual validators |
| Cryptographic time-lock reveals (drand) | Secret evaluation sets |
| Hardware attestation (TEE proofs) | Similarity detection (easier to evade than enforce) |
| Emergent answers from adversarial miner competition | Coldkey identity (no identity system in Bittensor) |
| On-chain data (registrations, stakes, weights, blocks) | Proprietary ground truth controlled by validators |

### Sybil resistance

- Real protection comes from **economic constraints**, not identity verification.
- 256 UID slots + dynamic registration costs create equilibrium: fees scale with expected rewards.
- **Design mechanisms where N miners isn't N times more profitable.** This is the bottom line.
- Registration costs naturally rise when subnet rewards are attractive, making multi-account attacks economically unfeasible.

### Incentive mechanism design flow

1. **Define commodity** – What miners provide: compute, data, predictions, external verification, detection/generation, or software agents.
2. **Establish ground truth** – Verification timing: immediate validator checks, delayed scoring, external APIs, or emergent adversarial challenges.
3. **Trust audit** – Four "no" checks: validators can't control truth, no secret eval sets, similarity detection is unreliable, coldkey dedup doesn't prevent sybils.
4. **Compute location** – Miners host endpoints; validators call APIs.
5. **Pattern selection** – Match to one of eight architectural patterns:
   - `compute_auction` – GPU/compute bidding
   - `capacity_market` – availability and throughput
   - `data_indexing` – data contribution and retrieval
   - `prediction_market` – forecasts scored against future outcomes
   - `time_series_forecasting` – time-series prediction (our task)
   - `external_activity_verification` – off-chain work validation (e.g. GitHub PRs)
   - `adversarial_red_blue` – miners challenge each other, validators don't know answers
   - `container_execution` – miners submit Docker images, compete on software quality
6. **Implement** – Single `validator.py` with config, miner specs, scoring logic, weight setting, and main loop.

### Scoring and weight setting

- Use **exponential moving average (EMA)** for reputation building over time.
- **Softmax normalization** with adjustable temperature to convert scores → weights.
- Weights must **sum to 1.0** and be submitted on schedule respecting rate limits.
- Penalty mechanisms: e.g. `verification_success_ema ^ 2.5` to exponentially discourage failures.
- **Commit-reveal for weights** only when weight-copying is a proven problem, not by default.
- Coldkey deduplication: keep highest-scoring hotkey per coldkey (helps but doesn't prevent sybils).

### Anti-gaming measures

- Credibility tracking and time decay rewarding freshness.
- Uniqueness scoring penalizing duplicated content.
- Response time variance detection for rate-gaming.
- Per-coldkey deduplication (best hotkey per coldkey).
- **Open source is preferred** – transparent mechanisms outperform black boxes because they enable miner learning, reduce attack surfaces, and allow auditing.

### Validator implementation requirements

- All logic in a single `validator.py` containing: configuration, miner specs, scoring logic, weight setting, main loop.
- Comprehensive docstrings explaining: what metric is measured, endpoint format, request/response schemas, scoring criteria.
- Must handle: timeout handling, historical score tracking (EMA), gaming prevention, deterministic scoring.
- **Must NOT**: write miner code, create reference solutions, conceal evaluation logic, maintain secret test sets, trust proprietary ground truth.

### Miner implementation requirements

- Subnet owners do NOT write miner code. Miners read `validator.py` to learn the interface.
- Miners register hotkey, commit endpoint to chain, serve requests, optimize for validator criteria.
- Recommended: FastAPI/Flask with epistula authentication.
- Alternatives: socket.io (when no public endpoint needed), external activity mining (no server), container submission (Docker images to registry).

### Operational recommendations

- **Deployment**: Docker + Watchtower auto-update pattern. GitHub Actions builds container images; Watchtower detects new releases every 5 minutes.
- **Environments**: Local (free TAO, ~6s blocks) → Testnet (free TAO faucet, ~12s blocks) → Mainnet (real TAO, ~12s blocks).
- **Security**: Coldkey stays air-gapped, never on servers. Hotkey can be on-server but rotate if compromised.
- **Monitoring**: Track requests/min, response time, success rate, emissions. Alert on service failures, error rates > 5%, registration changes.
- **Locked parameters**: tempo, max_allowed_uids (cannot change).
- **Adjustable parameters**: immunity_period (default 7200 blocks), weights_rate_limit, difficulty, burn, commit-reveal settings.
- **Emission split**: Validators 41%, Miners 41%, Subnet owner 18%.
