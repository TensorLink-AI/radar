"""
Universal model base contract.

Every candidate model (regardless of task) must satisfy a minimal
interface so that the universal trainer and evaluator can load,
train, and score it without knowing the task-specific details.

Task-specific abstract base classes (e.g.
``tasks.ts_foundation.model_base.TimeSeriesFoundationModel``) extend
this contract with additional signatures like ``forward()`` and
``generate()``.  The universal trainer only depends on this file.
"""

from __future__ import annotations

import importlib.util
from abc import ABC, abstractmethod
from typing import Any, Dict, Optional

import torch
import torch.nn as nn


class BaseModel(nn.Module, ABC):
    """Absolute minimum contract every candidate model must satisfy.

    Subclasses must implement:
    - ``forward(**batch) -> Dict[str, Tensor]``
    - ``from_config(cfg) -> BaseModel``  (class method)
    - ``to_config() -> Dict[str, Any]``

    ``forward`` receives a batch dict whose keys are defined by the
    task's dataloader and returns a dict that the task's loss function
    can consume.
    """

    @abstractmethod
    def forward(self, **kwargs) -> Dict[str, torch.Tensor]:
        """Run the model on a single batch (training mode).

        Args:
            **kwargs: Task-specific batch tensors (e.g. ``past_y``,
                ``future_target``, ``input_ids``).

        Returns:
            A dict of output tensors the task's loss function needs.
        """
        ...

    @classmethod
    @abstractmethod
    def from_config(cls, cfg: Dict[str, Any]) -> "BaseModel":
        """Reconstruct the model from a JSON-serialisable config."""
        ...

    @abstractmethod
    def to_config(self) -> Dict[str, Any]:
        """Serialise the model's hyperparameters to a plain dict.

        Must round-trip: ``Model.from_config(model.to_config())``
        should produce an equivalent model.
        """
        ...


def load_candidate_module(candidate_code_path: str):
    """Dynamically import a candidate source file and return the module.

    The module must define an ``instantiate_model()`` factory function.
    """
    spec = importlib.util.spec_from_file_location(
        "candidate_model", candidate_code_path,
    )
    if spec is None or spec.loader is None:
        raise ImportError(
            f"Could not load candidate module at {candidate_code_path}"
        )
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)

    if not hasattr(module, "instantiate_model"):
        raise AttributeError(
            f"Candidate module '{candidate_code_path}' must define "
            "instantiate_model()."
        )
    return module


def instantiate_candidate(
    candidate_code_path: str,
    device: torch.device,
    *,
    model_config: Optional[Dict[str, Any]] = None,
) -> nn.Module:
    """Load and instantiate a candidate model on *device*.

    This is a task-agnostic version of
    ``tasks.ts_foundation.training.load_candidate_model()``.
    Task-specific validation (e.g. shape checking) should be applied
    separately by the task after calling this function.
    """
    module = load_candidate_module(candidate_code_path)
    instantiate = module.instantiate_model

    try:
        model = (
            instantiate(model_config) if model_config is not None
            else instantiate()
        )
    except TypeError:
        if model_config is None:
            raise
        model = instantiate(**model_config)

    model.to(device)
    return model
