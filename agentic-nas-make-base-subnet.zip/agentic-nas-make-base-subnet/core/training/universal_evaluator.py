"""
Universal evaluation loop.

Task-agnostic model evaluation on a ``DataLoader``.  The caller
supplies a ``score_batch`` callable that knows how to extract
predictions from the model output and compare them to targets.

This module is designed to work with the universal trainer but can
also be used standalone for zero-cost proxy evaluation.
"""

from __future__ import annotations

from typing import Any, Callable, Dict, Optional, Protocol

import torch
from torch.utils.data import DataLoader


class ScoreBatchFn(Protocol):
    """Score a single (output, batch) pair.

    Returns a dict of metric_name -> scalar float.  The evaluator
    averages these across all batches.
    """

    def __call__(
        self,
        output: Dict[str, torch.Tensor],
        batch: Dict[str, torch.Tensor],
        device: torch.device,
    ) -> Dict[str, float]: ...


def evaluate_model(
    model: torch.nn.Module,
    loader: DataLoader,
    score_batch: ScoreBatchFn,
    *,
    device: Optional[torch.device] = None,
    forward_fn: Optional[Callable] = None,
    max_batches: Optional[int] = None,
) -> Dict[str, float]:
    """Run evaluation, return averaged metrics.

    Args:
        model: Trained model.
        loader: Validation or test ``DataLoader``.
        score_batch: Task-specific scoring function.
        device: Target device (defaults to model's current device).
        forward_fn: Optional override for calling the model (same
            signature as ``universal_trainer.ForwardFn``).
        max_batches: Cap the number of batches evaluated (useful for
            quick proxy scores).

    Returns:
        Dict of metric_name -> averaged float value.
    """
    if device is None:
        device = next(model.parameters()).device

    model.eval()
    accumulators: Dict[str, float] = {}
    count = 0

    with torch.no_grad():
        for i, batch in enumerate(loader):
            if max_batches is not None and i >= max_batches:
                break

            if forward_fn is not None:
                output = forward_fn(model, batch, device)
            else:
                device_batch = {
                    k: v.to(device) if isinstance(v, torch.Tensor) else v
                    for k, v in batch.items()
                }
                output = model(**device_batch)

            batch_metrics = score_batch(output, batch, device)
            for k, v in batch_metrics.items():
                accumulators[k] = accumulators.get(k, 0.0) + v
            count += 1

    if count == 0:
        return {}

    return {k: v / count for k, v in accumulators.items()}


def count_parameters(model: torch.nn.Module, trainable_only: bool = True) -> int:
    """Return the number of (trainable) parameters."""
    if trainable_only:
        return sum(p.numel() for p in model.parameters() if p.requires_grad)
    return sum(p.numel() for p in model.parameters())


def measure_inference_latency(
    model: torch.nn.Module,
    sample_batch: Dict[str, torch.Tensor],
    device: torch.device,
    *,
    forward_fn: Optional[Callable] = None,
    warmup_iters: int = 3,
    measure_iters: int = 10,
) -> float:
    """Measure average forward-pass latency in milliseconds.

    Args:
        model: The model to benchmark.
        sample_batch: A representative batch.
        device: CUDA device (CPU timing is less reliable).
        forward_fn: Optional override for calling the model.
        warmup_iters: GPU warmup iterations.
        measure_iters: Timed iterations.

    Returns:
        Average latency in milliseconds.
    """
    model.eval()
    fwd = forward_fn or (lambda m, b, d: m(**{
        k: v.to(d) if isinstance(v, torch.Tensor) else v
        for k, v in b.items()
    }))

    with torch.no_grad():
        for _ in range(warmup_iters):
            fwd(model, sample_batch, device)

        if device.type == "cuda":
            torch.cuda.synchronize()

        import time
        start = time.perf_counter()
        for _ in range(measure_iters):
            fwd(model, sample_batch, device)
        if device.type == "cuda":
            torch.cuda.synchronize()
        elapsed = time.perf_counter() - start

    return (elapsed / measure_iters) * 1000.0
