"""
Universal training loop.

Task-agnostic PyTorch training that works with any model satisfying
``core.models.base_contract.BaseModel``.  Tasks plug in via:

- **loss_fn(output, batch, device)** – computes scalar loss.
- **eval_fn(model, loader, device)** – returns a metrics dict.

This module is extracted from ``tasks/ts_foundation/training.py`` so
that new tasks can reuse it without copying the training loop.
"""

from __future__ import annotations

import csv
import json
import math
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Protocol

import torch
from torch.nn.utils import clip_grad_norm_
from torch.optim import AdamW
from torch.utils.data import DataLoader


# ── Protocols (callables the task must provide) ─────────────────────────


class LossFn(Protocol):
    """Compute scalar loss from model output + batch."""

    def __call__(
        self,
        output: Dict[str, torch.Tensor],
        batch: Dict[str, torch.Tensor],
        device: torch.device,
    ) -> torch.Tensor: ...


class EvalFn(Protocol):
    """Evaluate model on a DataLoader, return metrics dict."""

    def __call__(
        self,
        model: torch.nn.Module,
        loader: DataLoader,
        device: torch.device,
    ) -> Dict[str, float]: ...


class ForwardFn(Protocol):
    """Call the model on a single batch, return output dict.

    Default implementation just calls ``model(**batch_tensors)`` but
    tasks can override to pass extra kwargs (e.g. ``forecast_length``).
    """

    def __call__(
        self,
        model: torch.nn.Module,
        batch: Dict[str, torch.Tensor],
        device: torch.device,
    ) -> Dict[str, torch.Tensor]: ...


# ── Config ──────────────────────────────────────────────────────────────


@dataclass
class TrainingConfig:
    """Configuration for the universal training loop.

    All fields have sensible defaults; override per-task as needed.
    """

    # Training budget
    max_steps: int = 100
    eval_interval: int = 64
    batch_size: int = 32

    # Optimiser
    learning_rate: float = 1e-3
    weight_decay: float = 1e-4
    gradient_clip: float = 1.0

    # LR schedule
    warmup_steps: int = 0
    lr_scheduler: str = "constant"  # "constant" | "cosine" | "linear"
    min_lr_ratio: float = 0.1

    # Stability
    max_consecutive_nan: int = 10
    log_grad_norm: bool = True

    # Device / reproducibility
    device: Optional[str] = None
    seed: int = 42

    # Evaluation limits (None = full pass)
    max_val_batches: Optional[int] = None

    # Arbitrary extra config forwarded to loss/eval/forward fns
    extra: Dict[str, Any] = field(default_factory=dict)


@dataclass
class TrainingResult:
    """Return value of ``train_model()``."""

    metrics: Dict[str, Any]
    history: List[Dict[str, Any]]
    steps_completed: int
    model: torch.nn.Module


# ── LR scheduling ──────────────────────────────────────────────────────


def _get_lr_multiplier(
    step: int,
    warmup_steps: int,
    max_steps: int,
    scheduler_type: str,
    min_lr_ratio: float,
) -> float:
    """Compute LR multiplier for warmup + decay scheduling."""
    if warmup_steps > 0 and step <= warmup_steps:
        return step / warmup_steps

    if scheduler_type == "constant":
        return 1.0

    decay_steps = max_steps - warmup_steps
    if decay_steps <= 0:
        return 1.0

    progress = min(1.0, max(0.0, (step - warmup_steps) / decay_steps))

    if scheduler_type == "cosine":
        return min_lr_ratio + (1.0 - min_lr_ratio) * 0.5 * (
            1.0 + math.cos(math.pi * progress)
        )
    elif scheduler_type == "linear":
        return 1.0 - progress * (1.0 - min_lr_ratio)
    return 1.0


def _compute_grad_norm(model: torch.nn.Module) -> float:
    total_norm = 0.0
    for p in model.parameters():
        if p.grad is not None:
            total_norm += p.grad.data.norm(2).item() ** 2
    return total_norm ** 0.5


# ── I/O helpers ─────────────────────────────────────────────────────────


def _write_json(path: Path, payload: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(payload, f, indent=2, default=float)


def _write_csv(path: Path, rows: List[Dict[str, Any]]) -> None:
    if not rows:
        return
    path.parent.mkdir(parents=True, exist_ok=True)
    fieldnames: set = set()
    for row in rows:
        fieldnames.update(row.keys())
    sorted_fields = sorted(fieldnames)
    if "step" in sorted_fields:
        sorted_fields.remove("step")
        sorted_fields.insert(0, "step")
    with open(path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=sorted_fields)
        writer.writeheader()
        for row in rows:
            writer.writerow(row)


# ── Default forward function ───────────────────────────────────────────


def _default_forward(
    model: torch.nn.Module,
    batch: Dict[str, torch.Tensor],
    device: torch.device,
) -> Dict[str, torch.Tensor]:
    """Move batch tensors to device and call model.forward()."""
    device_batch = {
        k: v.to(device) if isinstance(v, torch.Tensor) else v
        for k, v in batch.items()
    }
    return model(**device_batch)


# ── Main training loop ──────────────────────────────────────────────────


def train_model(
    model: torch.nn.Module,
    train_loader: DataLoader,
    loss_fn: LossFn,
    config: TrainingConfig,
    *,
    val_loader: Optional[DataLoader] = None,
    eval_fn: Optional[EvalFn] = None,
    forward_fn: Optional[ForwardFn] = None,
    run_dir: Optional[str] = None,
    eval_type: str = "small_budget",
    progress_callback: Optional[Callable[[Dict[str, Any]], None]] = None,
) -> TrainingResult:
    """Run a generic PyTorch training loop.

    This is the universal replacement for
    ``tasks.ts_foundation.training.train_model()``.  The caller
    provides task-specific callables (loss, eval, forward) and this
    function handles the rest: gradient clipping, LR scheduling, NaN
    detection, metric recording, and checkpoint I/O.

    Args:
        model: Any ``nn.Module`` (need not subclass ``BaseModel``).
        train_loader: Training ``DataLoader``.
        loss_fn: ``(output, batch, device) -> scalar Tensor``.
        config: ``TrainingConfig`` with budget and optimiser params.
        val_loader: Optional validation ``DataLoader``.
        eval_fn: Optional ``(model, loader, device) -> metrics dict``.
        forward_fn: Optional override for how to call the model.
            Default moves batch to device and calls ``model(**batch)``.
        run_dir: If set, write JSON/CSV metrics here.
        eval_type: Label for output files (e.g. ``"small_budget"``).
        progress_callback: Called with metrics dict after each eval.

    Returns:
        ``TrainingResult`` with final metrics, history, and model.
    """
    device = (
        torch.device(config.device) if config.device
        else torch.device("cuda" if torch.cuda.is_available() else "cpu")
    )
    torch.manual_seed(config.seed)
    if device.type == "cuda":
        torch.cuda.manual_seed_all(config.seed)

    model.to(device)
    fwd = forward_fn or _default_forward

    optimizer = AdamW(
        model.parameters(),
        lr=config.learning_rate,
        weight_decay=config.weight_decay,
    )

    step = 0
    running_loss = 0.0
    running_batches = 0
    history: List[Dict[str, Any]] = []
    consecutive_nan = 0
    total_nan = 0

    while step < config.max_steps:
        for batch in train_loader:
            model.train()
            optimizer.zero_grad()

            # Forward pass
            try:
                output = fwd(model, batch, device)
            except Exception:
                raise

            loss = loss_fn(output, batch, device)

            # NaN / Inf guard
            if torch.isnan(loss) or torch.isinf(loss):
                consecutive_nan += 1
                total_nan += 1
                step += 1
                history.append({
                    "step": step,
                    "train_loss": float("nan"),
                    "nan_skipped": True,
                })
                if consecutive_nan >= config.max_consecutive_nan:
                    raise RuntimeError(
                        f"Training halted: {consecutive_nan} consecutive "
                        "NaN/Inf losses."
                    )
                if step >= config.max_steps:
                    break
                continue

            consecutive_nan = 0
            loss.backward()

            grad_norm = None
            if config.log_grad_norm:
                grad_norm = _compute_grad_norm(model)

            if config.gradient_clip:
                clip_grad_norm_(model.parameters(), config.gradient_clip)

            step += 1
            lr_mult = _get_lr_multiplier(
                step,
                config.warmup_steps,
                config.max_steps,
                config.lr_scheduler,
                config.min_lr_ratio,
            )
            current_lr = config.learning_rate * lr_mult
            for pg in optimizer.param_groups:
                pg["lr"] = current_lr

            optimizer.step()

            running_loss += loss.item()
            running_batches += 1

            entry: Dict[str, Any] = {
                "step": step,
                "train_loss": float(loss.item()),
                "running_train_loss": running_loss / max(running_batches, 1),
                "learning_rate": current_lr,
            }
            if grad_norm is not None:
                entry["grad_norm"] = grad_norm

            # Periodic validation
            if (
                val_loader is not None
                and eval_fn is not None
                and step % config.eval_interval == 0
                and step < config.max_steps
            ):
                val_metrics = eval_fn(model, val_loader, device)
                for k, v in val_metrics.items():
                    entry[f"val_{k}"] = float(v)
                if progress_callback:
                    progress_callback({"step": step, **entry})

            history.append(entry)

            if step >= config.max_steps:
                break

        if step >= config.max_steps:
            break

    # Final evaluation
    train_loss = running_loss / max(running_batches, 1)
    val_metrics: Dict[str, Any] = {}
    if val_loader is not None and eval_fn is not None:
        val_metrics = eval_fn(model, val_loader, device)

    metrics: Dict[str, Any] = {
        "train": {"loss": float(train_loss)},
        "validation": {k: float(v) for k, v in val_metrics.items()},
        "budget": {"steps": step, "max_steps": config.max_steps},
        "metadata": {
            "device": str(device),
            "batch_size": config.batch_size,
            "total_nan_batches": total_nan,
        },
        "history": history,
    }

    if hasattr(model, "to_config"):
        metrics["model"] = {"config": model.to_config()}

    # Persist metrics
    if run_dir:
        run_path = Path(run_dir)
        _write_json(run_path / f"{eval_type}_metrics.json", metrics)
        if history:
            _write_json(run_path / f"{eval_type}_history.json", history)
            _write_csv(run_path / f"{eval_type}_train.csv", history)

    return TrainingResult(
        metrics=metrics,
        history=history,
        steps_completed=step,
        model=model,
    )
