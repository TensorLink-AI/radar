"""
Concurrent CUDA-streams training loop.

Trains multiple models simultaneously on a single GPU using one
``torch.cuda.Stream`` per model with round-robin scheduling.  This
is the production variant of the pattern proven in
``stress_test/stress_main_streams.py``.

The public entry point is :func:`train_models_concurrent`, which
accepts N ``(model, train_loader, val_loader)`` triples and returns
N :class:`TrainingResult` objects -- one per model, with the same
shape as :func:`universal_trainer.train_model`.

Key differences from the sequential ``train_model``:

* Each model gets its own ``torch.cuda.Stream``, optimizer, and
  ``GradScaler`` (AMP mixed precision).
* The outer loop advances *one step at a time for every model*
  (round-robin), ensuring perfect step-level fairness.
* A periodic ``torch.cuda.synchronize`` every ``sync_frequency``
  steps lets the GPU hardware scheduler reorder kernels.
* Evaluation is still serial (one model at a time, on the default
  stream) to keep metric computation deterministic.
"""

from __future__ import annotations

import math
import time
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional, Protocol

import torch
from torch.cuda.amp import GradScaler, autocast
from torch.nn.utils import clip_grad_norm_
from torch.optim import AdamW
from torch.utils.data import DataLoader

from core.training.universal_trainer import (
    EvalFn,
    ForwardFn,
    LossFn,
    TrainingConfig,
    TrainingResult,
    _compute_grad_norm,
    _default_forward,
    _get_lr_multiplier,
    _write_csv,
    _write_json,
)

from pathlib import Path


# ── Per-model bundle (mirrors stress_test ModelBundle) ─────────────────


@dataclass
class _ModelBundle:
    """Wraps a single candidate model with its own stream + optimizer state."""

    idx: int
    model: torch.nn.Module
    optimizer: AdamW
    scaler: GradScaler
    stream: torch.cuda.Stream
    device: torch.device

    # Pluggable callables (task-specific)
    loss_fn: LossFn
    forward_fn: ForwardFn

    # Bookkeeping
    step: int = 0
    running_loss: float = 0.0
    running_batches: int = 0
    consecutive_nan: int = 0
    total_nan: int = 0
    history: List[Dict[str, Any]] = field(default_factory=list)
    last_loss: Optional[float] = None

    def train_step(
        self,
        batch: Dict[str, Any],
        config: TrainingConfig,
    ) -> Optional[float]:
        """Execute one forward-backward-update on this model's stream.

        Returns the scalar loss value, or ``None`` if the loss was NaN/Inf.
        """
        with torch.cuda.stream(self.stream):
            self.model.train()
            self.optimizer.zero_grad(set_to_none=True)

            with autocast():
                output = self.forward_fn(self.model, batch, self.device)
                loss = self.loss_fn(output, batch, self.device)

            # NaN / Inf guard
            if torch.isnan(loss) or torch.isinf(loss):
                self.consecutive_nan += 1
                self.total_nan += 1
                self.step += 1
                self.history.append({
                    "step": self.step,
                    "train_loss": float("nan"),
                    "nan_skipped": True,
                })
                if self.consecutive_nan >= config.max_consecutive_nan:
                    raise RuntimeError(
                        f"Model {self.idx}: training halted after "
                        f"{self.consecutive_nan} consecutive NaN/Inf losses."
                    )
                return None

            self.consecutive_nan = 0
            self.scaler.scale(loss).backward()
            self.scaler.unscale_(self.optimizer)

            grad_norm = None
            if config.log_grad_norm:
                grad_norm = _compute_grad_norm(self.model)

            if config.gradient_clip:
                clip_grad_norm_(self.model.parameters(), config.gradient_clip)

            self.step += 1

            # LR scheduling
            lr_mult = _get_lr_multiplier(
                self.step,
                config.warmup_steps,
                config.max_steps,
                config.lr_scheduler,
                config.min_lr_ratio,
            )
            current_lr = config.learning_rate * lr_mult
            for pg in self.optimizer.param_groups:
                pg["lr"] = current_lr

            self.scaler.step(self.optimizer)
            self.scaler.update()

            loss_val = loss.item()

        # Bookkeeping (outside stream context)
        self.running_loss += loss_val
        self.running_batches += 1
        self.last_loss = loss_val

        entry: Dict[str, Any] = {
            "step": self.step,
            "train_loss": float(loss_val),
            "running_train_loss": self.running_loss / max(self.running_batches, 1),
            "learning_rate": current_lr,
        }
        if grad_norm is not None:
            entry["grad_norm"] = grad_norm
        self.history.append(entry)

        return loss_val


# ── Public API ─────────────────────────────────────────────────────────


@dataclass
class ConcurrentTrainingSpec:
    """Everything needed to train one candidate concurrently."""

    model: torch.nn.Module
    train_loader: DataLoader
    loss_fn: LossFn
    config: TrainingConfig
    val_loader: Optional[DataLoader] = None
    eval_fn: Optional[EvalFn] = None
    forward_fn: Optional[ForwardFn] = None
    run_dir: Optional[str] = None
    eval_type: str = "small_budget"
    label: str = ""  # human-readable name for logging


def train_models_concurrent(
    specs: List[ConcurrentTrainingSpec],
    *,
    sync_frequency: int = 10,
    log_frequency: int = 100,
    device: Optional[torch.device] = None,
) -> List[TrainingResult]:
    """Train N models concurrently on one GPU using CUDA streams.

    Args:
        specs: One :class:`ConcurrentTrainingSpec` per candidate model.
        sync_frequency: How often (in round-robin steps) to call
            ``torch.cuda.synchronize``.
        log_frequency: How often to print progress.
        device: Override CUDA device (default: ``cuda:0``).

    Returns:
        A list of :class:`TrainingResult`, one per spec, in the same
        order as *specs*.
    """
    if not specs:
        return []

    if device is None:
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    n = len(specs)
    use_streams = device.type == "cuda"

    print(
        f"[StreamTrainer] Training {n} models concurrently "
        f"(device={device}, streams={'yes' if use_streams else 'no'}, "
        f"sync_freq={sync_frequency})"
    )

    # ── Build bundles ──────────────────────────────────────────────
    bundles: List[_ModelBundle] = []
    train_iters: List[Any] = []
    max_steps = 0

    for i, spec in enumerate(specs):
        stream = torch.cuda.Stream(device=device) if use_streams else None

        # Move model to device on its stream
        if use_streams:
            with torch.cuda.stream(stream):
                spec.model.to(device)
        else:
            spec.model.to(device)

        optimizer = AdamW(
            spec.model.parameters(),
            lr=spec.config.learning_rate,
            weight_decay=spec.config.weight_decay,
        )

        bundle = _ModelBundle(
            idx=i,
            model=spec.model,
            optimizer=optimizer,
            scaler=GradScaler(enabled=use_streams),
            stream=stream,
            device=device,
            loss_fn=spec.loss_fn,
            forward_fn=spec.forward_fn or _default_forward,
        )
        bundles.append(bundle)
        train_iters.append(iter(spec.train_loader))
        max_steps = max(max_steps, spec.config.max_steps)

    if use_streams:
        torch.cuda.synchronize(device)

    # ── Round-robin training loop ──────────────────────────────────
    wall_start = time.time()
    global_step = 0

    while True:
        # Check if all models are done
        all_done = all(b.step >= specs[b.idx].config.max_steps for b in bundles)
        if all_done:
            break

        # One round: each model gets one step
        for i, bundle in enumerate(bundles):
            cfg = specs[i].config
            if bundle.step >= cfg.max_steps:
                continue

            # Get next batch (restart iterator if exhausted)
            try:
                batch = next(train_iters[i])
            except StopIteration:
                train_iters[i] = iter(specs[i].train_loader)
                batch = next(train_iters[i])

            # Move batch to device
            device_batch = {
                k: v.to(device) if isinstance(v, torch.Tensor) else v
                for k, v in batch.items()
            }

            try:
                bundle.train_step(device_batch, cfg)
            except RuntimeError as exc:
                if "out of memory" in str(exc).lower():
                    print(f"[StreamTrainer] OOM on model {i} at step {bundle.step}")
                    raise
                # NaN halt etc. -- mark model as done by setting step to max
                print(f"[StreamTrainer] Model {i} error: {exc}")
                bundle.step = cfg.max_steps
                bundle.history.append({
                    "step": bundle.step,
                    "error": str(exc),
                })

            # Periodic validation (within stream context is fine for eval)
            if (
                specs[i].val_loader is not None
                and specs[i].eval_fn is not None
                and bundle.step % cfg.eval_interval == 0
                and bundle.step < cfg.max_steps
            ):
                if use_streams:
                    torch.cuda.synchronize(device)
                val_metrics = specs[i].eval_fn(
                    bundle.model, specs[i].val_loader, device
                )
                for k, v in val_metrics.items():
                    bundle.history[-1][f"val_{k}"] = float(v)

        global_step += 1

        # Sync streams periodically
        if use_streams and global_step % sync_frequency == 0:
            torch.cuda.synchronize(device)

        # Log progress
        if global_step % log_frequency == 0:
            elapsed = time.time() - wall_start
            losses = [
                f"{b.last_loss:.4f}" if b.last_loss is not None else "n/a"
                for b in bundles
            ]
            steps = [str(b.step) for b in bundles]
            print(
                f"[StreamTrainer] round={global_step} elapsed={elapsed:.1f}s "
                f"steps=[{','.join(steps)}] losses=[{','.join(losses)}]"
            )

    # Final sync
    if use_streams:
        torch.cuda.synchronize(device)

    wall_time = time.time() - wall_start
    print(
        f"[StreamTrainer] All {n} models complete in {wall_time:.1f}s "
        f"({global_step} rounds)"
    )

    # ── Final evaluation + results ─────────────────────────────────
    results: List[TrainingResult] = []
    for i, bundle in enumerate(bundles):
        spec = specs[i]
        train_loss = bundle.running_loss / max(bundle.running_batches, 1)

        val_metrics: Dict[str, Any] = {}
        if spec.val_loader is not None and spec.eval_fn is not None:
            if use_streams:
                torch.cuda.synchronize(device)
            val_metrics = spec.eval_fn(bundle.model, spec.val_loader, device)

        metrics: Dict[str, Any] = {
            "train": {"loss": float(train_loss)},
            "validation": {k: float(v) for k, v in val_metrics.items()},
            "budget": {
                "steps": bundle.step,
                "max_steps": spec.config.max_steps,
            },
            "metadata": {
                "device": str(device),
                "batch_size": spec.config.batch_size,
                "total_nan_batches": bundle.total_nan,
                "concurrent_models": n,
                "wall_time_sec": wall_time,
                "training_method": "cuda_streams",
            },
            "history": bundle.history,
        }

        if hasattr(bundle.model, "to_config"):
            metrics["model"] = {"config": bundle.model.to_config()}

        # Persist per-model metrics
        if spec.run_dir:
            run_path = Path(spec.run_dir)
            _write_json(run_path / f"{spec.eval_type}_metrics.json", metrics)
            if bundle.history:
                _write_json(
                    run_path / f"{spec.eval_type}_history.json", bundle.history
                )
                _write_csv(
                    run_path / f"{spec.eval_type}_train.csv", bundle.history
                )

        results.append(TrainingResult(
            metrics=metrics,
            history=bundle.history,
            steps_completed=bundle.step,
            model=bundle.model,
        ))

    return results
