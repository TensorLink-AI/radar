TASKS = {}


def register_task(name: str):
    def deco(cls):
        TASKS[name] = cls
        return cls

    return deco


def get_task(name: str):
    try:
        return TASKS[name]
    except KeyError as exc:
        raise KeyError(f"Task '{name}' is not registered.") from exc


# Ensure built-in tasks register themselves when the registry is imported.
import tasks  # noqa: F401

