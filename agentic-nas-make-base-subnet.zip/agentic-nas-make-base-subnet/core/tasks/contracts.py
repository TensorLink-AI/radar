from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any, Dict, List, Tuple, Union, TYPE_CHECKING

if TYPE_CHECKING:  # pragma: no cover - type checking only
    import torch


# ── Declarative task definition ─────────────────────────────────────────


@dataclass
class TaskDefinition:
    """Declarative, JSON-serialisable description of a task.

    New tasks define **one** of these instead of overriding dozens of
    methods.  The universal trainer and remote harness read it to
    configure training, evaluation, and data loading automatically.

    Existing ``BaseTask`` subclasses can adopt it incrementally by
    implementing the ``definition`` property.
    """

    # ── Identity ────────────────────────────────────────────────────
    name: str                          # e.g. "time_series_foundation"
    description: str = ""              # one-line goal

    # ── Data ────────────────────────────────────────────────────────
    hf_repo_id: Union[str, List[str], Dict[str, str]] = ""
    """Hugging Face dataset repo(s).  Accepts a single repo ID string,
    a list of repo IDs, or a dict mapping logical names to repo IDs.
    Examples::

        "tensorlink-dev/time-series-six-datasets"          # single
        ["repo/dataset-a", "repo/dataset-b"]               # list
        {"electricity": "repo/elec", "traffic": "repo/tr"} # named
    """
    hf_split_map: Dict[str, str] = field(default_factory=lambda: {
        "train": "train",
        "val": "validation",
        "test": "test",
    })

    # ── Model constraints ───────────────────────────────────────────
    max_params: int = 125_000_000      # parameter budget
    model_base_module: str = ""        # e.g. "tasks.ts_foundation.model_base"
    scaffold_path: str = ""            # relative path to scaffold file

    # ── Metrics ─────────────────────────────────────────────────────
    primary_metric: str = "loss"       # metric name used for ranking
    direction: str = "minimize"        # "minimize" or "maximize"
    extra_metrics: List[str] = field(default_factory=list)

    # ── Training budget ─────────────────────────────────────────────
    zero_cost_timeout_sec: int = 120
    small_budget_steps: int = 100
    small_budget_timeout_sec: int = 1800
    large_budget_steps: int = 1000
    large_budget_timeout_sec: int = 7200

    # ── Misc ────────────────────────────────────────────────────────
    keywords: List[str] = field(default_factory=list)
    challenge_categories: List[str] = field(default_factory=list)
    supported_training_styles: List[str] = field(default_factory=list)
    """Training styles the task's model contract supports.  For example
    ``["teacher_forced", "direct"]``.  Empty means "not specified"."""

    def to_dict(self) -> Dict[str, Any]:
        """Serialise to a plain dict suitable for JSON transport."""
        # Normalise hf_repo_id for JSON: str stays str, list/dict
        # are passed through as-is (all are JSON-serialisable).
        if isinstance(self.hf_repo_id, dict):
            hf_repo_id_out: Any = dict(self.hf_repo_id)
        elif isinstance(self.hf_repo_id, list):
            hf_repo_id_out = list(self.hf_repo_id)
        else:
            hf_repo_id_out = self.hf_repo_id
        return {
            "name": self.name,
            "description": self.description,
            "hf_repo_id": hf_repo_id_out,
            "hf_split_map": dict(self.hf_split_map),
            "max_params": self.max_params,
            "model_base_module": self.model_base_module,
            "scaffold_path": self.scaffold_path,
            "primary_metric": self.primary_metric,
            "direction": self.direction,
            "extra_metrics": list(self.extra_metrics),
            "zero_cost_timeout_sec": self.zero_cost_timeout_sec,
            "small_budget_steps": self.small_budget_steps,
            "small_budget_timeout_sec": self.small_budget_timeout_sec,
            "large_budget_steps": self.large_budget_steps,
            "large_budget_timeout_sec": self.large_budget_timeout_sec,
            "keywords": list(self.keywords),
            "challenge_categories": list(self.challenge_categories),
            "supported_training_styles": list(self.supported_training_styles),
        }


# ── Helpers ────────────────────────────────────────────────────────────


def normalize_repo_ids(
    hf_repo_id: Union[str, List[str], Dict[str, str]],
) -> List[str]:
    """Return a flat list of HF repo ID strings from any accepted format.

    >>> normalize_repo_ids("repo/a")
    ['repo/a']
    >>> normalize_repo_ids(["repo/a", "repo/b"])
    ['repo/a', 'repo/b']
    >>> normalize_repo_ids({"elec": "repo/a", "traffic": "repo/b"})
    ['repo/a', 'repo/b']
    """
    if isinstance(hf_repo_id, dict):
        return list(hf_repo_id.values())
    if isinstance(hf_repo_id, list):
        return list(hf_repo_id)
    if hf_repo_id:
        return [hf_repo_id]
    return []


# ── Base task class ─────────────────────────────────────────────────────


class BaseTask(ABC):
    """Abstract base class for all tasks.

    Tasks can implement the full abstract interface (current approach)
    **or** return a ``TaskDefinition`` from the ``definition`` property
    and let the services derive most behaviour automatically (thin-task
    approach).
    """

    @property
    def definition(self) -> TaskDefinition:
        """Return a declarative ``TaskDefinition`` for this task.

        Override to opt in to the thin-task pattern.  The default
        raises ``NotImplementedError`` so existing fat tasks keep
        working.
        """
        raise NotImplementedError(
            f"{self.__class__.__name__} has not migrated to "
            "TaskDefinition yet."
        )

    @abstractmethod
    def planner_context(self) -> str:
        """Returns a string containing the planner context for the task."""
        pass

    @abstractmethod
    def set_run_environment(self, run_dir: str):
        """Sets the working directory for the current run."""
        pass

    @abstractmethod
    def build_datasets(self, cfg: Dict[str, Any]) -> Dict[str, Any]:
        """Builds and returns the datasets for this task."""
        pass

    @abstractmethod
    def train_and_eval(self, candidate_code_path: str, datasets: Dict[str, Any], run_dir: str, eval_type: str) -> Dict[str, Any]:
        """
        Runs the training and evaluation loop for a candidate.
        The behavior can change based on the eval_type (e.g., 'quick', 'full').
        """
        pass

    @abstractmethod
    def primary_objectives(self) -> List[str]:
        """Returns the primary optimization objectives for this task."""
        pass

    @abstractmethod
    def task_constraints(self) -> List[str]:
        """Returns the constraints for this task, e.g., latency, memory."""
        pass
        
    @abstractmethod
    def get_analysis_context(self, eval_type: str) -> Dict[str, Any]:
        """
        Returns task-specific context for the Analyzer agent, adapted for the eval_type.
        """
        pass

    @abstractmethod
    def get_scaffold_path(self) -> str:
        """Returns the absolute path to the scaffold file for this task."""
        pass

    @abstractmethod
    def get_source_file_path(self, name: str) -> str:
        """Returns the path to the candidate's source code file."""
        pass

    @abstractmethod
    def get_result_file_path(self, name: str, eval_type: str) -> str:
        """Returns the path to the training progression file for a given eval_type."""
        pass

    @abstractmethod
    def get_test_result_file_path(self, name: str, eval_type: str) -> str:
        """Returns the path to the final evaluation metrics file for a given eval_type."""
        pass

    @abstractmethod
    def get_task_description(self) -> str:
        """Returns a high-level description of the task's goal."""
        pass

    @abstractmethod
    def get_task_keywords(self) -> List[str]:
        """Returns a list of keywords relevant to the task."""
        pass

    @abstractmethod
    def get_evaluation_script(self) -> str:
        """
        Returns the absolute path to the task-specific bash script
        used for evaluation.
        """
        pass

    def build_remote_harness(
        self,
        *,
        candidate_code: str,
        dataset_spec: Dict[str, Any],
        eval_type: str,
        primary_metrics: List[str],
    ) -> str:
        """
        Return a standalone Python script for remote execution.

        The harness should embed all task-specific dependencies (dataloaders,
        training loops, model definitions) alongside the candidate code so the
        remote environment does not need to import the validator's codebase.
        """

        raise NotImplementedError

    def load_model_for_shape_sanity(
        self,
        candidate_code_path: str,
        device: "torch.device",
        datasets: Dict[str, Any],
    ) -> Any:
        """
        Load a candidate model for the shape sanity check.

        Tasks should reuse their canonical loading pathway to ensure any
        task-specific validation or configuration is applied consistently.
        """
        raise NotImplementedError

    def build_shape_sanity_batch(
        self, datasets: Dict[str, Any], device: "torch.device"
    ) -> Dict[str, Any]:
        """
        Construct a minimal batch of model inputs for the shape sanity check.

        Returns a mapping of keyword arguments to be passed directly into the
        model's forward pass. Tensors should already be placed on ``device``.
        """
        raise NotImplementedError

    def get_role_instruction(self, role: str) -> str:
        """Return additional role-specific instructions for agent prompts."""
        del role
        return ""

    def build_prompt_fragments(self, role: str, channel: str | None = None) -> Dict[str, str]:
        """Return templating fragments for agent prompts.

        The returned mapping is used to fill agent-specific prompt templates with
        structured task context. Subclasses can override to supply richer details
        without duplicating shared prompt logic.
        """

        constraints = self._format_constraints_list(role)
        objectives = [obj.strip() for obj in self.primary_objectives() if obj and obj.strip()]
        fragments: Dict[str, str] = {
            "task_role": (role or "agent").strip() or "agent",
            "task_objective": self.get_task_description().strip() or "Follow the provided task contract.",
            "task_constraints": "\n".join(f"- {item}" for item in constraints)
            if constraints
            else "No explicit constraints provided.",
            "task_success_criteria": "\n".join(f"- {item}" for item in objectives)
            if objectives
            else "Deliver correct outputs that satisfy the task contract.",
            "task_role_instruction": self.get_role_instruction(role).strip(),
        }

        if channel:
            fragments["task_channel"] = channel

        return fragments

    def build_agent_prompt(self, role: str) -> str:
        """
        Optional helper returning canonical task context for a given agent role.

        Subclasses can override to provide richer, role-aware prompts that keep
        all agents aligned on the same task contract. The default implementation
        combines the generic task description with any role-specific extension
        returned by :meth:`get_role_instruction` and includes constraints for the
        planner, debugger, and code checker.
        """
        fragments = self.build_prompt_fragments(role, channel="task_prompt")
        parts = [fragments.get("task_objective", "").strip(), fragments.get("task_role_instruction", "").strip()]

        constraint_block = self._format_constraints_for_role(role, fragments.get("task_constraints", ""))
        if constraint_block:
            parts.append(constraint_block)

        return "\n\n".join(part for part in parts if part)

    def _format_constraints_for_role(self, role: str, constraint_text: str) -> str:
        """Return a formatted constraint list for roles that must honor them."""

        role_lower = (role or "").lower()
        if role_lower not in {"planner", "debugger", "code_checker", "stability_checker", "analyzer", "judger", "deduplicator", "motivation_checker"}:
            return ""

        if not constraint_text:
            return ""

        return f"### Task Constraints\n{constraint_text}"

    def _format_constraints_list(self, role: str) -> List[str]:
        role_lower = (role or "").lower()
        if role_lower not in {"planner", "debugger", "code_checker", "stability_checker", "analyzer", "judger", "deduplicator", "motivation_checker"}:
            return []

        return [c.strip() for c in self.task_constraints() if c and c.strip()]

    # =========================================================================
    # Challenge-related methods (task-specific design priorities)
    # =========================================================================

    def get_challenge_categories(self) -> List[str]:
        """
        Return list of challenge category names for this task.

        Override in subclasses to define task-specific challenges that guide
        architectural innovation. Used by the Analyzer to tag experiments and
        by the Planner to understand design priorities.
        """
        return []

    def get_challenge_patterns(self) -> Dict[str, Tuple[str, List[str]]]:
        """
        Return challenge detection patterns for keyword-based inference.

        Returns a dict mapping challenge_id to (display_name, keywords_list).
        Used for backwards-compatible challenge inference when explicit tags
        are not available.

        Override in subclasses to define task-specific patterns.
        """
        return {}

    def get_challenge_context_for_analyzer(self) -> str:
        """
        Return formatted challenge context for the Analyzer agent.

        This context helps the Analyzer understand what challenges to look for
        and how to tag experiments. Override in subclasses for task-specific
        challenge definitions with descriptions.
        """
        categories = self.get_challenge_categories()
        if not categories:
            return ""

        return "Choose from: " + ", ".join(categories)
