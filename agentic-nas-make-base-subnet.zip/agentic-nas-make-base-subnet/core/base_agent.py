# base_agent.py
from abc import ABC, abstractmethod
from typing import Type, List, Any, Dict, Optional
from pydantic import BaseModel

class BaseAgent(ABC):
    """
    Abstract Base Class for all agents in the system.
    """
    def __init__(self, name: str, instructions: str, tools: List[Any] = None):
        self.name = name
        self.instructions = instructions
        self.tools = tools or []
        # NEW: fast lookup for tool calls (name -> fn)
        self.tool_map: Dict[str, Any] = {getattr(t, "__tool_name__", t.__name__): t for t in self.tools}

    def register_tools(self, tools: List[Any]) -> None:
        """Optional: register more tools after construction."""
        for t in tools:
            self.tools.append(t)
            self.tool_map[getattr(t, "__tool_name__", t.__name__)] = t

    @abstractmethod
    def run(self, user_prompt: str, response_model: Type[BaseModel] = None, *, skip_prepare_prompt: bool = False, **kwargs):
        pass

    def _prepare_user_prompt(self, **kwargs) -> str:
        return "\n".join([f"## {key.replace('_', ' ').title()}\n{value}\n" for key, value in kwargs.items()])

    def run_with_structured_input(self, response_model: Type[BaseModel] = None, **kwargs):
        user_prompt = self._prepare_user_prompt(**kwargs)
        # just return the provider result (no stray "and ..." tail)
        # Pass skip_prepare_prompt=True to avoid invoking _prepare_user_prompt() a second time
        return self.run(user_prompt, response_model, skip_prepare_prompt=True, **kwargs)
