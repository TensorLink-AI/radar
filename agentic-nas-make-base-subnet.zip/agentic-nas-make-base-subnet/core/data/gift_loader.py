"""GIFT-Eval benchmark data loader.

Re-implements the GIFT-Eval splitting and windowing pipeline
(https://github.com/SalesforceAIResearch/gift-eval) without depending on
GluonTS, toolz, or pyarrow.compute.  Only allowed dependencies are torch,
numpy, the HuggingFace ``datasets`` library, and the Python stdlib.

Two modes are supported:

* **zero_shot** (default) -- produces the rolling *test* windows used by
  the benchmark.  Context (past) and label (future) are yielded per
  window.  No training data is exposed.
* **fine_tuning** -- exposes the *training* split (everything before the
  validation window) as a sliding-window PyTorch ``Dataset`` suitable for
  DataLoader iteration.

The output batch format matches the codebase convention::

    {"past_target": [B, T, 1], "future_target": [B, H, 1],
     "past_observed_mask": [B, T, 1], "item_id": str,
     "static_features": [B, C_s] (optional)}
"""

from __future__ import annotations

import math
from dataclasses import dataclass
from enum import Enum
from typing import Any, Dict, Iterator, List, Optional, Sequence, Union

import numpy as np
import torch
from torch.utils.data import DataLoader, Dataset, IterableDataset

from core.data.ts_augmenter import AugmentationConfig, UniversalTSAugmenter


# Lazy imports for the HF datasets library.  Defined at module level so
# tests can patch ``core.data.gift_loader.load_dataset`` etc.
def load_dataset(*args: Any, **kwargs: Any) -> Any:
    from datasets import load_dataset as _load
    return _load(*args, **kwargs)


def load_from_disk(*args: Any, **kwargs: Any) -> Any:
    from datasets import load_from_disk as _load
    return _load(*args, **kwargs)


# ── Constants ────────────────────────────────────────────────────────────

TEST_SPLIT_FRACTION = 0.1
MAX_WINDOW = 20

# Standard GIFT-Eval prediction lengths (base, before term multiplier).
PRED_LENGTH_MAP: Dict[str, int] = {
    "M": 12,
    "W": 8,
    "D": 30,
    "H": 48,
    "T": 48,
    "S": 60,
}

# M4-specific prediction lengths.
M4_PRED_LENGTH_MAP: Dict[str, int] = {
    "A": 6,
    "Q": 8,
    "M": 18,
    "W": 13,
    "D": 14,
    "H": 48,
}

# TFB prediction lengths (Time-series Forecasting Benchmark).
TFB_PRED_LENGTH_MAP: Dict[str, int] = {
    "A": 6,
    "H": 48,
    "Q": 8,
    "D": 14,
    "M": 18,
    "W": 13,
    "U": 8,
    "T": 8,
}

# Pandas 2.x deprecated-frequency aliases → canonical short codes.
_DEPRECATED_FREQ_MAP: Dict[str, str] = {
    "Y": "A",
    "YE": "A",
    "YS": "A",
    "QE": "Q",
    "QS": "Q",
    "ME": "M",
    "MS": "M",
    "h": "H",
    "min": "T",
    "s": "S",
    "us": "U",
}

# Mapping from common pandas offset *names* (the `.name` attribute of a
# ``DateOffset``) to single-letter canonical codes.  This replaces the
# GluonTS ``norm_freq_str`` + ``to_offset().name`` chain.
_OFFSET_NAME_MAP: Dict[str, str] = {
    # Standard / legacy
    "A": "A", "A-DEC": "A", "Y": "A", "YE": "A", "YS": "A",
    "Q": "Q", "Q-DEC": "Q", "QE": "Q", "QS": "Q",
    "M": "M", "ME": "M", "MS": "M",
    "W": "W", "W-SUN": "W", "W-MON": "W", "W-TUE": "W",
    "W-WED": "W", "W-THU": "W", "W-FRI": "W", "W-SAT": "W",
    "D": "D",
    "B": "D",  # business day → daily bucket
    "H": "H", "h": "H",
    "T": "T", "min": "T",
    "S": "S", "s": "S",
    "U": "U", "us": "U",
}


# ── Enums ────────────────────────────────────────────────────────────────


class Term(Enum):
    """Forecast-horizon term multiplier as defined by GIFT-Eval."""

    SHORT = "short"
    MEDIUM = "medium"
    LONG = "long"

    @property
    def multiplier(self) -> int:
        if self is Term.SHORT:
            return 1
        if self is Term.MEDIUM:
            return 10
        return 15  # LONG


class GiftEvalMode(Enum):
    """Loader operating mode."""

    ZERO_SHOT = "zero_shot"
    FINE_TUNING = "fine_tuning"


# ── Frequency helpers ────────────────────────────────────────────────────


def maybe_reconvert_freq(freq: str) -> str:
    """Normalise a pandas frequency alias to the canonical single-letter
    code used by the GIFT-Eval prediction-length maps.

    Handles pandas >= 2.0 deprecations (e.g. ``"ME"`` → ``"M"``,
    ``"h"`` → ``"H"``) *without* importing pandas.
    """
    if freq in _DEPRECATED_FREQ_MAP:
        return _DEPRECATED_FREQ_MAP[freq]
    return freq


def normalize_freq(raw_freq: str) -> str:
    """Turn an arbitrary frequency string into a canonical single letter.

    Examples::

        "15T"   → "T"
        "H"     → "H"
        "W-WED" → "W"
        "10S"   → "S"
        "1h"    → "H"

    The function first strips leading digits (``"15T"`` → ``"T"``), then
    applies the offset-name map and deprecated-alias map.  No pandas
    import is required.
    """
    s = raw_freq.strip()

    # Strip leading digits: "15T" → "T", "10S" → "S"
    idx = 0
    while idx < len(s) and (s[idx].isdigit() or s[idx] == "."):
        idx += 1
    base = s[idx:] if idx < len(s) else s

    # Try offset-name map first (handles "W-WED" etc.)
    if base in _OFFSET_NAME_MAP:
        return _OFFSET_NAME_MAP[base]

    # Fall back to deprecated-alias map
    canonical = maybe_reconvert_freq(base)
    if canonical in _OFFSET_NAME_MAP:
        return _OFFSET_NAME_MAP[canonical]

    return canonical


def resolve_prediction_length(
    raw_freq: str,
    term: Term,
    dataset_name: str,
) -> int:
    """Compute the final prediction length for a GIFT-Eval dataset.

    Mirrors the reference implementation's logic:
    1. Normalise the frequency string to a single-letter code.
    2. Look up the base prediction length (M4 map for m4 datasets,
       standard map otherwise).
    3. Multiply by the term multiplier.
    """
    code = normalize_freq(raw_freq)

    if "m4" in dataset_name.lower():
        pred_map = M4_PRED_LENGTH_MAP
    else:
        pred_map = PRED_LENGTH_MAP

    if code not in pred_map:
        raise ValueError(
            f"Unsupported frequency code '{code}' (from '{raw_freq}'). "
            f"Supported: {sorted(pred_map)}"
        )

    return term.multiplier * pred_map[code]


# ── Sample dataclass ─────────────────────────────────────────────────────


@dataclass
class GiftEvalSample:
    """A single sample yielded by the GIFT-Eval loader."""

    past_values: torch.Tensor        # [T, 1]
    future_values: torch.Tensor      # [H, 1]
    past_observed_mask: torch.Tensor  # [T, 1]
    item_id: str
    static_features: Optional[torch.Tensor] = None  # [C_s]

    def to_dict(self) -> Dict[str, Any]:
        """Return a dict matching the codebase batch convention."""
        d: Dict[str, Any] = {
            "past_target": self.past_values,
            "future_target": self.future_values,
            "past_observed_mask": self.past_observed_mask,
            "item_id": self.item_id,
        }
        if self.static_features is not None:
            d["static_features"] = self.static_features
        return d


# ── Internal helpers ─────────────────────────────────────────────────────


def _extract_target(row: Dict[str, Any]) -> np.ndarray:
    """Extract a 1-D numpy target array from an HF dataset row.

    Handles both univariate ``[T]`` and multivariate ``[C, T]`` targets
    by returning only the first channel for multivariate data (the
    ``MultivariateToUnivariate`` expansion handles the rest).
    """
    target = row["target"]
    arr = np.asarray(target, dtype=np.float32)
    if arr.ndim > 1:
        return arr[0]  # first channel
    return arr


def _extract_all_channels(row: Dict[str, Any]) -> List[np.ndarray]:
    """Extract all channels from an HF row's target field.

    Returns a list of 1-D arrays.  For univariate data this is a
    single-element list.
    """
    target = row["target"]
    arr = np.asarray(target, dtype=np.float32)
    if arr.ndim > 1:
        return [arr[c] for c in range(arr.shape[0])]
    return [arr]


def _observed_mask(values: np.ndarray) -> np.ndarray:
    """Create an observation mask: 1 where finite, 0 where NaN/inf."""
    return np.isfinite(values).astype(np.float32)


def _compute_min_series_length(
    hf_dataset: Any,
    *,
    multivariate: bool,
) -> int:
    """Compute the minimum series length across the dataset.

    Replaces the pyarrow.compute-based implementation from the reference
    code with a pure-numpy scan.
    """
    min_len = float("inf")
    for row in hf_dataset:
        target = row["target"]
        arr = np.asarray(target, dtype=np.float32)
        if multivariate and arr.ndim > 1:
            # Per-channel lengths are identical for well-formed data;
            # take the first channel's length.
            length = arr.shape[1]
        else:
            length = arr.shape[-1] if arr.ndim > 0 else 0
        if length < min_len:
            min_len = length
    return int(min_len)


def _compute_windows(
    min_series_length: int,
    prediction_length: int,
    dataset_name: str,
) -> int:
    """Number of rolling test windows, clamped to [1, MAX_WINDOW].

    M4 datasets always use exactly 1 window.
    """
    if "m4" in dataset_name.lower():
        return 1
    w = math.ceil(TEST_SPLIT_FRACTION * min_series_length / prediction_length)
    return min(max(1, w), MAX_WINDOW)


# ── Datasets ─────────────────────────────────────────────────────────────


class _GiftEvalZeroShotDataset(IterableDataset):
    """Yields rolling test windows for zero-shot evaluation.

    Each series produces up to ``windows`` non-overlapping windows of
    length ``prediction_length``, anchored at the end of the series.
    The context (past) is everything preceding each window.
    """

    def __init__(
        self,
        hf_dataset: Any,
        prediction_length: int,
        windows: int,
        context_length: int,
        to_univariate: bool,
        dataset_name: str,
        augmentation: Optional[AugmentationConfig] = None,
    ) -> None:
        self.hf_dataset = hf_dataset
        self.prediction_length = prediction_length
        self.windows = windows
        self.context_length = context_length
        self.to_univariate = to_univariate
        self.dataset_name = dataset_name
        self.augmentation = augmentation
        self._augmenter: Optional[UniversalTSAugmenter] = None
        if augmentation is not None:
            seed = augmentation.random_seed if augmentation.random_seed is not None else 42
            self._augmenter = UniversalTSAugmenter(random_seed=seed)

    def _maybe_augment(self, past: np.ndarray) -> np.ndarray:
        """Apply augmentation to the past context if configured."""
        if self._augmenter is None or self.augmentation is None:
            return past
        return self._augmenter.augment_from_config(past, self.augmentation)

    def __iter__(self) -> Iterator[Dict[str, Any]]:
        pred_len = self.prediction_length
        n_win = self.windows
        ctx_len = self.context_length

        for row in self.hf_dataset:
            item_id = row.get("item_id", "unknown")
            static_feat = row.get("static_features", None)
            channels = (
                _extract_all_channels(row)
                if self.to_univariate
                else [_extract_target(row)]
            )

            for ch_idx, series in enumerate(channels):
                series_len = len(series)
                # Test offset: the last (windows * pred_len) steps
                test_start = series_len - n_win * pred_len
                if test_start < ctx_len:
                    # Series too short for full context; use what we have
                    pass

                ch_id = (
                    f"{item_id}_dim{ch_idx}"
                    if self.to_univariate and len(channels) > 1
                    else str(item_id)
                )

                for w in range(n_win):
                    future_end = test_start + (w + 1) * pred_len
                    future_start = future_end - pred_len
                    if future_end > series_len:
                        break

                    past_start = max(0, future_start - ctx_len)
                    past = series[past_start:future_start]
                    future = series[future_start:future_end]

                    # Augment past context only (future is ground truth)
                    past = self._maybe_augment(past)

                    past_t = torch.tensor(past, dtype=torch.float32).unsqueeze(-1)
                    future_t = torch.tensor(future, dtype=torch.float32).unsqueeze(-1)
                    mask_t = torch.tensor(
                        _observed_mask(past), dtype=torch.float32
                    ).unsqueeze(-1)

                    sample: Dict[str, Any] = {
                        "past_target": past_t,
                        "future_target": future_t,
                        "past_observed_mask": mask_t,
                        "item_id": ch_id,
                    }
                    if static_feat is not None:
                        sample["static_features"] = torch.tensor(
                            np.asarray(static_feat, dtype=np.float32)
                        )
                    yield sample


class _GiftEvalFineTuningDataset(Dataset):
    """Map-style dataset for the training split with sliding windows.

    Pre-computes all (series_idx, window_offset) pairs so the DataLoader
    can shuffle and batch efficiently.
    """

    def __init__(
        self,
        series_list: List[np.ndarray],
        item_ids: List[str],
        static_features_list: List[Optional[np.ndarray]],
        context_length: int,
        prediction_length: int,
        stride: int,
        train_end_offsets: List[int],
        augmentation: Optional[AugmentationConfig] = None,
    ) -> None:
        self.series_list = series_list
        self.item_ids = item_ids
        self.static_features_list = static_features_list
        self.context_length = context_length
        self.prediction_length = prediction_length
        self.stride = stride
        self.train_end_offsets = train_end_offsets
        self.augmentation = augmentation
        self._augmenter: Optional[UniversalTSAugmenter] = None
        if augmentation is not None:
            seed = augmentation.random_seed if augmentation.random_seed is not None else 42
            self._augmenter = UniversalTSAugmenter(random_seed=seed)

        # Pre-compute index pairs: (series_idx, window_start)
        self._index_pairs: List[tuple] = []
        total_needed = context_length + prediction_length
        for s_idx, series in enumerate(series_list):
            train_end = train_end_offsets[s_idx]
            usable = series[:train_end]
            if len(usable) < total_needed:
                continue
            max_start = len(usable) - total_needed
            for start in range(0, max_start + 1, stride):
                self._index_pairs.append((s_idx, start))

    def _maybe_augment(self, past: np.ndarray) -> np.ndarray:
        """Apply augmentation to the past context if configured."""
        if self._augmenter is None or self.augmentation is None:
            return past
        return self._augmenter.augment_from_config(past, self.augmentation)

    def __len__(self) -> int:
        return len(self._index_pairs)

    def __getitem__(self, idx: int) -> Dict[str, Any]:
        s_idx, start = self._index_pairs[idx]
        series = self.series_list[s_idx]
        ctx = self.context_length
        pred = self.prediction_length

        past = series[start : start + ctx]
        future = series[start + ctx : start + ctx + pred]

        # Augment past context only (future is ground truth)
        past = self._maybe_augment(past)

        past_t = torch.tensor(past, dtype=torch.float32).unsqueeze(-1)
        future_t = torch.tensor(future, dtype=torch.float32).unsqueeze(-1)
        mask_t = torch.tensor(
            _observed_mask(past), dtype=torch.float32
        ).unsqueeze(-1)

        sample: Dict[str, Any] = {
            "past_target": past_t,
            "future_target": future_t,
            "past_observed_mask": mask_t,
            "item_id": self.item_ids[s_idx],
        }
        sf = self.static_features_list[s_idx]
        if sf is not None:
            sample["static_features"] = torch.tensor(sf)
        return sample


# ── Main loader class ────────────────────────────────────────────────────


class GiftEvalDataset:
    """GIFT-Eval benchmark data loader.

    Loads a GIFT-Eval dataset from HuggingFace Hub or a local directory,
    applies the benchmark's splitting and windowing logic, and provides
    PyTorch ``DataLoader`` instances.

    Args:
        dataset_name: HF Hub dataset name or local path.  For HF Hub,
            pass the full repo id (e.g.
            ``"Salesforce/gift-eval-electricity-W"``).  For local
            directories, pass the path to a ``datasets.load_from_disk``
            directory.
        term: Forecast-horizon multiplier (``"short"``, ``"medium"``,
            ``"long"`` or a :class:`Term` enum).
        mode: ``"zero_shot"`` for test evaluation windows or
            ``"fine_tuning"`` for training sliding windows.
        context_length: Number of past time steps in each sample.  If
            ``None``, defaults to ``4 * prediction_length``.
        to_univariate: If ``True``, multivariate series are flattened
            into individual univariate samples.  Auto-detected by
            default.
        stride: Step size for sliding windows in fine-tuning mode.
            Defaults to ``prediction_length``.
        batch_size: Batch size for the returned ``DataLoader``.
        num_workers: Workers for the ``DataLoader``.
        from_disk: If ``True``, load using ``datasets.load_from_disk``
            instead of ``datasets.load_dataset``.
        augmentation: Optional :class:`AugmentationConfig` to apply
            stress-test augmentations to the *past context* of each
            sample.  ``None`` (default) disables augmentation, yielding
            the original unaugmented series.  Only the past context is
            augmented; future targets (ground truth) are never modified.
    """

    def __init__(
        self,
        dataset_name: str,
        term: Union[str, Term] = Term.SHORT,
        mode: Union[str, GiftEvalMode] = GiftEvalMode.ZERO_SHOT,
        context_length: Optional[int] = None,
        to_univariate: Optional[bool] = None,
        stride: Optional[int] = None,
        batch_size: int = 32,
        num_workers: int = 0,
        from_disk: bool = False,
        augmentation: Optional[AugmentationConfig] = None,
    ) -> None:
        self.dataset_name = dataset_name
        self.term = Term(term) if isinstance(term, str) else term
        self.mode = (
            GiftEvalMode(mode) if isinstance(mode, str) else mode
        )
        self.batch_size = batch_size
        self.num_workers = num_workers
        self._augmentation = augmentation

        # Load raw HF dataset
        if from_disk:
            self._hf_dataset = load_from_disk(dataset_name)
        else:
            self._hf_dataset = load_dataset(dataset_name, split="train")

        # Set numpy format for efficient access
        self._hf_dataset = self._hf_dataset.with_format("numpy")

        # Detect dimensionality
        first_target = np.asarray(self._hf_dataset[0]["target"], dtype=np.float32)
        self._target_dim = (
            first_target.shape[0] if first_target.ndim > 1 else 1
        )

        # Auto-detect to_univariate
        if to_univariate is None:
            self._to_univariate = self._target_dim > 1
        else:
            self._to_univariate = to_univariate

        # Resolve frequency and prediction length
        self._raw_freq: str = str(self._hf_dataset[0]["freq"])
        self._prediction_length = resolve_prediction_length(
            self._raw_freq, self.term, self.dataset_name,
        )

        # Compute min series length and window count
        self._is_multivariate = self._target_dim > 1
        self._min_series_length = _compute_min_series_length(
            self._hf_dataset, multivariate=self._is_multivariate,
        )
        self._windows = _compute_windows(
            self._min_series_length,
            self._prediction_length,
            self.dataset_name,
        )

        # Context length
        if context_length is not None:
            self._context_length = context_length
        else:
            self._context_length = 4 * self._prediction_length

        # Stride for fine-tuning
        self._stride = stride if stride is not None else self._prediction_length

    # ── Properties ───────────────────────────────────────────────────

    @property
    def prediction_length(self) -> int:
        return self._prediction_length

    @property
    def context_length(self) -> int:
        return self._context_length

    @property
    def windows(self) -> int:
        return self._windows

    @property
    def target_dim(self) -> int:
        return self._target_dim

    @property
    def freq(self) -> str:
        return self._raw_freq

    @property
    def min_series_length(self) -> int:
        return self._min_series_length

    # ── Split offsets ────────────────────────────────────────────────

    def _train_end_offset(self, series_length: int) -> int:
        """Index where the training split ends for a given series."""
        return series_length - self._prediction_length * (self._windows + 1)

    def _val_end_offset(self, series_length: int) -> int:
        """Index where the validation split ends (= test split starts)."""
        return series_length - self._prediction_length * self._windows

    # ── DataLoader builders ──────────────────────────────────────────

    def get_dataloader(self) -> DataLoader:
        """Build and return the appropriate ``DataLoader`` for the
        configured mode.
        """
        if self.mode is GiftEvalMode.ZERO_SHOT:
            return self._build_zero_shot_loader()
        return self._build_fine_tuning_loader()

    def _build_zero_shot_loader(self) -> DataLoader:
        ds = _GiftEvalZeroShotDataset(
            hf_dataset=self._hf_dataset,
            prediction_length=self._prediction_length,
            windows=self._windows,
            context_length=self._context_length,
            to_univariate=self._to_univariate,
            dataset_name=self.dataset_name,
            augmentation=self._augmentation,
        )
        return DataLoader(
            ds,
            batch_size=self.batch_size,
            shuffle=False,
            num_workers=self.num_workers,
            collate_fn=_gift_collate,
        )

    def _build_fine_tuning_loader(self) -> DataLoader:
        series_list: List[np.ndarray] = []
        item_ids: List[str] = []
        static_list: List[Optional[np.ndarray]] = []
        train_ends: List[int] = []

        for row in self._hf_dataset:
            channels = (
                _extract_all_channels(row)
                if self._to_univariate
                else [_extract_target(row)]
            )
            item_id = row.get("item_id", "unknown")
            static_feat = row.get("static_features", None)
            if static_feat is not None:
                static_feat = np.asarray(static_feat, dtype=np.float32)

            for ch_idx, ch_arr in enumerate(channels):
                ch_id = (
                    f"{item_id}_dim{ch_idx}"
                    if self._to_univariate and len(channels) > 1
                    else str(item_id)
                )
                train_end = self._train_end_offset(len(ch_arr))
                if train_end <= 0:
                    continue
                series_list.append(ch_arr)
                item_ids.append(ch_id)
                static_list.append(static_feat)
                train_ends.append(train_end)

        ds = _GiftEvalFineTuningDataset(
            series_list=series_list,
            item_ids=item_ids,
            static_features_list=static_list,
            context_length=self._context_length,
            prediction_length=self._prediction_length,
            stride=self._stride,
            train_end_offsets=train_ends,
            augmentation=self._augmentation,
        )
        return DataLoader(
            ds,
            batch_size=self.batch_size,
            shuffle=True,
            num_workers=self.num_workers,
            collate_fn=_gift_collate,
        )


# ── Collate ──────────────────────────────────────────────────────────────


def _gift_collate(batch: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Custom collate that handles mixed tensor / string fields."""
    out: Dict[str, Any] = {}
    keys = batch[0].keys()
    for key in keys:
        values = [sample[key] for sample in batch]
        if isinstance(values[0], torch.Tensor):
            out[key] = torch.stack(values)
        else:
            out[key] = values
    return out


# ── Convenience builder ──────────────────────────────────────────────────


def build_gift_eval_loaders(
    dataset_name: str,
    term: Union[str, Term] = "short",
    context_length: Optional[int] = None,
    stride: Optional[int] = None,
    batch_size: int = 32,
    num_workers: int = 0,
    from_disk: bool = False,
    augmentation: Optional[AugmentationConfig] = None,
) -> Dict[str, Any]:
    """Build both zero-shot and fine-tuning loaders for a GIFT-Eval
    dataset, returning them in a dict compatible with the codebase's
    ``DataLoaderBundle``-style patterns.

    Args:
        augmentation: Optional :class:`AugmentationConfig`.  When
            supplied, the *test* (zero-shot) loader will yield
            augmented past contexts while fine-tuning remains
            unaugmented.  Pass to both modes explicitly if desired.

    Returns:
        Dict with keys:
        - ``test_loader``: ``DataLoader`` for zero-shot evaluation
          (augmented if *augmentation* is provided).
        - ``train_loader``: ``DataLoader`` for fine-tuning
          (always unaugmented).
        - ``prediction_length``: resolved prediction length.
        - ``context_length``: context window size.
        - ``windows``: number of rolling test windows.
        - ``freq``: raw frequency string.
        - ``dataset_name``: dataset identifier.
        - ``augmented``: ``True`` if augmentation was applied to
          the test loader, ``False`` otherwise.
    """
    shared = dict(
        dataset_name=dataset_name,
        term=term,
        context_length=context_length,
        stride=stride,
        batch_size=batch_size,
        num_workers=num_workers,
        from_disk=from_disk,
    )

    zero_shot = GiftEvalDataset(mode="zero_shot", augmentation=augmentation, **shared)
    fine_tune = GiftEvalDataset(mode="fine_tuning", **shared)

    return {
        "test_loader": zero_shot.get_dataloader(),
        "train_loader": fine_tune.get_dataloader(),
        "prediction_length": zero_shot.prediction_length,
        "context_length": zero_shot.context_length,
        "windows": zero_shot.windows,
        "freq": zero_shot.freq,
        "dataset_name": dataset_name,
        "augmented": augmentation is not None,
    }
