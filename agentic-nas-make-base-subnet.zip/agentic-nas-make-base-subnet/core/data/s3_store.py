"""
S3-compatible object store abstraction.

Provides a thin wrapper around boto3 for accessing S3-compatible storage
backends (Cloudflare R2, Hippius, AWS S3, MinIO, etc.).  Supports retries,
streaming reads, and construction from environment variables.

Environment variables (generic)::

    AWS_ENDPOINT_URL          – S3-compatible endpoint (required)
    AWS_ACCESS_KEY_ID         – Access key
    AWS_SECRET_ACCESS_KEY     – Secret key
    AWS_REGION                – Region name (default: "auto")

For Hippius, set a different endpoint URL.  Both R2 and Hippius use the
same S3 API — switch backends by changing the endpoint URL and credentials.
"""

from __future__ import annotations

import io
import json
import logging
import os
import time
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


# ── Configuration ────────────────────────────────────────────────────────


@dataclass
class S3StoreConfig:
    """Configuration for an S3-compatible object store connection.

    Args:
        endpoint_url: S3-compatible endpoint (e.g. R2, Hippius, MinIO).
        access_key: AWS-style access key ID.
        secret_key: AWS-style secret access key.
        region: Region name.  Use ``"auto"`` for R2/Hippius.
        signature_version: Signature version for botocore.
        max_retries: Number of retries on transient failures.
        retry_backoff_base: Base seconds for exponential backoff.
    """

    endpoint_url: str = ""
    access_key: str = ""
    secret_key: str = ""
    region: str = "auto"
    signature_version: str = "s3v4"
    max_retries: int = 3
    retry_backoff_base: float = 1.0


# ── S3 Object Store ─────────────────────────────────────────────────────


class S3ObjectStore:
    """Thin wrapper around a boto3 S3 client for read-oriented operations.

    Provides ``list_keys``, ``get_bytes``, ``get_stream``, and ``get_json``
    with automatic retries and exponential backoff.

    Args:
        config: Connection configuration.
        bucket: S3 bucket name.
    """

    def __init__(self, config: S3StoreConfig, bucket: str) -> None:
        import boto3
        from botocore.config import Config

        self.bucket = bucket
        self._cfg = config
        self._client = boto3.client(
            "s3",
            endpoint_url=config.endpoint_url,
            aws_access_key_id=config.access_key,
            aws_secret_access_key=config.secret_key,
            config=Config(signature_version=config.signature_version),
            region_name=config.region,
        )

    # ── Retry helper ─────────────────────────────────────────────────

    def _retry(self, fn, *args, **kwargs):  # type: ignore[no-untyped-def]
        """Execute *fn* with retries on transient S3 errors."""
        from botocore.exceptions import ClientError, EndpointConnectionError

        last_exc: Optional[Exception] = None
        for attempt in range(1, self._cfg.max_retries + 1):
            try:
                return fn(*args, **kwargs)
            except (ClientError, EndpointConnectionError, OSError) as exc:
                last_exc = exc
                if isinstance(exc, ClientError):
                    code = (exc.response or {}).get("Error", {}).get("Code", "")
                    # Non-retryable errors
                    if code in {"NoSuchKey", "NoSuchBucket", "AccessDenied", "403", "404"}:
                        raise
                wait = self._cfg.retry_backoff_base * (2 ** (attempt - 1))
                logger.warning(
                    "S3 request failed (attempt %d/%d), retrying in %.1fs: %s",
                    attempt, self._cfg.max_retries, wait, exc,
                )
                time.sleep(wait)
        raise last_exc  # type: ignore[misc]

    # ── Public API ───────────────────────────────────────────────────

    def list_keys(self, prefix: str) -> List[str]:
        """List all object keys under *prefix*.

        Uses paginated listing to handle large key spaces.

        Args:
            prefix: S3 key prefix to list.

        Returns:
            List of full object keys.
        """
        keys: List[str] = []
        paginator = self._client.get_paginator("list_objects_v2")

        def _list() -> List[str]:
            result: List[str] = []
            for page in paginator.paginate(Bucket=self.bucket, Prefix=prefix):
                for obj in page.get("Contents", []):
                    result.append(obj["Key"])
            return result

        keys = self._retry(_list)
        logger.debug("Listed %d keys under prefix=%s", len(keys), prefix)
        return keys

    def get_bytes(self, key: str) -> bytes:
        """Download an object as bytes.

        Args:
            key: Full S3 object key.

        Returns:
            Raw bytes of the object.
        """

        def _get() -> bytes:
            resp = self._client.get_object(Bucket=self.bucket, Key=key)
            return resp["Body"].read()

        return self._retry(_get)

    def get_stream(self, key: str) -> io.BytesIO:
        """Download an object and return a seekable BytesIO stream.

        Args:
            key: Full S3 object key.

        Returns:
            ``io.BytesIO`` wrapping the object contents.
        """
        return io.BytesIO(self.get_bytes(key))

    def get_json(self, key: str) -> Dict[str, Any]:
        """Download and parse a JSON object.

        Args:
            key: Full S3 object key.

        Returns:
            Parsed JSON as a dict.
        """
        raw = self.get_bytes(key)
        return json.loads(raw)


# ── Factory ──────────────────────────────────────────────────────────────


def build_s3_store_from_env(
    bucket: str,
    *,
    env_prefix: str = "AWS",
    required: bool = True,
) -> Optional[S3ObjectStore]:
    """Build an :class:`S3ObjectStore` from environment variables.

    The environment variable names are constructed from *env_prefix*:

    - ``{env_prefix}_ENDPOINT_URL``
    - ``{env_prefix}_ACCESS_KEY_ID``
    - ``{env_prefix}_SECRET_ACCESS_KEY``
    - ``{env_prefix}_REGION`` (default ``"auto"``)

    This allows configuring multiple backends (R2, Hippius, etc.) by
    changing the prefix.

    Examples::

        # Cloudflare R2
        store = build_s3_store_from_env("my-bucket", env_prefix="R2")

        # Hippius
        store = build_s3_store_from_env("my-bucket", env_prefix="HIPPIUS")

    Args:
        bucket: S3 bucket name.
        env_prefix: Prefix for environment variable names.
        required: If ``True``, raise on missing config.

    Returns:
        Configured ``S3ObjectStore`` or ``None`` if not required and
        configuration is missing.
    """
    endpoint_url = os.getenv(f"{env_prefix}_ENDPOINT_URL", "")
    access_key = os.getenv(f"{env_prefix}_ACCESS_KEY_ID", "")
    secret_key = os.getenv(f"{env_prefix}_SECRET_ACCESS_KEY", "")
    region = os.getenv(f"{env_prefix}_REGION", "auto")

    missing = [
        name
        for name, value in {
            f"{env_prefix}_ENDPOINT_URL": endpoint_url,
            f"{env_prefix}_ACCESS_KEY_ID": access_key,
            f"{env_prefix}_SECRET_ACCESS_KEY": secret_key,
        }.items()
        if not value
    ]
    if missing:
        if required:
            raise RuntimeError(
                f"Missing required S3 configuration: {', '.join(sorted(missing))}"
            )
        return None

    config = S3StoreConfig(
        endpoint_url=endpoint_url,
        access_key=access_key,
        secret_key=secret_key,
        region=region,
    )
    return S3ObjectStore(config, bucket)


__all__ = [
    "S3StoreConfig",
    "S3ObjectStore",
    "build_s3_store_from_env",
]
