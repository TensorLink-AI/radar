"""
Generic Hugging Face streaming dataloader.

Provides a task-agnostic streaming ``IterableDataset`` backed by
Hugging Face ``datasets.load_dataset(..., streaming=True)``.  Tasks
supply a ``row_to_sample`` callable that converts a raw HF row into
the dict of tensors the model expects.

For non-streaming (local) datasets, use ``build_local_dataloaders``.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable, Dict, Iterator, List, Optional, Protocol, Union

import torch
from torch.utils.data import DataLoader, IterableDataset


# ── Protocol for row conversion ─────────────────────────────────────────


class RowToSampleFn(Protocol):
    """Convert a single Hugging Face row into a batch-ready dict.

    The returned dict's values should be ``torch.Tensor`` or
    Python scalars.  The universal trainer / evaluator will move
    tensors to the correct device.
    """

    def __call__(self, row: Dict[str, Any]) -> Dict[str, torch.Tensor]: ...


# ── Bundle ──────────────────────────────────────────────────────────────


@dataclass
class DataLoaderBundle:
    """Container for train / val / test loaders.

    Tasks can extend this with task-specific metadata (e.g.
    ``mase_scale`` for time-series).
    """

    train: DataLoader
    val: DataLoader
    test: Optional[DataLoader] = None
    metadata: Dict[str, Any] = field(default_factory=dict)


# ── Streaming dataset ──────────────────────────────────────────────────


class StreamingWindowDataset(IterableDataset):
    """Stream rows from Hugging Face and convert via ``row_to_sample``.

    This is the generalised version of
    ``tasks.ts_foundation.dataloader.StreamingSlidingWindowDataset``.
    The windowing / sample-construction logic is delegated entirely
    to the ``row_to_sample`` callable so this class can work for any
    domain (text, image, audio, tabular).

    Args:
        hf_repo_id: Hugging Face dataset repo (e.g.
            ``"tensorlink-dev/time-series-six-datasets"``).
        split: HF split name (``"train"``, ``"validation"``, etc.).
        row_to_sample: Converts a HF row to a dict of tensors.
        shuffle_buffer_size: If > 0, approximate shuffle with a
            fixed-size reservoir buffer.
        max_samples: Cap the total samples yielded per epoch.
    """

    def __init__(
        self,
        hf_repo_id: str,
        split: str,
        row_to_sample: RowToSampleFn,
        shuffle_buffer_size: int = 0,
        max_samples: Optional[int] = None,
    ) -> None:
        self.hf_repo_id = hf_repo_id
        self.split = split
        self.row_to_sample = row_to_sample
        self.shuffle_buffer_size = shuffle_buffer_size
        self.max_samples = max_samples

    def __iter__(self) -> Iterator[Dict[str, torch.Tensor]]:
        from datasets import load_dataset

        ds = load_dataset(
            self.hf_repo_id, split=self.split, streaming=True,
        )

        if self.shuffle_buffer_size > 0:
            ds = ds.shuffle(buffer_size=self.shuffle_buffer_size)

        count = 0
        for row in ds:
            try:
                sample = self.row_to_sample(row)
            except Exception:
                continue  # skip malformed rows
            yield sample
            count += 1
            if self.max_samples is not None and count >= self.max_samples:
                return


# ── Builder ─────────────────────────────────────────────────────────────


def build_hf_dataloaders(
    hf_repo_id: Union[str, List[str], Dict[str, str]],
    row_to_sample: RowToSampleFn,
    *,
    batch_size: int = 32,
    train_split: str = "train",
    val_split: str = "validation",
    test_split: Optional[str] = "test",
    shuffle_buffer_size: int = 1000,
    max_train_samples: Optional[int] = None,
    max_val_samples: Optional[int] = None,
    num_workers: int = 0,
    metadata: Optional[Dict[str, Any]] = None,
) -> DataLoaderBundle:
    """Build streaming train / val / test ``DataLoader``s from HF.

    Args:
        hf_repo_id: Hugging Face dataset repository ID(s).  Accepts a
            single string, a list of repo IDs, or a dict mapping
            logical names to repo IDs.  When multiple repos are given
            the streams are chained sequentially.
        row_to_sample: Callable converting an HF row to a tensor dict.
        batch_size: Batch size for all loaders.
        train_split: HF split name for training data.
        val_split: HF split name for validation data.
        test_split: HF split name for test data (``None`` to skip).
        shuffle_buffer_size: Shuffle buffer for training stream.
        max_train_samples: Cap training samples per epoch.
        max_val_samples: Cap validation samples.
        num_workers: ``DataLoader`` worker count.
        metadata: Extra metadata to store in the bundle.

    Returns:
        ``DataLoaderBundle`` with configured loaders.
    """
    from core.tasks.contracts import normalize_repo_ids

    repo_ids = normalize_repo_ids(hf_repo_id)
    if not repo_ids:
        raise ValueError("hf_repo_id must specify at least one dataset repo")

    def _build_datasets(
        split: str,
        shuffle: int = 0,
        max_samples: Optional[int] = None,
    ) -> IterableDataset:
        datasets = [
            StreamingWindowDataset(
                rid, split, row_to_sample,
                shuffle_buffer_size=shuffle,
                max_samples=max_samples,
            )
            for rid in repo_ids
        ]
        if len(datasets) == 1:
            return datasets[0]
        from torch.utils.data import ChainDataset
        return ChainDataset(datasets)

    train_ds = _build_datasets(train_split, shuffle=shuffle_buffer_size, max_samples=max_train_samples)
    val_ds = _build_datasets(val_split, max_samples=max_val_samples)

    train_loader = DataLoader(
        train_ds, batch_size=batch_size, num_workers=num_workers,
    )
    val_loader = DataLoader(
        val_ds, batch_size=batch_size, num_workers=num_workers,
    )

    test_loader = None
    if test_split:
        test_ds = _build_datasets(test_split, max_samples=max_val_samples)
        test_loader = DataLoader(
            test_ds, batch_size=batch_size, num_workers=num_workers,
        )

    return DataLoaderBundle(
        train=train_loader,
        val=val_loader,
        test=test_loader,
        metadata=metadata or {},
    )
