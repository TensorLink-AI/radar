"""Universal time-series augmenter for evaluation stress-testing.

Provides calibrated, scale-aware augmentations targeting specific model
weaknesses: long-range dependency, multi-scale representation,
non-stationarity handling, and signal-to-noise robustness.

The augmenter is designed to be composed with data loaders (e.g.
:class:`~core.data.gift_loader.GiftEvalDataset`) so that evaluation sets
can be served in *augmented* or *unaugmented* form.

Dependencies: numpy, scipy, PyWavelets (``pywt``).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Sequence, Tuple, Union

import numpy as np

try:
    import pywt
except ImportError:  # pragma: no cover – optional at import time
    pywt = None  # type: ignore[assignment]

try:
    from scipy.interpolate import CubicSpline
except ImportError:  # pragma: no cover
    CubicSpline = None  # type: ignore[assignment,misc]


# ── Augmentation configuration ──────────────────────────────────────────


@dataclass
class AugmentationConfig:
    """Declarative configuration for which augmentations to apply.

    Parameters
    ----------
    challenges : list[str]
        Challenge strings accepted by :meth:`UniversalTSAugmenter.stress`.
        Each entry is ``"category"`` or ``"category/submode"``, e.g.
        ``["long_range/cutout_zero", "snr", "multi_scale/fine"]``.
    severity : float
        Default severity in ``[0, 1]``.  Per-challenge overrides can be
        supplied via *severity_overrides*.
    severity_overrides : dict[str, float]
        Map from challenge string to severity, overriding the default.
    probability : float
        Per-sample probability of applying *any* augmentation.  ``1.0``
        means every sample is augmented; ``0.0`` effectively disables
        augmentation.
    random_seed : int | None
        Seed for the augmenter's RNG.  ``None`` uses a random seed.
    """

    challenges: List[str] = field(default_factory=lambda: [
        "long_range",
        "multi_scale",
        "non_stationary",
        "snr",
    ])
    severity: float = 0.5
    severity_overrides: Dict[str, float] = field(default_factory=dict)
    probability: float = 1.0
    random_seed: Optional[int] = 42


# ── Core augmenter ──────────────────────────────────────────────────────


class UniversalTSAugmenter:
    """Production-grade univariate time-series augmenter.

    Goals
    -----
    * Scale-invariance (noise relative to signal std)
    * Realistic degradation (residual-based, time-varying smoothing)
    * Diagnostic precision (sub-challenge targeting via ``"category/submode"``)
    * Manifold safety (constraints on mean/std/range)
    * Multi-scale stress that actually bites (severity controls strength
      + number of bands)

    Challenges (main categories)
    ----------------------------
    * ``long_range``
    * ``multi_scale``
    * ``non_stationary``
    * ``snr``

    Example diagnostic calls::

        aug.stress(x, "long_range/cutout_zero", severity=1.0)
        aug.stress(x, "multi_scale/detail_1",   severity=1.0)
        aug.stress(x, "non_stationary",         severity=0.7)
        aug.stress(x, "snr",                    severity=0.9)
    """

    def __init__(self, random_seed: int = 42) -> None:
        self.rng = np.random.default_rng(random_seed)

    # ------------------------------------------------------------------ #
    # Helpers & safety                                                     #
    # ------------------------------------------------------------------ #

    def _as_float_1d(self, x: np.ndarray) -> np.ndarray:
        x = np.asarray(x, dtype=float)
        if x.ndim != 1:
            raise ValueError(f"Expected 1D array, got {x.shape}")
        return x

    def _sev01(self, severity: Optional[float]) -> float:
        if severity is None:
            return 0.5
        s = float(severity)
        if s > 1.0:
            s = np.clip(s / 10.0, 0.0, 1.0)
        return float(np.clip(s, 0.0, 1.0))

    def _get_scale(self, x: np.ndarray) -> float:
        sd = float(np.std(x))
        return sd if sd > 1e-9 else 1.0

    def _sigmoid_blend(self, n_points: int) -> np.ndarray:
        t = np.linspace(-6, 6, n_points)
        return 1.0 / (1.0 + np.exp(-t))

    def _constrain(
        self,
        y: np.ndarray,
        x_orig: np.ndarray,
        preserve_mean: bool = False,
        preserve_std: bool = False,
        clip_quantiles: Optional[Tuple[float, float]] = (0.001, 0.999),
    ) -> np.ndarray:
        y = np.asarray(y, dtype=float)
        if clip_quantiles:
            lo_q, hi_q = clip_quantiles
            lo, hi = np.quantile(x_orig, (lo_q, hi_q))
            margin = (hi - lo) * 0.5
            y = np.clip(y, lo - margin, hi + margin)
        if preserve_std:
            y_mu = float(np.mean(y))
            y_std = float(np.std(y) + 1e-6)
            x_std = float(np.std(x_orig) + 1e-6)
            y = (y - y_mu) * (x_std / y_std) + y_mu
        if preserve_mean:
            y = y - float(np.mean(y)) + float(np.mean(x_orig))
        return y

    # ------------------------------------------------------------------ #
    # TIER 1: GEOMETRIC (scale-aware)                                      #
    # ------------------------------------------------------------------ #

    def jitter(self, x: np.ndarray, sigma: float = 0.03) -> np.ndarray:
        x = self._as_float_1d(x)
        scale = self._get_scale(x)
        return x + self.rng.normal(0.0, sigma * scale, size=x.shape)

    def scale(self, x: np.ndarray, sigma: float = 0.1) -> np.ndarray:
        x = self._as_float_1d(x)
        factor = float(self.rng.normal(1.0, sigma))
        return x * factor

    def affine(
        self, x: np.ndarray, sigma_scale: float = 0.1, sigma_shift: float = 0.1
    ) -> np.ndarray:
        x = self._as_float_1d(x)
        scale = self._get_scale(x)
        a = float(self.rng.normal(1.0, sigma_scale))
        b = float(self.rng.normal(0.0, sigma_shift * scale))
        return a * x + b

    # ------------------------------------------------------------------ #
    # TIER 2: TEMPORAL & MEMORY                                            #
    # ------------------------------------------------------------------ #

    def time_warp(
        self, x: np.ndarray, sigma: float = 0.2, knots: int = 4
    ) -> np.ndarray:
        x = self._as_float_1d(x)
        T = len(x)
        if T < 8:
            return x.copy()
        if CubicSpline is None:
            raise ImportError("scipy is required for time_warp")

        knots = int(max(2, knots))
        t = np.linspace(0, T - 1, num=T)
        k_t = np.linspace(0, T - 1, num=knots + 2)
        r_k = self.rng.normal(1.0, sigma, size=knots + 2)

        inc = np.abs(CubicSpline(k_t, r_k)(t)) + 1e-3
        warp = np.cumsum(inc)
        denom = float(warp[-1] - warp[0])
        if denom < 1e-9:
            return x.copy()
        warp = (warp - warp[0]) / denom * (T - 1)
        return np.interp(t, warp, x)

    def history_cutout(
        self, x: np.ndarray, cut_frac: float = 0.15, mode: str = "interp"
    ) -> np.ndarray:
        x = self._as_float_1d(x)
        T = len(x)
        if T < 8:
            return x.copy()

        cut_len = int(np.clip(round(T * float(cut_frac)), 1, T - 2))
        start = int(self.rng.integers(1, T - cut_len - 1))
        end = start + cut_len

        y = x.copy()
        left = y[start - 1]
        right = y[end]

        if mode == "interp":
            y[start:end] = np.linspace(left, right, end - start)
        elif mode == "hold":
            y[start:end] = left
        elif mode == "noise":
            w = min(32, start)
            seg = x[max(0, start - w) : start]
            if seg.size >= 4:
                seg_mu = float(np.mean(seg))
                seg_sd = float(np.std(seg) + 1e-6)
            else:
                seg_mu = float(np.mean(x))
                seg_sd = self._get_scale(x)
            y[start:end] = self.rng.normal(seg_mu, seg_sd, size=(end - start))
        elif mode == "zero":
            y[start:end] = 0.0
        else:
            raise ValueError(f"Unknown mode={mode!r}")
        return y

    def block_permute(self, x: np.ndarray, num_blocks: int = 4) -> np.ndarray:
        x = self._as_float_1d(x)
        T = len(x)
        num_blocks = int(max(2, num_blocks))
        if T < 2 * num_blocks:
            return x.copy()

        edges = np.linspace(0, T, num_blocks + 1, dtype=int)
        blocks = [x[edges[i] : edges[i + 1]] for i in range(num_blocks)]
        self.rng.shuffle(blocks)
        return np.concatenate(blocks)

    # ------------------------------------------------------------------ #
    # TIER 3: MULTI-SCALE (frequency)                                      #
    # ------------------------------------------------------------------ #

    def _wavelet_coeffs(self, x: np.ndarray, level: int):
        if pywt is None:
            raise ImportError("PyWavelets (pywt) is required for wavelet_mask")
        level = int(max(1, level))
        return pywt.wavedec(x, "db4", level=level, mode="periodization")

    def wavelet_mask(
        self,
        x: np.ndarray,
        level: int = 2,
        target: str = "random",
        s: float = 0.5,
        max_drop_bands: int = 3,
    ) -> np.ndarray:
        x = self._as_float_1d(x)
        T = len(x)
        if T < 16:
            return x.copy()

        coeffs = self._wavelet_coeffs(x, level=level)
        if len(coeffs) < 2:
            return x.copy()

        attn = float(np.clip(0.8 - 0.7 * s, 0.05, 0.95))

        if s < 0.7:
            n_drop = 1
        elif s < 0.9:
            n_drop = 2
        else:
            n_drop = 3
        n_drop = int(min(max_drop_bands, n_drop, max(1, len(coeffs) - 1)))

        target = (target or "random").lower().strip()
        detail_idxs = list(range(1, len(coeffs)))
        approx_idx = 0

        def apply_to_indices(idxs: Sequence[int]) -> None:
            for idx in idxs:
                if 0 <= idx < len(coeffs):
                    coeffs[idx] = coeffs[idx] * attn

        if target in ("approx", "coarse"):
            apply_to_indices([approx_idx])
        elif target.startswith("detail_"):
            try:
                k = int(target.split("_", 1)[1])
            except Exception:
                return x.copy()
            idx = len(coeffs) - k
            if idx < 1 or idx >= len(coeffs):
                return x.copy()
            apply_to_indices([idx])
        elif target == "fine":
            idxs = [len(coeffs) - k for k in range(1, n_drop + 1) if len(coeffs) - k >= 1]
            apply_to_indices(idxs)
        elif target == "mixed":
            idxs = [approx_idx]
            idx_fine = len(coeffs) - 1
            if idx_fine >= 1:
                idxs.append(idx_fine)
            apply_to_indices(idxs)
        else:
            # "random" or fallback
            self.rng.shuffle(detail_idxs)
            apply_to_indices(detail_idxs[:n_drop])

        recon = pywt.waverec(coeffs, "db4", mode="periodization")
        return recon[:T]

    # ------------------------------------------------------------------ #
    # TIER 4: NON-STATIONARY (regime shift)                                #
    # ------------------------------------------------------------------ #

    def regime_splice(
        self,
        x: np.ndarray,
        mean_shift: float = 0.5,
        var_scale: float = 0.5,
        transition_window: int = 10,
    ) -> np.ndarray:
        x = self._as_float_1d(x).copy()
        T = len(x)
        scale = self._get_scale(x)
        if T < 20:
            return x

        bp = int(self.rng.integers(int(0.3 * T), int(0.7 * T)))

        shift = float(self.rng.normal(0.0, mean_shift * scale)) if mean_shift > 0 else 0.0
        vs = (
            float(np.clip(1.0 + self.rng.uniform(-1, 1) * var_scale, 0.2, 3.0))
            if var_scale > 0
            else 1.0
        )

        y2 = x.copy()
        mu_local = float(np.mean(y2[bp:]))
        y2[bp:] = (y2[bp:] - mu_local) * vs + mu_local + shift

        w = int(min(max(0, transition_window), bp, T - bp - 1))
        if w > 1:
            sigmoid = self._sigmoid_blend(2 * w)
            trans_start, trans_end = bp - w, bp + w
            seg1 = x[trans_start:trans_end]
            seg2 = y2[trans_start:trans_end]
            y2[trans_start:trans_end] = (1.0 - sigmoid) * seg1 + sigmoid * seg2
            y2[:trans_start] = x[:trans_start]
        else:
            y2[:bp] = x[:bp]
        return y2

    # ------------------------------------------------------------------ #
    # TIER 5: SNR & SENSOR DEGRADATION                                     #
    # ------------------------------------------------------------------ #

    def adaptive_smoothing(
        self,
        x: np.ndarray,
        base_alpha: float = 0.1,
        max_smoothing: float = 0.9,
    ) -> np.ndarray:
        x = self._as_float_1d(x)
        T = len(x)
        if T < 2:
            return x.copy()

        baseline = np.zeros_like(x)
        curr = float(x[0])
        for t in range(T):
            curr = 0.2 * float(x[t]) + 0.8 * curr
            baseline[t] = curr

        resid = np.abs(x - baseline)
        resid_smooth = np.zeros_like(resid)
        r_curr = float(resid[0])
        for t in range(T):
            r_curr = 0.1 * float(resid[t]) + 0.9 * r_curr
            resid_smooth[t] = r_curr

        r_ref = float(np.quantile(resid_smooth, 0.95) + 1e-9)
        roughness = np.clip(resid_smooth / r_ref, 0.0, 1.0)

        y = np.zeros_like(x)
        curr_y = float(x[0])
        y[0] = curr_y

        max_smoothing = float(np.clip(max_smoothing, 0.0, 0.999))
        base_alpha = float(np.clip(base_alpha, 1e-4, 1.0))

        for t in range(1, T):
            alpha_t = 1.0 - float(roughness[t]) * max_smoothing
            alpha_t = float(np.clip(alpha_t, base_alpha, 1.0))
            curr_y = alpha_t * float(x[t]) + (1.0 - alpha_t) * curr_y
            y[t] = curr_y
        return y

    # ------------------------------------------------------------------ #
    # MAIN INTERFACE                                                       #
    # ------------------------------------------------------------------ #

    def stress(
        self,
        x: np.ndarray,
        challenge: str,
        severity: Optional[float] = 0.5,
        preserve_mean: bool = False,
        preserve_std: bool = False,
        clip_quantiles: Optional[Tuple[float, float]] = (0.001, 0.999),
    ) -> np.ndarray:
        """Apply a calibrated stress test.

        Parameters
        ----------
        x : 1-D array
            Input time series.
        challenge : str
            ``"category"`` or ``"category/submode"``.
        severity : float
            Strength in ``[0, 1]``.
        """
        x = self._as_float_1d(x)
        y = x.copy()
        s = self._sev01(severity)

        parts = challenge.split("/", 1)
        main_cat = parts[0].strip().lower()
        sub_mode = parts[1].strip().lower() if len(parts) > 1 else None

        if main_cat == "long_range":
            if sub_mode == "cutout_zero":
                y = self.history_cutout(y, cut_frac=0.1 + 0.3 * s, mode="zero")
            elif sub_mode == "cutout_hold":
                y = self.history_cutout(y, cut_frac=0.1 + 0.3 * s, mode="hold")
            elif sub_mode == "cutout_noise":
                y = self.history_cutout(y, cut_frac=0.1 + 0.3 * s, mode="noise")
            elif sub_mode == "cutout_interp":
                y = self.history_cutout(y, cut_frac=0.1 + 0.3 * s, mode="interp")
            elif sub_mode == "permute":
                y = self.block_permute(y, num_blocks=int(2 + 4 * s))
            elif sub_mode == "warp":
                y = self.time_warp(y, sigma=0.15 + 0.65 * s, knots=int(3 + 5 * s))
            else:
                if self.rng.random() < 0.5:
                    y = self.block_permute(y, num_blocks=int(2 + 4 * s))
                else:
                    y = self.history_cutout(y, cut_frac=0.1 + 0.3 * s, mode="interp")

        elif main_cat == "multi_scale":
            if sub_mode is None:
                sub_mode = "random"
            y = self.wavelet_mask(
                y, level=int(1 + 3 * s), target=sub_mode, s=s, max_drop_bands=3,
            )

        elif main_cat == "non_stationary":
            ms = 0.5 + 2.5 * s
            vs = 0.5 + 2.0 * s
            y = self.regime_splice(y, mean_shift=ms, var_scale=vs, transition_window=10)

        elif main_cat == "snr":
            max_smooth = 0.5 + 0.45 * s
            y = self.adaptive_smoothing(y, base_alpha=0.05, max_smoothing=max_smooth)
            y = self.jitter(y, sigma=0.01 + 0.1 * s)

        else:
            raise ValueError(f"Unknown challenge={challenge!r}")

        return self._constrain(
            y,
            x,
            preserve_mean=preserve_mean,
            preserve_std=preserve_std,
            clip_quantiles=clip_quantiles,
        )

    # ------------------------------------------------------------------ #
    # Config-driven batch interface                                        #
    # ------------------------------------------------------------------ #

    def augment_from_config(
        self,
        x: np.ndarray,
        config: AugmentationConfig,
    ) -> np.ndarray:
        """Apply a randomly-chosen challenge from *config* to *x*.

        A uniform draw against ``config.probability`` decides whether any
        augmentation is applied at all.  When applied, a single challenge
        is sampled uniformly from ``config.challenges``.
        """
        if self.rng.random() >= config.probability:
            return np.asarray(x, dtype=float)

        challenge = config.challenges[
            int(self.rng.integers(0, len(config.challenges)))
        ]
        severity = config.severity_overrides.get(challenge, config.severity)
        return self.stress(x, challenge, severity=severity)
