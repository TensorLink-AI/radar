"""
PyTorch IterableDataset backed by Parquet shards on S3-compatible storage.

Streams data from Parquet files stored on Cloudflare R2 or Hippius
(both S3-compatible).  Supports weighted sampling by domain and
frequency, manifest-based file selection, multi-worker deterministic
sharding, and thread-based prefetching.

This module is **task-agnostic**.  Subclass :class:`S3ParquetDataset` or
pass a ``row_to_sample`` callable to convert raw Parquet rows into the
dict format your model expects.

Data layout on S3::

    <root_prefix>/data/domain=<DOMAIN>/freq=<FREQ>/global_part=<N>/part-<N>.parquet

Manifest (optional, for fast file lookup)::

    <root_prefix>/manifest/entries/YYYY-MM-DD/*.json
    <root_prefix>/manifest/consolidated.parquet   (or .jsonl)

Environment variables — set endpoint + credentials per backend::

    # Cloudflare R2 (default)
    AWS_ENDPOINT_URL=https://<account>.r2.cloudflarestorage.com
    AWS_ACCESS_KEY_ID=...
    AWS_SECRET_ACCESS_KEY=...

    # Hippius (same S3 API, different endpoint)
    HIPPIUS_ENDPOINT_URL=https://...
    HIPPIUS_ACCESS_KEY_ID=...
    HIPPIUS_SECRET_ACCESS_KEY=...
"""

from __future__ import annotations

import io
import json
import logging
import os
import random
import re
from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass, field
from typing import (
    Any,
    Callable,
    Dict,
    Iterator,
    List,
    Optional,
    Sequence,
    Tuple,
)

import torch
from torch.utils.data import DataLoader, IterableDataset, get_worker_info

from core.data.s3_store import S3ObjectStore, S3StoreConfig, build_s3_store_from_env

logger = logging.getLogger(__name__)


# ── Type alias for row conversion ────────────────────────────────────────

RowToSampleFn = Callable[[Dict[str, Any]], Dict[str, Any]]
"""Callable that converts a raw Parquet row dict into a training sample dict."""


# ── Configuration ────────────────────────────────────────────────────────


@dataclass
class S3ParquetConfig:
    """Configuration for the S3 Parquet streaming dataset.

    Args:
        bucket: S3 bucket name.
        root_prefix: Key prefix under which data and manifest live.
        endpoint_url: S3-compatible endpoint URL.
        region: AWS region or ``"auto"`` for R2/Hippius.
        access_key: AWS-style access key ID.
        secret_key: AWS-style secret access key.
        env_prefix: If credentials are not set explicitly, load from
            ``{env_prefix}_ENDPOINT_URL``, etc.  Default ``"AWS"``.
        domain_weights: Sampling weights per domain.
        freq_weights: Sampling weights per frequency.
        joint_weights: Joint ``(domain, freq)`` weights.  Overrides
            domain/freq weights when provided.
        seed: Base random seed for deterministic sampling.
        prefetch_files: Number of files to prefetch via thread pool.
        parquet_batch_size: Row-group batch size for pyarrow streaming.
        shuffle_rows: Shuffle rows within each file.
        max_retries: Retries for S3 operations.
        retry_backoff_base: Backoff base in seconds.
    """

    bucket: str = ""
    root_prefix: str = ""
    endpoint_url: str = ""
    region: str = "auto"
    access_key: str = ""
    secret_key: str = ""
    env_prefix: str = "AWS"

    # Sampling weights
    domain_weights: Dict[str, float] = field(default_factory=dict)
    freq_weights: Dict[str, float] = field(default_factory=dict)
    joint_weights: Dict[Tuple[str, str], float] = field(default_factory=dict)

    # Reproducibility
    seed: int = 42

    # Performance
    prefetch_files: int = 2
    parquet_batch_size: int = 1024
    shuffle_rows: bool = True

    # S3 robustness
    max_retries: int = 3
    retry_backoff_base: float = 1.0

    def build_store(self) -> S3ObjectStore:
        """Build an :class:`S3ObjectStore` from this config.

        If ``endpoint_url`` is set, uses explicit credentials.
        Otherwise falls back to environment variables via ``env_prefix``.
        """
        if self.endpoint_url:
            store_cfg = S3StoreConfig(
                endpoint_url=self.endpoint_url,
                access_key=self.access_key,
                secret_key=self.secret_key,
                region=self.region,
                max_retries=self.max_retries,
                retry_backoff_base=self.retry_backoff_base,
            )
            return S3ObjectStore(store_cfg, self.bucket)
        store = build_s3_store_from_env(
            self.bucket,
            env_prefix=self.env_prefix,
            required=True,
        )
        assert store is not None  # required=True guarantees this
        return store


# ── Manifest / Index ─────────────────────────────────────────────────────


@dataclass
class FileEntry:
    """Metadata for a single Parquet shard on S3.

    Args:
        key: Full S3 object key.
        domain: Domain label (e.g. ``"Energy/Grid"``).
        freq: Frequency string (e.g. ``"1H"``).
        rows: Number of rows in the file (0 if unknown).
        size_bytes: File size in bytes (0 if unknown).
    """

    key: str
    domain: str
    freq: str
    rows: int = 0
    size_bytes: int = 0


class ManifestIndex:
    """In-memory index of Parquet shards grouped by (domain, freq).

    Loads from manifest entries on S3 or discovers files by listing
    the data prefix directly.

    Args:
        store: S3 object store.
        root_prefix: Root key prefix.
    """

    def __init__(self, store: S3ObjectStore, root_prefix: str) -> None:
        self._store = store
        self._root_prefix = root_prefix.rstrip("/")
        self.by_group: Dict[Tuple[str, str], List[FileEntry]] = defaultdict(list)

    def load(self) -> None:
        """Load the manifest index, trying consolidated first, then entries, then scan."""
        loaded = self._try_consolidated()
        if not loaded:
            loaded = self._try_manifest_entries()
        if not loaded:
            self._scan_data_prefix()
        total_files = sum(len(v) for v in self.by_group.values())
        logger.info(
            "ManifestIndex loaded: %d groups, %d total files",
            len(self.by_group), total_files,
        )

    def _try_consolidated(self) -> bool:
        """Try loading a consolidated manifest (JSONL or Parquet)."""
        jsonl_key = f"{self._root_prefix}/manifest/consolidated.jsonl"
        try:
            raw = self._store.get_bytes(jsonl_key)
            for line in raw.decode("utf-8").splitlines():
                line = line.strip()
                if not line:
                    continue
                entry = json.loads(line)
                self._add_entry(entry)
            logger.info("Loaded consolidated manifest (JSONL)")
            return True
        except Exception:
            pass

        parquet_key = f"{self._root_prefix}/manifest/consolidated.parquet"
        try:
            import pyarrow.parquet as pq

            raw = self._store.get_bytes(parquet_key)
            table = pq.read_table(io.BytesIO(raw))
            for row in table.to_pylist():
                self._add_entry(row)
            logger.info("Loaded consolidated manifest (Parquet)")
            return True
        except Exception:
            pass

        return False

    def _try_manifest_entries(self) -> bool:
        """Scan manifest/entries/ for per-day JSON files."""
        prefix = f"{self._root_prefix}/manifest/entries/"
        try:
            keys = self._store.list_keys(prefix)
        except Exception:
            return False

        json_keys = [k for k in keys if k.endswith(".json")]
        if not json_keys:
            return False

        for key in json_keys:
            try:
                data = self._store.get_json(key)
                # May be a single entry or list of entries
                entries = data if isinstance(data, list) else [data]
                for entry in entries:
                    self._add_entry(entry)
            except Exception:
                logger.warning("Failed to load manifest entry: %s", key)
                continue

        logger.info("Loaded %d manifest entry files", len(json_keys))
        return bool(self.by_group)

    def _scan_data_prefix(self) -> None:
        """Fall back: list data/ prefix and parse paths for domain/freq."""
        prefix = f"{self._root_prefix}/data/"
        try:
            keys = self._store.list_keys(prefix)
        except Exception:
            logger.error("Failed to list data prefix: %s", prefix)
            return

        pattern = re.compile(
            r"/data/domain=(?P<domain>[^/]+)/freq=(?P<freq>[^/]+)/"
        )
        parquet_keys = [k for k in keys if k.endswith(".parquet")]
        for key in parquet_keys:
            m = pattern.search(key)
            if m:
                entry = FileEntry(
                    key=key,
                    domain=m.group("domain"),
                    freq=m.group("freq"),
                    rows=0,
                    size_bytes=0,
                )
                self.by_group[(entry.domain, entry.freq)].append(entry)

        logger.info("Scanned %d parquet files from data prefix", len(parquet_keys))

    def _add_entry(self, raw: Dict[str, Any]) -> None:
        """Add a single entry dict to the index."""
        key = raw.get("key", "")
        domain = raw.get("domain", "")
        freq = raw.get("freq", "")
        if not key or not domain or not freq:
            return
        entry = FileEntry(
            key=key,
            domain=domain,
            freq=freq,
            rows=int(raw.get("rows", 0)),
            size_bytes=int(raw.get("bytes", raw.get("size_bytes", 0))),
        )
        self.by_group[(entry.domain, entry.freq)].append(entry)

    def groups(self) -> List[Tuple[str, str]]:
        """Return all (domain, freq) groups."""
        return list(self.by_group.keys())

    def domains(self) -> List[str]:
        """Return unique domain names."""
        return list({d for d, _ in self.by_group.keys()})

    def freqs(self) -> List[str]:
        """Return unique frequency names."""
        return list({f for _, f in self.by_group.keys()})

    def groups_for_domain(self, domain: str) -> List[Tuple[str, str]]:
        """Return groups that match *domain*."""
        return [(d, f) for d, f in self.by_group if d == domain]

    def groups_for_freq(self, freq: str) -> List[Tuple[str, str]]:
        """Return groups that match *freq*."""
        return [(d, f) for d, f in self.by_group if f == freq]


# ── Weighted sampler ─────────────────────────────────────────────────────


class _GroupSampler:
    """Chooses (domain, freq) groups and files based on configured weights.

    Args:
        index: Populated ``ManifestIndex``.
        domain_weights: Per-domain sampling weights.
        freq_weights: Per-frequency sampling weights.
        joint_weights: Joint ``(domain, freq)`` weights.
        rng: Random number generator for reproducibility.
    """

    def __init__(
        self,
        index: ManifestIndex,
        *,
        domain_weights: Dict[str, float],
        freq_weights: Dict[str, float],
        joint_weights: Dict[Tuple[str, str], float],
        rng: random.Random,
    ) -> None:
        self._index = index
        self._domain_weights = domain_weights
        self._freq_weights = freq_weights
        self._joint_weights = joint_weights
        self._rng = rng
        self._groups = index.groups()

        # Precompute group weights
        self._group_weights = self._compute_group_weights()

    def _compute_group_weights(self) -> List[float]:
        """Compute normalised sampling weight per group."""
        weights: List[float] = []
        for domain, freq in self._groups:
            if self._joint_weights:
                w = self._joint_weights.get((domain, freq), 0.0)
            elif self._domain_weights and self._freq_weights:
                w = self._domain_weights.get(domain, 0.0) * self._freq_weights.get(freq, 0.0)
            elif self._domain_weights:
                w = self._domain_weights.get(domain, 0.0)
            elif self._freq_weights:
                w = self._freq_weights.get(freq, 0.0)
            else:
                w = 1.0  # uniform
            weights.append(w)

        total = sum(weights)
        if total <= 0:
            # Fall back to uniform if all weights are zero
            return [1.0 / len(self._groups)] * len(self._groups)
        return [w / total for w in weights]

    def sample_file(self) -> Optional[FileEntry]:
        """Sample a file using the configured weighting scheme.

        Returns:
            A ``FileEntry`` or ``None`` if no files are available.
        """
        if not self._groups:
            return None

        # 1) Choose group
        group = self._rng.choices(self._groups, weights=self._group_weights, k=1)[0]
        entries = self._index.by_group.get(group, [])
        if not entries:
            return None

        # 2) Choose file within group, proportional to rows if known
        row_counts = [max(e.rows, 1) for e in entries]
        chosen = self._rng.choices(entries, weights=row_counts, k=1)[0]
        return chosen


# ── Parquet file reader ──────────────────────────────────────────────────


def _read_parquet_rows(
    store: S3ObjectStore,
    key: str,
    batch_size: int,
    shuffle: bool,
    rng: random.Random,
) -> List[Dict[str, Any]]:
    """Read all rows from a Parquet file on S3.

    Downloads the file and streams row batches via pyarrow.

    Args:
        store: S3 store to read from.
        key: S3 object key.
        batch_size: pyarrow ``iter_batches`` batch size.
        shuffle: Whether to shuffle rows.
        rng: Random generator for shuffling.

    Returns:
        List of row dicts.
    """
    import pyarrow.parquet as pq

    raw = store.get_bytes(key)
    buf = io.BytesIO(raw)
    pf = pq.ParquetFile(buf)

    rows: List[Dict[str, Any]] = []
    for batch in pf.iter_batches(batch_size=batch_size):
        for row in batch.to_pylist():
            rows.append(row)

    if shuffle and len(rows) > 1:
        rng.shuffle(rows)

    return rows


def _default_row_to_sample(row: Dict[str, Any]) -> Dict[str, Any]:
    """Default identity row converter — returns the raw Parquet row as-is.

    Subclasses or callers should provide a task-specific ``row_to_sample``
    instead.  This default is only useful for testing or when the raw
    Parquet schema already matches the desired sample format.
    """
    return dict(row)


# ── IterableDataset ──────────────────────────────────────────────────────


class S3ParquetDataset(IterableDataset):
    """Streaming IterableDataset reading Parquet shards from S3.

    At each step, the dataset:

    1. Selects a ``(domain, freq)`` group using configured weights.
    2. Selects a Parquet file within the group (proportional to rows).
    3. Streams the file's rows, converting each via ``row_to_sample``.
    4. Prefetches the next file(s) in a thread pool for efficiency.

    When used with ``DataLoader(num_workers>0)``, each worker gets a
    deterministic RNG seeded from ``base_seed + worker_id``.

    Args:
        config: Dataset configuration.
        row_to_sample: Callable converting a raw Parquet row dict to a
            training sample dict.  If ``None``, rows are returned as-is.
        store: Pre-built S3 object store (built from config if ``None``).
        index: Pre-built manifest index (loaded from S3 if ``None``).
    """

    def __init__(
        self,
        config: S3ParquetConfig,
        *,
        row_to_sample: Optional[RowToSampleFn] = None,
        store: Optional[S3ObjectStore] = None,
        index: Optional[ManifestIndex] = None,
    ) -> None:
        self.config = config
        self._row_to_sample = row_to_sample or _default_row_to_sample
        self._store = store
        self._index = index
        self._corrupt_count = 0

    def _ensure_store(self) -> S3ObjectStore:
        if self._store is None:
            self._store = self.config.build_store()
        return self._store

    def _ensure_index(self) -> ManifestIndex:
        if self._index is None:
            store = self._ensure_store()
            self._index = ManifestIndex(store, self.config.root_prefix)
            self._index.load()
        return self._index

    @property
    def corrupt_count(self) -> int:
        """Number of files skipped due to read/parse errors."""
        return self._corrupt_count

    def _convert_row(self, row: Dict[str, Any]) -> Dict[str, Any]:
        """Convert a raw Parquet row to a sample dict.

        Override in subclasses for task-specific conversion logic,
        or pass ``row_to_sample`` at construction time.
        """
        return self._row_to_sample(row)

    def __iter__(self) -> Iterator[Dict[str, Any]]:
        store = self._ensure_store()
        index = self._ensure_index()

        # Deterministic RNG per worker
        worker_info = get_worker_info()
        worker_id = worker_info.id if worker_info is not None else 0
        rng = random.Random(self.config.seed + worker_id)

        sampler = _GroupSampler(
            index,
            domain_weights=self.config.domain_weights,
            freq_weights=self.config.freq_weights,
            joint_weights=self.config.joint_weights,
            rng=rng,
        )

        prefetch_n = max(1, self.config.prefetch_files)
        executor = ThreadPoolExecutor(max_workers=prefetch_n)

        try:
            yield from self._stream_loop(store, sampler, rng, executor, prefetch_n)
        finally:
            executor.shutdown(wait=False)

    def _stream_loop(
        self,
        store: S3ObjectStore,
        sampler: _GroupSampler,
        rng: random.Random,
        executor: ThreadPoolExecutor,
        prefetch_n: int,
    ) -> Iterator[Dict[str, Any]]:
        """Core streaming loop with prefetch.

        Stops after ``max_consecutive_errors`` (default 50) consecutive
        file-read failures to avoid infinite loops on all-corrupt data.
        """
        max_consecutive_errors = 50

        # Submit initial batch of file reads
        futures = []
        for _ in range(prefetch_n):
            entry = sampler.sample_file()
            if entry is not None:
                fut = executor.submit(
                    _read_parquet_rows,
                    store,
                    entry.key,
                    self.config.parquet_batch_size,
                    self.config.shuffle_rows,
                    rng,
                )
                futures.append(fut)

        consecutive_errors = 0
        while futures:
            # Take first completed future
            done_fut = futures.pop(0)
            try:
                rows = done_fut.result()
            except Exception as exc:
                self._corrupt_count += 1
                consecutive_errors += 1
                logger.warning("Skipping corrupted/failed file: %s", exc)
                if consecutive_errors >= max_consecutive_errors:
                    logger.error(
                        "Stopping after %d consecutive file errors",
                        consecutive_errors,
                    )
                    return
                # Submit replacement
                entry = sampler.sample_file()
                if entry is not None:
                    fut = executor.submit(
                        _read_parquet_rows,
                        store,
                        entry.key,
                        self.config.parquet_batch_size,
                        self.config.shuffle_rows,
                        rng,
                    )
                    futures.append(fut)
                continue

            consecutive_errors = 0

            # Yield rows from this file
            for row in rows:
                try:
                    sample = self._convert_row(row)
                    yield sample
                except Exception:
                    continue

            # Submit next file
            entry = sampler.sample_file()
            if entry is not None:
                fut = executor.submit(
                    _read_parquet_rows,
                    store,
                    entry.key,
                    self.config.parquet_batch_size,
                    self.config.shuffle_rows,
                    rng,
                )
                futures.append(fut)


# ── Builder ──────────────────────────────────────────────────────────────


def build_s3_parquet_dataloader(
    config: S3ParquetConfig,
    *,
    row_to_sample: Optional[RowToSampleFn] = None,
    collate_fn: Optional[Callable] = None,
    batch_size: int = 32,
    num_workers: int = 0,
    store: Optional[S3ObjectStore] = None,
    index: Optional[ManifestIndex] = None,
) -> DataLoader:
    """Build a ``DataLoader`` streaming Parquet shards from S3.

    Args:
        config: Dataset configuration.
        row_to_sample: Callable converting raw Parquet rows to sample
            dicts.  Passed through to :class:`S3ParquetDataset`.
        collate_fn: Optional collate function for the ``DataLoader``.
            If ``None``, PyTorch's default collation is used.
        batch_size: Batch size.
        num_workers: DataLoader worker processes.
        store: Pre-built S3 store (built from config if ``None``).
        index: Pre-built manifest index (loaded if ``None``).

    Returns:
        Configured ``DataLoader``.

    Example::

        config = S3ParquetConfig(
            bucket="my-data",
            root_prefix="datasets/v1",
            endpoint_url="https://acct.r2.cloudflarestorage.com",
            access_key="...",
            secret_key="...",
            seed=42,
        )
        loader = build_s3_parquet_dataloader(
            config,
            row_to_sample=my_row_converter,
            collate_fn=my_collate,
            batch_size=64,
            num_workers=4,
        )
        for batch in loader:
            print(batch.keys())
    """
    dataset = S3ParquetDataset(
        config, row_to_sample=row_to_sample, store=store, index=index,
    )
    kwargs: Dict[str, Any] = {
        "batch_size": batch_size,
        "num_workers": num_workers,
    }
    if collate_fn is not None:
        kwargs["collate_fn"] = collate_fn
    return DataLoader(dataset, **kwargs)


__all__ = [
    "RowToSampleFn",
    "S3ParquetConfig",
    "FileEntry",
    "ManifestIndex",
    "S3ParquetDataset",
    "build_s3_parquet_dataloader",
]
