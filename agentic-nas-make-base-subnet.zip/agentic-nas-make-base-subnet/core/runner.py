from __future__ import annotations

from dataclasses import dataclass, asdict, field
from typing import Any, Dict, List, Optional

@dataclass
class RunnerResult:
    """
    Normalized wrapper so AgentLogger can log everything consistently.
    """
    final_output: Any
    raw_responses: List[Dict[str, Any]] = field(default_factory=list)
    usage: Dict[str, int] = field(default_factory=dict)
    messages: Optional[List[Dict[str, Any]]] = None  # conversation transcript

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


def _zero_usage() -> Dict[str, int]:
    return {
        "input_tokens": 0,
        "output_tokens": 0,
        "total_tokens": 0,
    }


def _coerce_usage(obj: Any) -> Dict[str, int]:
    """
    Convert provider usage formats into {input_tokens, output_tokens, total_tokens}.
    Supports both OpenAI style and custom.
    """
    if not obj:
        return _zero_usage()

    if isinstance(obj, dict):
        inp = obj.get("input_tokens", obj.get("prompt_tokens", 0))
        out = obj.get("output_tokens", obj.get("completion_tokens", 0))
        total = obj.get("total_tokens", inp + out)
        return {
            "input_tokens": int(inp),
            "output_tokens": int(out),
            "total_tokens": int(total),
        }

    # attribute-style object
    inp = getattr(obj, "input_tokens", getattr(obj, "prompt_tokens", 0))
    out = getattr(obj, "output_tokens", getattr(obj, "completion_tokens", 0))
    total = getattr(obj, "total_tokens", (inp + out))
    return {
        "input_tokens": int(inp),
        "output_tokens": int(out),
        "total_tokens": int(total),
    }


def _get_usage(agent: Any) -> Dict[str, int]:
    """
    Best-effort extraction from agent.llm after a run().
    """
    llm = getattr(agent, "llm", None)
    if llm is None:
        return _zero_usage()

    if hasattr(llm, "last_usage"):
        try:
            return _coerce_usage(llm.last_usage)
        except Exception:
            pass

    if hasattr(llm, "get_last_usage") and callable(llm.get_last_usage):  # optional extension
        try:
            return _coerce_usage(llm.get_last_usage())
        except Exception:
            pass

    if hasattr(llm, "usage"):
        try:
            return _coerce_usage(llm.usage)
        except Exception:
            pass

    return _zero_usage()


def _get_raw_responses(agent: Any) -> List[Dict[str, Any]]:
    """
    Collect the raw provider responses for debugging.
    """
    llm = getattr(agent, "llm", None)
    if llm is None:
        return []

    if hasattr(llm, "history"):
        try:
            return list(llm.history)
        except Exception:
            pass

    if hasattr(llm, "last_response"):
        try:
            return [llm.last_response]
        except Exception:
            pass

    return []


def _get_messages(agent: Any) -> Optional[List[Dict[str, Any]]]:
    """
    Retrieve recorded transcript from ProviderAgent.run()
    """
    return getattr(agent, "last_messages", None)


class Runner:
    """
    The single integration point between AgentLogger and any Agent.

    AgentLogger will call:
        result = await Runner.run(agent, input=..., **kwargs)

    We:
    - call agent.run(...)
    - pull usage + raw responses + transcript
    - return RunnerResult with a consistent shape
    """

    @staticmethod
    async def run(agent: Any, input: Any = None, **kwargs) -> RunnerResult:
        # Call the agent.
        # ProviderAgent.run expects: run(user_prompt: str, response_model: Type[BaseModel] = None, **kwargs)

        # Handle case where user_prompt is passed in kwargs (e.g., from log_agent_run)
        # to avoid "got multiple values for keyword argument 'user_prompt'" error
        if "user_prompt" in kwargs:
            user_prompt = kwargs.pop("user_prompt")
            # Prefer explicit input parameter if provided, otherwise use user_prompt from kwargs
            if input is not None:
                user_prompt = str(input)
        else:
            user_prompt = str(input) if input is not None else ""

        final_output = await agent.run(
            user_prompt=user_prompt,
            **kwargs
        )

        usage = _get_usage(agent)
        raw_responses = _get_raw_responses(agent)
        messages = _get_messages(agent)

        return RunnerResult(
            final_output=final_output,
            raw_responses=raw_responses,
            usage=usage,
            messages=messages,
        )
