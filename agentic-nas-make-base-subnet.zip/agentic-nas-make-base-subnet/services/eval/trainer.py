import asyncio
import json
import os
from typing import Any, Dict, List

from core.tasks.contracts import BaseTask
from services.config import Config
from services.eval.errors import build_shape_error
from services.eval.remote_training.remote_types import (
    BudgetTier,
    Provider,
    TrainingJobMetadata,
    TrainingJobSpec,
    TrainingStatus,
)


def _flatten_metrics(metrics: Dict[str, Any]) -> Dict[str, float]:
    """Convert nested metric dictionaries into a flat mapping of metric names to floats."""
    flattened: Dict[str, float] = {}

    def _walk(prefix: str, value: Any) -> None:
        if isinstance(value, dict):
            for sub_key, sub_value in value.items():
                new_prefix = f"{prefix}.{sub_key}" if prefix else str(sub_key)
                _walk(new_prefix, sub_value)
        elif isinstance(value, (int, float)) and not isinstance(value, bool):
            flattened[prefix] = float(value)

    for key, value in (metrics or {}).items():
        # Exclude model configuration from the flattened metrics CSV
        if key == "model":
            continue
        _walk(str(key), value)

    return flattened


def _select_primary_metric(task: BaseTask, flattened: Dict[str, float]) -> float:
    """Pick a representative metric value for the training CSV."""
    objectives = [obj.lower() for obj in task.primary_objectives()]
    for objective in objectives:
        for key, value in flattened.items():
            if objective in key.lower():
                return value
    return next(iter(flattened.values()), 0.0) if flattened else 0.0


def _write_text(path: str, content: str) -> None:
    dir_path = os.path.dirname(path)
    if dir_path:
        os.makedirs(dir_path, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        f.write(content)


class Trainer:
    """Execute task-provided training/evaluation via remote execution."""

    name = "Model Trainer"

    async def _materialize_metrics(
        self,
        *,
        task: BaseTask,
        name: str,
        eval_type: str,
        metrics: Dict[str, Any],
    ) -> Dict[str, Any]:
        """Write CSV artifacts from metric dictionaries and return structured payloads."""

        flattened = _flatten_metrics(metrics)
        if not flattened:
            flattened = {"placeholder_metric": 0.0}

        primary_metric = _select_primary_metric(task, flattened)

        if (
            "history" in metrics
            and isinstance(metrics["history"], list)
            and len(metrics["history"]) > 0
        ):
            history = metrics["history"]
            keys = list(history[0].keys())
            train_csv_lines = [",".join(keys)]
            for row in history:
                train_csv_lines.append(",".join(str(row.get(k, "")) for k in keys))
            train_csv = "\n".join(train_csv_lines) + "\n"
        else:
            train_csv = "step,loss\nfinal,{:.6f}\n".format(primary_metric)

        header = ["metric"] + list(flattened.keys())
        values = ["scores"] + [f"{flattened[k]:.6f}" for k in flattened.keys()]
        test_csv = ",".join(header) + "\n" + ",".join(values) + "\n"

        train_path = task.get_result_file_path(name, eval_type)
        test_path = task.get_test_result_file_path(name, eval_type)
        await asyncio.to_thread(_write_text, train_path, train_csv)
        await asyncio.to_thread(_write_text, test_path, test_csv)

        logs = json.dumps(metrics, indent=2, default=str)

        return {
            "success": True,
            "error": None,
            "train_csv": train_csv,
            "test_csv": test_csv,
            "logs": logs,
            "metrics": flattened,
        }

    async def run_remote(
        self,
        *,
        name: str,
        task: BaseTask,
        candidate: Dict[str, Any],
        run_dir: str,
        eval_type: str,
        training_client: Any,
    ) -> Dict[str, Any]:
        """Dispatch training to a remote executor and normalize the results."""

        code_path = candidate.get("code_path")
        if not code_path:
            return {
                "success": False,
                "error": "Candidate payload is missing 'code_path'",
                "logs": "",
            }

        try:
            remote_result = await self._run_remote_training(
                name=name,
                eval_type=eval_type,
                task=task,
                code_path=code_path,
                candidate=candidate,
                training_client=training_client,
            )
        except Exception as exc:  # pragma: no cover - defensive catch for async context
            error_payload = build_shape_error(
                str(exc),
                config=None,
                shapes=None,
                context={"stage": "trainer.run_remote"},
            )
            return {
                "success": False,
                "error": error_payload,
                "logs": "",
            }

        result_status = getattr(remote_result, "status", TrainingStatus.FAILED)
        if result_status != TrainingStatus.SUCCEEDED:
            stdout_tail = getattr(remote_result, "stdout_tail", "")
            # Preserve timeout information in the error message for downstream detection
            if result_status == TrainingStatus.TIMED_OUT:
                error_msg = stdout_tail if stdout_tail else "Remote training timed out"
                if "timed out" not in error_msg.lower() and "timeout" not in error_msg.lower():
                    error_msg = f"[Timeout] {error_msg}"
            else:
                error_msg = stdout_tail if stdout_tail else "Remote training failed"
            return {
                "success": False,
                "error": error_msg,
                "logs": stdout_tail,
            }

        metrics = getattr(remote_result, "metrics", {}) or {}
        if not isinstance(metrics, dict):
            return {
                "success": False,
                "error": "Remote training returned invalid metrics payload",
                "logs": json.dumps(remote_result, default=str),
            }

        return await self._materialize_metrics(
            task=task,
            name=name,
            eval_type=eval_type,
            metrics=metrics,
        )

    def _derive_dataset_spec(self, *, task: BaseTask, candidate: Dict[str, Any]) -> Dict[str, Any]:
        """Collect dataset hints locally so the remote worker needs no imports."""

        dataset_spec: Dict[str, Any] = {}
        overrides = candidate.get("dataset_spec") or candidate.get("dataset_cfg")
        if isinstance(overrides, dict):
            dataset_spec.update(overrides)

        task_path = getattr(task, "_dataset_path", None)
        if task_path and "dataset_path" not in dataset_spec:
            dataset_spec["dataset_path"] = task_path

        constraints = getattr(task, "get_code_generation_constraints", None)
        if callable(constraints):
            task_constraints = constraints()
            dataset_spec.setdefault("input_length", task_constraints.get("input_length"))
            dataset_spec.setdefault("forecast_length", task_constraints.get("forecast_length"))

        # For remote training, ensure we have a data source. If no local path is set,
        # use the HuggingFace default repo so the remote worker can stream data.
        if "dataset_path" not in dataset_spec and "hf_repo_id" not in dataset_spec:
            # Use the default HF repo for time-series tasks
            dataset_spec["hf_repo_id"] = "tensorlink-dev/time-series-six-datasets"

        return dataset_spec

    def _resolve_primary_metrics(self, task: BaseTask) -> List[str]:
        """Normalize primary metrics for downstream consumers."""

        try:
            return [metric for metric in task.primary_objectives() if metric]
        except Exception:
            return []

    def _resolve_timeout(self, budget_tier: Any, provider: Provider = Provider.TARGON) -> float:
        """Infer an execution timeout for the remote harness.

        Returns a tier-based default (SMALL=1800s, LARGE=7200s).

        For RunPod the timeout is additionally capped so the harness finishes
        before RunPod's platform-level executionTimeout kills the container.

        For Basilica no capping is done here -- the BasilicaTrainingClient owns
        its TTL configuration and applies its own fallback via
        ``_get_ttl_for_tier()`` if ``spec.timeout_sec`` is missing.
        """

        try:
            tier = BudgetTier(budget_tier) if budget_tier else None
        except Exception:
            tier = None

        # Default timeouts per tier
        if tier == BudgetTier.LARGE:
            base_timeout = 7200.0
        elif tier == BudgetTier.SMALL:
            base_timeout = 1800.0
        else:
            base_timeout = 3600.0

        # For RunPod, cap timeout to platform limit minus safety buffer
        # This ensures graceful shutdown before RunPod kills the container
        if provider == Provider.RUNPOD:
            # Allow env var override for flexibility
            runpod_execution_timeout = int(
                os.getenv("RUNPOD_EXECUTION_TIMEOUT_SEC")
                or getattr(Config, "RUNPOD_EXECUTION_TIMEOUT_SEC", 1800)
            )
            runpod_buffer = int(
                os.getenv("RUNPOD_TIMEOUT_BUFFER_SEC")
                or getattr(Config, "RUNPOD_TIMEOUT_BUFFER_SEC", 120)
            )
            max_harness_timeout = float(runpod_execution_timeout - runpod_buffer)

            # Sanity check: warn if the timeout is too short for meaningful training
            min_useful_timeout = 300.0  # 5 minutes minimum
            if max_harness_timeout < min_useful_timeout:
                print(
                    f"[Trainer] WARNING: Harness timeout ({max_harness_timeout:.0f}s) is very short. "
                    f"Consider increasing RUNPOD_EXECUTION_TIMEOUT_SEC or reducing RUNPOD_TIMEOUT_BUFFER_SEC. "
                    f"Current: execution={runpod_execution_timeout}s, buffer={runpod_buffer}s"
                )

            if base_timeout > max_harness_timeout:
                print(
                    f"[Trainer] Capping harness timeout from {base_timeout:.0f}s to {max_harness_timeout:.0f}s "
                    f"(RunPod execution timeout: {runpod_execution_timeout}s, buffer: {runpod_buffer}s)"
                )
                return max_harness_timeout

        return base_timeout

    async def _run_remote_training(
        self,
        *,
        name: str,
        eval_type: str,
        task: BaseTask,
        code_path: str,
        candidate: Dict[str, Any],
        training_client: Any,
    ) -> Any:
        """Package a standalone harness and dispatch it to the remote executor."""

        with open(code_path, "r", encoding="utf-8") as handle:
            candidate_code = handle.read()

        dataset_spec = self._derive_dataset_spec(task=task, candidate=candidate)
        primary_metrics = self._resolve_primary_metrics(task)

        harness = task.build_remote_harness(
            candidate_code=candidate_code,
            dataset_spec=dataset_spec,
            eval_type=eval_type,
            primary_metrics=primary_metrics,
        )

        provider = getattr(training_client, "provider", Provider.TARGON)

        # Get validation buffer from config (default: 300s = 5 min)
        validation_buffer = float(
            getattr(Config, "HARNESS_VALIDATION_BUFFER_SEC", 300)
        )

        # Prefer explicit budget_tier from candidate; fall back to deriving from eval_type
        budget_tier = candidate.get("budget_tier")
        if not budget_tier and eval_type:
            budget_tier = eval_type.replace("_budget", "")  # "small_budget" -> "small"

        spec = TrainingJobSpec(
            metadata=TrainingJobMetadata(task=Config.TASK_NAME, eval_type=eval_type),
            dataset_spec=dataset_spec,
            model_code_content=harness,
            budget_tier=budget_tier,
            provider=provider,
            timeout_sec=self._resolve_timeout(budget_tier, provider=provider),
            validation_buffer_sec=validation_buffer,
        )

        dispatcher = getattr(training_client, "train", None) or getattr(
            training_client, "run_training", None
        )
        if dispatcher is None:
            raise AttributeError("training_client must expose a 'train' coroutine")

        return await dispatcher(spec)
