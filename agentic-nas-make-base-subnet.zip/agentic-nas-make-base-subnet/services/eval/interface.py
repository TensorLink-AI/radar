import asyncio
import os
from dataclasses import dataclass
from typing import Callable, Dict, Any, Optional

from services.config import Config
from core.tasks.contracts import BaseTask
from services.eval.errors import (
    _normalize_error_payload,
    build_shape_error,
    format_error_payload,
    is_timeout_error,
)
from services.eval.shape_sanity import shape_sanity_forward
from services.eval.trainer import Trainer
from services.providers.simple_agent import tool
from services.eval.remote_training.remote_types import Provider


def make_shape_check_tool(task: BaseTask, code_path: str) -> Callable:
    """
    Creates a tool that runs the shape sanity check on the candidate code.
    Used by CodeChecker and Debugger to verify fixes in-loop.

    Args:
        task: The task instance providing dataset/model loading utilities
        code_path: Path to the candidate code file to validate

    Returns:
        A tool function that can be passed to agents
    """
    @tool("Check for tensor shape mismatches and runtime errors")
    def check_shapes() -> str:
        """
        Runs a lightweight forward pass of the model to verify tensor shapes.
        Returns 'SUCCESS' or a detailed error report.
        """
        import torch

        if not os.path.exists(code_path):
            return f"Error: Code file not found at {code_path}"

        try:
            # Build datasets
            datasets = task.build_datasets({})
            device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

            # Build inputs for shape sanity check
            forward_inputs = task.build_shape_sanity_batch(datasets, device)

            # Load and run model
            model = task.load_model_for_shape_sanity(code_path, device, datasets)
            with torch.no_grad():
                shape_sanity_forward(model, code_path=code_path, **forward_inputs)

            return "SUCCESS: Model initialized and forward pass completed without shape errors."

        except Exception as exc:
            # Extract structured context if available (from shape_sanity.py)
            error_payload = getattr(exc, "shape_error_context", None)
            if error_payload:
                formatted = format_error_payload(error_payload)
                return f"SHAPE ERROR DETECTED:\n{formatted}"

            # Fallback for standard runtime errors
            return f"RUNTIME ERROR:\n{type(exc).__name__}: {str(exc)}"

    return check_shapes


@dataclass
class EvaluationArtifacts:
    """Container for evaluation outputs passed between services stages."""

    success: bool
    result: Dict[str, str]
    logs: str
    run_dir: str
    candidate_code_path: str
    eval_type: str
    error: Optional[Any] = None
    request_new_candidate: bool = False


async def evaluation(
    name: str,
    motivation: str,
    task: BaseTask,
    run_dir: str,
    eval_type: str,
    candidate: Dict[str, Any]
) -> EvaluationArtifacts:
    """Evaluate a candidate program and capture metrics/logs for downstream analysis."""

    artifacts = await run_training_with_retries(
        name=name,
        motivation=motivation,
        task=task,
        run_dir=run_dir,
        eval_type=eval_type,
        candidate=candidate,
    )

    if not artifacts.success:
        formatted_error = format_error_payload(artifacts.error)
        print(
            f"Evaluation failed for '{name}' after all attempts: {formatted_error}"
        )
        error_file_path = os.path.join(run_dir, "final_error.txt")
        with open(error_file_path, 'w', encoding='utf-8') as f:
            f.write(formatted_error or "Unknown error")
    else:
        print(f"Evaluation successful for '{name}'.")

    return artifacts


async def run_shape_sanity_check(
    candidate: Dict[str, Any], task: BaseTask
) -> tuple[bool, Dict[str, Any]]:
    """Run a lightweight forward pass to surface structural shape issues."""

    def _run_check() -> tuple[bool, Dict[str, Any]]:
        code_path = candidate.get("code_path")
        if not code_path or not os.path.exists(code_path):
            return False, build_shape_error(
                f"Candidate code path is invalid: {code_path}",
                context={"stage": "shape_sanity"},
            )

        try:
            datasets = task.build_datasets({})
        except Exception as exc:
            return False, build_shape_error(
                str(exc),
                context={"stage": "build_datasets"},
            )

        input_length = getattr(datasets, "input_length", None)
        forecast_length = getattr(datasets, "forecast_length", None)
        dataset_path = getattr(datasets, "dataset_path", None)
        config = {
            "input_length": input_length,
            "forecast_length": forecast_length,
            "dataset_path": dataset_path,
        }

        batch_shapes: Dict[str, Any] = {}
        try:
            import torch

            device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
            forward_inputs = task.build_shape_sanity_batch(datasets, device)
            batch_shapes = {
                key: list(value.shape)
                for key, value in forward_inputs.items()
                if isinstance(value, torch.Tensor)
            }

            model = task.load_model_for_shape_sanity(code_path, device, datasets)
            with torch.no_grad():
                shape_sanity_forward(model, code_path=code_path, **forward_inputs)
            return True, {"config": config, "shapes": batch_shapes}
        except Exception as exc:
            context = getattr(exc, "shape_error_context", {"stage": "shape_sanity_forward"})
            return False, build_shape_error(
                str(exc),
                config=config,
                shapes=batch_shapes or None,
                context=context,
            )

    return await asyncio.to_thread(_run_check)


async def run_training_with_retries(
    name: str,
    motivation: str,
    task: BaseTask,
    run_dir: str,
    eval_type: str,
    candidate: Dict[str, Any]
) -> EvaluationArtifacts:
    """Run training: shape check then train. No debugger — failures are returned immediately.

    The validator does not debug miner code; it fails the candidate.
    """

    trainer = Trainer()
    use_remote_training = getattr(Config, "USE_REMOTE_TRAINING", False)
    provider_name = os.getenv(
        "TRAINING_BACKEND",
        getattr(Config, "REMOTE_TRAINING_PROVIDER", Provider.TARGON.value),
    )
    try:
        selected_provider = Provider(provider_name)
    except Exception:
        selected_provider = Provider.TARGON
    training_client = None
    if use_remote_training:
        try:
            if selected_provider == Provider.RUNPOD:
                from services.eval.remote_training.client import RunpodTrainingClient

                training_client = RunpodTrainingClient()
            elif selected_provider == Provider.BASILICA:
                from services.eval.remote_training.client import BasilicaTrainingClient

                training_client = BasilicaTrainingClient()
            else:
                from services.eval.remote_training.client import TargonTrainingClient

                training_client = TargonTrainingClient()
        except Exception as exc:
            error_msg = (
                "Remote training is enabled, but the remote client failed to initialize: "
                f"{exc}"
            )
            return EvaluationArtifacts(
                success=False,
                result={"train": "", "test": ""},
                logs="",
                run_dir=run_dir,
                candidate_code_path=candidate.get("code_path", ""),
                eval_type=eval_type,
                error=error_msg,
            )
    aggregated_logs: list[str] = []

    # --- Shape sanity check ---
    print(f"Running shape sanity check for '{name}'...")
    shape_ok, shape_payload = await run_shape_sanity_check(candidate, task)
    if not shape_ok:
        normalized = _normalize_error_payload(shape_payload)
        formatted_error = format_error_payload(normalized)
        aggregated_logs.append(f"Shape sanity check failed: {formatted_error}")
        print(f"Shape sanity check failed for '{name}': {formatted_error}")
        return EvaluationArtifacts(
            success=False,
            result={"train": "", "test": ""},
            logs="\n\n".join(aggregated_logs),
            run_dir=run_dir,
            candidate_code_path=candidate.get("code_path", ""),
            eval_type=eval_type,
            error=formatted_error,
            request_new_candidate=True,
        )

    # --- Training (single attempt, no debugger) ---
    print(f"Starting training for '{name}'...")

    train_result = await trainer.run_remote(
        name=name,
        task=task,
        candidate=candidate,
        run_dir=run_dir,
        eval_type=eval_type,
        training_client=training_client,
    )

    logs = train_result.get("logs")
    if logs:
        aggregated_logs.append(f"Training logs:\n{logs}")

    if train_result.get("success"):
        print(f"Training successful for '{name}'.")
        return EvaluationArtifacts(
            success=True,
            result={
                "train": train_result.get("train_csv", ""),
                "test": train_result.get("test_csv", ""),
            },
            logs="\n\n".join(aggregated_logs),
            run_dir=run_dir,
            candidate_code_path=candidate.get("code_path", ""),
            eval_type=eval_type,
        )

    previous_error = _normalize_error_payload(
        train_result.get("error", "An unknown training error occurred.")
    )
    formatted_error = format_error_payload(previous_error)
    aggregated_logs.append(f"Error: {formatted_error}")
    print(f"Training failed for '{name}': {formatted_error}")

    # Check for timeout errors - these are infrastructure issues, not code bugs
    if is_timeout_error(previous_error):
        timeout_msg = f"Training timed out (not a code error): {formatted_error}"
        aggregated_logs.append(f"[Timeout] {timeout_msg}")
        print(f"Training timed out for '{name}'. This is an infrastructure issue.")
        return EvaluationArtifacts(
            success=False,
            result={"train": "", "test": ""},
            logs="\n\n".join(aggregated_logs),
            run_dir=run_dir,
            candidate_code_path=candidate.get("code_path", ""),
            eval_type=eval_type,
            error=timeout_msg,
            request_new_candidate=False,  # Don't blame the candidate
        )

    # Fail the candidate
    return EvaluationArtifacts(
        success=False,
        result={"train": "", "test": ""},
        logs="\n\n".join(aggregated_logs),
        run_dir=run_dir,
        candidate_code_path=candidate.get("code_path", ""),
        eval_type=eval_type,
        error=formatted_error,
        request_new_candidate=True,
    )
