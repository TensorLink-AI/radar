from __future__ import annotations

"""Utilities for capturing structured context around shape validation failures."""
import traceback
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Iterable, Optional

import torch
import torch.nn as nn
import torch.nn.functional as F


@dataclass
class ShapeOpContext:
    """Metadata for a single shape-affecting operation."""

    op: str
    module_path: Optional[str]
    input_shapes: Dict[str, Any]
    output_shapes: Optional[Dict[str, Any]] = None
    location: Optional[Dict[str, Any]] = None
    code_snippet: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        payload: Dict[str, Any] = {
            "op": self.op,
            "module_path": self.module_path,
            "input_shapes": self.input_shapes,
        }
        if self.output_shapes:
            payload["output_shapes"] = self.output_shapes
        if self.location:
            payload["location"] = self.location
        if self.code_snippet:
            payload["code_snippet"] = self.code_snippet
        return payload


class ShapeOpRecorder:
    """Context manager that records shape contexts for high-risk operations.

    By default, a broad set of Tensor methods and ``torch.nn.functional``
    helpers that change tensor shapes are patched. Callers can supply
    ``extra_patch_targets`` to record additional operations without editing the
    recorder itself.
    """

    _DEFAULT_TENSOR_METHODS = [
        "view",
        "reshape",
        "flatten",
        "transpose",
        "permute",
        "squeeze",
        "unsqueeze",
        "expand",
        "expand_as",
        "broadcast_to",
        "mm",
        "matmul",
        "bmm",
        "add",
        "__add__",
        "__radd__",
    ]
    _DEFAULT_TORCH_FUNCS = [
        "reshape",
        "flatten",
        "stack",
        "cat",
        "add",
        "einsum",
        "mm",
        "matmul",
        "bmm",
        "addmm",
        "zeros",
        "ones",
        "broadcast_to",
    ]
    _DEFAULT_FUNCTIONAL_FUNCS = [
        "linear",
        *[f"conv{dim}d" for dim in (1, 2, 3)],
        *[f"conv_transpose{dim}d" for dim in (1, 2, 3)],
    ]

    def __init__(
        self,
        model: nn.Module,
        *,
        code_path: Optional[str] = None,
        extra_patch_targets: Optional[Iterable[tuple[str, Any, str]]] = None,
    ) -> None:
        self.model = model
        self.code_path = Path(code_path).resolve() if code_path else None
        self.module_names: Dict[int, str] = {}
        self._hooks: list[Any] = []
        self._originals: Dict[str, Any] = {}
        self._current_module: Optional[str] = None
        self._patch_targets = self._build_patch_targets(extra_patch_targets)
        self.last_op: Optional[ShapeOpContext] = None

    def __enter__(self) -> "ShapeOpRecorder":
        self._capture_module_names()
        self._register_hooks()
        self._patch_ops()
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        for handle in self._hooks:
            handle.remove()
        self._restore_ops()

    def _capture_module_names(self) -> None:
        self.module_names = {id(self.model): "<root>"}
        self.module_names.update({id(mod): name or "<root>" for name, mod in self.model.named_modules()})

    def _register_hooks(self) -> None:
        seen = set()

        def _on_pre_forward(mod: nn.Module, args: tuple[Any, ...], kwargs: Dict[str, Any]) -> None:
            if id(mod) in self.module_names:
                self._current_module = self.module_names[id(mod)]
            else:
                self._current_module = mod.__class__.__name__

        for mod in self.model.modules():
            if id(mod) in seen:
                continue
            seen.add(id(mod))
            self._hooks.append(mod.register_forward_pre_hook(_on_pre_forward, with_kwargs=True))

    def _patch_ops(self) -> None:
        for name, (target, attr) in self._patch_targets.items():
            original = getattr(target, attr, None)
            if original is None:
                continue
            self._originals[name] = original
            setattr(target, attr, self._wrap_op(name, original))

    def _restore_ops(self) -> None:
        for name, original in self._originals.items():
            target, attr = self._patch_targets[name]
            setattr(target, attr, original)

    def _shape_map_from_args(self, args: Iterable[Any], kwargs: Dict[str, Any]) -> Dict[str, Any]:
        shapes: Dict[str, Any] = {}

        def _assign(key: str, value: Any) -> None:
            if isinstance(value, torch.Tensor):
                shapes[key] = list(value.shape)

        for idx, arg in enumerate(args):
            _assign(f"arg{idx}", arg)
        for key, value in kwargs.items():
            _assign(str(key), value)

        return shapes

    def _shape_map_from_output(self, output: Any) -> Dict[str, Any]:
        if isinstance(output, torch.Tensor):
            return {"output": list(output.shape)}
        if isinstance(output, (list, tuple)):
            result: Dict[str, Any] = {}
            for idx, value in enumerate(output):
                if isinstance(value, torch.Tensor):
                    result[f"item{idx}"] = list(value.shape)
            return result
        if isinstance(output, dict):
            return {k: list(v.shape) for k, v in output.items() if isinstance(v, torch.Tensor)}
        return {}

    def _extract_location(
        self, exc: Exception
    ) -> tuple[Optional[str], Optional[int], Optional[str]]:
        tb = traceback.extract_tb(exc.__traceback__)
        candidate_dir = str(self.code_path.parent) if self.code_path else None
        selected_frame = None

        for frame in reversed(tb):
            try:
                frame_path = Path(frame.filename).resolve()
                if candidate_dir and str(frame_path).startswith(candidate_dir):
                    selected_frame = frame
                    break
            except Exception:
                continue

        if selected_frame is None and tb:
            selected_frame = tb[-1]

        if selected_frame:
            return selected_frame.filename, selected_frame.lineno, selected_frame.name
        return None, None, None

    def _build_location_payload(
        self, filename: Optional[str], lineno: Optional[int], function: Optional[str]
    ) -> Optional[Dict[str, Any]]:
        if not any((filename, lineno, function)):
            return None

        payload: Dict[str, Any] = {}
        if filename:
            payload["file"] = filename
        if lineno:
            payload["line"] = lineno
        if function:
            payload["function"] = function
        return payload

    def _read_snippet(self, filename: str, lineno: int, *, radius: int = 2) -> Optional[str]:
        try:
            path = Path(filename)
            if not path.exists():
                return None
            lines = path.read_text().splitlines()
            start = max(lineno - radius - 1, 0)
            end = min(lineno + radius, len(lines))
            snippet = "\n".join(lines[start:end])
            return snippet if snippet else None
        except Exception:
            return None

    def _wrap_op(self, op_name: str, fn):  # type: ignore[no-untyped-def]
        def wrapper(*args, **kwargs):  # type: ignore[no-untyped-def]
            input_shapes = self._shape_map_from_args(args, kwargs)
            try:
                output = fn(*args, **kwargs)
            except Exception as exc:
                location_file, location_line, location_name = self._extract_location(exc)
                snippet = (
                    self._read_snippet(location_file, location_line)
                    if location_file and location_line
                    else None
                )
                ctx = ShapeOpContext(
                    op=op_name,
                    module_path=self._current_module,
                    input_shapes=input_shapes,
                    output_shapes=None,
                    location=self._build_location_payload(
                        location_file, location_line, location_name
                    ),
                    code_snippet=snippet,
                )
                self.last_op = ctx
                setattr(exc, "shape_error_context", self.build_context(ctx))
                raise

            ctx = ShapeOpContext(
                op=op_name,
                module_path=self._current_module,
                input_shapes=input_shapes,
                output_shapes=self._shape_map_from_output(output),
            )
            self.last_op = ctx
            return output

        return wrapper

    def build_context(self, ctx: Optional[ShapeOpContext] = None) -> Dict[str, Any]:
        context: Dict[str, Any] = {"stage": "shape_sanity_forward"}
        op_ctx = ctx or self.last_op
        if op_ctx:
            if op_ctx.op:
                context["failed_op_name"] = op_ctx.op
            context["operation"] = op_ctx.to_dict()
        return context

    def _build_patch_targets(
        self, extra_patch_targets: Optional[Iterable[tuple[str, Any, str]]]
    ) -> Dict[str, tuple[Any, str]]:
        patch_targets: Dict[str, tuple[Any, str]] = {}

        for method in self._DEFAULT_TENSOR_METHODS:
            patch_targets[f"tensor.{method}"] = (torch.Tensor, method)

        for fn in self._DEFAULT_TORCH_FUNCS:
            patch_targets[f"torch.{fn}"] = (torch, fn)

        for fn in self._DEFAULT_FUNCTIONAL_FUNCS:
            patch_targets[f"nn.functional.{fn}"] = (F, fn)

        if extra_patch_targets:
            for name, target, attr in extra_patch_targets:
                patch_targets[name] = (target, attr)

        return patch_targets


def shape_sanity_forward(
    model: nn.Module, *, code_path: Optional[str], **model_inputs: Any
) -> Any:
    """Run a model forward pass with instrumentation for shape-affecting ops."""

    with ShapeOpRecorder(model, code_path=code_path) as recorder:
        try:
            return model(**model_inputs)
        except Exception as exc:
            if not hasattr(exc, "shape_error_context"):
                location_file, location_line, location_name = recorder._extract_location(exc)
                snippet = (
                    recorder._read_snippet(location_file, location_line)
                    if location_file and location_line
                    else None
                )
                fallback_op = (
                    location_name
                    or (recorder.last_op.op if recorder.last_op else None)
                    or exc.__class__.__name__
                )
                module_path = (
                    recorder.last_op.module_path
                    if recorder.last_op
                    else recorder._current_module
                )
                input_shapes = (
                    recorder.last_op.input_shapes if recorder.last_op else {}
                )
                ctx = ShapeOpContext(
                    op=fallback_op,
                    module_path=module_path,
                    input_shapes=input_shapes,
                    output_shapes=None,
                    location=recorder._build_location_payload(
                        location_file, location_line, location_name
                    ),
                    code_snippet=snippet,
                )
                setattr(exc, "shape_error_context", recorder.build_context(ctx))
            raise
