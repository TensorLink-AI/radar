from __future__ import annotations

"""Shared helpers for structured evaluation error reporting."""

import json
from dataclasses import dataclass
from typing import Any, Dict, Optional


@dataclass
class ShapeError:
    """Normalized schema for reporting shape-related failures."""

    message: str
    config: Optional[Dict[str, Any]] = None
    shapes: Optional[Dict[str, Any]] = None
    context: Optional[Dict[str, Any]] = None
    type: str = "shape_error"

    def to_dict(self) -> Dict[str, Any]:
        payload: Dict[str, Any] = {"type": self.type, "message": self.message}
        if self.config:
            payload["config"] = self.config
        if self.shapes:
            payload["shapes"] = self.shapes
        if self.context:
            payload["context"] = self.context
        return payload


STRUCTURAL_ERROR_PATTERNS = [
    # Matrix multiplication errors
    "mat1 and mat2 shapes cannot be multiplied",
    "size of tensor a must match tensor b",
    "the size of tensor a",
    # General shape errors
    "shape mismatch",
    "dimension mismatch",
    "invalid shape",
    "shape .* is invalid for input of size",
    # Einsum and broadcasting
    "einsum",
    "does not broadcast",
    "subscript .* has size .* which does not broadcast",
    # View/reshape errors
    "view size is not compatible",
    "cannot reshape tensor",
    # Index errors (often from wrong sequence handling)
    "index out of range",
    "index .* is out of bounds",
]

TIMEOUT_ERROR_PATTERNS = [
    "timed out",
    "timed_out",
    "executiontimeout",
    "execution timeout",
    "polling timed out",
    "client error.*timeout",
    "executor error.*timeout",
    "job timed out",
    "runpod platform error.*timeout",
]


def build_shape_error(
    message: str,
    *,
    config: Dict[str, Any] | None = None,
    shapes: Dict[str, Any] | None = None,
    context: Dict[str, Any] | None = None,
) -> ShapeError:
    """Return a normalized payload for reporting structural shape issues."""

    return ShapeError(message=message, config=config, shapes=shapes, context=context)


def _normalize_error_payload(error: Any) -> Any:
    return error.to_dict() if isinstance(error, ShapeError) else error


def extract_error_message(error: Any) -> str:
    """Return a string representation of any error payload."""

    normalized = _normalize_error_payload(error)
    if isinstance(normalized, dict):
        return str(normalized.get("message") or json.dumps(normalized, indent=2))
    if isinstance(error, ShapeError):
        return error.message
    return str(error or "")


def format_error_payload(error: Any) -> str:
    """Serialize an error payload for logs or prompts."""

    normalized = _normalize_error_payload(error)
    if isinstance(normalized, dict):
        try:
            return json.dumps(normalized, indent=2)
        except Exception:  # pragma: no cover - defensive serialization
            return str(normalized)
    return str(normalized or "")


def is_structural_shape_error(error: Any) -> bool:
    """Detect structural shape errors based on schema or known patterns."""
    import re

    if isinstance(error, ShapeError):
        return True
    if isinstance(error, dict) and error.get("type") == "shape_error":
        return True
    message = extract_error_message(error).lower()
    for pattern in STRUCTURAL_ERROR_PATTERNS:
        if ".*" in pattern:
            # Use regex for patterns with wildcards
            if re.search(pattern, message):
                return True
        else:
            # Simple substring match
            if pattern in message:
                return True
    return False


def is_timeout_error(error: Any) -> bool:
    """Detect timeout errors that should not trigger debugging.

    Timeout errors indicate infrastructure/resource constraints, not code bugs.
    When a timeout occurs, the candidate code should not be modified.
    """
    import re

    message = extract_error_message(error).lower()
    for pattern in TIMEOUT_ERROR_PATTERNS:
        if ".*" in pattern:
            # Use regex for patterns with wildcards
            if re.search(pattern, message):
                return True
        else:
            # Simple substring match
            if pattern in message:
                return True
    return False
