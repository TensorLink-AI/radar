"""Backwards-compatible re-export of remote training types.

The canonical definitions now live in :mod:`services.eval.remote_training.remote_types`
so deployment code stays colocated with runtime entrypoints.
"""

from services.eval.remote_training.remote_types import *  # noqa: F401,F403
