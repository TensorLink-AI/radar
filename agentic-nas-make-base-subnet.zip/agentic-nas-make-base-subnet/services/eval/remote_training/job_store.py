"""Shared helpers for persisting remote training job state."""

from __future__ import annotations

import json
import math
import os
import time
from typing import Any, Optional

# Ensure .env is loaded even when this module is imported outside services_v2
try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass

class JobStore:
    """Durable state manager backed by an S3-compatible object store."""

    def __init__(
        self,
        *,
        endpoint_url: str,
        access_key: str,
        secret_key: str,
        bucket: str,
        prefix: str,
    ) -> None:
        import boto3
        from botocore.config import Config

        self.bucket = bucket
        self.prefix = prefix
        self.client = boto3.client(
            "s3",
            endpoint_url=endpoint_url,
            aws_access_key_id=access_key,
            aws_secret_access_key=secret_key,
            config=Config(signature_version="s3v4"),
            region_name="auto",
        )

    def _object_key(self, job_id: str) -> str:
        # Store a single JSON per job_id
        return f"{self.prefix}{job_id}.json"

    @staticmethod
    def _sanitize_floats(obj: Any) -> Any:
        """Replace NaN/Infinity floats with None for JSON compliance."""
        if isinstance(obj, float):
            if math.isnan(obj) or math.isinf(obj):
                return None
            return obj
        if isinstance(obj, dict):
            return {k: JobStore._sanitize_floats(v) for k, v in obj.items()}
        if isinstance(obj, (list, tuple)):
            return [JobStore._sanitize_floats(v) for v in obj]
        return obj

    def write_state(self, job_id: str, data: dict[str, Any]) -> dict[str, Any]:
        payload = {"job_id": job_id, "updated_at": time.time(), **data}
        payload = self._sanitize_floats(payload)
        self.client.put_object(
            Bucket=self.bucket,
            Key=self._object_key(job_id),
            Body=json.dumps(payload, ensure_ascii=False).encode("utf-8"),
            ContentType="application/json",
        )
        return payload

    def read_state(self, job_id: str) -> Optional[dict[str, Any]]:
        from botocore.exceptions import ClientError

        try:
            obj = self.client.get_object(Bucket=self.bucket, Key=self._object_key(job_id))
        except ClientError as exc:  # pragma: no cover - network path
            code = (exc.response or {}).get("Error", {}).get("Code")
            if code in {"NoSuchKey", "NoSuchEntity", "404"}:
                return None
            raise

        try:
            payload = obj["Body"].read()
        except Exception:
            return None

        try:
            data = json.loads(payload)
        except Exception:
            return None

        if isinstance(data, dict):
            return data
        return None


def build_job_store_from_env(*, required: bool = True) -> Optional[JobStore]:
    """Instantiate a :class:`JobStore` using R2-compatible environment variables."""

    endpoint_url = os.getenv("R2_ENDPOINT_URL")
    access_key = os.getenv("R2_ACCESS_KEY_ID")
    secret_key = os.getenv("R2_SECRET_ACCESS_KEY")
    bucket = os.getenv("R2_BUCKET")
    prefix = os.getenv("R2_PREFIX", "training_jobs/")

    missing = [
        name
        for name, value in {
            "R2_ENDPOINT_URL": endpoint_url,
            "R2_ACCESS_KEY_ID": access_key,
            "R2_SECRET_ACCESS_KEY": secret_key,
            "R2_BUCKET": bucket,
        }.items()
        if not value
    ]
    if missing:
        if required:
            raise RuntimeError(f"Missing required R2 configuration: {', '.join(sorted(missing))}")
        return None

    return JobStore(
        endpoint_url=endpoint_url,  # type: ignore[arg-type]
        access_key=access_key,  # type: ignore[arg-type]
        secret_key=secret_key,  # type: ignore[arg-type]
        bucket=bucket,  # type: ignore[arg-type]
        prefix=prefix,
    )


__all__ = ["JobStore", "build_job_store_from_env"]
