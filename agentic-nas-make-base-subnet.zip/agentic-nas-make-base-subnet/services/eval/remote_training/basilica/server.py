"""
Basilica/Affinetes Training Server.

This FastAPI server runs inside the Basilica container and handles training
requests via HTTP. It's the container-side component of the Basilica integration.

Endpoints:
- GET /health: Health check
- POST /train: Execute a single training job
- POST /train-batch: Train N candidates concurrently on one GPU via CUDA streams
- POST /proxy-eval-batch: Run AZNAS zero-cost proxy evaluation on N candidates
"""

from __future__ import annotations

import math
import os
import shutil
import subprocess
import tempfile
import time
import traceback
import uuid
from dataclasses import asdict
from typing import Any, Dict, List, Optional

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel

from services.eval.remote_training.job_store import build_job_store_from_env
from services.eval.remote_training.remote_types import (
    BudgetTier,
    Provider,
    TrainingResult,
    TrainingStatus,
    build_training_job_spec,
    coerce_budget_tier,
    sanitize_for_json,
)
from services.eval.remote_training.targon_app.runner import (
    run_batch_training,
    run_large_budget_training,
    run_small_budget_training,
)

app = FastAPI(title="Agentic-NAS Basilica Training Server")

# ---------------------------------------------------------------------------
# CUDA version detection (cached at module level)
# ---------------------------------------------------------------------------

def _detect_cuda_versions() -> Dict[str, Any]:
    """Detect CUDA toolkit and PyTorch CUDA versions for diagnostics."""
    info: Dict[str, Any] = {}

    # Container-level CUDA toolkit version (from nvidia/cuda base image)
    nvcc = shutil.which("nvcc")
    if nvcc:
        try:
            out = subprocess.check_output(
                [nvcc, "--version"], text=True, timeout=5
            )
            for line in out.splitlines():
                if "release" in line.lower():
                    # e.g. "Cuda compilation tools, release 12.4, V12.4.131"
                    parts = line.split("release")[-1].strip().rstrip(".")
                    info["cuda_toolkit"] = parts.split(",")[0].strip()
                    break
        except Exception:
            pass

    # PyTorch CUDA version
    try:
        import torch
        info["torch_version"] = torch.__version__
        info["torch_cuda_version"] = torch.version.cuda or "none"
        info["cuda_available"] = torch.cuda.is_available()
        if torch.cuda.is_available():
            info["cuda_device"] = torch.cuda.get_device_name(0)
            info["gpu_compute_capability"] = (
                f"{torch.cuda.get_device_properties(0).major}."
                f"{torch.cuda.get_device_properties(0).minor}"
            )
    except Exception as exc:
        info["torch_error"] = str(exc)

    return info


_CUDA_INFO: Dict[str, Any] | None = None


def _get_cuda_info() -> Dict[str, Any]:
    """Return cached CUDA version info (computed once)."""
    global _CUDA_INFO
    if _CUDA_INFO is None:
        _CUDA_INFO = _detect_cuda_versions()
    return _CUDA_INFO


# Global job store (lazy initialized)
_JOB_STORE = None
_JOB_STORE_INITIALIZED = False


def _get_job_store():
    global _JOB_STORE, _JOB_STORE_INITIALIZED
    if not _JOB_STORE_INITIALIZED:
        _JOB_STORE = build_job_store_from_env(required=False)
        _JOB_STORE_INITIALIZED = True
        if _JOB_STORE is None:
            print(
                "[Basilica Server] R2 job store is NOT configured. "
                "Training state will not be persisted to R2. "
                "Ensure R2_ENDPOINT_URL, R2_ACCESS_KEY_ID, R2_SECRET_ACCESS_KEY, "
                "and R2_BUCKET are set in the container environment."
            )
        else:
            bucket = os.getenv("R2_BUCKET", "?")
            prefix = os.getenv("R2_PREFIX", "training_jobs/")
            print(f"[Basilica Server] R2 job store configured: bucket={bucket}, prefix={prefix}")
    return _JOB_STORE


def _write_state(job_id: str, payload: dict) -> None:
    """Write job state to R2 store if available."""
    store = _get_job_store()
    if store is None:
        return
    try:
        store.write_state(job_id, payload)
    except Exception as exc:
        print(f"[Basilica Server] WARNING: Failed to write state for job {job_id} to R2: {exc}")


def _result_to_dict(result: TrainingResult) -> Dict[str, Any]:
    """Convert TrainingResult to serializable dictionary."""
    data = asdict(result)
    if hasattr(result.status, "value"):
        data["status"] = result.status.value
    if hasattr(result.budget_tier, "value"):
        data["budget_tier"] = result.budget_tier.value
    data.setdefault("provider", Provider.BASILICA.value)
    return sanitize_for_json(data)


class TrainingRequest(BaseModel):
    """Request model for training endpoint."""
    metadata: Optional[Dict[str, Any]] = None
    dataset_spec: Optional[Dict[str, Any]] = None
    model_code_content: str
    job_id: Optional[str] = None
    budget_tier: Optional[str] = None
    timeout_sec: Optional[float] = None
    validation_buffer_sec: Optional[float] = None


class BatchTrainingRequest(BaseModel):
    """Request model for concurrent multi-model training on a single GPU.

    Instead of ``model_code_content`` (singular), this accepts
    ``model_codes`` (a list of N candidate source strings).  The server
    generates a concurrent harness that trains all N models via CUDA
    streams round-robin on the pod's GPU.
    """
    metadata: Optional[Dict[str, Any]] = None
    dataset_spec: Optional[Dict[str, Any]] = None
    model_codes: list[str]
    job_id: Optional[str] = None
    budget_tier: Optional[str] = None
    timeout_sec: Optional[float] = None
    validation_buffer_sec: Optional[float] = None
    sync_frequency: int = 10
    log_frequency: int = 100


class BatchProxyEvalRequest(BaseModel):
    """Request model for batch AZNAS zero-cost proxy evaluation.

    Accepts a list of candidate model source codes and evaluates all
    of them using signal-aware architecture-agnostic proxies
    (expressivity, grad-saliency, sensitivity, collapse ratio,
    gradient coherence, state velocity, local contrast).

    Each candidate is loaded, validated (FX shape propagation), and
    scored without any training.  Results include per-candidate proxy
    metrics, parameter counts, and inference latency measurements.
    """
    model_codes: list[str]
    input_length: int = 512
    forecast_length: int = 256
    batch_size: int = 4
    num_variants: int = 7
    max_params: Optional[int] = None
    max_inference_latency_ms: Optional[float] = None


@app.get("/")
@app.head("/")
async def root():
    """Root endpoint for Kubernetes / Basilica infrastructure health probes.

    Basilica's reverse proxy sends ``HEAD /`` to determine if the container
    is ready to receive traffic.  Returning 200 here ensures the pod is
    marked healthy and external requests (e.g. ``POST /train``) are routed
    to this container.
    """
    return {"ok": True}


@app.get("/health")
async def health():
    """Health check endpoint with CUDA and environment diagnostics.

    This must stay cheap (no network calls, no R2 connections) so that
    infrastructure probes never time out or flap.
    """
    # Check R2 readiness via env vars only – no actual connection attempt.
    r2_vars = ("R2_ENDPOINT_URL", "R2_ACCESS_KEY_ID", "R2_SECRET_ACCESS_KEY", "R2_BUCKET")
    r2_configured = all(k in os.environ for k in r2_vars)

    return {
        "ok": True,
        "ts": time.time(),
        "provider": "basilica",
        "cuda": _get_cuda_info(),
        "r2_configured": r2_configured,
        "r2_prefix": os.getenv("R2_PREFIX", "training_jobs/"),
    }


@app.post("/train")
async def train(request: TrainingRequest):
    """Execute a training job."""
    spec_dict = request.model_dump()
    spec_dict["metadata"] = spec_dict.get("metadata") or {"task": "unknown", "eval_type": "unknown"}
    spec_dict["dataset_spec"] = spec_dict.get("dataset_spec") or {}
    spec_dict["job_id"] = spec_dict.get("job_id") or uuid.uuid4().hex
    spec_dict["provider"] = Provider.BASILICA.value

    try:
        spec_obj = build_training_job_spec(spec_dict)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

    job_id = spec_obj.job_id
    tier = coerce_budget_tier(spec_obj.budget_tier) or BudgetTier.SMALL

    # Write initial running state
    _write_state(job_id, {
        "status": "running",
        "provider": Provider.BASILICA.value,
        "tier": tier.value,
    })

    try:
        # Execute training using the shared runner
        if tier == BudgetTier.LARGE:
            result = await run_large_budget_training(spec_obj)
        else:
            result = await run_small_budget_training(spec_obj)

        result_dict = _result_to_dict(result)

        # Write completion state
        _write_state(job_id, {
            "status": "finished",
            "provider": Provider.BASILICA.value,
            "tier": tier.value,
            "result": result_dict,
        })

        return {"job_id": job_id, **result_dict}

    except Exception as exc:
        tb = traceback.format_exc()
        _write_state(job_id, {
            "status": "failed",
            "provider": Provider.BASILICA.value,
            "tier": tier.value if tier else "unknown",
            "error": repr(exc),
            "traceback": tb,
        })
        raise HTTPException(status_code=500, detail=str(exc))


@app.post("/train-batch")
async def train_batch(request: BatchTrainingRequest):
    """Train N candidates concurrently on one GPU using CUDA streams.

    The server generates a concurrent harness script
    (``services.packager_concurrent``) that loads all candidate models
    and trains them via round-robin CUDA stream scheduling.

    Returns a list of per-model results in the same order as
    ``request.model_codes``.
    """
    if not request.model_codes:
        raise HTTPException(status_code=400, detail="model_codes must be a non-empty list")

    job_id = request.job_id or uuid.uuid4().hex
    tier = coerce_budget_tier(request.budget_tier) or BudgetTier.SMALL
    n_models = len(request.model_codes)

    _write_state(job_id, {
        "status": "running",
        "provider": Provider.BASILICA.value,
        "tier": tier.value,
        "mode": "batch",
        "num_models": n_models,
    })

    try:
        result = await run_batch_training(
            model_codes=request.model_codes,
            metadata=request.metadata or {"task": "unknown", "eval_type": "unknown"},
            budget_tier=tier,
            timeout_sec=request.timeout_sec,
            validation_buffer_sec=request.validation_buffer_sec,
            sync_frequency=request.sync_frequency,
            log_frequency=request.log_frequency,
        )

        result_dict = _result_to_dict(result)

        _write_state(job_id, {
            "status": "finished",
            "provider": Provider.BASILICA.value,
            "tier": tier.value,
            "mode": "batch",
            "num_models": n_models,
            "result": result_dict,
        })

        return {"job_id": job_id, **result_dict}

    except Exception as exc:
        tb = traceback.format_exc()
        _write_state(job_id, {
            "status": "failed",
            "provider": Provider.BASILICA.value,
            "tier": tier.value,
            "mode": "batch",
            "num_models": n_models,
            "error": repr(exc),
            "traceback": tb,
        })
        raise HTTPException(status_code=500, detail=str(exc))


# ---------------------------------------------------------------------------
# Batch proxy evaluation (AZNAS zero-cost proxies)
# ---------------------------------------------------------------------------


def _eval_single_candidate(
    code: str,
    index: int,
    input_length: int,
    forecast_length: int,
    batch_size: int,
    num_variants: int,
    device: "torch.device",
    max_params: Optional[int],
    max_inference_latency_ms: Optional[float],
) -> Dict[str, Any]:
    """Evaluate a single candidate model with AZNAS proxies.

    Runs inside the pod process.  Loads the model from source code,
    runs FX shape validation, measures param count and latency, then
    computes all signal-aware proxy metrics.

    Returns a dict with proxy metrics, constraint info, and status.
    """
    import torch
    from core.training.universal_evaluator import (
        count_parameters,
        measure_inference_latency,
    )
    from tasks.ts_foundation.model_base import load_candidate_model
    from tasks.ts_foundation.zero_cost_proxies import evaluate_candidate

    fd, tmp_path = tempfile.mkstemp(suffix=".py", prefix=f"proxy_eval_{index}_")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            f.write(code)

        # Load + FX shape validation
        model = load_candidate_model(
            tmp_path, device,
            input_length=input_length,
            forecast_length=forecast_length,
        )

        param_count = count_parameters(model, trainable_only=True)

        # Inference latency
        sample_batch = {
            "past_y": torch.zeros((1, input_length, 1), device=device),
            "y_future_tf": torch.zeros((1, forecast_length, 1), device=device),
            "forecast_length": forecast_length,
            "input_length": input_length,
        }
        latency_ms = measure_inference_latency(
            model, sample_batch, device,
            warmup_iters=2,
            measure_iters=5,
        )

        # Weight L2 norm
        weight_sq = sum(
            float(torch.sum(p.detach().float() ** 2).item())
            for p in model.parameters() if p.requires_grad
        )
        weight_l2 = math.sqrt(max(weight_sq, 0.0))

        # Training style
        training_style = getattr(model, "training_style", None)
        training_style_str = str(training_style) if training_style is not None else None

        # AZNAS proxy evaluation
        proxy = evaluate_candidate(
            model,
            input_length=input_length,
            forecast_length=forecast_length,
            batch_size=batch_size,
            num_variants=num_variants,
            device=device,
            name=f"candidate_{index}",
        )

        # Check hard constraints
        constraints_satisfied = True
        if max_params is not None and param_count > max_params:
            constraints_satisfied = False
        if max_inference_latency_ms is not None and latency_ms > max_inference_latency_ms:
            constraints_satisfied = False

        return {
            **proxy.to_dict(),
            "index": index,
            "status": "ok",
            "shape_valid": True,
            "param_count": param_count,
            "inference_latency_ms": latency_ms,
            "weight_l2_norm": weight_l2,
            "training_style": training_style_str,
            "constraints_satisfied": constraints_satisfied,
            "proxy_status": proxy.status,
        }
    except Exception as exc:
        return {
            "index": index,
            "status": "error",
            "error": str(exc),
            "shape_valid": False,
            "param_count": 0,
            "inference_latency_ms": 0.0,
            "weight_l2_norm": 0.0,
            "training_style": None,
            "constraints_satisfied": False,
            "proxy_status": "FAIL",
        }
    finally:
        try:
            os.unlink(tmp_path)
        except OSError:
            pass


@app.post("/proxy-eval-batch")
async def proxy_eval_batch(request: BatchProxyEvalRequest):
    """Run AZNAS zero-cost proxy evaluation on N candidates in a single pod.

    Each candidate is loaded from source, validated via FX shape
    propagation, and scored using 7 architecture-agnostic proxies.
    No training occurs -- this is purely a screening step.

    The response contains a list of per-candidate result dicts in the
    same order as ``request.model_codes``.  Each dict includes all
    proxy metrics from ``ProxyResult.to_dict()`` plus param count,
    inference latency, and constraint satisfaction.
    """
    if not request.model_codes:
        raise HTTPException(
            status_code=400,
            detail="model_codes must be a non-empty list",
        )

    import asyncio
    import torch

    n_models = len(request.model_codes)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    print(
        f"[Basilica] Proxy eval batch: {n_models} candidates "
        f"(device={device}, variants={request.num_variants})"
    )
    t0 = time.time()

    # Run each candidate evaluation sequentially to avoid GPU OOM.
    # Each eval is fast (~2-10s) so serial execution is fine for
    # typical batch sizes (16-64 candidates).
    def _run_all() -> List[Dict[str, Any]]:
        results = []
        for i, code in enumerate(request.model_codes):
            result = _eval_single_candidate(
                code=code,
                index=i,
                input_length=request.input_length,
                forecast_length=request.forecast_length,
                batch_size=request.batch_size,
                num_variants=request.num_variants,
                device=device,
                max_params=request.max_params,
                max_inference_latency_ms=request.max_inference_latency_ms,
            )
            results.append(result)
            status = result.get("status", "?")
            params = result.get("param_count", 0)
            print(
                f"[Basilica] Proxy eval {i+1}/{n_models}: "
                f"status={status} params={params}"
            )
        return results

    results = await asyncio.to_thread(_run_all)
    elapsed = time.time() - t0

    n_ok = sum(1 for r in results if r.get("status") == "ok")
    print(
        f"[Basilica] Proxy eval batch complete: {n_ok}/{n_models} "
        f"passed in {elapsed:.1f}s"
    )

    return sanitize_for_json({
        "results": results,
        "num_models": n_models,
        "num_passed": n_ok,
        "wall_time_sec": elapsed,
        "device": str(device),
    })
