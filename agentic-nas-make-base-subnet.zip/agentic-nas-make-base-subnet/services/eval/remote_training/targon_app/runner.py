"""Generic executor that runs standalone harness scripts.

Supports both single-model execution (``run_small_budget_training``,
``run_large_budget_training``) and concurrent multi-model execution
(``run_batch_training``) via CUDA streams.
"""

from __future__ import annotations

import asyncio
import json
import os
import tempfile
import time
import uuid
from typing import Any, Dict, List, Optional

from services.eval.remote_training.remote_types import (
    BudgetTier,
    TrainingJobSpec,
    TrainingJobMetadata,
    TrainingResult,
    TrainingStatus,
)


async def _execute_training(spec: TrainingJobSpec, timeout_sec: int = 3600) -> TrainingResult:
    """Execute a bundled harness script in isolation."""

    start_time = time.time()
    metrics: Dict[str, Any] = {}
    stdout_tail = ""
    status = TrainingStatus.FAILED

    with tempfile.TemporaryDirectory(prefix="targon-exec-") as temp_run_dir:
        script_path = os.path.join(temp_run_dir, "harness.py")
        results_path = os.path.join(temp_run_dir, "results.json")

        with open(script_path, "w", encoding="utf-8") as handle:
            handle.write(spec.model_code_content)

        harness_timeout = float(spec.timeout_sec) if spec.timeout_sec else timeout_sec
        # Default validation buffer: 300s (5 min) to ensure final validation always runs
        validation_buffer = float(spec.validation_buffer_sec) if spec.validation_buffer_sec else 300.0

        # External process timeout: the harness is given harness_timeout seconds total.
        # The validation_buffer is time reserved INSIDE harness_timeout for final validation
        # (training stops early to leave time for validation), so we should NOT add it again.
        # Just add a small margin (60s) for graceful shutdown and result flushing.
        process_timeout = harness_timeout + 60.0

        try:
            process = await asyncio.create_subprocess_exec(
                "python",
                script_path,
                "--run-dir",
                temp_run_dir,
                "--timeout-sec",
                str(harness_timeout),
                "--validation-buffer-sec",
                str(validation_buffer),
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )

            try:
                stdout_bytes, stderr_bytes = await asyncio.wait_for(
                    process.communicate(), timeout=process_timeout
                )
                combined_output = (stdout_bytes or b"") + (stderr_bytes or b"")
                stdout_tail = combined_output.decode(errors="replace")[-2000:]

                status = (
                    TrainingStatus.SUCCEEDED
                    if process.returncode == 0
                    else TrainingStatus.FAILED
                )
            except asyncio.TimeoutError:
                # Send SIGTERM first to allow graceful shutdown
                process.terminate()
                try:
                    # Give process up to 10 seconds to flush results and exit
                    stdout_bytes, stderr_bytes = await asyncio.wait_for(
                        process.communicate(), timeout=10.0
                    )
                    combined_output = (stdout_bytes or b"") + (stderr_bytes or b"")
                    stdout_tail = combined_output.decode(errors="replace")[-2000:]
                except asyncio.TimeoutError:
                    # Process didn't exit gracefully, force kill
                    process.kill()
                    await process.wait()
                    stdout_tail = "[Executor Error]: Job timed out and was force-terminated."
                status = TrainingStatus.TIMED_OUT
                if not stdout_tail or "[Executor Error]" not in stdout_tail:
                    stdout_tail = f"[Executor Error]: Job timed out and was terminated.\n{stdout_tail}"
        except Exception as exc:  # pragma: no cover - defensive guardrail
            stdout_tail = f"[Executor Error]: {exc}"
            status = TrainingStatus.FAILED

        if os.path.exists(results_path):
            try:
                with open(results_path, "r", encoding="utf-8") as handle:
                    data = json.load(handle)
                    if isinstance(data, dict):
                        raw_metrics = data.get("metrics", {})
                        metrics = raw_metrics if isinstance(raw_metrics, dict) else {}
            except (json.JSONDecodeError, OSError):
                # Swallow parsing errors to avoid masking execution failures
                pass

    return TrainingResult(
        job_id=spec.job_id,
        status=status,
        metrics=metrics,
        stdout_tail=stdout_tail,
        budget_tier=spec.budget_tier,
        wall_time_sec=time.time() - start_time,
        updated_at=time.time(),
    )


async def run_small_budget_training(spec: TrainingJobSpec) -> TrainingResult:
    """Execute the small-budget training flow (usually faster/smaller constraints)."""

    timeout_sec = float(spec.timeout_sec) if spec.timeout_sec else 1800
    return await _execute_training(spec, timeout_sec=timeout_sec)


async def run_large_budget_training(spec: TrainingJobSpec) -> TrainingResult:
    """Execute the large-budget training flow."""

    timeout_sec = float(spec.timeout_sec) if spec.timeout_sec else 7200
    return await _execute_training(spec, timeout_sec=timeout_sec)


async def run_batch_training(
    *,
    model_codes: List[str],
    metadata: Dict[str, Any],
    budget_tier: BudgetTier = BudgetTier.SMALL,
    timeout_sec: Optional[float] = None,
    validation_buffer_sec: Optional[float] = None,
    sync_frequency: int = 10,
    log_frequency: int = 100,
) -> TrainingResult:
    """Train N candidates concurrently on one GPU via CUDA streams.

    Generates a concurrent harness (via
    :func:`services.packager_concurrent.build_concurrent_harness`) and
    executes it as a subprocess, exactly like single-model training.

    The metrics dict in the returned ``TrainingResult`` contains a
    ``batch_results`` key: a list of per-model metric dicts (or ``None``
    for models that failed to load).

    Args:
        model_codes: Source code for each candidate model.
        metadata: Job metadata (task, eval_type, etc.).
        budget_tier: Training budget tier.
        timeout_sec: Override wall-clock timeout.
        validation_buffer_sec: Time reserved for final validation.
        sync_frequency: CUDA stream sync interval.
        log_frequency: Console log interval.

    Returns:
        A single ``TrainingResult`` whose ``metrics["batch_results"]``
        is a list of per-model metric dicts.
    """
    from core.tasks.registry import get_task
    from services.packager_concurrent import build_concurrent_harness

    task_name = metadata.get("task", "time_series_foundation")
    eval_type = metadata.get("eval_type", "small_budget")

    task = get_task(task_name)
    task_def = task.definition

    harness_code = build_concurrent_harness(
        task_def=task_def,
        candidate_codes=model_codes,
        eval_type=eval_type,
        timeout_sec=int(timeout_sec) if timeout_sec else None,
        sync_frequency=sync_frequency,
        log_frequency=log_frequency,
    )

    # Build a TrainingJobSpec with the concurrent harness as model_code_content
    if timeout_sec is None:
        timeout_sec = 7200.0 if budget_tier == BudgetTier.LARGE else 1800.0

    spec = TrainingJobSpec(
        metadata=TrainingJobMetadata(task=task_name, eval_type=eval_type),
        dataset_spec={},
        model_code_content=harness_code,
        job_id=uuid.uuid4().hex,
        budget_tier=budget_tier,
        timeout_sec=timeout_sec,
        validation_buffer_sec=validation_buffer_sec,
    )

    return await _execute_training(spec, timeout_sec=int(timeout_sec))


__all__ = [
    "run_small_budget_training",
    "run_large_budget_training",
    "run_batch_training",
]
