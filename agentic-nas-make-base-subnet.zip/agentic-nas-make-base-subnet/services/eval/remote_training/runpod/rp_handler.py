"""RunPod serverless handler that executes the shared training harness."""

from __future__ import annotations

import json
import os
import traceback
import uuid
from dataclasses import asdict
from typing import Any

import runpod

from services.eval.remote_training.job_store import build_job_store_from_env
from services.eval.remote_training.remote_types import (
    BudgetTier,
    Provider,
    TrainingResult,
    build_training_job_spec,
    coerce_budget_tier,
)
from services.eval.remote_training.targon_app.runner import (
    run_large_budget_training,
    run_small_budget_training,
)


_JOB_STORE = None


def _get_job_store():
    global _JOB_STORE
    if _JOB_STORE is None:
        _JOB_STORE = build_job_store_from_env(required=False)
    return _JOB_STORE


def _result_to_dict(result: TrainingResult) -> dict[str, Any]:
    data = asdict(result)
    if hasattr(result.status, "value"):
        data["status"] = result.status.value
    if hasattr(result.budget_tier, "value"):
        data["budget_tier"] = result.budget_tier.value
    data.setdefault("provider", Provider.RUNPOD.value)
    return data


def _coerce_spec(spec: Any) -> dict:
    if isinstance(spec, str):
        return json.loads(spec)
    if spec is None:
        return {}
    if isinstance(spec, dict):
        return spec
    return dict(spec)


async def handler(event: dict) -> dict:
    job_store = _get_job_store()
    spec_payload = _coerce_spec(event.get("input"))
    job_id = event.get("id") or event.get("job_id") or spec_payload.get("job_id")
    if not job_id:
        job_id = spec_payload.get("jobId") or os.getenv("RUNPOD_JOB_ID")
    if not job_id:
        job_id = f"job-{uuid.uuid4().hex}"
    tier = coerce_budget_tier(spec_payload.get("budget_tier")) or BudgetTier.SMALL

    spec_payload.setdefault("provider", Provider.RUNPOD.value)
    spec_payload["job_id"] = job_id

    if job_store and job_id:
        job_store.write_state(job_id, {"status": "running", "provider": Provider.RUNPOD.value})

    try:
        spec_obj = build_training_job_spec(spec_payload)
        if tier == BudgetTier.LARGE:
            result = await run_large_budget_training(spec_obj)
        else:
            result = await run_small_budget_training(spec_obj)

        result_dict = _result_to_dict(result)
        if job_store and job_id:
            job_store.write_state(
                job_id,
                {
                    "status": "finished",
                    "provider": Provider.RUNPOD.value,
                    "tier": tier.value,
                    "result": result_dict,
                },
            )
        return result_dict
    except Exception as exc:  # pragma: no cover - defensive path
        tb = traceback.format_exc()
        if job_store and job_id:
            job_store.write_state(
                job_id,
                {
                    "status": "failed",
                    "provider": Provider.RUNPOD.value,
                    "tier": tier.value,
                    "error": repr(exc),
                    "traceback": tb,
                },
            )
        raise


runpod.serverless.start({"handler": handler})
