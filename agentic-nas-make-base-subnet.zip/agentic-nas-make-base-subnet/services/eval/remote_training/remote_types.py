"""Lightweight data structures for remote training jobs."""

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional, Union
import math
import time
import uuid


class Provider(str, Enum):
    """Supported remote training backends."""

    TARGON = "targon"
    RUNPOD = "runpod"
    BASILICA = "basilica"


class TrainingStatus(str, Enum):
    """Possible lifecycle states for a remote training job."""

    PENDING = "pending"
    RUNNING = "running"
    SUCCEEDED = "succeeded"
    FAILED = "failed"
    TIMED_OUT = "timed_out"


class BudgetTier(str, Enum):
    """Supported budget tiers for training jobs."""

    SMALL = "small"
    LARGE = "large"


@dataclass
class TrainingJobMetadata:
    """Metadata describing the requested training run."""

    task: str
    eval_type: str


@dataclass
class TrainingJobSpec:
    """Payload sent to the remote executor."""

    metadata: TrainingJobMetadata
    dataset_spec: Dict[str, Any]
    model_code_content: str
    job_id: str = field(default_factory=lambda: uuid.uuid4().hex)
    budget_tier: Optional[Union[str, BudgetTier]] = None
    provider: Provider = Provider.TARGON
    timeout_sec: Optional[float] = None
    # Time reserved at end of training for final validation (default: 300s = 5 min)
    validation_buffer_sec: Optional[float] = None


@dataclass
class TrainingResult:
    """Result returned by the remote executor."""

    job_id: str
    status: TrainingStatus
    metrics: Dict[str, Any]
    stdout_tail: str
    budget_tier: Optional[Union[str, BudgetTier]]
    wall_time_sec: float
    updated_at: float = field(default_factory=time.time)


def coerce_budget_tier(raw: Optional[Union[str, BudgetTier]]) -> Optional[BudgetTier]:
    """Normalize incoming budget tier strings to the enum when possible."""

    if raw is None:
        return None
    try:
        return BudgetTier(raw)
    except ValueError:
        return None


def _coerce_provider(raw: Optional[str]) -> Provider:
    if isinstance(raw, Provider):
        return raw
    try:
        return Provider(raw) if raw else Provider.TARGON
    except Exception:
        return Provider.TARGON


def build_training_job_spec(payload: Dict[str, Any]) -> TrainingJobSpec:
    """Construct a :class:`TrainingJobSpec` from an arbitrary mapping."""

    # Validate required field with helpful error message
    if "model_code_content" not in payload:
        raise ValueError(
            "Missing required field 'model_code_content' in training job payload. "
            "Ensure the candidate code is included in the spec."
        )
    model_code = payload["model_code_content"]
    if not isinstance(model_code, str) or not model_code.strip():
        raise ValueError(
            "Field 'model_code_content' must be a non-empty string containing the model code."
        )

    metadata_payload = payload.get("metadata") or {}
    metadata = (
        metadata_payload
        if isinstance(metadata_payload, TrainingJobMetadata)
        else TrainingJobMetadata(**metadata_payload)
    )

    return TrainingJobSpec(
        metadata=metadata,
        dataset_spec=payload.get("dataset_spec", {}),
        model_code_content=model_code,
        job_id=payload.get("job_id", uuid.uuid4().hex),
        budget_tier=coerce_budget_tier(payload.get("budget_tier")),
        provider=_coerce_provider(payload.get("provider")),
        timeout_sec=payload.get("timeout_sec"),
        validation_buffer_sec=payload.get("validation_buffer_sec"),
    )


def sanitize_for_json(obj: Any) -> Any:
    """Recursively replace non-JSON-compliant floats (NaN, Inf, -Inf) with None."""
    if isinstance(obj, float):
        if math.isnan(obj) or math.isinf(obj):
            return None
        return obj
    if isinstance(obj, dict):
        return {k: sanitize_for_json(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [sanitize_for_json(v) for v in obj]
    return obj


__all__ = [
    "BudgetTier",
    "Provider",
    "TrainingJobMetadata",
    "TrainingJobSpec",
    "TrainingResult",
    "TrainingStatus",
    "build_training_job_spec",
    "coerce_budget_tier",
    "sanitize_for_json",
]
