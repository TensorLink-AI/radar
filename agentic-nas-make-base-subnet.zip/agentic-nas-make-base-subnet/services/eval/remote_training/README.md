# Remote Training (Targon + RunPod + Basilica)

This directory contains the remote-training apps and client helpers. Multiple providers are available for multi-provider deployments:

- **Targon**: Original integration using the Targon SDK
- **RunPod**: Serverless GPU workers on RunPod infrastructure
- **Basilica**: GPU containers on Basilica using Affinetes for orchestration

Job state can be stored durably in Cloudflare R2 for all providers.

## Environment configuration
Set the following environment variables (or Targon secrets) so the job store can access R2:

- `R2_ENDPOINT_URL`
- `R2_ACCESS_KEY_ID`
- `R2_SECRET_ACCESS_KEY`
- `R2_BUCKET`
- Optional: `R2_PREFIX` (defaults to `training_jobs/`)

To choose a provider at runtime, set:

- `TRAINING_BACKEND` (defaults to `targon`)

`Config.REMOTE_TRAINING_PROVIDER` is also available as a code-level default.

## Testing the small-training endpoint
The `/submit_training` endpoint enqueues a job and returns immediately. To exercise the **small** training path locally via the deployed Targon app:

1. Prepare a JSON payload `spec.json` with the training specification.
2. Submit the job:

```bash
curl -X POST "https://<targon-host>/submit_training" \
  -H "Authorization: Bearer <token>" \
  -H "Content-Type: application/json" \
  --data-binary @spec.json
```

3. Note the returned `job_id` and poll until completion:

```bash
curl -X GET "https://<targon-host>/poll_training?job_id=<job-id-from-submit>" \
  -H "Authorization: Bearer <token>"
```

When the job uses the `SMALL` budget tier, it runs through `run_small_training_job`, updates its status in R2 from `queued` → `running` → `finished/failed`, and returns the final `TrainingResult` payload once finished.

## RunPod Serverless worker

The RunPod worker lives in this repository under `services/eval/remote_training/runpod/rp_handler.py`. Build the worker image from the monorepo using the provided Dockerfile (CUDA-enabled base image for GPU training):

```bash
docker build -f services/eval/remote_training/runpod/Dockerfile -t agentic-nas-runpod .
```

RunPod endpoint requirements:

- GPU-backed serverless endpoint (15+ minute timeout recommended for training)
- Set environment variables in the endpoint:
  - `RUNPOD_ENDPOINT_ID`
  - `RUNPOD_API_KEY`
  - Optional R2 variables (`R2_ENDPOINT_URL`, `R2_ACCESS_KEY_ID`, `R2_SECRET_ACCESS_KEY`, `R2_BUCKET`, `R2_PREFIX`)
- Ensure the handler path is `services.eval.remote_training.runpod.rp_handler` (RunPod discovers the `handler` callable automatically via `runpod.serverless.start`).

Submitting and polling with RunPod using curl:

```bash
# Submit a job
curl -X POST "https://api.runpod.ai/v2/${RUNPOD_ENDPOINT_ID}/run" \
  -H "Authorization: Bearer ${RUNPOD_API_KEY}" \
  -H "Content-Type: application/json" \
  --data "{\"input\": $(cat spec.json)}"

# Poll status
curl -X GET "https://api.runpod.ai/v2/${RUNPOD_ENDPOINT_ID}/status/<job_id>" \
  -H "Authorization: Bearer ${RUNPOD_API_KEY}"
```

### Provider selection

The training dispatcher now honors a provider enum (`targon` default, `runpod` for RunPod, `basilica` for Basilica). Set `TRAINING_BACKEND=runpod` or `TRAINING_BACKEND=basilica` (or `Config.REMOTE_TRAINING_PROVIDER`) to direct jobs to the appropriate provider while keeping the same `TrainingJobSpec` → `TrainingResult` contract.

## Basilica/Affinetes Integration

Basilica is a GPU cloud platform that uses Affinetes for container orchestration. The integration deploys training containers on-demand using Docker images and executes jobs via HTTP.

### Setup

1. Install the Basilica SDK:
```bash
pip install basilica-sdk
```

2. Build and push the Docker image:
```bash
# Build the training image from repo root
docker build -f services/eval/remote_training/basilica/Dockerfile -t your-registry/agentic-nas-basilica:latest .

# Push to your container registry
docker push your-registry/agentic-nas-basilica:latest
```

3. Configure environment variables:
```bash
# Required
export BASILICA_API_TOKEN=your-token-here
export BASILICA_DOCKER_IMAGE=your-registry/agentic-nas-basilica:latest
export TRAINING_BACKEND=basilica

# Optional: GPU resources
export BASILICA_GPU_TYPE=A4000       # Default: A4000 (16GB VRAM)
export BASILICA_GPU_COUNT=1          # Default: 1
export BASILICA_MEMORY=16Gi          # Default: 16Gi

# Optional: TTL per budget tier
export BASILICA_TTL_SMALL=3600       # Default: 3600 (1 hour)
export BASILICA_TTL_LARGE=14400      # Default: 14400 (4 hours)
```

### Architecture

The Basilica integration uses Docker image deployment via Affinetes:

1. **Client** (`BasilicaTrainingClient`): Deploys a GPU container using pre-built Docker image
2. **Server** (`basilica/server.py`): FastAPI application with `/health` and `/train` endpoints
3. **Execution**: The server runs the training harness in a subprocess (same as Targon/RunPod)
4. **Cleanup**: Containers are automatically deleted after use (TTL-based auto-cleanup per tier)

### Key Differences from Targon/RunPod

| Feature | Targon | RunPod | Basilica |
|---------|--------|--------|----------|
| Deployment | Pre-deployed functions | Serverless endpoint | On-demand containers |
| Container | Shared image | Serverless pods | Docker image via Affinetes |
| Scaling | Managed replicas | Auto-scaling | Per-job deployment |
| Cold start | Fast (warm instances) | Medium (cold start) | Slower (container deploy) |
| Cost model | Function execution | Per-second billing | Container TTL-based |
| GPU access | Via Targon scheduler | Via RunPod scheduler | Direct GPU allocation |
| TTL | Fixed per function | Fixed per endpoint | Dynamic per budget tier |

### Files

- `basilica/Dockerfile`: Docker image for training container
- `basilica/server.py`: FastAPI server with /health and /train endpoints
- `basilica/__init__.py`: Module exports

### Example Usage

```python
from services.eval.remote_training.client import BasilicaTrainingClient
from services.eval.remote_training.remote_types import TrainingJobSpec, TrainingJobMetadata

# Initialize client (requires BASILICA_API_TOKEN and BASILICA_DOCKER_IMAGE)
client = BasilicaTrainingClient()

# Submit training job
spec = TrainingJobSpec(
    metadata=TrainingJobMetadata(task="time_series_foundation", eval_type="small_budget"),
    dataset_spec={"hf_repo_id": "tensorlink-dev/time-series-six-datasets"},
    model_code_content="<harness script>",
    budget_tier="small",
)

result = await client.train(spec)
print(f"Status: {result.status}, Metrics: {result.metrics}")
```

### Dockerfile Build

The Dockerfile (`basilica/Dockerfile`) creates a CUDA-enabled container with:
- Python 3.10 + PyTorch (CUDA 12.1)
- All training dependencies (einops, scipy, datasets, timm, etc.)
- FastAPI + uvicorn for the HTTP server
- The remote training code from this repository

Build from the repository root:
```bash
docker build -f services/eval/remote_training/basilica/Dockerfile -t agentic-nas-basilica .
```

## Harness heartbeat + partial metrics

Remote harnesses stream lightweight progress updates to `results.json` in the `run-dir` using atomic writes (temporary file + `os.replace`). The payload includes a `partial: true` marker while training is still running:

```json
{
  "success": true,
  "partial": true,
  "primary_metrics": ["MASE", "CRPS"],
  "metrics": {
    "dataloader": {"status": "built", "dataset_path": "/tmp/data"},
    "training_progress": {
      "steps": 3,
      "train_loss": [0.98, 0.96, 0.94],
      "val_score": [0.99, 0.97, 0.95],
      "remaining_time_sec": 120.5,
      "timestamp": 1710000000.0
    }
  }
}
```

When the remaining wall-clock budget dips under the grace buffer (or a `KeyboardInterrupt`/`TimeoutError` is raised), the harness flushes a final snapshot (without `partial: true`) and exits with status code `0` so the executor records a clean completion instead of a timeout failure. If the budget fully elapses, the heartbeat annotates `halt_reason: "time_budget_exhausted"` before the final write so downstream consumers can distinguish a graceful timeout from early loop exit.
