"""
Targon remote training app — uses pre-built RunPod container image.

Uses the same Docker image as RunPod (christensor/agentic-nas-runpod:110126v3)
which already contains all dependencies and the training harness.

Endpoints:
- GET  /health
- GET  /poll?job_id=...
- POST /run_small_training
- POST /run_large_training

Per-function hard caps:
- SMALL_TRAIN_TIMEOUT_SEC (seconds)
- LARGE_TRAIN_TIMEOUT_SEC (seconds)
"""

from __future__ import annotations

import json
import os
import time
import traceback
import uuid
from dataclasses import asdict
from pathlib import Path
from typing import Any, Sequence

# Ensure .env is loaded even when this module is imported outside services_v2
try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass

import targon
from targon import Compute


# -----------------------------------------------------------------------------
# Local paths (deploy-time packaging for local_dir mounting)
# -----------------------------------------------------------------------------
APP_DIR = Path(__file__).resolve().parent


def _find_repo_root(start: Path) -> Path:
    for p in [start] + list(start.parents):
        if (p / "services" / "eval" / "remote_training").exists():
            return p
    return start.parent


REPO_ROOT = _find_repo_root(APP_DIR)
REMOTE_TRAINING_DIR = REPO_ROOT / "services" / "eval" / "remote_training"

if not REMOTE_TRAINING_DIR.exists():
    raise RuntimeError(f"Expected remote training dir not found: {REMOTE_TRAINING_DIR}")

# -----------------------------------------------------------------------------
# R2 environment variables (baked into image at deploy-time)
# -----------------------------------------------------------------------------
R2_ENDPOINT_URL = os.getenv("R2_ENDPOINT_URL")
R2_ACCESS_KEY_ID = os.getenv("R2_ACCESS_KEY_ID")
R2_SECRET_ACCESS_KEY = os.getenv("R2_SECRET_ACCESS_KEY")
R2_BUCKET = os.getenv("R2_BUCKET")
R2_PREFIX = os.getenv("R2_PREFIX", "training_jobs/")

# -----------------------------------------------------------------------------
# Image: Use the pre-built RunPod image (same as runpod/Dockerfile builds)
# -----------------------------------------------------------------------------
_IGNORE_PATTERNS: Sequence[str] = ["__pycache__", "*.pyc", ".git", ".DS_Store", ".venv"]

_IMAGE = targon.Image.from_registry(
    "christensor/agentic-nas-runpod:110126v3",
)

# Copy local remote_training code to override what's in the image
# This allows iterating on the harness without rebuilding the Docker image
_IMAGE = _IMAGE.add_local_dir(
    str(REMOTE_TRAINING_DIR),
    "/workspace/services/eval/remote_training",
    ignore=_IGNORE_PATTERNS,
)

# Bake R2 credentials and runtime settings into the image
_IMAGE = _IMAGE.env(
    {
        # PYTHONPATH is already set in base image to /workspace
        "PYTHONPATH": "/workspace",
        # R2 settings for job state persistence
        "R2_ENDPOINT_URL": R2_ENDPOINT_URL or "",
        "R2_ACCESS_KEY_ID": R2_ACCESS_KEY_ID or "",
        "R2_SECRET_ACCESS_KEY": R2_SECRET_ACCESS_KEY or "",
        "R2_BUCKET": R2_BUCKET or "",
        "R2_PREFIX": R2_PREFIX or "training_jobs/",
    }
)

# -----------------------------------------------------------------------------
# App
# -----------------------------------------------------------------------------
app = targon.App(name="targon-training-app", image=_IMAGE, project_name="agentic-nas")

CPU_TIER = Compute.CPU_SMALL
GPU_TIER = os.getenv("TARGON_GPU_TIER", "rtx4090-small")

# Hard caps (SECONDS)
SMALL_TRAIN_TIMEOUT_SEC = int(os.getenv("SMALL_TRAIN_TIMEOUT_SEC", str(60 * 60)))        # 1h
LARGE_TRAIN_TIMEOUT_SEC = int(os.getenv("LARGE_TRAIN_TIMEOUT_SEC", str(4 * 60 * 60)))   # 4h

HEALTH_TIMEOUT_SEC = int(os.getenv("HEALTH_TIMEOUT_SEC", "10"))
POLL_TIMEOUT_SEC = int(os.getenv("POLL_TIMEOUT_SEC", "15"))

# -----------------------------------------------------------------------------
# Imports from copied package
# -----------------------------------------------------------------------------
from services.eval.remote_training.job_store import build_job_store_from_env  # noqa: E402
from services.eval.remote_training.remote_types import (  # noqa: E402
    BudgetTier,
    Provider,
    TrainingResult,
    build_training_job_spec,
    sanitize_for_json,
)
from services.eval.remote_training.targon_app.runner import (  # noqa: E402
    run_large_budget_training,
    run_small_budget_training,
)

# -----------------------------------------------------------------------------
# Job store
# -----------------------------------------------------------------------------
_JOB_STORE = None


def _get_job_store(required: bool = False):
    """
    Retrieve or initialize the job store for R2 state persistence.
    Still keep required=False to avoid hard-crashing endpoints if envs are blank.
    """
    global _JOB_STORE
    if _JOB_STORE is None:
        _JOB_STORE = build_job_store_from_env(required=required)
    return _JOB_STORE


def _write_state(job_id: str, payload: dict) -> None:
    store = _get_job_store(required=False)
    if store is None:
        return
    try:
        store.write_state(job_id, payload)
    except Exception:
        pass


# -----------------------------------------------------------------------------
# Helpers
# -----------------------------------------------------------------------------
def _result_to_dict(result: TrainingResult) -> dict:
    data = asdict(result)
    if hasattr(result.status, "value"):
        data["status"] = result.status.value
    if hasattr(result.budget_tier, "value"):
        data["budget_tier"] = result.budget_tier.value
    data.setdefault("provider", Provider.TARGON.value)
    return sanitize_for_json(data)


def _coerce_spec(spec: Any) -> dict:
    if isinstance(spec, str):
        return json.loads(spec)
    if spec is None:
        return {}
    if isinstance(spec, dict):
        return spec
    return dict(spec)


# -----------------------------------------------------------------------------
# Web endpoints (FastAPI single-handler endpoints)
# -----------------------------------------------------------------------------
@app.function(resource=CPU_TIER, timeout=HEALTH_TIMEOUT_SEC, min_replicas=1, max_replicas=2)
@targon.fastapi_endpoint(method="GET", docs=True, requires_auth=True)
def health() -> dict:
    """Health check endpoint showing R2 configuration status."""
    return {
        "ok": True,
        "ts": time.time(),
        "r2_configured": bool(os.getenv("R2_ENDPOINT_URL")) and bool(os.getenv("R2_BUCKET")),
        "r2_prefix": os.getenv("R2_PREFIX", "training_jobs/"),
    }


@app.function(resource=CPU_TIER, timeout=POLL_TIMEOUT_SEC, min_replicas=0, max_replicas=2)
@targon.fastapi_endpoint(method="GET", docs=True, requires_auth=True)
def poll(job_id: str) -> dict:
    """Poll job state from R2 store."""
    store = _get_job_store(required=False)
    if store is None:
        return {"job_id": job_id, "status": "not_configured"}

    state = store.read_state(job_id)
    if state is None:
        return {"job_id": job_id, "status": "not_found"}
    return state


@app.function(resource=GPU_TIER, timeout=SMALL_TRAIN_TIMEOUT_SEC, min_replicas=0, max_replicas=2)
@targon.fastapi_endpoint(method="POST", docs=True, requires_auth=True)
async def run_small_training(spec: dict) -> dict:
    """Execute small-budget training (matches RunPod handler behavior)."""
    spec_dict = _coerce_spec(spec)
    spec_obj = build_training_job_spec(spec_dict)

    job_id = spec_obj.job_id or f"job-{uuid.uuid4().hex}"
    spec_obj.provider = Provider.TARGON

    _write_state(job_id, {"status": "running", "provider": Provider.TARGON.value, "tier": BudgetTier.SMALL.value})

    try:
        result: TrainingResult = await run_small_budget_training(spec_obj)
        out = _result_to_dict(result)
        _write_state(job_id, {
            "status": "finished",
            "provider": Provider.TARGON.value,
            "tier": BudgetTier.SMALL.value,
            "result": out,
        })
        return {"job_id": job_id, **out}
    except Exception as exc:
        tb = traceback.format_exc()
        _write_state(job_id, {
            "status": "failed",
            "provider": Provider.TARGON.value,
            "tier": BudgetTier.SMALL.value,
            "error": repr(exc),
            "traceback": tb,
        })
        raise


@app.function(resource=GPU_TIER, timeout=LARGE_TRAIN_TIMEOUT_SEC, min_replicas=0, max_replicas=2)
@targon.fastapi_endpoint(method="POST", docs=True, requires_auth=True)
async def run_large_training(spec: dict) -> dict:
    """Execute large-budget training (matches RunPod handler behavior)."""
    spec_dict = _coerce_spec(spec)
    spec_obj = build_training_job_spec(spec_dict)

    job_id = spec_obj.job_id or f"job-{uuid.uuid4().hex}"
    spec_obj.provider = Provider.TARGON

    _write_state(job_id, {"status": "running", "provider": Provider.TARGON.value, "tier": BudgetTier.LARGE.value})

    try:
        result: TrainingResult = await run_large_budget_training(spec_obj)
        out = _result_to_dict(result)
        _write_state(job_id, {
            "status": "finished",
            "provider": Provider.TARGON.value,
            "tier": BudgetTier.LARGE.value,
            "result": out,
        })
        return {"job_id": job_id, **out}
    except Exception as exc:
        tb = traceback.format_exc()
        _write_state(job_id, {
            "status": "failed",
            "provider": Provider.TARGON.value,
            "tier": BudgetTier.LARGE.value,
            "error": repr(exc),
            "traceback": tb,
        })
        raise


# -----------------------------------------------------------------------------
# Dedicated local entrypoint (SMALL trainer)
# -----------------------------------------------------------------------------
#@app.local_entrypoint()
async def run_small_locally(
    spec_file: str | None = None,
    spec_json: str | None = None,
) -> dict:
    """Run small-budget training locally (for testing)."""
    # 1. Parse Input
    if spec_file:
        with open(spec_file, "r", encoding="utf-8") as f:
            spec_obj_raw = json.load(f)
    elif spec_json is not None:
        s = spec_json.strip()
        if not s:
            raise ValueError("--spec-json was provided but is empty.")
        spec_obj_raw = json.loads(s)
    else:
        spec_obj_raw = {}

    # 2. Prep Spec
    try:
        spec_dict = _coerce_spec(spec_obj_raw)
        spec_obj = build_training_job_spec(spec_dict)
    except Exception as e:
        print(f"Spec validation failed: {e}")
        return {"error": str(e)}

    # 3. Job ID & Initial State
    try:
        job_id = spec_obj.job_id or f"job-{uuid.uuid4().hex}"
        print(f"Starting Job ID: {job_id}")

        _write_state(job_id, {
            "status": "running",
            "provider": Provider.TARGON.value,
            "tier": BudgetTier.SMALL.value,
        })

    except Exception as exc:
        print(f"CRITICAL: Failed to initialize job state.")
        print(f"Reason: {exc}")
        raise RuntimeError(f"Could not write initial state to DB: {exc}")

    # 4. Execute with Lifecycle Management
    try:
        result: TrainingResult = await run_small_budget_training(spec_obj)
        out = _result_to_dict(result)

        _write_state(job_id, {
            "status": "finished",
            "provider": Provider.TARGON.value,
            "tier": BudgetTier.SMALL.value,
            "result": out,
        })
        return {"job_id": job_id, **out}

    except Exception as exc:
        tb = traceback.format_exc()
        print(f"Job failed locally:\n{tb}")

        try:
            _write_state(job_id, {
                "status": "failed",
                "provider": Provider.TARGON.value,
                "tier": BudgetTier.SMALL.value,
                "error": repr(exc),
                "traceback": tb,
            })
        except Exception as write_exc:
            print(f"Warning: Could not write failure state to DB: {write_exc}")

        raise exc


#@app.local_entrypoint()
async def run_small_remote(
    spec_file: str | None = None,
    spec_json: str | None = None,
) -> dict:
    """Launch small-budget training on remote Targon infrastructure."""
    # 1. Parse Input
    if spec_file:
        with open(spec_file, "r", encoding="utf-8") as f:
            spec_obj_raw = json.load(f)
    elif spec_json is not None:
        s = spec_json.strip()
        if not s:
            raise ValueError("--spec-json was provided but is empty.")
        spec_obj_raw = json.loads(s)
    else:
        spec_obj_raw = {}

    # 2. Launch remote training
    try:
        out = run_small_training.remote(spec_obj_raw)
        return out
    except Exception as e:
        print(f"Remote launch failed: {e}")
        return {"error": str(e)}


__all__ = ["app", "health", "poll", "run_small_training", "run_large_training"]
