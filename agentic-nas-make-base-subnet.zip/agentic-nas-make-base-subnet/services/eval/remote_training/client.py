"""Client wrappers for dispatching remote training jobs."""

from __future__ import annotations

import time
import os
import json
import asyncio
from dataclasses import asdict
from typing import Any

# Ensure .env is loaded even when this module is imported outside services_v2
try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass

from services.eval.remote_training.remote_types import (
    BudgetTier,
    Provider,
    TrainingJobSpec,
    TrainingResult,
    TrainingStatus,
    build_training_job_spec,
    coerce_budget_tier,
)
from services.eval.remote_training.job_store import build_job_store_from_env


def _serialize_spec(spec_obj: TrainingJobSpec) -> dict[str, Any]:
    payload = asdict(spec_obj)
    payload["metadata"] = asdict(spec_obj.metadata)
    if hasattr(spec_obj.budget_tier, "value"):
        payload["budget_tier"] = spec_obj.budget_tier.value
    if hasattr(spec_obj.provider, "value"):
        payload["provider"] = spec_obj.provider.value
    return payload


class TargonTrainingClient:
    """Send training jobs to the bundled Targon app (uses same image as RunPod)."""

    provider: Provider = Provider.TARGON

    def __init__(self) -> None:
        try:
            from services.eval.remote_training import sdk_app
        except Exception as exc:  # pragma: no cover - import guardrail
            raise RuntimeError(
                "Targon SDK is unavailable; cannot use remote training"
            ) from exc

        self._app = sdk_app.app
        self._run_small = sdk_app.run_small_training
        self._run_large = sdk_app.run_large_training

    async def train(self, spec: TrainingJobSpec | dict[str, Any]) -> TrainingResult:
        spec_obj = (
            build_training_job_spec(spec)
            if isinstance(spec, dict)
            else spec
        )
        spec_obj.provider = Provider.TARGON
        payload = _serialize_spec(spec_obj)

        tier = coerce_budget_tier(spec_obj.budget_tier) or BudgetTier.SMALL

        async with self._app.run():
            if tier == BudgetTier.LARGE:
                result_dict = await self._run_large.remote(payload)
            else:
                result_dict = await self._run_small.remote(payload)

        try:
            status = TrainingStatus(result_dict.get("status", TrainingStatus.FAILED))
        except Exception:
            status = TrainingStatus.FAILED
        budget = coerce_budget_tier(result_dict.get("budget_tier"))

        return TrainingResult(
            job_id=result_dict.get("job_id", spec_obj.job_id),
            status=status,
            metrics=result_dict.get("metrics", {}),
            stdout_tail=result_dict.get("stdout_tail", ""),
            budget_tier=budget,
            wall_time_sec=float(result_dict.get("wall_time_sec", 0.0)),
            updated_at=float(result_dict.get("updated_at", time.time())),
        )


class RunpodTrainingClient:
    """Dispatch training runs to a RunPod serverless endpoint."""

    provider: Provider = Provider.RUNPOD

    def __init__(
        self,
        *,
        endpoint_id: str | None = None,
        api_key: str | None = None,
        base_url: str | None = None,
        poll_interval: float = 5.0,
        max_poll_seconds: float = 86400.0,
        validate_credentials: bool = True,
    ) -> None:
        self.endpoint_id = endpoint_id or os.getenv("RUNPOD_ENDPOINT_ID")
        self.api_key = api_key or os.getenv("RUNPOD_API_KEY")
        self.base_url = base_url or os.getenv("RUNPOD_BASE_URL", "https://api.runpod.ai")
        self.poll_interval = poll_interval
        self._job_store = build_job_store_from_env(required=False)

        if not self.endpoint_id:
            raise RuntimeError("RUNPOD_ENDPOINT_ID is required for RunPod remote training")
        if not self.api_key:
            raise RuntimeError("RUNPOD_API_KEY is required for RunPod remote training")

        # Validate max_poll_seconds is positive
        if max_poll_seconds <= 0:
            raise ValueError(f"max_poll_seconds must be positive, got {max_poll_seconds}")
        self.max_poll_seconds = max_poll_seconds

        # Optionally validate credentials by checking endpoint health
        if validate_credentials:
            self._validate_credentials()

    @staticmethod
    def map_runpod_status(raw_status: str | None) -> TrainingStatus:
        normalized = (raw_status or "").lower()
        # RunPod statuses: IN_QUEUE, IN_PROGRESS, COMPLETED, FAILED, TIMED_OUT
        mapping = {
            "queued": TrainingStatus.PENDING,
            "in_queue": TrainingStatus.PENDING,
            "pending": TrainingStatus.PENDING,
            "in_progress": TrainingStatus.RUNNING,
            "running": TrainingStatus.RUNNING,
            "completed": TrainingStatus.SUCCEEDED,
            "finished": TrainingStatus.SUCCEEDED,
            "succeeded": TrainingStatus.SUCCEEDED,
            "failed": TrainingStatus.FAILED,
            "cancelled": TrainingStatus.FAILED,
            "timed_out": TrainingStatus.TIMED_OUT,
        }
        return mapping.get(normalized, TrainingStatus.FAILED)

    def _build_headers(self) -> dict[str, str]:
        return {"Authorization": f"Bearer {self.api_key}"}

    def _validate_credentials(self) -> None:
        """Validate RunPod credentials by checking endpoint health."""
        import httpx

        try:
            with httpx.Client(base_url=self.base_url, timeout=10.0) as client:
                response = client.get(
                    f"/v2/{self.endpoint_id}/health",
                    headers=self._build_headers(),
                )
                # 401/403 = bad credentials, 404 = bad endpoint_id
                if response.status_code == 401:
                    raise RuntimeError(
                        "RunPod authentication failed: Invalid API key. "
                        "Check RUNPOD_API_KEY environment variable."
                    )
                if response.status_code == 403:
                    raise RuntimeError(
                        "RunPod authorization failed: API key lacks permissions for this endpoint."
                    )
                if response.status_code == 404:
                    raise RuntimeError(
                        f"RunPod endpoint not found: '{self.endpoint_id}'. "
                        "Check RUNPOD_ENDPOINT_ID environment variable."
                    )
                # Don't fail on other errors - endpoint might just be idle
        except httpx.RequestError as exc:
            # Network errors shouldn't block initialization, just warn
            print(f"Warning: Could not validate RunPod credentials: {exc}")

    async def _submit_job(self, spec_obj: TrainingJobSpec) -> str:
        import httpx

        payload = {"input": _serialize_spec(spec_obj)}
        async with httpx.AsyncClient(base_url=self.base_url, timeout=30.0) as client:
            response = await client.post(
                f"/v2/{self.endpoint_id}/run",
                json=payload,
                headers=self._build_headers(),
            )
            response.raise_for_status()
            data = response.json()
        return data.get("id") or data.get("job_id") or data.get("jobId") or spec_obj.job_id

    def _build_result_from_status(
        self,
        *,
        status_payload: dict[str, Any],
        fallback_job_id: str,
        fallback_budget: BudgetTier | None,
    ) -> TrainingResult:
        raw_status = status_payload.get("status")
        status = self.map_runpod_status(raw_status)

        # Prefer handler output, but allow for alternate fields
        output = status_payload.get("output") or status_payload.get("result") or {}
        error_msg = status_payload.get("error")
        if isinstance(output, str):
            try:
                output = json.loads(output)
            except json.JSONDecodeError as parse_err:
                # Log the parsing error for debugging instead of silently swallowing
                print(f"Warning: Failed to parse RunPod output as JSON: {parse_err}")
                print(f"  Raw output (truncated): {output[:500]!r}")
                if not error_msg:
                    error_msg = f"Invalid JSON response: {output[:200]}"
                output = {}

        metrics: dict[str, Any] = {}
        stdout_tail = ""
        budget = fallback_budget
        wall_time_sec = 0.0
        updated_at = time.time()

        if isinstance(output, dict):
            if output.get("error") and not error_msg:
                error_msg = output.get("error")

            metrics = output.get("metrics", {}) if isinstance(output.get("metrics", {}), dict) else {}
            stdout_tail = output.get("stdout_tail", "")
            wall_time_sec = float(output.get("wall_time_sec", wall_time_sec))
            updated_at = float(output.get("updated_at", updated_at))
            budget = coerce_budget_tier(output.get("budget_tier")) or budget

        if status == TrainingStatus.FAILED and error_msg:
            if not stdout_tail:
                stdout_tail = f"[RunPod Platform Error]: {error_msg}"
            else:
                stdout_tail += f"\n[RunPod Platform Error]: {error_msg}"

        job_id = status_payload.get("id") or status_payload.get("job_id") or fallback_job_id

        return TrainingResult(
            job_id=job_id,
            status=status,
            metrics=metrics,
            stdout_tail=stdout_tail,
            budget_tier=budget,
            wall_time_sec=wall_time_sec,
            updated_at=updated_at,
        )

    async def _poll_job(self, job_id: str) -> dict[str, Any]:
        import httpx

        async with httpx.AsyncClient(base_url=self.base_url, timeout=30.0) as client:
            response = await client.get(
                f"/v2/{self.endpoint_id}/status/{job_id}", headers=self._build_headers()
            )
            response.raise_for_status()
            return response.json()

    async def train(self, spec: TrainingJobSpec | dict[str, Any]) -> TrainingResult:
        spec_obj = (
            build_training_job_spec(spec)
            if isinstance(spec, dict)
            else spec
        )
        spec_obj.provider = Provider.RUNPOD

        job_id = await self._submit_job(spec_obj)

        budget = coerce_budget_tier(spec_obj.budget_tier)

        start_time = time.time()
        poll_errors: list[str] = []  # Track poll failures for debugging

        while True:
            if time.time() - start_time > self.max_poll_seconds:
                # Include poll errors in timeout message for debugging
                error_details = "[Client Error] Polling timed out (client-side limit reached)."
                if poll_errors:
                    recent_errors = poll_errors[-3:]  # Last 3 errors
                    error_details += f"\nRecent poll errors ({len(poll_errors)} total): " + "; ".join(recent_errors)
                return TrainingResult(
                    job_id=job_id,
                    status=TrainingStatus.TIMED_OUT,
                    metrics={},
                    stdout_tail=error_details,
                    budget_tier=budget,
                    wall_time_sec=time.time() - start_time,
                    updated_at=time.time(),
                )

            try:
                status_payload = await self._poll_job(job_id)
            except Exception as e:
                error_msg = f"Poll failed at {time.time() - start_time:.1f}s: {e}"
                print(f"Warning: {error_msg}")
                poll_errors.append(str(e)[:100])  # Truncate long errors
                await asyncio.sleep(self.poll_interval)
                continue
            # Merge with R2 state if available and more complete
            if self._job_store:
                store_state = self._job_store.read_state(job_id)
                if store_state and store_state.get("result"):
                    return self._build_result_from_status(
                        status_payload=store_state,
                        fallback_job_id=job_id,
                        fallback_budget=budget,
                    )

            result = self._build_result_from_status(
                status_payload=status_payload,
                fallback_job_id=job_id,
                fallback_budget=budget,
            )
            if result.status in {TrainingStatus.SUCCEEDED, TrainingStatus.FAILED, TrainingStatus.TIMED_OUT}:
                return result
            await asyncio.sleep(self.poll_interval)


class BasilicaTrainingClient:
    """
    Dispatch training runs to Basilica GPU infrastructure using affinetes.

    This client deploys training jobs to Basilica's GPU platform via Docker
    containers using ``affinetes`` (``af.load_env``) and polls for completion.
    It follows the same interface as TargonTrainingClient and
    RunpodTrainingClient.

    Architecture:
    - Deploy a GPU container on Basilica via ``af.load_env(mode="basilica")``
    - Submit training spec via HTTP to the deployed container
    - Wait for training to complete
    - Auto-cleanup via ``env.cleanup()`` or TTL expiry

    Environment Variables:
        BASILICA_API_TOKEN: Required. API token for Basilica authentication.
        BASILICA_DOCKER_IMAGE: Required. Docker image for training container.
        BASILICA_GPU_TYPE: Optional. GPU type (e.g., A4000, A100). If not set, Basilica auto-selects.
        BASILICA_GPU_COUNT: Optional. Number of GPUs (default: 1).
        BASILICA_GPU_MEMORY_GB: Optional. Minimum GPU VRAM in GB (default: 16).
        BASILICA_MEMORY: Optional. Container memory (default: 16Gi).
        BASILICA_TTL_SMALL: Optional. TTL for small training (default: 3600).
        BASILICA_TTL_LARGE: Optional. TTL for large training (default: 14400).
        BASILICA_DEPLOYMENT_NAME: Optional. Custom deployment name prefix.
    """

    provider: Provider = Provider.BASILICA

    # Default configuration
    DEFAULT_GPU_COUNT = 1
    DEFAULT_MEMORY = "16Gi"  # Container memory
    DEFAULT_GPU_MEMORY_GB = 16  # GPU VRAM in GB
    DEFAULT_TTL_SMALL = 3600    # 1 hour for small training
    DEFAULT_TTL_LARGE = 14400   # 4 hours for large training
    DEFAULT_POLL_INTERVAL = 10.0
    DEFAULT_DEPLOYMENT_TIMEOUT = 600  # 10 minutes to wait for deployment

    def __init__(
        self,
        *,
        api_token: str | None = None,
        docker_image: str | None = None,
        gpu_type: str | None = None,
        gpu_count: int | None = None,
        gpu_memory_gb: int | None = None,
        memory: str | None = None,
        ttl_small: int | None = None,
        ttl_large: int | None = None,
        poll_interval: float = DEFAULT_POLL_INTERVAL,
        max_poll_seconds: float = 86400.0,
        validate_credentials: bool = True,
        deployment_name_prefix: str | None = None,
    ) -> None:
        """
        Initialize the Basilica training client.

        Args:
            api_token: Basilica API token. Falls back to BASILICA_API_TOKEN env var.
            docker_image: Docker image for training. Falls back to BASILICA_DOCKER_IMAGE.
            gpu_type: GPU type to request (e.g., "A4000", "A100"). If not set, Basilica auto-selects.
            gpu_count: Number of GPUs per container.
            gpu_memory_gb: Minimum GPU VRAM in GB. Falls back to BASILICA_GPU_MEMORY_GB.
            memory: Container memory allocation (e.g., "16Gi").
            ttl_small: TTL for small budget training in seconds.
            ttl_large: TTL for large budget training in seconds.
            poll_interval: Seconds between status polls.
            max_poll_seconds: Maximum time to poll before timeout.
            validate_credentials: Whether to validate token on init.
            deployment_name_prefix: Prefix for deployment names.
        """
        self.api_token = api_token or os.getenv("BASILICA_API_TOKEN")
        self.docker_image = docker_image or os.getenv("BASILICA_DOCKER_IMAGE")
        self.gpu_type = gpu_type or os.getenv("BASILICA_GPU_TYPE")  # None = auto-select
        self.gpu_count = gpu_count or int(os.getenv("BASILICA_GPU_COUNT", str(self.DEFAULT_GPU_COUNT)))
        self.gpu_memory_gb = gpu_memory_gb or int(os.getenv("BASILICA_GPU_MEMORY_GB", str(self.DEFAULT_GPU_MEMORY_GB)))
        self.memory = memory or os.getenv("BASILICA_MEMORY", self.DEFAULT_MEMORY)
        self.ttl_small = ttl_small or int(os.getenv("BASILICA_TTL_SMALL", str(self.DEFAULT_TTL_SMALL)))
        self.ttl_large = ttl_large or int(os.getenv("BASILICA_TTL_LARGE", str(self.DEFAULT_TTL_LARGE)))
        self.poll_interval = poll_interval
        self.max_poll_seconds = max_poll_seconds
        self.deployment_name_prefix = deployment_name_prefix or os.getenv(
            "BASILICA_DEPLOYMENT_NAME", "agentic-nas-trainer"
        )

        if not self.api_token:
            raise RuntimeError(
                "BASILICA_API_TOKEN is required for Basilica remote training. "
                "Set the environment variable or pass api_token to the constructor."
            )

        if not self.docker_image:
            raise RuntimeError(
                "BASILICA_DOCKER_IMAGE is required for Basilica remote training. "
                "Build and push the image from services/eval/remote_training/basilica/Dockerfile, "
                "then set the BASILICA_DOCKER_IMAGE environment variable."
            )

        if max_poll_seconds <= 0:
            raise ValueError(f"max_poll_seconds must be positive, got {max_poll_seconds}")

        self._job_store = build_job_store_from_env(required=False)
        self._active_envs: dict[str, Any] = {}

        if validate_credentials:
            self._validate_credentials()

    def _validate_credentials(self) -> None:
        """Validate that affinetes is importable and a token is present."""
        try:
            import affinetes as af  # type: ignore[import-untyped]  # noqa: F401
        except ImportError:
            raise RuntimeError(
                "affinetes is not installed. Install it with: pip install affinetes"
            )
        if not self.api_token:
            print("Warning: BASILICA_API_TOKEN is empty – deployment will fail.")

    @staticmethod
    def _normalize_gpu_model(gpu_type: str) -> str:
        """Normalize a short GPU name to the Basilica SDK format.

        The SDK expects names like ``"NVIDIA-RTX-A4000"`` but users typically
        set short names such as ``"A4000"`` or ``"A100"``.  If the value
        already contains ``"NVIDIA"`` it is returned as-is.
        """
        if gpu_type.upper().startswith("NVIDIA"):
            return gpu_type
        # Common mappings – extend as needed
        _SHORT_TO_FULL: dict[str, str] = {
            "A4000": "NVIDIA-RTX-A4000",
            "A5000": "NVIDIA-RTX-A5000",
            "A6000": "NVIDIA-RTX-A6000",
            "A100": "NVIDIA-A100",
            "A100-80G": "NVIDIA-A100-80GB",
            "H100": "NVIDIA-H100",
            "L40S": "NVIDIA-L40S",
            "L4": "NVIDIA-L4",
            "T4": "NVIDIA-T4",
        }
        normalised = gpu_type.upper().replace(" ", "-")
        return _SHORT_TO_FULL.get(normalised, f"NVIDIA-{gpu_type}")

    def _get_ttl_for_tier(self, budget_tier: BudgetTier | None) -> int:
        """Get appropriate TTL based on budget tier."""
        if budget_tier == BudgetTier.LARGE:
            return self.ttl_large
        return self.ttl_small

    def _build_deployment_name(self, job_id: str) -> str:
        """Generate a unique deployment name for a job."""
        safe_job_id = job_id.replace("-", "")[:12]
        return f"{self.deployment_name_prefix}-{safe_job_id}"

    async def _run_with_progress(
        self,
        coro_func,
        description: str,
        interval: float = 10.0,
    ):
        """Run a blocking operation with periodic progress updates."""
        start_time = time.time()
        task = asyncio.create_task(coro_func)

        while not task.done():
            try:
                # Wait for either the task to complete or the interval
                await asyncio.wait_for(asyncio.shield(task), timeout=interval)
            except asyncio.TimeoutError:
                elapsed = time.time() - start_time
                print(f"[Basilica] {description}... ({elapsed:.0f}s elapsed)")

        return await task

    async def _deploy_training_container(
        self,
        job_id: str,
        budget_tier: BudgetTier | None,
    ) -> tuple[str, Any]:
        """
        Deploy a training container on Basilica via ``affinetes``.

        Args:
            job_id: Unique job identifier
            budget_tier: Budget tier for TTL selection

        Returns:
            Tuple of (deployment_url, env_object)
        """
        import affinetes as af  # type: ignore[import-untyped]

        ttl = self._get_ttl_for_tier(budget_tier)

        # Prepare environment variables – only forward R2 vars that are actually
        # set on the host so the container can distinguish "not configured" from
        # "configured but empty".
        env_vars: dict[str, str] = {"PYTHONUNBUFFERED": "1"}

        _r2_required = [
            "R2_ENDPOINT_URL",
            "R2_ACCESS_KEY_ID",
            "R2_SECRET_ACCESS_KEY",
            "R2_BUCKET",
        ]
        _r2_optional = ["R2_PREFIX"]
        _r2_missing = [k for k in _r2_required if k not in os.environ]
        if not _r2_missing:
            # All required R2 vars present – forward them (plus optional ones)
            for k in _r2_required + _r2_optional:
                val = os.environ.get(k)
                if val is not None:
                    env_vars[k] = val
        else:
            print(
                "[Basilica] WARNING: R2 environment variables are not fully "
                "configured on the host. Training state/logs will NOT be "
                f"persisted to R2. Missing: {', '.join(_r2_missing)}. "
                "Set these in your .env file (see .env.example) or export "
                "them in your shell."
            )

        print(f"[Basilica] Deploying training container for job {job_id} via affinetes...")

        env = await self._run_with_progress(
            asyncio.to_thread(
                af.load_env,
                mode="basilica",
                image=self.docker_image,
                api_token=self.api_token,
                env_vars=env_vars,
                gpu_count=self.gpu_count,
                min_gpu_memory_gb=self.gpu_memory_gb,
                memory=self.memory,
                ttl_seconds=ttl,
                timeout=900,
            ),
            f"Deploying container (image: {self.docker_image})",
            interval=15.0,
        )

        url = env.url
        self._active_envs[job_id] = env
        print(f"[Basilica] Container ready at {url}")

        return url, env

    async def _check_container_health(
        self,
        url: str,
        *,
        max_attempts: int = 12,
        initial_delay: float = 5.0,
        backoff_factor: float = 1.5,
        max_delay: float = 30.0,
    ) -> None:
        """Wait for the container to become routable, then log CUDA info.

        Basilica's reverse proxy only starts routing external traffic after
        its own ``HEAD /`` health probe succeeds.  There is a race between
        the SDK's ``deploy()`` returning (pod is *running*) and the proxy
        marking the pod *routable*.  This method retries with exponential
        backoff so we don't hit ``/train`` before traffic is being forwarded.
        """
        import httpx

        health_url = f"{url.rstrip('/')}/health"
        delay = initial_delay

        for attempt in range(1, max_attempts + 1):
            try:
                async with httpx.AsyncClient(timeout=httpx.Timeout(30.0)) as client:
                    resp = await client.get(health_url)
                    resp.raise_for_status()
                    data = resp.json()
                    cuda_info = data.get("cuda", {})
                    if cuda_info:
                        toolkit = cuda_info.get("cuda_toolkit", "?")
                        torch_cuda = cuda_info.get("torch_cuda_version", "?")
                        torch_ver = cuda_info.get("torch_version", "?")
                        device = cuda_info.get("cuda_device", "N/A")
                        available = cuda_info.get("cuda_available", False)
                        print(
                            f"[Basilica] Container CUDA info: "
                            f"toolkit={toolkit}, torch={torch_ver} (CUDA {torch_cuda}), "
                            f"gpu={device}, available={available}"
                        )
                        if not available:
                            print(
                                "[Basilica] WARNING: CUDA is NOT available inside the "
                                "container. Training will likely fail or run on CPU."
                            )
                    else:
                        print("[Basilica] Health check OK (no CUDA info returned)")
                    # Success – container is routable
                    return
            except Exception as exc:
                if attempt < max_attempts:
                    print(
                        f"[Basilica] Health check attempt {attempt}/{max_attempts} "
                        f"failed ({exc}). Retrying in {delay:.0f}s..."
                    )
                    await asyncio.sleep(delay)
                    delay = min(delay * backoff_factor, max_delay)
                else:
                    print(
                        f"[Basilica] WARNING: Health check failed after "
                        f"{max_attempts} attempts ({exc}). "
                        "Proceeding to /train but it may also fail."
                    )

    async def _call_training_endpoint(
        self,
        url: str,
        spec_dict: dict[str, Any],
        timeout_sec: float,
    ) -> dict[str, Any]:
        """Call the training endpoint on the deployed container."""
        import httpx

        train_url = f"{url.rstrip('/')}/train"

        # Set timeout slightly longer than training timeout
        http_timeout = timeout_sec + 300  # Add 5 min buffer

        async with httpx.AsyncClient(timeout=httpx.Timeout(http_timeout)) as client:
            response = await client.post(train_url, json=spec_dict)
            response.raise_for_status()
            return response.json()

    async def _cleanup_deployment(self, job_id: str) -> None:
        """Clean up an affinetes environment after training completes."""
        env = self._active_envs.pop(job_id, None)
        if env is not None:
            try:
                await env.cleanup()
            except Exception:
                pass

    @staticmethod
    def map_basilica_status(raw_status: str | None) -> TrainingStatus:
        """Map Basilica/handler status to TrainingStatus enum."""
        normalized = (raw_status or "").lower()
        mapping = {
            "pending": TrainingStatus.PENDING,
            "running": TrainingStatus.RUNNING,
            "succeeded": TrainingStatus.SUCCEEDED,
            "finished": TrainingStatus.SUCCEEDED,
            "completed": TrainingStatus.SUCCEEDED,
            "failed": TrainingStatus.FAILED,
            "timed_out": TrainingStatus.TIMED_OUT,
            "timeout": TrainingStatus.TIMED_OUT,
        }
        return mapping.get(normalized, TrainingStatus.FAILED)

    def _build_result_from_response(
        self,
        response: dict[str, Any],
        fallback_job_id: str,
        fallback_budget: BudgetTier | None,
    ) -> TrainingResult:
        """Build a TrainingResult from the handler response."""
        raw_status = response.get("status")
        status = self.map_basilica_status(raw_status)

        metrics = response.get("metrics", {})
        if not isinstance(metrics, dict):
            metrics = {}

        stdout_tail = response.get("stdout_tail", "")
        budget = coerce_budget_tier(response.get("budget_tier")) or fallback_budget
        wall_time_sec = float(response.get("wall_time_sec", 0.0))
        updated_at = float(response.get("updated_at", time.time()))
        job_id = response.get("job_id", fallback_job_id)

        return TrainingResult(
            job_id=job_id,
            status=status,
            metrics=metrics,
            stdout_tail=stdout_tail,
            budget_tier=budget,
            wall_time_sec=wall_time_sec,
            updated_at=updated_at,
        )

    async def train(self, spec: TrainingJobSpec | dict[str, Any]) -> TrainingResult:
        """
        Submit a training job to Basilica and wait for completion.

        This method:
        1. Deploys a GPU container on Basilica using Docker image
        2. Sends the training spec to the container via HTTP
        3. Waits for training to complete
        4. Cleans up the deployment
        5. Returns the training result

        Args:
            spec: Training job specification (TrainingJobSpec or dict)

        Returns:
            TrainingResult with status, metrics, and logs
        """
        spec_obj = (
            build_training_job_spec(spec)
            if isinstance(spec, dict)
            else spec
        )
        spec_obj.provider = Provider.BASILICA

        job_id = spec_obj.job_id
        budget = coerce_budget_tier(spec_obj.budget_tier)
        start_time = time.time()

        # Trust the timeout already computed by trainer._resolve_timeout() and
        # carried in the spec.  Only fall back to our own TTL config if the
        # spec somehow arrives without one.
        timeout_sec = float(
            spec_obj.timeout_sec
            or self._get_ttl_for_tier(budget)
        )

        try:
            # Deploy the training container
            print(f"[Basilica] Deploying training container for job {job_id}...")
            gpu_info = self.gpu_type or "auto"
            print(f"[Basilica] Image: {self.docker_image}, GPU: {gpu_info} x{self.gpu_count}, GPU Memory: {self.gpu_memory_gb}GB, Memory: {self.memory}")
            url, deployment = await self._deploy_training_container(job_id, budget)
            print(f"[Basilica] Container deployed at {url}")

            # Check container health and log CUDA version info
            await self._check_container_health(url)

            # Prepare the spec for HTTP transmission
            payload = _serialize_spec(spec_obj)

            # Call the training endpoint (blocking call - container executes training)
            print(f"[Basilica] Starting training for job {job_id} (tier: {budget}, timeout: {timeout_sec}s)...")
            response = await self._call_training_endpoint(url, payload, timeout_sec)
            print(f"[Basilica] Training completed for job {job_id}")

            # Build result from response
            result = self._build_result_from_response(response, job_id, budget)

            return result

        except Exception as exc:
            error_msg = str(exc)
            print(f"[Basilica] Training failed for job {job_id}: {error_msg}")

            # Collect diagnostics on failure (if env supports it)
            env = self._active_envs.get(job_id)
            if env:
                try:
                    st = await asyncio.to_thread(getattr, env, "status", "unknown")
                    print("[Basilica] env status:", st)
                except Exception as e:
                    print("[Basilica] status check failed:", e)

            return TrainingResult(
                job_id=job_id,
                status=TrainingStatus.FAILED,
                metrics={},
                stdout_tail=f"[Basilica Error]: {error_msg}",
                budget_tier=budget,
                wall_time_sec=time.time() - start_time,
                updated_at=time.time(),
            )


        finally:
            await self._cleanup_deployment(job_id)

    async def batch_train(
        self,
        specs: list[TrainingJobSpec | dict[str, Any]],
        *,
        max_concurrency: int = 4,
    ) -> list[TrainingResult]:
        """Train multiple candidates concurrently on separate Basilica pods.

        Each spec gets its own GPU pod deployed via ``af.load_env``.
        Concurrency is bounded by ``max_concurrency`` to avoid overloading
        the cluster.

        Args:
            specs: List of training job specifications.
            max_concurrency: Maximum number of pods running simultaneously.

        Returns:
            List of ``TrainingResult`` objects in the same order as *specs*.
            Failed jobs return a ``TrainingResult`` with
            ``status=TrainingStatus.FAILED`` rather than raising.
        """
        if not specs:
            return []

        sem = asyncio.Semaphore(max_concurrency)
        print(
            f"[Basilica] Batch training {len(specs)} candidates "
            f"(max_concurrency={max_concurrency})"
        )

        async def _guarded_train(
            idx: int,
            spec: TrainingJobSpec | dict[str, Any],
        ) -> TrainingResult:
            async with sem:
                try:
                    return await self.train(spec)
                except Exception as exc:
                    # Catch any exception (e.g. spec parsing) so one
                    # failure doesn't cancel the whole batch.
                    job_id = getattr(spec, "job_id", None) or (
                        spec.get("job_id", f"batch-{idx}") if isinstance(spec, dict)
                        else f"batch-{idx}"
                    )
                    print(f"[Basilica] Batch item {idx} ({job_id}) failed: {exc}")
                    return TrainingResult(
                        job_id=str(job_id),
                        status=TrainingStatus.FAILED,
                        metrics={},
                        stdout_tail=f"[Basilica Batch Error]: {exc}",
                        budget_tier=None,
                        wall_time_sec=0.0,
                        updated_at=time.time(),
                    )

        tasks = [
            asyncio.create_task(_guarded_train(i, s))
            for i, s in enumerate(specs)
        ]
        results: list[TrainingResult] = list(await asyncio.gather(*tasks))
        succeeded = sum(1 for r in results if r.status == TrainingStatus.SUCCEEDED)
        print(
            f"[Basilica] Batch complete: {succeeded}/{len(specs)} succeeded"
        )
        return results

    async def batch_train_streams(
        self,
        model_codes: list[str],
        *,
        budget_tier: str = "small",
        timeout_sec: float | None = None,
        metadata: dict[str, Any] | None = None,
        sync_frequency: int = 10,
        log_frequency: int = 100,
    ) -> list[TrainingResult]:
        """Train multiple candidates on a **single** GPU pod using CUDA streams.

        Unlike :meth:`batch_train` (which deploys N pods, one per model),
        this method deploys **one** pod and sends all candidate source codes
        to its ``POST /train-batch`` endpoint.  The pod trains all models
        concurrently via round-robin CUDA stream scheduling, achieving
        near-linear throughput scaling.

        Args:
            model_codes: Raw Python source for each candidate model.
            budget_tier: ``"small"`` or ``"large"``.
            timeout_sec: Wall-clock timeout for the whole batch.
            metadata: Job metadata forwarded to the training server.
            sync_frequency: CUDA stream sync interval (steps).
            log_frequency: Console log interval (round-robin rounds).

        Returns:
            A list of ``TrainingResult`` objects, one per model_code,
            in the same order.  Models that failed to load/train get
            ``status=FAILED``.
        """
        if not model_codes:
            return []

        n = len(model_codes)
        job_id = f"batch-streams-{time.time_ns()}"
        budget = coerce_budget_tier(budget_tier)
        start_time = time.time()

        if timeout_sec is None:
            timeout_sec = float(self._get_ttl_for_tier(budget))

        print(
            f"[Basilica] Batch stream training: {n} models on 1 pod "
            f"(budget={budget_tier}, timeout={timeout_sec:.0f}s)"
        )

        try:
            # 1. Deploy a single pod
            url, env = await self._deploy_training_container(job_id, budget)
            await self._check_container_health(url)

            # 2. POST to /train-batch with all model codes
            import httpx

            batch_url = f"{url.rstrip('/')}/train-batch"
            payload = {
                "model_codes": model_codes,
                "metadata": metadata or {},
                "budget_tier": budget_tier,
                "timeout_sec": timeout_sec,
                "sync_frequency": sync_frequency,
                "log_frequency": log_frequency,
                "job_id": job_id,
            }

            http_timeout = timeout_sec + 300
            async with httpx.AsyncClient(timeout=httpx.Timeout(http_timeout)) as client:
                response = await client.post(batch_url, json=payload)
                response.raise_for_status()
                resp_data = response.json()

            print(f"[Basilica] Batch stream training completed for {job_id}")

            # 3. Parse per-model results from the batch response
            # The response has the same structure as a single TrainingResult,
            # but metrics["batch_results"] is a list of per-model metric dicts.
            batch_metrics = resp_data.get("metrics", {})
            batch_results_list = batch_metrics.get("batch_results", [])
            wall_time = float(resp_data.get("wall_time_sec", time.time() - start_time))
            overall_status = self.map_basilica_status(resp_data.get("status"))

            results: list[TrainingResult] = []
            for i, per_model in enumerate(batch_results_list):
                if per_model is None:
                    # Model failed to load
                    results.append(TrainingResult(
                        job_id=f"{job_id}-{i}",
                        status=TrainingStatus.FAILED,
                        metrics={},
                        stdout_tail="Model failed to load during batch training",
                        budget_tier=budget,
                        wall_time_sec=wall_time,
                        updated_at=time.time(),
                    ))
                else:
                    results.append(TrainingResult(
                        job_id=f"{job_id}-{i}",
                        status=overall_status,
                        metrics=per_model if isinstance(per_model, dict) else {},
                        stdout_tail="",
                        budget_tier=budget,
                        wall_time_sec=wall_time,
                        updated_at=time.time(),
                    ))

            # Pad results if fewer came back than we sent
            while len(results) < n:
                results.append(TrainingResult(
                    job_id=f"{job_id}-{len(results)}",
                    status=TrainingStatus.FAILED,
                    metrics={},
                    stdout_tail="Missing from batch results",
                    budget_tier=budget,
                    wall_time_sec=wall_time,
                    updated_at=time.time(),
                ))

            succeeded = sum(
                1 for r in results if r.status == TrainingStatus.SUCCEEDED
            )
            print(
                f"[Basilica] Batch stream complete: "
                f"{succeeded}/{n} succeeded in {wall_time:.1f}s"
            )
            return results

        except Exception as exc:
            error_msg = str(exc)
            print(f"[Basilica] Batch stream training failed: {error_msg}")
            # Return FAILED results for all models
            return [
                TrainingResult(
                    job_id=f"{job_id}-{i}",
                    status=TrainingStatus.FAILED,
                    metrics={},
                    stdout_tail=f"[Basilica Batch Error]: {error_msg}",
                    budget_tier=budget,
                    wall_time_sec=time.time() - start_time,
                    updated_at=time.time(),
                )
                for i in range(n)
            ]
        finally:
            await self._cleanup_deployment(job_id)

    async def batch_proxy_eval(
        self,
        model_codes: list[str],
        *,
        input_length: int = 512,
        forecast_length: int = 256,
        batch_size: int = 4,
        num_variants: int = 7,
        max_params: int | None = None,
        max_inference_latency_ms: float | None = None,
        timeout_sec: float | None = None,
    ) -> list[dict[str, Any]]:
        """Run AZNAS zero-cost proxy evaluation on a batch of candidates.

        Deploys a single Basilica pod and sends all candidate source
        codes to its ``POST /proxy-eval-batch`` endpoint.  The pod
        loads each model, runs FX shape validation, measures param
        count and latency, and computes all signal-aware proxy metrics.

        Args:
            model_codes: Raw Python source for each candidate model.
            input_length: Past context window length.
            forecast_length: Forecast horizon length.
            batch_size: UCB calibration batch size.
            num_variants: Number of UCB probe variants (max 7).
            max_params: Hard constraint on trainable parameter count.
            max_inference_latency_ms: Hard constraint on forward latency.
            timeout_sec: Wall-clock timeout for the whole batch.

        Returns:
            A list of result dicts, one per model_code, in the same
            order.  Each dict contains proxy metrics, param count,
            inference latency, and ``constraints_satisfied`` flag.
            Models that failed to load/validate get
            ``status="error"`` with an ``error`` message.
        """
        if not model_codes:
            return []

        n = len(model_codes)
        job_id = f"proxy-eval-{time.time_ns()}"
        start_time = time.time()

        if timeout_sec is None:
            # Proxy eval is fast: ~5-10s per candidate, budget generously
            timeout_sec = float(max(300, n * 30))

        print(
            f"[Basilica] Batch proxy eval: {n} models on 1 pod "
            f"(timeout={timeout_sec:.0f}s)"
        )

        try:
            # Deploy a single pod (small budget tier -- proxy eval is lightweight)
            url, env = await self._deploy_training_container(job_id, BudgetTier.SMALL)
            await self._check_container_health(url)

            import httpx

            proxy_url = f"{url.rstrip('/')}/proxy-eval-batch"
            payload = {
                "model_codes": model_codes,
                "input_length": input_length,
                "forecast_length": forecast_length,
                "batch_size": batch_size,
                "num_variants": num_variants,
                "max_params": max_params,
                "max_inference_latency_ms": max_inference_latency_ms,
            }

            http_timeout = timeout_sec + 120
            async with httpx.AsyncClient(timeout=httpx.Timeout(http_timeout)) as client:
                response = await client.post(proxy_url, json=payload)
                response.raise_for_status()
                resp_data = response.json()

            results = resp_data.get("results", [])
            n_passed = resp_data.get("num_passed", 0)
            wall_time = resp_data.get("wall_time_sec", time.time() - start_time)

            print(
                f"[Basilica] Batch proxy eval complete: "
                f"{n_passed}/{n} passed in {wall_time:.1f}s"
            )

            # Pad if fewer results came back than we sent
            while len(results) < n:
                results.append({
                    "index": len(results),
                    "status": "error",
                    "error": "Missing from proxy eval results",
                    "constraints_satisfied": False,
                    "proxy_status": "FAIL",
                })

            return results

        except Exception as exc:
            error_msg = str(exc)
            print(f"[Basilica] Batch proxy eval failed: {error_msg}")
            return [
                {
                    "index": i,
                    "status": "error",
                    "error": f"[Basilica Proxy Eval Error]: {error_msg}",
                    "constraints_satisfied": False,
                    "proxy_status": "FAIL",
                }
                for i in range(n)
            ]
        finally:
            await self._cleanup_deployment(job_id)


__all__ = ["TargonTrainingClient", "RunpodTrainingClient", "BasilicaTrainingClient"]
