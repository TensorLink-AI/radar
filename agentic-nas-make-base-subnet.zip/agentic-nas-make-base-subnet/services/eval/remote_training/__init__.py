"""Remote training deployment utilities and types."""

from .remote_types import (
    BudgetTier,
    Provider,
    TrainingJobMetadata,
    TrainingJobSpec,
    TrainingResult,
    TrainingStatus,
    build_training_job_spec,
    coerce_budget_tier,
)
from .client import BasilicaTrainingClient, RunpodTrainingClient, TargonTrainingClient

__all__ = [
    "BudgetTier",
    "Provider",
    "TrainingJobMetadata",
    "TrainingJobSpec",
    "TrainingResult",
    "TrainingStatus",
    "build_training_job_spec",
    "coerce_budget_tier",
    "BasilicaTrainingClient",
    "RunpodTrainingClient",
    "TargonTrainingClient",
]
