from typing import Optional, Type, List, Sequence
from pydantic import BaseModel
from services.providers.provider import ProviderAgent
from services.providers.agents.base import format_sections
from services.providers.agents.base import resolve_task_fragments


class SummarizerOutput(BaseModel):
    summary: str
    innovation_opportunities: list[str]


SUMMARIZER_INSTRUCTIONS = """
# Experience Synthesis Task

You are the "Long-Term Memory" of the architecture search. Your goal is to synthesize the results of the latest experiment into a concise but deep strategic summary that will guide the NEXT generation of the Planner.

## Synthesis Requirements

1. **Root Cause Diagnosis**:
   - Trace performance limitations to specific architectural design choices.
   - Did the results match the theoretical design motivation?

2. **Innovation Opportunity Identification**:
   - What research directions are most promising for addressing the observed limitations?
   - What specifically should be PRESERVED vs. MODIFIED in the next iteration?

## Output Format
Return a JSON object with:
- `summary`: A comprehensive narrative summary (3-4 paragraphs) integrating performance patterns and theoretical validation.
- `innovation_opportunities`: A list of 3-5 concrete, actionable architectural directions for the Planner to try next.
"""


class Summarizer(ProviderAgent):
    name = "Experience Summarizer"
    instructions = SUMMARIZER_INSTRUCTIONS
    tools: Sequence = []

    def __init__(self, *args, **kwargs):
        kwargs.setdefault("require_tools", False)
        kwargs.setdefault("force_json_initial_if_response_model", True)
        super().__init__(*args, **kwargs)

    def _prepare_user_prompt(
        self,
        motivation: str = "",
        analysis: str = "",
        cognition: str = "",
        task_prompt: str = "",
        task_prompt_fragments: Optional[dict] = None,
        **_: object,
    ) -> str:
        sections: List[tuple[str, str]] = []
        fragments = resolve_task_fragments(task_prompt_fragments, "user")

        # 1. Inject Task Context (Standard Protocol)
        if task_prompt.strip():
            sections.append(("Task Contract", task_prompt))
        elif fragments.get("task_objective"):
            sections.append(("Task Objective", fragments["task_objective"]))

        # 2. Inject Experiment Data
        if motivation:
            sections.append(("Design Motivation", motivation))
        if analysis:
            sections.append(("Performance Analysis", analysis))
        if cognition:
            sections.append(("Available Research Cognition", cognition))

        # 3. Response Requirements
        sections.append((
            "Final Response Requirements",
            "Return JSON with 'summary' and 'innovation_opportunities' based on the synthesis requirements."
        ))

        return format_sections(sections)
