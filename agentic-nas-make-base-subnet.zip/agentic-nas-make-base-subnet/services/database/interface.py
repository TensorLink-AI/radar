from collections import Counter
from typing import List, Tuple

from core.tasks.contracts import BaseTask
from .element import DataElement, CHALLENGE_PATTERNS, infer_challenges_addressed
from .mongo_database import create_client


# Create database instance
db = create_client()


def aggregate_challenge_coverage(elements: List[DataElement]) -> str:
    """
    Aggregate which challenges have been addressed across a set of experiments.

    Returns a formatted string summarizing challenge coverage and gaps.
    """
    if not elements:
        return ""

    # Count how many times each challenge was addressed
    challenge_counts: Counter = Counter()
    all_challenges = set(name for name, _ in CHALLENGE_PATTERNS.values())

    for elem in elements:
        # Prefer stored challenges_addressed (from Analyzer), fall back to inference
        if elem.challenges_addressed:
            addressed = elem.challenges_addressed
        else:
            addressed = infer_challenges_addressed(elem.motivation, elem.analysis)
        challenge_counts.update(addressed)

    # Identify underexplored challenges
    explored = set(challenge_counts.keys())
    underexplored = all_challenges - explored

    # Build summary
    lines = ["## CHALLENGE COVERAGE ANALYSIS", ""]
    lines.append("### Challenges Explored in Reference Experiments:")

    if challenge_counts:
        for challenge, count in challenge_counts.most_common():
            lines.append(f"- **{challenge}**: {count} experiment(s)")
    else:
        lines.append("- None clearly identified")

    lines.append("")
    lines.append("### Underexplored Challenges (Opportunities for Innovation):")

    if underexplored:
        for challenge in sorted(underexplored):
            lines.append(f"- **{challenge}**: Not yet addressed in sampled experiments")
    else:
        lines.append("- All challenges have been explored at least once")

    lines.append("")
    lines.append("---")
    lines.append("")

    return "\n".join(lines)


async def program_sample(task: BaseTask) -> Tuple[str, int]:
    """
    Samples a task-appropriate program from the database to act as the starting point for evolution.
    """
    context = ""
    task_name = task.__class__.__name__

    task_filter = {"task": task_name}
    architecture_keywords = task.get_task_keywords()
    if architecture_keywords:
        task_filter["architecture_keywords"] = architecture_keywords

    parent_candidates = db.sample_from_range(1, 10, 1, filter_dict=task_filter) or []
    parent_element = parent_candidates[0] if parent_candidates else None

    ref_elements = db.sample_from_range(11, 50, 4, filter_dict=task_filter) or []

    # Aggregate challenge coverage across all sampled experiments
    all_elements = ([parent_element] if parent_element else []) + ref_elements
    if all_elements:
        context += aggregate_challenge_coverage(all_elements)

    if parent_element:
        context += await parent_element.get_context()
    for element in ref_elements:
        context += await element.get_context()

    parent_index = parent_element.index if parent_element else None

    # Add task-specific context
    context += task.planner_context()

    source_file_path = task.get_source_file_path(task_name)
    if parent_element and parent_element.program:
        with open(source_file_path, 'w', encoding='utf-8') as f:
            f.write(parent_element.program)
        print(f"[DATABASE] Set source file for task '{task_name}' from parent (index: {parent_index})")
    else:
        try:
            scaffold_path = task.get_scaffold_path()
            with open(scaffold_path, 'r', encoding='utf-8') as scaffold_f:
                scaffold_code = scaffold_f.read()
            with open(source_file_path, 'w', encoding='utf-8') as source_f:
                source_f.write(scaffold_code)
            print(f"[DATABASE] No parent found for task '{task_name}'. Initializing from scaffold: {scaffold_path}")
        except FileNotFoundError:
            print(f"[ERROR] Scaffold file not found for task '{task_name}' at {scaffold_path}")
            return "", None

    return context, parent_index


def update(result: DataElement) -> bool:
    """
    Update database with new experimental result.
    """
    db.add_element_from_dict(result.to_dict())
    return True
