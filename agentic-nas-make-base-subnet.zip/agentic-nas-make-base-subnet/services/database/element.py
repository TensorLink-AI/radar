from dataclasses import dataclass, asdict, field
from typing import Dict, Optional, List, Any, Tuple
import re

from services.utils.agent_logger import log_agent_run

# Legacy summarizer support deprecated - use services.providers.agents.Summarizer instead
summarizer = None
Summary_input = None


# Challenge detection patterns for time-series foundation models
# Maps challenge ID to (display_name, detection_keywords)
CHALLENGE_PATTERNS: Dict[str, Tuple[str, List[str]]] = {
    "long_range": (
        "Long-Range Dependencies",
        ["long-range", "long range", "receptive field", "distant", "memory", "state-space", "ssm", "mamba", "s4", "retention"],
    ),
    "multi_scale": (
        "Multi-Scale & Frequency",
        ["multi-scale", "multiscale", "frequency", "fourier", "wavelet", "spectral", "multi-resolution", "temporal scale", "different clocks"],
    ),
    "non_stationary": (
        "Non-Stationarity",
        ["non-stationary", "nonstationary", "distribution shift", "regime", "adaptive normalization", "covariate shift", "concept drift"],
    ),
    "scale_free": (
        "Scale-Free Generalization",
        ["revin", "reversible", "instance norm", "scale-free", "magnitude", "normalization", "scale shock", "domain transfer"],
    ),
    "snr": (
        "SNR Variability",
        ["signal-to-noise", "snr", "noise", "sensitivity", "robust", "denoising", "filtering", "confidence"],
    ),
    "efficiency": (
        "Computational Efficiency",
        ["sub-quadratic", "linear attention", "sparse", "flash", "efficient", "o(n)", "o(l)", "chunked", "memory efficient"],
    ),
}


def infer_challenges_addressed(motivation: str, analysis: str) -> List[str]:
    """
    Infer which key challenges an experiment addressed based on its motivation and analysis.

    Returns a list of challenge display names that were likely targeted.
    """
    text = f"{motivation} {analysis}".lower()
    addressed = []

    for challenge_id, (display_name, keywords) in CHALLENGE_PATTERNS.items():
        for keyword in keywords:
            if keyword in text:
                addressed.append(display_name)
                break  # Only count each challenge once

    return addressed


@dataclass
class DataElement:
    """Data element model for experimental results."""
    time: str
    name: str
    # allow Any because some code stores structured dicts, not only str
    result: Dict[str, Any]
    program: str
    motivation: str
    analysis: str
    cognition: str
    log: str

    # Cross-task / cross-modal metadata
    task: str
    architecture_keywords: List[str] = field(default_factory=list)

    # Challenges this experiment addressed (tagged by Analyzer)
    challenges_addressed: List[str] = field(default_factory=list)

    # Tree & bookkeeping
    parent: Optional[int] = None
    index: Optional[int] = None
    summary: str = ""

    # Optional fields the DB layer may persist/read
    score: Optional[float] = None
    motivation_embedding: Optional[List[float]] = None

    def to_dict(self) -> Dict:
        """Convert DataElement instance to dictionary."""
        return asdict(self)

    async def get_context(self, include_code: bool = False) -> str:
        """Generate enhanced context with structured experimental evidence presentation.

        Args:
            include_code: If True, include full program code. Default False to reduce
                         token usage (the current file is already shown separately).
        """
        # Priority 1: Use pre-computed summary from analysis phase (Long-Term Memory)
        if self.summary:
            summary_result = self.summary
        # Priority 2: Generate on-demand via legacy summarizer if available
        elif summarizer and Summary_input:
            summary = await log_agent_run(
                "summarizer",
                summarizer,
                Summary_input(self.motivation, self.analysis, self.cognition),
            )
            summary_result = getattr(getattr(summary, "final_output", None), "experience", "")
        # Priority 3: Fallback to raw concatenation
        else:
            summary_parts = [self.motivation, self.analysis, self.cognition]
            summary_result = "\n\n".join(part for part in summary_parts if part)

        arch_kw = ", ".join(self.architecture_keywords) if self.architecture_keywords else "—"

        # Use stored challenges if available, otherwise infer from motivation/analysis
        if self.challenges_addressed:
            challenges_list = self.challenges_addressed
        else:
            challenges_list = infer_challenges_addressed(self.motivation, self.analysis)
        challenges_str = ", ".join(challenges_list) if challenges_list else "Not clearly identified"

        # Build implementation section based on include_code flag
        if include_code and self.program:
            implementation_section = f"""#### Implementation
```python
{self.program}
```"""
        else:
            # Provide a brief summary instead of full code
            code_lines = len(self.program.splitlines()) if self.program else 0
            implementation_section = f"#### Implementation Summary\n**Lines of code**: {code_lines}"

        return f"""## EXPERIMENTAL EVIDENCE PORTFOLIO

### Experiment: {self.name}
**Task**: {self.task}
**Architecture Identifier**: {self.name}
**Architecture Keywords**: {arch_kw}
**Challenges Addressed**: {challenges_str}

#### Performance Metrics Summary
**Training Progression**: {self.result.get("train", "")}
**Evaluation Results**: {self.result.get("test", "")}

{implementation_section}

#### Synthesized Experimental Insights

{summary_result}

---"""

    @classmethod
    def from_dict(cls, data: Dict) -> 'DataElement':
        """Create DataElement instance from dictionary."""
        # This will work as long as unknown keys aren't present; DB code aligns with these fields.
        return cls(**data)
