# services/tools/tools.py
from __future__ import annotations

"""
Validator-side tool registry for the agentic pipeline.
Includes:
  - run_rag                           : retrieval tool with httpx→urllib fallback
  - read_training_logs                : on-demand training log retrieval
  - read_code_section                 : on-demand code section retrieval
  - read_reference_experiment         : on-demand reference experiment retrieval
  - set/clear storage helpers         : manage global state for analysis tools

Conventions:
  * Tools accept **kwargs and pick arguments via _pick_* helpers.
  * Each tool carries an OpenAI-style tool_spec (JSON schema).

Config keys referenced (provide via services.config.Config):
  - RAG_ENDPOINT: URL for RAG POST (expects JSON body)
  - RAG_API_KEY: optional API key for RAG (sent as Authorization: Bearer <key>)
  - RAG_TIMEOUT_SECONDS: optional timeout for RAG requests
"""

from typing import Any, Dict, Optional, List
import json
import time

try:
    import httpx  # used if available
except Exception:
    httpx = None

from services.config import Config


# =============================================================================
# Tool-spec helpers (OpenAI-style)
# =============================================================================

def _attach_tool_spec(func, *, name: str, description: str, parameters: Dict[str, Any]) -> None:
    """
    Attach an OpenAI tools schema to a Python function.
    """
    func.tool_spec = {
        "type": "function",
        "function": {
            "name": name,
            "description": description,
            "parameters": parameters,
        },
    }

def to_tool_spec(tool_func: Any) -> Dict[str, Any]:
    """
    Return the attached tool_spec (if any).
    """
    return getattr(tool_func, "tool_spec", {})

def list_tool_specs() -> List[dict]:
    """
    Convenience: enumerate all exported tool specs for debugging / registration.
    """
    specs = [
        to_tool_spec(run_rag),
        to_tool_spec(read_training_logs),
    ]
    return specs


# =============================================================================
# Argument pickers (robust to numbered-dict calls)
# =============================================================================

def _pick_timeout(kwargs: Dict[str, Any], default: int) -> int:
    v = kwargs.get("timeout_seconds")
    if isinstance(v, (int, float)) and v > 0:
        return int(v)
    return int(default)


# =============================================================================
# run_rag (HTTP POST)
# =============================================================================

def _rag_http_post(url: str, json_body: Dict[str, Any], headers: Dict[str, str], timeout_s: int) -> Dict[str, Any]:
    """
    Internal HTTP client: prefers httpx if installed; falls back to urllib.
    Returns a dict with {status, json, text}.
    """
    # Try httpx first
    if httpx is not None:
        try:
            with httpx.Client(timeout=timeout_s) as client:
                resp = client.post(url, json=json_body, headers=headers)
                resp_text = resp.text
                try:
                    resp_json = resp.json()
                except Exception:
                    resp_json = None
                return {"status": resp.status_code, "json": resp_json, "text": resp_text}
        except Exception as e:
            return {"status": 0, "json": None, "text": f"httpx error: {type(e).__name__}: {e}"}

    # Fallback: urllib
    try:
        import urllib.request
        import urllib.error
        req = urllib.request.Request(
            url,
            data=json.dumps(json_body).encode("utf-8"),
            headers={"Content-Type": "application/json", **headers},
            method="POST",
        )
        with urllib.request.urlopen(req, timeout=timeout_s) as resp:
            body = resp.read().decode("utf-8", "replace")
            try:
                js = json.loads(body)
            except Exception:
                js = None
            return {"status": getattr(resp, "status", 200), "json": js, "text": body}
    except Exception as e:
        return {"status": 0, "json": None, "text": f"urllib error: {type(e).__name__}: {e}"}

def _pick_query(kwargs: Dict[str, Any]) -> Optional[str]:
    for key in ("query", "q", "text"):
        v = kwargs.get(key)
        if isinstance(v, str) and v.strip():
            return v.strip()
    v0 = kwargs.get("0")
    if isinstance(v0, str) and v0.strip():
        return v0.strip()
    return None

def run_rag(**kwargs) -> Dict[str, Any]:
    """
    Query the RAG backend. Requires Config.RAG_ENDPOINT or 'endpoint' arg.

    Args (kwargs):
      - query (str) [required]
      - top_k (int) [optional]
      - filters (dict) [optional]
      - endpoint (str) [optional] overrides Config.RAG_ENDPOINT
      - timeout_seconds (int) [optional] overrides Config.RAG_TIMEOUT_SECONDS

    Returns:
      { success: bool, query: str, results: list, took_ms: int, [error], [endpoint] }
    """
    q = _pick_query(kwargs)
    if not q:
        return {"success": False, "error": "Missing required argument: query"}

    endpoint = kwargs.get("endpoint") or getattr(Config, "RAG_ENDPOINT", None)
    if not endpoint:
        return {"success": True, "query": q, "results": [], "note": "RAG backend not configured."}

    top_k = kwargs.get("top_k", 5)
    filters = kwargs.get("filters") or {}
    default_timeout = getattr(Config, "RAG_TIMEOUT_SECONDS", 20)
    timeout_s = _pick_timeout(kwargs, default=default_timeout)
    api_key = getattr(Config, "RAG_API_KEY", None)

    headers = {}
    if api_key:
        headers["Authorization"] = f"Bearer {api_key}"

    payload = {"query": q, "top_k": int(top_k), "filters": filters}

    start = time.time()
    resp = _rag_http_post(endpoint, payload, headers, timeout_s)
    took_ms = int((time.time() - start) * 1000)

    status = resp.get("status", 0)
    js = resp.get("json")
    text = resp.get("text", "")

    if status and 200 <= status < 300:
        # Expect either {results: [...]} or raw array
        if isinstance(js, dict):
            results = js.get("results", js.get("data", []))
        elif isinstance(js, list):
            results = js
        else:
            results = []
        return {"success": True, "query": q, "results": results, "took_ms": took_ms, "endpoint": endpoint}

    return {
        "success": False,
        "query": q,
        "error": f"RAG HTTP {status}: {text[:500]}",
        "took_ms": took_ms,
        "endpoint": endpoint,
    }

_attach_tool_spec(
    run_rag,
    name="run_rag",
    description="Query the research retrieval system for supporting literature (if configured).",
    parameters={
        "type": "object",
        "properties": {
            "query": {"type": "string", "description": "Natural-language query."},
            "top_k": {"type": "integer", "description": "Max results to return (default 5)."},
            "filters": {"type": "object", "description": "Optional filter dict.", "additionalProperties": True},
            "endpoint": {"type": "string", "description": "Override RAG endpoint (POST)."},
            "timeout_seconds": {"type": "integer", "description": "HTTP timeout seconds (default 20 or Config.RAG_TIMEOUT_SECONDS)."},
        },
        "required": ["query"],
    },
)


# =============================================================================
# read_training_logs
# =============================================================================

# Global storage for training logs (set by analyse interface before running Analyzer)
_training_logs_store: Dict[str, str] = {}

# Global storage for program code (for on-demand fetching by Analyzer)
_program_code_store: Dict[str, str] = {}

# Global storage for reference experiments (for on-demand fetching by Analyzer)
_reference_experiments_store: Dict[str, Dict[str, Any]] = {}


def set_training_logs(logs_id: str, logs_content: str) -> None:
    """Store training logs for later retrieval by the read_training_logs tool."""
    _training_logs_store[logs_id] = logs_content


def clear_training_logs(logs_id: str) -> None:
    """Clear training logs after analysis is complete."""
    _training_logs_store.pop(logs_id, None)


def read_training_logs(**kwargs) -> str:
    """
    Read training logs for the current analysis session.

    Args (kwargs):
      - logs_id: str - identifier for the logs (provided in the analysis context)
      - section: str - optional, one of: "full", "history", "first_epochs", "last_epochs", "metrics", "summary"
      - start_epoch: int - optional, for fetching a specific epoch range
      - end_epoch: int - optional, for fetching a specific epoch range

    Returns:
      The requested portion of training logs as a string.
    """
    logs_id = kwargs.get("logs_id") or kwargs.get("id") or "current"
    section = kwargs.get("section", "summary")

    logs_content = _training_logs_store.get(logs_id)
    if not logs_content:
        return f"ERROR: No training logs found for id '{logs_id}'. Available ids: {list(_training_logs_store.keys())}"

    # Try to parse as JSON for intelligent extraction
    try:
        logs_data = json.loads(logs_content)
    except (json.JSONDecodeError, TypeError):
        # Not JSON - return raw content (possibly truncated)
        if section == "full":
            return logs_content
        # Return first/last portions for non-JSON
        if len(logs_content) > 50000:
            return logs_content[:25000] + "\n\n... [truncated] ...\n\n" + logs_content[-25000:]
        return logs_content

    if section == "full":
        return json.dumps(logs_data, indent=2, default=str)

    if section == "history":
        history = logs_data.get("history", [])
        if not history:
            return "No training history found in logs."
        return json.dumps(history, indent=2, default=str)

    if section == "first_epochs":
        history = logs_data.get("history", [])
        if not history:
            return "No training history found in logs."
        n = min(10, len(history))
        return f"First {n} epochs:\n" + json.dumps(history[:n], indent=2, default=str)

    if section == "last_epochs":
        history = logs_data.get("history", [])
        if not history:
            return "No training history found in logs."
        n = min(10, len(history))
        return f"Last {n} epochs (of {len(history)} total):\n" + json.dumps(history[-n:], indent=2, default=str)

    if section == "metrics":
        # Return everything except history
        metrics = {k: v for k, v in logs_data.items() if k != "history"}
        return json.dumps(metrics, indent=2, default=str)

    if section == "epochs":
        # Fetch specific epoch range
        history = logs_data.get("history", [])
        if not history:
            return "No training history found in logs."
        start = kwargs.get("start_epoch", 0)
        end = kwargs.get("end_epoch", len(history))
        return f"Epochs {start}-{end} (of {len(history)} total):\n" + json.dumps(history[start:end], indent=2, default=str)

    # Default: summary
    summary_parts = []
    history = logs_data.get("history", [])
    if history:
        summary_parts.append(f"Training history: {len(history)} epochs")
        if len(history) > 0:
            summary_parts.append(f"  First epoch: {json.dumps(history[0], default=str)}")
        if len(history) > 1:
            summary_parts.append(f"  Last epoch: {json.dumps(history[-1], default=str)}")

    # Other top-level metrics
    for key, value in logs_data.items():
        if key == "history":
            continue
        if isinstance(value, (dict, list)):
            compact = json.dumps(value, default=str, separators=(',', ':'))
            if len(compact) > 200:
                compact = compact[:200] + "..."
            summary_parts.append(f"{key}: {compact}")
        else:
            summary_parts.append(f"{key}: {value}")

    return "\n".join(summary_parts)


_attach_tool_spec(
    read_training_logs,
    name="read_training_logs",
    description="Read training logs for the current experiment analysis. Use this to inspect detailed training history, specific epochs, or metrics.",
    parameters={
        "type": "object",
        "properties": {
            "logs_id": {
                "type": "string",
                "description": "Identifier for the logs (use 'current' for the active analysis)."
            },
            "section": {
                "type": "string",
                "enum": ["summary", "full", "history", "first_epochs", "last_epochs", "metrics", "epochs"],
                "description": "Which section to retrieve: 'summary' (default), 'full' (everything), 'history' (all epochs), 'first_epochs' (first 10), 'last_epochs' (last 10), 'metrics' (non-history data), 'epochs' (specific range)."
            },
            "start_epoch": {
                "type": "integer",
                "description": "Start epoch index when section='epochs'."
            },
            "end_epoch": {
                "type": "integer",
                "description": "End epoch index when section='epochs'."
            },
        },
        "required": [],
    },
)


# =============================================================================
# read_code_section (on-demand code fetching)
# =============================================================================

def set_program_code(code_id: str, code_content: str) -> None:
    """Store program code for later retrieval by the read_code_section tool."""
    _program_code_store[code_id] = code_content


def clear_program_code(code_id: str) -> None:
    """Clear program code after analysis is complete."""
    _program_code_store.pop(code_id, None)


def read_code_section(**kwargs) -> str:
    """
    Read a section of the program code being analyzed.

    Args (kwargs):
      - code_id: str - identifier for the code (provided in the analysis context)
      - section: str - one of: "summary", "full", "imports", "classes", "functions", "lines"
      - start_line: int - optional, start line for section='lines'
      - end_line: int - optional, end line for section='lines'
      - search: str - optional, search for a specific pattern and return surrounding context

    Returns:
      The requested portion of code as a string.
    """
    code_id = kwargs.get("code_id") or kwargs.get("id") or "current"
    section = kwargs.get("section", "summary")

    code_content = _program_code_store.get(code_id)
    if not code_content:
        return f"ERROR: No code found for id '{code_id}'. Available ids: {list(_program_code_store.keys())}"

    lines = code_content.split('\n')
    total_lines = len(lines)

    if section == "full":
        return code_content

    if section == "summary":
        summary_parts = [f"Total lines: {total_lines}"]
        imports = [l for l in lines[:50] if l.strip().startswith(('import ', 'from '))]
        if imports:
            summary_parts.append(f"\nImports ({len(imports)}):")
            summary_parts.extend(imports[:10])
            if len(imports) > 10:
                summary_parts.append(f"  ... and {len(imports) - 10} more imports")
        classes = [(i, l) for i, l in enumerate(lines, 1) if l.strip().startswith('class ')]
        if classes:
            summary_parts.append(f"\nClasses ({len(classes)}):")
            for line_no, line in classes[:10]:
                summary_parts.append(f"  L{line_no}: {line.strip()}")
        functions = [(i, l) for i, l in enumerate(lines, 1)
                     if l.strip().startswith('def ') and not l.startswith('    ')]
        if functions:
            summary_parts.append(f"\nTop-level functions ({len(functions)}):")
            for line_no, line in functions[:10]:
                summary_parts.append(f"  L{line_no}: {line.strip()}")
        summary_parts.append(f"\nUse read_code_section with section='lines' and start_line/end_line to fetch specific code.")
        return '\n'.join(summary_parts)

    if section == "imports":
        imports = [l for l in lines if l.strip().startswith(('import ', 'from '))]
        return '\n'.join(imports) if imports else "No imports found."

    if section == "classes":
        result = []
        i = 0
        while i < len(lines):
            if lines[i].strip().startswith('class '):
                class_lines = [f"L{i+1}: {lines[i]}"]
                for j in range(i + 1, min(i + 30, len(lines))):
                    if lines[j].strip().startswith(('class ', 'def ')) and not lines[j].startswith('    '):
                        break
                    class_lines.append(f"L{j+1}: {lines[j]}")
                result.append('\n'.join(class_lines))
                result.append("\n---\n")
            i += 1
        return '\n'.join(result) if result else "No classes found."

    if section == "functions":
        result = []
        i = 0
        while i < len(lines):
            line = lines[i]
            if line.strip().startswith('def ') and not line.startswith('    '):
                func_lines = [f"L{i+1}: {line}"]
                for j in range(i + 1, min(i + 20, len(lines))):
                    if lines[j].strip().startswith(('class ', 'def ')) and not lines[j].startswith('    '):
                        break
                    func_lines.append(f"L{j+1}: {lines[j]}")
                result.append('\n'.join(func_lines))
                result.append("\n---\n")
            i += 1
        return '\n'.join(result) if result else "No top-level functions found."

    if section == "lines":
        start = kwargs.get("start_line", 1) - 1
        end = kwargs.get("end_line", total_lines)
        start = max(0, start)
        end = min(total_lines, end)
        selected = lines[start:end]
        return '\n'.join(f"L{i}: {l}" for i, l in enumerate(selected, start + 1))

    search = kwargs.get("search")
    if search:
        matches = []
        for i, line in enumerate(lines):
            if search.lower() in line.lower():
                start = max(0, i - 3)
                end = min(len(lines), i + 4)
                context = [f"L{j+1}: {lines[j]}" for j in range(start, end)]
                matches.append('\n'.join(context))
                matches.append("---")
        if matches:
            return '\n'.join(matches[:10])
        return f"No matches found for '{search}'."

    return f"Unknown section: {section}. Use 'summary', 'full', 'imports', 'classes', 'functions', or 'lines'."


_attach_tool_spec(
    read_code_section,
    name="read_code_section",
    description="Read a section of the program code being analyzed. Start with 'summary' to see structure, then fetch specific sections as needed.",
    parameters={
        "type": "object",
        "properties": {
            "code_id": {
                "type": "string",
                "description": "Identifier for the code (provided in the analysis context, typically 'current')."
            },
            "section": {
                "type": "string",
                "enum": ["summary", "full", "imports", "classes", "functions", "lines"],
                "description": "Which section: 'summary' (default, shows structure), 'full' (all code), 'imports', 'classes', 'functions', 'lines' (specific range)."
            },
            "start_line": {
                "type": "integer",
                "description": "Start line number when section='lines'."
            },
            "end_line": {
                "type": "integer",
                "description": "End line number when section='lines'."
            },
            "search": {
                "type": "string",
                "description": "Search for a pattern and return matching lines with context."
            },
        },
        "required": [],
    },
)


# =============================================================================
# read_reference_experiment (on-demand reference fetching)
# =============================================================================

def set_reference_experiments(ref_id: str, experiments: Dict[str, Any]) -> None:
    """Store reference experiments for later retrieval by the read_reference_experiment tool."""
    _reference_experiments_store[ref_id] = experiments


def clear_reference_experiments(ref_id: str) -> None:
    """Clear reference experiments after analysis is complete."""
    _reference_experiments_store.pop(ref_id, None)


def read_reference_experiment(**kwargs) -> str:
    """
    Read details of reference experiments (parent, siblings, grandparent).

    Args (kwargs):
      - ref_id: str - identifier for the references (provided in the analysis context)
      - experiment: str - which experiment: "parent", "siblings", "grandparent", "all", "summary"
      - sibling_index: int - optional, index of specific sibling (0-indexed)

    Returns:
      The requested reference experiment details.
    """
    ref_id = kwargs.get("ref_id") or kwargs.get("id") or "current"
    experiment = kwargs.get("experiment", "summary")

    ref_data = _reference_experiments_store.get(ref_id)
    if not ref_data:
        return f"ERROR: No reference experiments found for id '{ref_id}'."

    def _format_experiment(exp_dict: Dict[str, Any], label: str) -> str:
        if not exp_dict:
            return f"{label}: Not available"
        parts = [f"## {label}: {exp_dict.get('name', 'Unknown')}"]
        if exp_dict.get('motivation'):
            parts.append(f"\n### Motivation:\n{exp_dict['motivation']}")
        if exp_dict.get('result'):
            result = exp_dict['result']
            if isinstance(result, dict):
                parts.append(f"\n### Results:")
                parts.append(f"- Train: {result.get('train', 'N/A')}")
                parts.append(f"- Test: {result.get('test', 'N/A')}")
            else:
                parts.append(f"\n### Results: {result}")
        if exp_dict.get('analysis'):
            analysis = exp_dict['analysis']
            if len(analysis) > 1000:
                analysis = analysis[:1000] + "... [truncated]"
            parts.append(f"\n### Analysis Summary:\n{analysis}")
        return '\n'.join(parts)

    if experiment == "summary":
        parts = ["# Reference Experiments Summary"]
        if ref_data.get("direct_parent"):
            p = ref_data["direct_parent"]
            parts.append(f"\n- **Parent**: {p.get('name', 'Unknown')} - {p.get('result', {}).get('test', 'N/A')}")
        if ref_data.get("strongest_siblings"):
            sibs = ref_data["strongest_siblings"]
            parts.append(f"\n- **Siblings**: {len(sibs)} available")
            for i, s in enumerate(sibs[:3]):
                parts.append(f"  - [{i}] {s.get('name', 'Unknown')} - {s.get('result', {}).get('test', 'N/A')}")
        if ref_data.get("grandparent"):
            g = ref_data["grandparent"]
            parts.append(f"\n- **Grandparent**: {g.get('name', 'Unknown')} - {g.get('result', {}).get('test', 'N/A')}")
        parts.append("\nUse read_reference_experiment with experiment='parent', 'siblings', or 'grandparent' for full details.")
        return '\n'.join(parts)

    if experiment == "parent":
        parent = ref_data.get("direct_parent")
        return _format_experiment(parent, "Direct Parent") if parent else "No parent experiment available."

    if experiment == "siblings":
        siblings = ref_data.get("strongest_siblings", [])
        if not siblings:
            return "No sibling experiments available."
        sibling_index = kwargs.get("sibling_index")
        if sibling_index is not None:
            if 0 <= sibling_index < len(siblings):
                return _format_experiment(siblings[sibling_index], f"Sibling [{sibling_index}]")
            return f"Invalid sibling_index: {sibling_index}. Available: 0-{len(siblings)-1}"
        results = []
        for i, sib in enumerate(siblings):
            results.append(_format_experiment(sib, f"Sibling [{i}]"))
            results.append("\n---\n")
        return '\n'.join(results)

    if experiment == "grandparent":
        grandparent = ref_data.get("grandparent")
        return _format_experiment(grandparent, "Grandparent") if grandparent else "No grandparent experiment available."

    if experiment == "all":
        parts = []
        if ref_data.get("direct_parent"):
            parts.append(_format_experiment(ref_data["direct_parent"], "Direct Parent"))
        if ref_data.get("strongest_siblings"):
            for i, sib in enumerate(ref_data["strongest_siblings"]):
                parts.append(_format_experiment(sib, f"Sibling [{i}]"))
        if ref_data.get("grandparent"):
            parts.append(_format_experiment(ref_data["grandparent"], "Grandparent"))
        return '\n\n---\n\n'.join(parts) if parts else "No reference experiments available."

    return f"Unknown experiment type: {experiment}. Use 'summary', 'parent', 'siblings', 'grandparent', or 'all'."


_attach_tool_spec(
    read_reference_experiment,
    name="read_reference_experiment",
    description="Read details of reference experiments (parent, siblings, grandparent) for ablation analysis. Start with 'summary' to see available experiments.",
    parameters={
        "type": "object",
        "properties": {
            "ref_id": {
                "type": "string",
                "description": "Identifier for the references (typically 'current')."
            },
            "experiment": {
                "type": "string",
                "enum": ["summary", "parent", "siblings", "grandparent", "all"],
                "description": "Which experiment(s) to fetch: 'summary' (default), 'parent', 'siblings', 'grandparent', or 'all'."
            },
            "sibling_index": {
                "type": "integer",
                "description": "Index of specific sibling when experiment='siblings'."
            },
        },
        "required": [],
    },
)


# =============================================================================
# Public exports (optional)
# =============================================================================

__all__ = [
    "run_rag",
    "read_training_logs",
    "set_training_logs",
    "clear_training_logs",
    "read_code_section",
    "set_program_code",
    "clear_program_code",
    "read_reference_experiment",
    "set_reference_experiments",
    "clear_reference_experiments",
    "to_tool_spec",
    "list_tool_specs",
]
