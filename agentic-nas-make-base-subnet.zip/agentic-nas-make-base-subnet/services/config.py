class Config:
    """Configuration settings for the validator pipeline."""

    # Default task selected by the validator pipeline
    TASK_NAME: str = "time_series_foundation"

    # Run artifact directories
    RUNS_DIR: str = "./runs"
    EVAL_RUNS_DIR: str = "./eval_runs"

    # Use remote training instead of local execution
    USE_REMOTE_TRAINING: bool = True
    REMOTE_TRAINING_PROVIDER: str = "runpod"  # Options: "runpod", "targon", "basilica"

    # RunPod execution timeout settings
    # These can be overridden via environment variables:
    #   - RUNPOD_EXECUTION_TIMEOUT_SEC
    #   - RUNPOD_TIMEOUT_BUFFER_SEC
    #
    # RUNPOD_EXECUTION_TIMEOUT_SEC: The platform-level timeout configured on RunPod endpoint
    # This should match your RunPod serverless endpoint's executionTimeout setting
    RUNPOD_EXECUTION_TIMEOUT_SEC: int = 1800  # 30 minutes (adjust to match your endpoint config)

    # Safety buffer to ensure graceful shutdown before RunPod kills the container
    # The harness timeout will be: RUNPOD_EXECUTION_TIMEOUT_SEC - RUNPOD_TIMEOUT_BUFFER_SEC
    # This gives the harness time to:
    #   1. Stop training gracefully (harness uses HARNESS_VALIDATION_BUFFER_SEC internally)
    #   2. Run final validation (always runs, ensures we get validation scores)
    #   3. Flush results to results.json
    #   4. Exit cleanly before RunPod terminates the container
    RUNPOD_TIMEOUT_BUFFER_SEC: int = 120  # 2 minutes buffer for graceful shutdown

    # Time reserved inside the training harness for final validation
    # Training stops this many seconds before the harness timeout to ensure
    # validation always completes and we get validation metrics even if training
    # was cut short. Default: 300s = 5 minutes
    HARNESS_VALIDATION_BUFFER_SEC: int = 300

    # Basilica/Affinetes configuration
    # These can be overridden via environment variables:
    #   - BASILICA_API_TOKEN (required for Basilica)
    #   - BASILICA_GPU_TYPE
    #   - BASILICA_GPU_COUNT
    #   - BASILICA_MEMORY
    #   - BASILICA_TTL_SMALL / BASILICA_TTL_LARGE
    #   - BASILICA_DEPLOYMENT_NAME
    #   - BASILICA_DOCKER_IMAGE
    BASILICA_GPU_TYPE: str = ""               # GPU type (A4000, A100, etc.) - empty = auto-select
    BASILICA_GPU_COUNT: int = 1               # Number of GPUs
    BASILICA_GPU_MEMORY_GB: int = 16          # Minimum GPU VRAM in GB
    BASILICA_MEMORY: str = "16Gi"             # Container memory
    BASILICA_TTL_SMALL: int = 3600            # TTL for small training (1 hour)
    BASILICA_TTL_LARGE: int = 14400           # TTL for large training (4 hours)
    BASILICA_DEPLOYMENT_TIMEOUT: int = 600    # Time to wait for deployment (10 min)
    BASILICA_DOCKER_IMAGE: str = ""           # Docker image for training (required)

    # Maximum number of evaluation attempts (no debugger; just retry on infra errors)
    MAX_EVAL_ATTEMPTS: int = 3

    # Maximum number of retry attempts
    MAX_RETRY_ATTEMPTS: int = 10

    # RAG service URL (cognition_base/rag_api.py runs on port 5000)
    RAG: str = "http://localhost:5000"

    # Database URL
    DATABASE: str = "http://localhost:8001"
