"""
Universal remote harness generator.

Builds a standalone Python training script from a ``TaskDefinition``
and candidate source code.  The generated script imports shared
modules (``core.training``, ``core.data``) from the Docker image
rather than embedding them -- so the Docker image must include the
``core/`` package (see ``services/eval/remote_training/basilica/Dockerfile``).

For tasks that need a fully self-contained harness (embedding
dataloaders, model_base, etc.), the existing ``BaseTask.build_remote_harness()``
override remains available.

Usage::

    from core.tasks.contracts import TaskDefinition
    from services.packager import build_universal_harness

    harness = build_universal_harness(
        task_def=my_task.definition,
        candidate_code=open("candidate.py").read(),
        eval_type="small_budget",
    )
    # harness is a string -- write to file and execute on Basilica pod
"""

from __future__ import annotations

import json
import textwrap
from typing import Optional

from core.tasks.contracts import TaskDefinition


def build_universal_harness(
    task_def: TaskDefinition,
    candidate_code: str,
    eval_type: str = "small_budget",
    *,
    timeout_sec: Optional[int] = None,
) -> str:
    """Generate a standalone training script for remote execution.

    The script assumes the Docker image has ``core/`` on its
    ``PYTHONPATH``.  It:

    1. Writes the candidate source to a temp file.
    2. Dynamically imports ``instantiate_model()`` from it.
    3. Configures ``TrainingConfig`` from the ``TaskDefinition``.
    4. Builds data loaders via the task-specific ``row_to_sample``
       hook (imported from ``model_base_module``).
    5. Runs the universal training loop.
    6. Prints JSON metrics to stdout.

    Args:
        task_def: Declarative task configuration.
        candidate_code: Raw Python source of the candidate model.
        eval_type: ``"zero_cost"`` | ``"small_budget"`` | ``"large_budget"``.
        timeout_sec: Override for total wall-clock budget.

    Returns:
        A complete Python script as a string.
    """
    # Resolve budget
    if eval_type == "zero_cost":
        max_steps = 0
        budget_timeout = timeout_sec or task_def.zero_cost_timeout_sec
    elif eval_type == "large_budget":
        max_steps = task_def.large_budget_steps
        budget_timeout = timeout_sec or task_def.large_budget_timeout_sec
    else:
        max_steps = task_def.small_budget_steps
        budget_timeout = timeout_sec or task_def.small_budget_timeout_sec

    candidate_escaped = json.dumps(candidate_code)
    split_map_escaped = json.dumps(task_def.hf_split_map)
    primary_metric = json.dumps(task_def.primary_metric)
    direction = json.dumps(task_def.direction)
    extra_metrics = json.dumps(task_def.extra_metrics)
    model_base_module = json.dumps(task_def.model_base_module)

    harness = textwrap.dedent(f"""\
        #!/usr/bin/env python3
        \"\"\"Auto-generated training harness for task: {task_def.name}\"\"\"

        import importlib, json, os, signal, sys, tempfile, time, traceback

        # ── Write candidate code to a temp file ───────────────────────
        _CANDIDATE_CODE = {candidate_escaped}
        _candidate_file = tempfile.NamedTemporaryFile(
            mode="w", suffix=".py", delete=False, dir="/tmp",
        )
        _candidate_file.write(_CANDIDATE_CODE)
        _candidate_file.close()
        _candidate_path = _candidate_file.name

        # ── Config from TaskDefinition ────────────────────────────────
        TASK_NAME        = {json.dumps(task_def.name)}
        HF_REPO_ID       = {json.dumps(task_def.hf_repo_id)}
        SPLIT_MAP        = {split_map_escaped}
        MAX_STEPS        = {max_steps}
        EVAL_TYPE        = {json.dumps(eval_type)}
        TIMEOUT_SEC      = {budget_timeout}
        PRIMARY_METRIC   = {primary_metric}
        DIRECTION        = {direction}
        EXTRA_METRICS    = {extra_metrics}
        MODEL_BASE_MOD   = {model_base_module}
        MAX_PARAMS       = {task_def.max_params}

        # ── Deadline handling ─────────────────────────────────────────
        _DEADLINE = time.time() + TIMEOUT_SEC
        _shutdown = False

        def _handle_sigterm(*_):
            global _shutdown
            _shutdown = True

        signal.signal(signal.SIGTERM, _handle_sigterm)

        def _time_remaining():
            return max(0, _DEADLINE - time.time())

        # ── Main ──────────────────────────────────────────────────────
        def main():
            import torch
            from core.models.base_contract import instantiate_candidate
            from core.training.universal_trainer import TrainingConfig, train_model
            from core.training.universal_evaluator import count_parameters

            device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

            # 1. Load candidate model
            print(f"Loading candidate from {{_candidate_path}}")
            model = instantiate_candidate(_candidate_path, device)

            # 2. Parameter count check
            n_params = count_parameters(model)
            print(f"Model parameters: {{n_params:,}}")
            if n_params > MAX_PARAMS:
                print(json.dumps({{
                    "error": f"Parameter count {{n_params}} exceeds limit {{MAX_PARAMS}}",
                    "param_count": n_params,
                }}))
                sys.exit(1)

            # 3. Zero-cost: just report param count
            if EVAL_TYPE == "zero_cost":
                print(json.dumps({{
                    "eval_type": "zero_cost",
                    "param_count": n_params,
                    "score": 1.0 / max(n_params, 1),
                }}))
                return

            # 4. Build data loaders
            # Task-specific row_to_sample is loaded from model_base_module
            # if available, otherwise falls back to identity
            row_to_sample = _load_row_converter()

            from core.data.hf_streaming import build_hf_dataloaders
            bundle = build_hf_dataloaders(
                hf_repo_id=HF_REPO_ID,
                row_to_sample=row_to_sample,
                batch_size=32,
                train_split=SPLIT_MAP.get("train", "train"),
                val_split=SPLIT_MAP.get("val", "validation"),
                test_split=SPLIT_MAP.get("test"),
                shuffle_buffer_size=1000,
            )

            # 5. Task-specific loss & eval functions
            loss_fn, eval_fn, forward_fn = _load_task_functions()

            # 6. Train
            config = TrainingConfig(
                max_steps=MAX_STEPS,
                device=str(device),
            )
            result = train_model(
                model=model,
                train_loader=bundle.train,
                loss_fn=loss_fn,
                config=config,
                val_loader=bundle.val,
                eval_fn=eval_fn,
                forward_fn=forward_fn,
                eval_type=EVAL_TYPE,
            )

            # 7. Output
            print(json.dumps(result.metrics, default=float))


        def _load_row_converter():
            \"\"\"Try to import row_to_sample from the task's model_base module.\"\"\"
            if MODEL_BASE_MOD:
                try:
                    mod = importlib.import_module(MODEL_BASE_MOD)
                    if hasattr(mod, "row_to_sample"):
                        return mod.row_to_sample
                except ImportError:
                    pass
            # Fallback: identity (caller must handle)
            return lambda row: row


        def _load_task_functions():
            \"\"\"Try to import loss_fn, eval_fn, forward_fn from model_base module.\"\"\"
            loss_fn = eval_fn = forward_fn = None
            if MODEL_BASE_MOD:
                try:
                    mod = importlib.import_module(MODEL_BASE_MOD)
                    loss_fn = getattr(mod, "loss_fn", None)
                    eval_fn = getattr(mod, "eval_fn", None)
                    forward_fn = getattr(mod, "forward_fn", None)
                except ImportError:
                    pass
            if loss_fn is None:
                raise RuntimeError(
                    f"Task '{{TASK_NAME}}' model_base_module '{{MODEL_BASE_MOD}}' "
                    "must export a loss_fn(output, batch, device) callable."
                )
            return loss_fn, eval_fn, forward_fn


        if __name__ == "__main__":
            try:
                main()
            except Exception:
                traceback.print_exc()
                sys.exit(1)
            finally:
                os.unlink(_candidate_path)
    """)

    return harness
