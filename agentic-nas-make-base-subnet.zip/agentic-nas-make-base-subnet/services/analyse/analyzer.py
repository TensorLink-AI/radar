from typing import Any, Dict, List, Optional, Type

from pydantic import BaseModel, Field
from services.providers.provider import ProviderAgent
from services.tools.tools import read_training_logs, read_code_section, read_reference_experiment
from core.tasks.contracts import BaseTask
from .strategies import get_analysis_strategy


class AnalyzerOutput(BaseModel):
    design_evaluation: str
    experimental_results_analysis: str
    expectation_vs_reality_comparison: str
    theoretical_explanation_with_evidence: str
    synthesis_and_insights: str
    challenges_addressed: List[str] = Field(
        default_factory=list,
        description="List of key challenges this experiment addressed (task-specific categories)"
    )


# Base instructions without task-specific challenge definitions
ANALYZER_INSTRUCTIONS_BASE = """You are an expert AI architecture researcher specializing in long-range sequence modeling experiments. Every response must combine quantitative evidence, code-level citations, and motivation alignment.

You will receive task-owned context (metric definitions, baselines, rubrics), a summary of experimental results, and motivation notes. Use the tools to fetch detailed code and reference experiments as needed.

TOOLS AVAILABLE:
- **read_training_logs**: Fetch detailed training logs when you need more information than the summary provides.
  - section="summary" (default): Quick overview of epochs and final metrics
  - section="first_epochs": First 10 epochs to see early training behavior
  - section="last_epochs": Last 10 epochs to see convergence
  - section="metrics": All non-history metrics
  - section="epochs" with start_epoch/end_epoch: Specific epoch range
  - section="full": Complete logs (use sparingly, can be large)

- **read_code_section**: Fetch specific sections of the program code being analyzed.
  - section="summary" (default): Code structure overview (imports, classes, functions)
  - section="imports": All import statements
  - section="classes": Class definitions with first ~30 lines each
  - section="functions": Top-level function definitions
  - section="lines" with start_line/end_line: Specific line range
  - search="pattern": Find lines matching a pattern with context

- **read_reference_experiment**: Fetch details of reference experiments for ablation analysis.
  - experiment="summary" (default): Overview of available parent/siblings/grandparent
  - experiment="parent": Full details of direct parent experiment
  - experiment="siblings" (optionally with sibling_index): Sibling experiments
  - experiment="grandparent": Grandparent experiment details

RECOMMENDED WORKFLOW:
1. Start with summaries to understand the experiment structure
2. Use read_code_section to examine specific implementation details
3. Use read_reference_experiment to compare with parent/siblings for ablation
4. Use read_training_logs if you need detailed training curves

ANALYSIS APPROACH:
1. **Task Context Assimilation** – Summarize the provided rubric so the reader sees the grading curve.
2. **Ablation & Genealogy (CRITICAL)** – Compare this experiment to its parent/reference.
   - **Isolation**: Which specific code change caused the performance delta?
   - **Validation**: Did the change achieve the theoretical effect predicted in the Motivation?
   - **Trade-offs**: What was gained vs. lost (e.g., speed vs. memory)?
3. **Result Examination** – Parse the supplied training/eval outputs, call out percentage deltas vs. baseline rows, and highlight instability, convergence, or compute anomalies. Use read_training_logs tool if you need more detail.
4. **Code Review** – Inspect the pasted file and identify the concrete mechanisms responsible for the observed behavior.
5. **Motivation Cross-Check** – Compare the intended innovation with what actually shipped in code and with how it performed empirically.

OUTPUT REQUIREMENTS (deliver each section explicitly):
1. **Motivation and Design Evaluation** → `design_evaluation` field – Discuss theoretical soundness, implementation fidelity, and contract compliance.
2. **Experimental Results Analysis** → `experimental_results_analysis` field – Use the metric descriptions to interpret evaluation signals. Quantify gains/losses relative to baselines.
3. **Expectation vs. Reality** → `expectation_vs_reality_comparison` field – Tie each promised capability to its measured outcome, flag unexpected regressions.
4. **Theoretical Explanation with Evidence** → `theoretical_explanation_with_evidence` field – Cite specific code snippets and explain why they produced the measured effect.
5. **Synthesis and Insights** → `synthesis_and_insights` field – Provide actionable recommendations, trade-off analysis, and concrete follow-up experiments.
6. **Challenges Addressed** → `challenges_addressed` field – {challenge_context}

FIELD MAPPING: Populate each output field with the corresponding section's content.

ANALYSIS STANDARDS:
- Support EVERY claim with references to metrics, code lines/sections, or rubric thresholds.
- Highlight data quality/log issues separately from architecture flaws.
- Maintain scientific rigor: prefer quantified comparisons, mention uncertainty, and avoid speculation detached from evidence.
- For challenges_addressed, only include challenges that the experiment ACTUALLY targeted with concrete mechanisms—do not tag challenges that were merely mentioned but not implemented.
"""

# Default fallback for tasks without challenge context
DEFAULT_CHALLENGE_CONTEXT = "Tag any key design challenges this experiment addressed based on the task domain."

class Analyzer(ProviderAgent):
    name = "Architecture Performance Analyzer"
    instructions = ANALYZER_INSTRUCTIONS_BASE.format(challenge_context=DEFAULT_CHALLENGE_CONTEXT)
    tools: list = [read_training_logs, read_code_section, read_reference_experiment]

    def run_with_structured_input(self, response_model: Optional[Type[BaseModel]] = None, **kwargs):
        """Override to call ProviderAgent.run directly, avoiding circular call through Analyzer.run."""
        user_prompt = self._prepare_user_prompt(**kwargs)
        # Bypass Analyzer.run() by calling ProviderAgent.run() directly
        return ProviderAgent.run(self, user_prompt, response_model, skip_prepare_prompt=True, **kwargs)

    async def run(
        self,
        user_prompt: str = "",
        response_model: Optional[Type[BaseModel]] = None,
        **kwargs,
    ) -> AnalyzerOutput:
        """Wrapper for analyze() to support log_agent_run."""
        return await self.analyze(
            user_prompt=user_prompt,
            response_model=response_model,
            **kwargs,
        )

    async def analyze(
        self,
        user_prompt: str = "",
        response_model: Optional[Type[BaseModel]] = None,
        *,
        name: str = "",
        motivation: str = "",
        ref_context: str = "",
        task: BaseTask ,
        eval_type: str = "",
        result: str = "",
        task_context: Optional[Dict[str, Any]] = None,
        task_prompt: str = "",
        **kwargs: Any,
    ) -> AnalyzerOutput:
        """
        Runs analysis by delegating to the appropriate analysis strategy
        based on the eval_type.
        """

        if task is None:
            raise ValueError("Analyzer.analyze requires a task instance")

        safe_name = name.strip()
        safe_motivation = motivation.strip()
        safe_ref_context = ref_context.strip() or "No reference context provided."
        safe_eval_type = eval_type.strip() or "unspecified"

        missing_fields = []
        if not safe_name:
            missing_fields.append("name")
        if not safe_motivation:
            missing_fields.append("motivation")

        if missing_fields:
            joined = ", ".join(missing_fields)
            raise ValueError(
                f"Analyzer.analyze missing required fields after normalization: {joined}"
            )
        # 1. Get the appropriate strategy from the factory
        strategy = get_analysis_strategy(safe_eval_type)

        # 2. Delegate the data gathering to the selected strategy
        analysis_data = await strategy.analyze(
            safe_name, safe_motivation, safe_ref_context, task, safe_eval_type
        )

        # 3. Prepare the final prompt for the LLM
        task_context = task_context or task.get_analysis_context(eval_type)
        program_file_path = kwargs.pop("program_file_path", None) or task.get_source_file_path(safe_name)
        program_code = kwargs.pop("program_code", None)
        if program_code is None:
            try:
                with open(program_file_path, "r", encoding="utf-8") as fh:
                    program_code = fh.read()
            except FileNotFoundError:
                program_code = f"File not found: {program_file_path}"
            except Exception as exc:  # pragma: no cover - unexpected IO issue
                program_code = f"Failed to read {program_file_path}: {exc}"
        
        # Structure the results for clear presentation to the LLM
        result_content = result or (
            f"Analysis for evaluation type '{analysis_data.get('analysis_type')}':\n"
            f"Train Result: {analysis_data.get('train_result', 'N/A')}\n"
            f"Test Result: {analysis_data.get('test_result', 'N/A')}\n"
            f"Content: {analysis_data.get('content', 'N/A')}"
        )

        response_model = response_model or AnalyzerOutput

        task_prompt = task_prompt or task.build_agent_prompt("analyzer")
        task_name = kwargs.pop("task_name", task.get_task_description())
        combined_instructions = self._merge_instructions(task_prompt, task=task)

        original_instructions = self.instructions
        self.instructions = combined_instructions
        try:
            return await self.run_with_structured_input(
                response_model=response_model,
                name=safe_name,
                result=result_content,
                motivation=safe_motivation,
                ref_context=safe_ref_context,
                task_context=task_context,
                program_file_path=program_file_path,
                program_code=program_code,
                task_name=task_name,
                eval_type=safe_eval_type,
                task_prompt=task_prompt,
                **kwargs,
            )
        finally:
            self.instructions = original_instructions

    def _prepare_user_prompt(
        self,
        name: str = "",
        result: str = "",
        motivation: str = "",
        ref_context: str = "",
        task_context: dict = None,
        task_prompt: str = "",
        **kwargs,
    ) -> str:
        """
        Creates a concise, tool-augmented prompt for the Analyzer agent.

        Instead of embedding full code and reference experiments (which caused context overflow),
        we provide summaries and instruct the agent to use tools to fetch details as needed.

        Note: task_prompt is already included in system instructions via _merge_instructions(),
        so we don't duplicate it here in the user message.
        """
        task_context = task_context or {}
        metric_descriptions = task_context.get("metric_descriptions", "No metric descriptions provided.")
        baseline_reference = task_context.get("baseline_reference", "No baseline reference provided.")
        performance_rubric = task_context.get("performance_rubric", "No performance rubric provided.")
        eval_type = kwargs.get("eval_type", "unknown")

        # Get IDs for tool-based fetching
        code_id = kwargs.get("code_id", "current")
        ref_id = kwargs.get("ref_id", "current")
        logs_id = kwargs.get("logs_id", "current")

        # Get code summary if available, otherwise indicate tool should be used
        code_summary = kwargs.get("code_summary", "")
        if not code_summary:
            code_summary = f"Use `read_code_section(code_id='{code_id}')` to examine the implementation."

        # Get reference summary if available
        ref_summary = kwargs.get("ref_summary", "")
        if not ref_summary:
            ref_summary = f"Use `read_reference_experiment(ref_id='{ref_id}')` to compare with parent/siblings."

        # Truncate motivation if too long (still include it since it's essential context)
        MAX_MOTIVATION_CHARS = 2000
        safe_motivation = motivation.strip()
        if len(safe_motivation) > MAX_MOTIVATION_CHARS:
            safe_motivation = safe_motivation[:MAX_MOTIVATION_CHARS] + "... [truncated]"

        # Note: task_prompt is intentionally NOT included here as it's already in system instructions
        # This avoids duplication that was causing context overflow
        sections = []

        sections.append(
            f"""# Analysis Request: Model {name}

## Task-Specific Context
This experiment is for the '{kwargs.get("task_name", "unknown")}' task.
The evaluation type for this analysis is: **{eval_type}**.

### Evaluation Metrics Understanding:
{metric_descriptions}

### Performance Rubric:
{performance_rubric}

### Baseline Reference:
{baseline_reference}

## Experiment Resources

### Results Summary:
{result}

### Code Implementation
- **Path**: {kwargs.get('program_file_path', 'N/A')}
- **Code ID for tools**: `{code_id}`
- **Summary**: {code_summary}

To examine the code, use: `read_code_section(code_id='{code_id}', section='summary')` to see structure, then fetch specific sections.

### Design Motivation:
{safe_motivation}

### Reference Experiments for Ablation
- **Reference ID for tools**: `{ref_id}`
- **Summary**: {ref_summary}

To compare with parent/siblings, use: `read_reference_experiment(ref_id='{ref_id}', experiment='summary')`

### Training Logs
- **Logs ID for tools**: `{logs_id}`

To examine training curves, use: `read_training_logs(logs_id='{logs_id}', section='summary')`

## Analysis Requirements
Please perform a thorough, evidence-based analysis following the system instructions.

**Recommended approach:**
1. First call `read_code_section` with section='summary' to understand the implementation structure
2. Call `read_reference_experiment` with experiment='summary' to see available comparisons
3. Dive into specific code sections or reference details as needed for your analysis
4. Use `read_training_logs` if you need detailed training progression data
"""
        )

        prompt = "\n\n".join(sections)

        # Final safety check: truncate if prompt is still too large
        # With tool-based approach, this should rarely trigger
        MAX_PROMPT_CHARS = 50000
        if len(prompt) > MAX_PROMPT_CHARS:
            # Truncate the middle portion, keeping start and end
            keep_start = MAX_PROMPT_CHARS * 2 // 3
            keep_end = MAX_PROMPT_CHARS // 3
            truncation_note = f"\n\n... [PROMPT TRUNCATED: {len(prompt) - MAX_PROMPT_CHARS:,} chars omitted to fit context window] ...\n\n"
            prompt = prompt[:keep_start] + truncation_note + prompt[-keep_end:]

        return prompt

    def _merge_instructions(self, task_prompt: str, task: Optional[BaseTask] = None) -> str:
        """Join base analyzer instructions with task-specific guidance when provided."""
        # Get task-specific challenge context if available
        if task is not None:
            challenge_context = task.get_challenge_context_for_analyzer()
        else:
            challenge_context = ""

        if not challenge_context:
            challenge_context = DEFAULT_CHALLENGE_CONTEXT

        # Build instructions with task-specific challenge context
        instructions = ANALYZER_INSTRUCTIONS_BASE.format(challenge_context=challenge_context)

        if not task_prompt.strip():
            return instructions
        return f"{instructions}\n\n### Task-Specific Contract\n{task_prompt.strip()}"
