import json
import re
import uuid
from datetime import datetime
from typing import Any, Dict, Optional

from services.config import Config
from services.database import DataElement
from services.database.mongo_database import create_client
from services.eval import EvaluationArtifacts
from services.providers.config import get_agent_model
from services.tools.tools import (
    run_rag,
    set_training_logs,
    clear_training_logs,
    set_program_code,
    clear_program_code,
    set_reference_experiments,
    clear_reference_experiments,
)
from services.utils.agent_logger import log_agent_run, log_error, log_info
from core.tasks.contracts import BaseTask

# Use simplified agents (following "The Bitter Lesson of Agent Frameworks")
from services.providers.agents import Analyzer, Summarizer, SummarizerOutput

# Maximum characters for summaries (full content available via tools)
MAX_CODE_SUMMARY_CHARS = 2000
MAX_REF_SUMMARY_CHARS = 1000

# Instantiate agents with per-agent model support
# Set ANALYZER_MODEL, SUMMARIZER_MODEL to override, or use MODEL_NAME as default
analyzer = Analyzer(model_name=get_agent_model("analyzer"))
summarizer = Summarizer(model_name=get_agent_model("summarizer"))


def _resolve_program_path(
    *,
    candidate: Optional[Dict[str, Any]],
    evaluation_artifacts: EvaluationArtifacts,
    task: BaseTask,
    name: str,
) -> str:
    """Resolve the most reliable code path for the candidate under analysis."""

    if candidate:
        candidate_path = candidate.get("code_path")
        if candidate_path:
            return candidate_path

    if evaluation_artifacts.candidate_code_path:
        return evaluation_artifacts.candidate_code_path

    return task.get_source_file_path(name)


def _load_program_text(program_path: str) -> str:
    """Load the program text from disk, returning a placeholder on failure."""

    try:
        with open(program_path, "r", encoding="utf-8") as program_file:
            return program_file.read()
    except FileNotFoundError:
        return "Program text unavailable."


def _truncate_text(text: str, max_chars: int, label: str = "content") -> str:
    """Truncate text to max_chars while preserving useful information."""
    if len(text) <= max_chars:
        return text

    # Keep first half and last quarter of the budget
    first_part = max_chars * 2 // 3
    last_part = max_chars // 3

    truncated_msg = f"\n\n... [{label} truncated: {len(text) - max_chars:,} chars omitted] ...\n\n"

    return text[:first_part] + truncated_msg + text[-last_part:]


def _create_logs_summary(logs_str: str) -> str:
    """Create a brief summary of training logs.

    Full logs are available via the read_training_logs tool.
    """
    if not logs_str:
        return "No training logs available."

    # Try to parse as JSON to extract key info
    try:
        logs_data = json.loads(logs_str)
        summary_parts = []

        history = logs_data.get("history", [])
        if history:
            summary_parts.append(f"Training completed: {len(history)} epochs")
            if len(history) > 0:
                first = history[0]
                last = history[-1]
                # Extract loss values if present
                first_loss = first.get("loss") or first.get("train_loss")
                last_loss = last.get("loss") or last.get("train_loss")
                if first_loss is not None and last_loss is not None:
                    summary_parts.append(f"Loss: {first_loss:.4f} → {last_loss:.4f}")

        # Add key final metrics
        for key in ["best_loss", "best_epoch", "final_loss", "final_val_loss"]:
            if key in logs_data:
                summary_parts.append(f"{key}: {logs_data[key]}")

        if summary_parts:
            return "\n".join(summary_parts)
    except (json.JSONDecodeError, TypeError):
        pass

    # Fallback: just indicate logs are available
    return f"Training logs available ({len(logs_str):,} chars). Use read_training_logs tool for details."


def _summarize_evaluation_artifacts(
    evaluation_artifacts: EvaluationArtifacts,
    logs_id: str = "current",
) -> str:
    """Create a concise textual summary from evaluation artifacts.

    Full logs are stored separately and accessible via read_training_logs tool.
    """

    if not evaluation_artifacts:
        return "No evaluation artifacts were provided for analysis."

    train_summary = evaluation_artifacts.result.get("train", "")
    test_summary = evaluation_artifacts.result.get("test", "")

    sections = ["# Evaluation Summary"]
    if train_summary:
        sections.append(f"Train Metrics: {train_summary}")
    if test_summary:
        sections.append(f"Test Metrics: {test_summary}")

    if evaluation_artifacts.logs:
        # Provide brief summary + instruction to use tool
        logs_summary = _create_logs_summary(evaluation_artifacts.logs)
        sections.append("## Training Logs Overview")
        sections.append(logs_summary)
        sections.append(f"\n**Note**: Full training logs are available via `read_training_logs(logs_id='{logs_id}')` tool.")
        sections.append("Use section='first_epochs', 'last_epochs', 'metrics', or 'epochs' with start_epoch/end_epoch for specific data.")

    return "\n".join(sections)


def extract_original_name(timestamped_name: str) -> str:
    """Extract original name from timestamped name."""

    timestamp_pattern = r"^\d{8}-\d{2}:\d{2}:\d{2}-"
    return re.sub(timestamp_pattern, "", timestamped_name)


def _create_code_summary(code_text: str) -> str:
    """Create a brief summary of code structure for the prompt.

    Full code is available via read_code_section tool.
    """
    if not code_text or code_text == "Program text unavailable.":
        return "Program code not available."

    lines = code_text.split('\n')
    total_lines = len(lines)

    summary_parts = [f"{total_lines} lines of code"]

    # Count imports
    imports = [l for l in lines[:50] if l.strip().startswith(('import ', 'from '))]
    if imports:
        summary_parts.append(f"{len(imports)} imports")

    # Count classes
    classes = [l.strip() for l in lines if l.strip().startswith('class ')]
    if classes:
        class_names = [c.split('(')[0].replace('class ', '').strip(':') for c in classes[:5]]
        summary_parts.append(f"Classes: {', '.join(class_names)}")
        if len(classes) > 5:
            summary_parts[-1] += f" (+{len(classes) - 5} more)"

    # Count top-level functions
    functions = [(i, l.strip()) for i, l in enumerate(lines, 1)
                 if l.strip().startswith('def ') and not l.startswith('    ')]
    if functions:
        func_names = [f[1].split('(')[0].replace('def ', '') for f in functions[:5]]
        summary_parts.append(f"Functions: {', '.join(func_names)}")
        if len(functions) > 5:
            summary_parts[-1] += f" (+{len(functions) - 5} more)"

    return "; ".join(summary_parts)


def _create_ref_summary(ref_elements: Optional[dict]) -> str:
    """Create a brief summary of reference experiments for the prompt.

    Full details available via read_reference_experiment tool.
    """
    if not ref_elements:
        return "No reference experiments available."

    parts = []

    if ref_elements.get("direct_parent"):
        p = ref_elements["direct_parent"]
        parts.append(f"Parent: {p.get('name', 'Unknown')}")

    if ref_elements.get("strongest_siblings"):
        sibs = ref_elements["strongest_siblings"]
        parts.append(f"{len(sibs)} siblings")

    if ref_elements.get("grandparent"):
        g = ref_elements["grandparent"]
        parts.append(f"Grandparent: {g.get('name', 'Unknown')}")

    if not parts:
        return "No reference experiments available."

    return "; ".join(parts)


class AnalyzerExecutionError(RuntimeError):
    """Raised when the analyzer fails after retries."""


def _build_reference_context(ref_elements: Optional[dict]) -> str:
    """Build reference context string from reference elements.

    Applies truncation to prevent context overflow when there are many siblings.
    """

    if not ref_elements:
        return "No reference experiments provided."

    ref_context = "# Reference Experiments\n"
    has_context = False

    if ref_elements.get("direct_parent"):
        ref_context += "### Direct Parent\n"
        ref_context += _ref_elements_context(DataElement(**ref_elements["direct_parent"]))
        ref_context += "\n\n"
        has_context = True

    if ref_elements.get("strongest_siblings"):
        ref_context += "### Strongest Siblings\n"
        # Limit to top 3 siblings to control context size
        siblings = ref_elements["strongest_siblings"][:3]
        for sibling in siblings:
            ref_context += _ref_elements_context(DataElement(**sibling))
        if len(ref_elements["strongest_siblings"]) > 3:
            ref_context += f"(+ {len(ref_elements['strongest_siblings']) - 3} more siblings omitted)\n"
        ref_context += "\n\n"
        has_context = True

    if ref_elements.get("grandparent"):
        ref_context += "### Grandparent\n"
        ref_context += _ref_elements_context(DataElement(**ref_elements["grandparent"]))
        ref_context += "\n\n"
        has_context = True

    if not has_context:
        return "No reference experiments provided."

    # Apply final truncation if still too large
    if len(ref_context) > MAX_REF_CONTEXT_CHARS:
        ref_context = _truncate_text(ref_context, MAX_REF_CONTEXT_CHARS, "reference context")

    return ref_context


def _ref_elements_context(ref_element: DataElement) -> str:
    """Generate context string for a reference element."""

    return (
        f"""### Reference Experiment {ref_element.name}
#### Experiment Motivation
{ref_element.motivation}
#### Experiment Result
**Training Progression**: {ref_element.result.get("train", "Unavailable")}
**Evaluation Results**: {ref_element.result.get("test", "Unavailable")}
"""
    )


async def analyse(
    *,
    name: str,
    motivation: str,
    context: str,
    parent: Optional[int],
    eval_type: str,
    run_id: Optional[str],
    task: BaseTask,
    evaluation_artifacts: EvaluationArtifacts,
    candidate: Optional[Dict[str, Any]] = None,
    program_text: Optional[str] = None,
    task_context: Optional[Dict[str, Any]] = None,
    task_prompt: Optional[str] = None,
    result: Optional[str] = None,
) -> DataElement:
    """Analyze experiment results and generate comprehensive analysis."""

    #del context, run_id

    if task is None:
        raise ValueError("Analysis requires a task instance")

    if evaluation_artifacts is None:
        raise ValueError("Analysis requires evaluation artifacts")

    current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    original_name = extract_original_name(name)

    safe_motivation = motivation.strip()
    if not safe_motivation:
        raise ValueError("Analyzer validation failed. Missing required fields: motivation")

    if not isinstance(task, BaseTask):
        raise TypeError(
            f"Task did not produce a BaseTask instance after construction."
        )

    resolved_program_text = program_text or ""
    if not resolved_program_text.strip():
        program_path = _resolve_program_path(
            candidate=candidate,
            evaluation_artifacts=evaluation_artifacts,
            task=task,
            name=name,
        )
        resolved_program_text = _load_program_text(program_path)

    safe_program_text = resolved_program_text.strip() or "Program text unavailable."

    db = create_client()
    ref_elements = db.get_analyse_elements(parent) or {}

    safe_name = original_name.strip()
    if not safe_name:
        raise ValueError("Analyzer validation failed. Missing required fields: name")

    resolved_eval_type = (
        eval_type
        or getattr(evaluation_artifacts, "eval_type", "")
        or getattr(Config, "FIRST_EVAL_TIER", "")
        or "unspecified"
    )
    resolved_task_context = task_context or task.get_analysis_context(resolved_eval_type)
    resolved_task_prompt = task_prompt or task.build_agent_prompt("analyzer")
    program_path = evaluation_artifacts.candidate_code_path or task.get_source_file_path(original_name)

    # Generate unique IDs for tool-based access
    session_id = uuid.uuid4().hex[:8]
    logs_id = f"analysis_{session_id}"
    code_id = f"code_{session_id}"
    ref_id = f"ref_{session_id}"

    # Store full content for tool access (instead of embedding in prompt)
    if evaluation_artifacts.logs:
        set_training_logs(logs_id, evaluation_artifacts.logs)

    # Store program code for tool access
    set_program_code(code_id, safe_program_text)

    # Store reference experiments for tool access (as dict, not formatted string)
    set_reference_experiments(ref_id, ref_elements)

    # Create brief summaries for the prompt
    code_summary = _create_code_summary(safe_program_text)
    ref_summary = _create_ref_summary(ref_elements)
    result_summary = result or _summarize_evaluation_artifacts(evaluation_artifacts, logs_id=logs_id)

    analysis_output = None
    last_error: Optional[Exception] = None
    try:
        for attempt in range(Config.MAX_RETRY_ATTEMPTS):
            try:
                analysis_result = await log_agent_run(
                    "analyzer",
                    analyzer,
                    name=safe_name,
                    motivation=safe_motivation,
                    ref_context="",  # No longer embedded, use tools
                    task=task,
                    eval_type=resolved_eval_type,
                    result=result_summary,
                    task_context=resolved_task_context,
                    program_file_path=program_path,
                    program_code="",  # No longer embedded, use tools
                    task_name=task.get_task_description(),
                    task_prompt=resolved_task_prompt,
                    # New: IDs and summaries for tool-based access
                    code_id=code_id,
                    ref_id=ref_id,
                    logs_id=logs_id,
                    code_summary=code_summary,
                    ref_summary=ref_summary,
                )
                analysis_output = getattr(analysis_result, "final_output", analysis_result)
                break
            except Exception as exc:  # pragma: no cover - runtime safety
                last_error = exc
                log_error(f"Analyzer error on attempt {attempt + 1}: {exc}")
                if isinstance(exc, ValueError):
                    raise
        else:
            raise AnalyzerExecutionError(
                f"Analyzer failed after {Config.MAX_RETRY_ATTEMPTS} attempts"
            ) from last_error
    finally:
        # Clean up all stored data
        clear_training_logs(logs_id)
        clear_program_code(code_id)
        clear_reference_experiments(ref_id)

    if analysis_output is None:
        raise RuntimeError("Analyzer did not return any output")

    paper_query = analysis_output.experimental_results_analysis
    paper_result = run_rag(query=paper_query) if paper_query else {"results": []}
    cognition = str(paper_result.get("results", ""))

    analysis_result = (
        analysis_output.design_evaluation
        + analysis_output.experimental_results_analysis
        + analysis_output.expectation_vs_reality_comparison
        + analysis_output.theoretical_explanation_with_evidence
        + analysis_output.synthesis_and_insights
    )

    # Extract challenges_addressed from Analyzer output (with fallback to empty list)
    challenges_addressed = getattr(analysis_output, "challenges_addressed", []) or []

    # Run Summarizer to synthesize experiment for long-term memory
    summary_text = ""
    try:
        summarizer_result = await log_agent_run(
            "summarizer",
            summarizer,
            response_model=SummarizerOutput,
            motivation=safe_motivation,
            analysis=analysis_result,
            cognition=cognition,
            task_prompt=resolved_task_prompt,
        )
        summary_output = getattr(summarizer_result, "final_output", summarizer_result)
        if summary_output:
            summary_text = getattr(summary_output, "summary", "")
            innovation_opps = getattr(summary_output, "innovation_opportunities", [])
            if innovation_opps:
                # Append innovation opportunities to cognition for future Planner guidance
                cognition += "\n\n## Innovation Opportunities for Next Generation\n"
                cognition += "\n".join(f"- {opp}" for opp in innovation_opps)
    except Exception as exc:
        log_error(f"Summarizer failed (non-blocking): {exc}")

    return DataElement(
        time=current_time,
        name=original_name,
        result=evaluation_artifacts.result,
        program=safe_program_text,
        motivation=safe_motivation,
        analysis=analysis_result,
        cognition=cognition,
        log=evaluation_artifacts.logs,
        parent=parent,
        task=task.__class__.__name__,
        architecture_keywords=task.get_task_keywords(),
        challenges_addressed=challenges_addressed,
        summary=summary_text,
    )
