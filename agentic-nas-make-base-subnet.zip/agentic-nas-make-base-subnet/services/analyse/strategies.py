from abc import ABC, abstractmethod
from typing import Dict, Any
from core.tasks.contracts import BaseTask

class BaseAnalysisStrategy(ABC):
    """Abstract base class for all analysis strategies."""

    @abstractmethod
    async def analyze(self, name: str, motivation: str, ref_context: str, task: BaseTask, eval_type: str) -> Dict[str, Any]:
        """
        Performs the analysis by fetching the correct data for the given eval_type
        and returns a dictionary payload for the Analyzer.
        """
        pass

class ZeroCostAnalysisStrategy(BaseAnalysisStrategy):
    """Analysis strategy for zero-cost NAS proxies."""
    async def analyze(self, name: str, motivation: str, ref_context: str, task: BaseTask, eval_type: str) -> Dict[str, Any]:
        try:
            result_path = task.get_result_file_path(name, eval_type)
            with open(result_path, "r") as f:
                result_content = f.read()
        except FileNotFoundError:
            result_content = f"Zero-cost proxy score file not found for '{name}' with eval_type '{eval_type}'."
        
        return {
            "analysis_type": "zero_cost",
            "content": result_content
        }

class TrainingCurveAnalysisStrategy(BaseAnalysisStrategy):
    """Analysis strategy for training curve extrapolation."""
    async def analyze(self, name: str, motivation: str, ref_context: str, task: BaseTask, eval_type: str) -> Dict[str, Any]:
        try:
            result_path = task.get_result_file_path(name, eval_type)
            with open(result_path, "r") as f:
                result_content = f.read()
        except FileNotFoundError:
            result_content = f"Training curve data not found for '{name}' with eval_type '{eval_type}'."
            
        return {
            "analysis_type": "training_curve",
            "content": result_content
        }

class SmallBudgetAnalysisStrategy(BaseAnalysisStrategy):
    """Analysis strategy for small budget which includes training curve and test results."""
    async def analyze(self, name: str, motivation: str, ref_context: str, task: BaseTask, eval_type: str) -> Dict[str, Any]:
        try:
            train_result_path = task.get_result_file_path(name, eval_type)
            with open(train_result_path, "r") as f:
                train_result = f.read()
        except FileNotFoundError:
            train_result = f"Train result file for '{eval_type}' eval not found."
        
        try:
            test_result_path = task.get_test_result_file_path(name, eval_type)
            with open(test_result_path, "r") as f:
                test_result = f.read()
        except FileNotFoundError:
            test_result = f"Test result file for '{eval_type}' eval not found."

        return {
            "analysis_type": "small_budget",
            "train_result": train_result,
            "test_result": test_result
        }

class FullTrainingAnalysisStrategy(BaseAnalysisStrategy):
    """The default, comprehensive analysis for a full train/test cycle."""
    async def analyze(self, name: str, motivation: str, ref_context: str, task: BaseTask, eval_type: str) -> Dict[str, Any]:
        try:
            train_result_path = task.get_result_file_path(name, eval_type)
            with open(train_result_path, "r") as f:
                train_result = f.read()
        except FileNotFoundError:
            train_result = "Train result file for 'full' eval not found."
        
        try:
            test_result_path = task.get_test_result_file_path(name, eval_type)
            with open(test_result_path, "r") as f:
                test_result = f.read()
        except FileNotFoundError:
            test_result = "Test result file for 'full' eval not found."

        return {
            "analysis_type": "full_training",
            "train_result": train_result,
            "test_result": test_result
        }

def get_analysis_strategy(eval_type: str) -> BaseAnalysisStrategy:
    """Factory function to get the appropriate analysis strategy."""
    if eval_type == "zero_cost":
        return ZeroCostAnalysisStrategy()
    elif eval_type == "curve_extrapolation":
        return TrainingCurveAnalysisStrategy()
    elif eval_type == "small_budget":
        return SmallBudgetAnalysisStrategy()
    elif eval_type == "large_budget" or eval_type == "full":
        return FullTrainingAnalysisStrategy()
    else:
        print(f"Warning: Unknown eval_type '{eval_type}', using returning False")
        return False
