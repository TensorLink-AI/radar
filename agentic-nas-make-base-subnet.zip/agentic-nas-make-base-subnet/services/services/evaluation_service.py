import os
import uuid
import asyncio
import functools
from typing import Dict, Any, Optional
from services.config import Config
from core.tasks.contracts import BaseTask
from services.utils.agent_logger import log_error

class EvaluationService:
    """Encapsulates all evaluation logic."""
    def __init__(self, loop=None):
        self.loop = loop or asyncio.get_running_loop()

    async def _run_in_executor(self, a_callable, *args, **kwargs):
        """Helper to run a synchronous function in an executor."""
        return await self.loop.run_in_executor(None, functools.partial(a_callable, *args, **kwargs))

    async def run_evaluation(
        self,
        task: BaseTask,
        program_code: str,
        eval_type: str,
        budget_override: Optional[dict] = None,
    ) -> Optional[Dict[str, Any]]:
        """
        Runs a full train-and-evaluation process for a given program and task
        in a sandboxed environment.
        """
        run_id = f"{task.__class__.__name__}_{eval_type}_{uuid.uuid4().hex[:8]}"
        run_dir = os.path.join(Config.EVAL_RUNS_DIR, run_id)
        os.makedirs(run_dir, exist_ok=True)
        
        candidate_code_path = os.path.join(run_dir, "candidate_code.py")
        with open(candidate_code_path, "w") as f:
            f.write(program_code)
            
        try:
            # Build datasets in a separate process
            datasets = await self._run_in_executor(task.build_datasets, budget_override or {})

            # Run training and evaluation in a separate process
            eval_results = await self._run_in_executor(
                task.train_and_eval,
                candidate_code_path=candidate_code_path,
                datasets=datasets,
                run_dir=run_dir,
                eval_type=eval_type,
            )
            return eval_results
            
        except Exception as e:
            log_error(f"Evaluation failed for run_id {run_id}: {e}")
            return None
        finally:
            # Clean up the run directory
            # shutil.rmtree(run_dir)
            pass
