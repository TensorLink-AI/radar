from typing import Optional
from services.utils.agent_logger import log_info, log_error
from core.tasks.registry import get_task
from .database_service import DatabaseService
from .evaluation_service import EvaluationService
# Use simplified agents (following "The Bitter Lesson of Agent Frameworks")
from services.providers.agents import Analyzer

class PromotionService:
    """Orchestrates promoting top-k candidates to deeper evaluation tiers."""
    def __init__(
        self,
        db_service: DatabaseService,
        eval_service: EvaluationService,
        analyzer: Analyzer
    ):
        self.db_service = db_service
        self.eval_service = eval_service
        self.analyzer = analyzer

    async def promote_task_top_k(
        self,
        task_name: str,
        source_eval_type: str,
        target_eval_type: str,
        k: int = 10,
        budget: Optional[dict] = None,
    ) -> int:
        """Pulls top-k based on source_eval_type and promotes them."""
        log_info(f"[Promote] Finding top {k} for '{task_name}' based on '{source_eval_type}' results.")
        elems = self.db_service.get_top_k_for_task(task_name, k=k, eval_type_filter=source_eval_type)
        
        task = get_task(task_name)()
        promoted_count = 0

        for e in elems:
            evals = (e.result or {}).get("evals", {})
            if any(key.startswith(target_eval_type + "@") for key in evals.keys()):
                continue

            if not getattr(e, "program", None):
                continue

            payload = await self.eval_service.run_evaluation(
                task=task,
                program_code=e.program,
                eval_type=target_eval_type,
                budget_override=budget or {},
            )
            if payload is None:
                continue

            ok = self.db_service.append_eval(index=e.index, eval_type=target_eval_type, payload=payload)
            if ok:
                promoted_count += 1
                log_info(f"[Promote] Successfully promoted index={e.index} ({e.name}).")
        
        return promoted_count
