from typing import Dict, Any, List, Optional
from datetime import datetime, timezone
from services.database.mongo_database import create_client
from services.database.element import DataElement

class DatabaseService:
    """Encapsulates all database persistence logic."""
    def __init__(self, db_instance=None):
        self.db = db_instance or create_client()

    def append_eval(self, index: int, eval_type: str, payload: Dict[str, Any]) -> bool:
        """Appends one eval payload under result.evals.<eval_id>."""
        eval_id = f"{eval_type}@{datetime.now(timezone.utc).isoformat()}"
        patch = {
            f"result.evals.{eval_id}": payload,
            "result.completed_eval_types": {"$addToSet": eval_type}
        }
        return self.db.update_fields(index=index, patch=patch)

    def get_top_k_for_task(
        self,
        task_name: str,
        k: int = 10,
        eval_type_filter: Optional[str] = None
    ) -> List[DataElement]:
        """
        Finds the top k elements for a task, optionally sorting by the
        objective of a specific evaluation type.
        """
        all_results = self.db.get_top_k_results(k=10_000)
        task_results = [e for e in all_results if getattr(e, "task", None) == task_name]

        if not eval_type_filter:
            return sorted(task_results, key=lambda e: e.index, reverse=True)[:k]

        candidates_with_eval = []
        for e in task_results:
            evals = (e.result or {}).get("evals", {})
            target_eval = next((p for k, p in evals.items() if k.startswith(eval_type_filter + "@")), None)
            if target_eval and "objective" in target_eval:
                candidates_with_eval.append((e, target_eval))

        try:
            sorted_candidates = sorted(
                candidates_with_eval,
                key=lambda item: item[1]["objective"],
                reverse=True
            )
        except (TypeError, KeyError):
            return []

        return [element for element, payload in sorted_candidates][:k]
