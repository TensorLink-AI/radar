"""
Concurrent multi-model harness generator.

Builds a standalone Python script that loads N candidate models and
trains them all concurrently on a single GPU using CUDA streams
round-robin scheduling (via ``core.training.stream_trainer``).

The generated script assumes the Docker image contains ``core/``
on its ``PYTHONPATH`` (same as the single-model harness from
:mod:`services.packager`).

Usage::

    from services.packager_concurrent import build_concurrent_harness

    harness = build_concurrent_harness(
        task_def=my_task.definition,
        candidate_codes=["code_a", "code_b", "code_c"],
        eval_type="small_budget",
    )
    # harness is a string -- write to file and execute on Basilica pod
"""

from __future__ import annotations

import json
import textwrap
from typing import List, Optional

from core.tasks.contracts import TaskDefinition


def build_concurrent_harness(
    task_def: TaskDefinition,
    candidate_codes: List[str],
    eval_type: str = "small_budget",
    *,
    timeout_sec: Optional[int] = None,
    sync_frequency: int = 10,
    log_frequency: int = 100,
) -> str:
    """Generate a standalone script that trains N candidates concurrently.

    The output script:

    1. Writes each candidate to a temp file.
    2. Loads each via ``instantiate_candidate()``.
    3. Builds shared data loaders (all models use the same data).
    4. Calls ``train_models_concurrent()`` from
       ``core.training.stream_trainer``.
    5. Writes per-model JSON results to ``<run_dir>/results.json``.

    Args:
        task_def: Declarative task configuration.
        candidate_codes: Raw Python source for each candidate model.
        eval_type: ``"zero_cost"`` | ``"small_budget"`` | ``"large_budget"``.
        timeout_sec: Override for total wall-clock budget.
        sync_frequency: CUDA stream sync interval (steps).
        log_frequency: Console log interval (round-robin rounds).

    Returns:
        A complete Python script as a string.
    """
    if eval_type == "zero_cost":
        max_steps = 0
        budget_timeout = timeout_sec or task_def.zero_cost_timeout_sec
    elif eval_type == "large_budget":
        max_steps = task_def.large_budget_steps
        budget_timeout = timeout_sec or task_def.large_budget_timeout_sec
    else:
        max_steps = task_def.small_budget_steps
        budget_timeout = timeout_sec or task_def.small_budget_timeout_sec

    # Serialize candidate codes as a JSON list
    candidates_escaped = json.dumps(candidate_codes)
    split_map_escaped = json.dumps(task_def.hf_split_map)
    model_base_module = json.dumps(task_def.model_base_module)

    harness = textwrap.dedent(f"""\
        #!/usr/bin/env python3
        \"\"\"Auto-generated concurrent training harness for task: {task_def.name}
        Models: {len(candidate_codes)} candidates trained via CUDA streams.\"\"\"

        import importlib, json, os, signal, sys, tempfile, time, traceback

        # ── Candidate codes ─────────────────────────────────────────
        _CANDIDATE_CODES = {candidates_escaped}
        _NUM_MODELS = len(_CANDIDATE_CODES)

        # ── Config from TaskDefinition ──────────────────────────────
        TASK_NAME        = {json.dumps(task_def.name)}
        HF_REPO_ID       = {json.dumps(task_def.hf_repo_id)}
        SPLIT_MAP        = {split_map_escaped}
        MAX_STEPS        = {max_steps}
        EVAL_TYPE        = {json.dumps(eval_type)}
        TIMEOUT_SEC      = {budget_timeout}
        MODEL_BASE_MOD   = {model_base_module}
        MAX_PARAMS       = {task_def.max_params}
        SYNC_FREQUENCY   = {sync_frequency}
        LOG_FREQUENCY    = {log_frequency}

        # ── Deadline handling ───────────────────────────────────────
        _DEADLINE = time.time() + TIMEOUT_SEC
        _shutdown = False

        def _handle_sigterm(*_):
            global _shutdown
            _shutdown = True

        signal.signal(signal.SIGTERM, _handle_sigterm)

        def _time_remaining():
            return max(0, _DEADLINE - time.time())

        # ── Main ────────────────────────────────────────────────────
        def main():
            import argparse
            parser = argparse.ArgumentParser()
            parser.add_argument("--run-dir", default="/tmp/concurrent-train")
            parser.add_argument("--timeout-sec", type=float, default=TIMEOUT_SEC)
            parser.add_argument("--validation-buffer-sec", type=float, default=300)
            args = parser.parse_args()

            run_dir = args.run_dir
            os.makedirs(run_dir, exist_ok=True)

            import torch
            from core.models.base_contract import instantiate_candidate
            from core.training.universal_trainer import TrainingConfig
            from core.training.stream_trainer import (
                ConcurrentTrainingSpec,
                train_models_concurrent,
            )
            from core.training.universal_evaluator import count_parameters

            device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

            # 1. Load all candidate models
            models = []
            candidate_paths = []
            for i, code in enumerate(_CANDIDATE_CODES):
                path = os.path.join(run_dir, f"candidate_{{i}}.py")
                with open(path, "w") as f:
                    f.write(code)
                candidate_paths.append(path)

                try:
                    model = instantiate_candidate(path, device)
                    n_params = count_parameters(model)
                    print(f"Model {{i}}: {{n_params:,}} params")
                    if n_params > MAX_PARAMS:
                        print(f"Model {{i}}: exceeds param limit ({{n_params}} > {{MAX_PARAMS}})")
                        models.append(None)
                    else:
                        models.append(model)
                except Exception as exc:
                    print(f"Model {{i}}: failed to load: {{exc}}")
                    models.append(None)

            # 2. Build shared data loaders
            row_to_sample = _load_row_converter()
            from core.data.hf_streaming import build_hf_dataloaders
            bundle = build_hf_dataloaders(
                hf_repo_id=HF_REPO_ID,
                row_to_sample=row_to_sample,
                batch_size=32,
                train_split=SPLIT_MAP.get("train", "train"),
                val_split=SPLIT_MAP.get("val", "validation"),
                test_split=SPLIT_MAP.get("test"),
                shuffle_buffer_size=1000,
            )

            # 3. Load task-specific functions
            loss_fn, eval_fn, forward_fn = _load_task_functions()

            # 4. Build training specs for valid models
            specs = []
            spec_to_model_idx = []  # maps spec index -> original model index
            for i, model in enumerate(models):
                if model is None:
                    continue
                model_run_dir = os.path.join(run_dir, f"model_{{i}}")
                os.makedirs(model_run_dir, exist_ok=True)
                spec = ConcurrentTrainingSpec(
                    model=model,
                    train_loader=bundle.train,
                    loss_fn=loss_fn,
                    config=TrainingConfig(
                        max_steps=MAX_STEPS,
                        device=str(device),
                    ),
                    val_loader=bundle.val,
                    eval_fn=eval_fn,
                    forward_fn=forward_fn,
                    run_dir=model_run_dir,
                    eval_type=EVAL_TYPE,
                    label=f"model_{{i}}",
                )
                specs.append(spec)
                spec_to_model_idx.append(i)

            if not specs:
                print("No valid models to train")
                _write_results(run_dir, [])
                return

            # 5. Train all models concurrently
            results = train_models_concurrent(
                specs,
                sync_frequency=SYNC_FREQUENCY,
                log_frequency=LOG_FREQUENCY,
                device=device,
            )

            # 6. Build per-model results
            all_results = [None] * _NUM_MODELS
            for spec_idx, result in enumerate(results):
                model_idx = spec_to_model_idx[spec_idx]
                all_results[model_idx] = result.metrics

            _write_results(run_dir, all_results)


        def _write_results(run_dir, all_results):
            \"\"\"Write results to JSON file for the runner to read.\"\"\"
            results_path = os.path.join(run_dir, "results.json")
            output = {{
                "batch_results": all_results,
                "num_models": _NUM_MODELS,
            }}
            with open(results_path, "w") as f:
                json.dump(output, f, indent=2, default=float)
            # Also print to stdout for the runner
            print(json.dumps(output, default=float))


        def _load_row_converter():
            \"\"\"Try to import row_to_sample from the task's model_base module.\"\"\"
            if MODEL_BASE_MOD:
                try:
                    mod = importlib.import_module(MODEL_BASE_MOD)
                    if hasattr(mod, "row_to_sample"):
                        return mod.row_to_sample
                except ImportError:
                    pass
            return lambda row: row


        def _load_task_functions():
            \"\"\"Try to import loss_fn, eval_fn, forward_fn from model_base module.\"\"\"
            loss_fn = eval_fn = forward_fn = None
            if MODEL_BASE_MOD:
                try:
                    mod = importlib.import_module(MODEL_BASE_MOD)
                    loss_fn = getattr(mod, "loss_fn", None)
                    eval_fn = getattr(mod, "eval_fn", None)
                    forward_fn = getattr(mod, "forward_fn", None)
                except ImportError:
                    pass
            if loss_fn is None:
                raise RuntimeError(
                    f"Task '{{TASK_NAME}}' model_base_module '{{MODEL_BASE_MOD}}' "
                    "must export a loss_fn(output, batch, device) callable."
                )
            return loss_fn, eval_fn, forward_fn


        if __name__ == "__main__":
            try:
                main()
            except Exception:
                traceback.print_exc()
                sys.exit(1)
    """)

    return harness
