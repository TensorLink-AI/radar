from typing import Any, Dict, List, Optional, Protocol, runtime_checkable

Messages = List[Dict[str, Any]]

@runtime_checkable
class LLMClient(Protocol):
    async def chat(
        self,
        *,
        model: Optional[str],
        messages: Messages,
        temperature: Optional[float] = None,
        tools: Optional[List[Dict[str, Any]]] = None,
        tool_choice: Optional[str] = "auto",
        extra: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """
        Send the conversation to the provider and return the RAW provider response.
        The raw response SHOULD include usage info if the provider supports it.
        If temperature is None, the client should use its default temperature.
        """
        ...

    @staticmethod
    def normalize(resp_json: Dict[str, Any]) -> Dict[str, Any]:
        """
        Normalize provider response into:
        {
            "text_response": str,
            "tool_calls": Optional[List[{
                "id": str,
                "type": "function",
                "function": {
                    "name": str,
                    "arguments": str  # JSON string from the model
                }
            }]]
        }
        """
        choice = (resp_json.get("choices") or [{}])[0]
        msg = choice.get("message") or {}
        text = msg.get("content") or ""
        tool_calls = None

        if msg.get("tool_calls"):
            tool_calls = []
            for i, tc in enumerate(msg["tool_calls"]):
                fn = tc.get("function") or {}
                tool_calls.append({
                    "id": tc.get("id", f"call_{i}"),
                    "type": tc.get("type", "function"),
                    "function": {
                        "name": fn.get("name"),
                        "arguments": fn.get("arguments", "{}"),
                    },
                })

        return {
            "text_response": text,
            "tool_calls": tool_calls,
        }

    # --- These attributes/methods enable logging + usage accounting ---

    last_usage: Optional[Dict[str, Any]]
    """
    Most recent usage struct from provider, e.g.:
    {
        "prompt_tokens": int,
        "completion_tokens": int,
        "total_tokens": int
    }
    We'll coerce these to input_tokens/output_tokens later.
    """

    history: List[Dict[str, Any]]
    """
    List of raw provider responses across turns.
    Used for debugging and full audit logs.
    """

    last_response: Optional[Dict[str, Any]]
    """
    The most recent raw provider response.
    """

    async def aclose(self) -> None:
        """
        Optional async cleanup hook. Close HTTP sessions, etc.
        It's OK if this is a no-op in simple clients.
        """
        ...
