"""Agent configuration models for provider-backed agents."""
from __future__ import annotations

import os
from enum import Enum
from typing import List, Optional

from pydantic import BaseModel, Field


def get_agent_model(agent_name: str) -> Optional[str]:
    """Get the model name for a specific agent.

    Checks for an agent-specific environment variable first (e.g., PLANNER_MODEL),
    then falls back to the global MODEL_NAME.

    Args:
        agent_name: Name of the agent (e.g., "planner", "debugger", "analyzer")

    Returns:
        Model name string, or None if neither env var is set.

    Example:
        export PLANNER_MODEL=deepseek-ai/DeepSeek-V3
        export MODEL_NAME=meta-llama/Llama-4-Scout-17B-16E-Instruct

        get_agent_model("planner")  # Returns "deepseek-ai/DeepSeek-V3"
        get_agent_model("debugger") # Returns "meta-llama/Llama-4-Scout-17B-16E-Instruct"
    """
    agent_env_var = f"{agent_name.upper()}_MODEL"
    return os.getenv(agent_env_var) or os.getenv("MODEL_NAME")


class ToolPolicy(str, Enum):
    """Policy for when tools should be available to the agent.

    ONCE: Tools available only on the first round, then disabled.
    UNTIL_JSON: Tools available on every turn until final JSON is produced.
    ALWAYS: Tools always available (even after final JSON - use with caution).
    """

    ONCE = "once"
    UNTIL_JSON = "until_json"
    ALWAYS = "always"


class AgentConfig(BaseModel):
    """Centralized configuration for :class:`ProviderAgent` behavior.

    The previous implementation relied on a large number of ``__init__`` keyword
    arguments, which made it error-prone for subclasses to customize behavior.
    ``AgentConfig`` collects every behavioral flag and limit in one place so the
    agent orchestration code can simply consume ``self.config``.

    ``ProviderAgent`` accepts either an ``AgentConfig`` instance or keyword
    overrides which will be fed into this model. Subclasses can define a default
    ``config`` and use ``model_copy(update=...)`` to tweak only the fields they
    care about.
    """

    max_turns: int = Field(8, description="Maximum model turns before aborting")
    max_tool_rounds: int = Field(4, description="Maximum tool rounds allowed")
    max_tool_calls_per_round: int = Field(
        8, description="Maximum tool calls executed within a single round"
    )
    max_tool_calls_total: int = Field(
        32, description="Total tool call budget across the run"
    )

    require_write_code: bool = Field(
        False,
        description="Require the agent to call write_code_file before finalizing",
    )

    temperature: float = Field(0.0, description="LLM temperature")
    tool_choice: Optional[str] = Field(
        "auto", description="Tool choice policy for the underlying provider"
    )
    debug_payload: bool = Field(
        False, description="Emit structured debug payloads for each LLM call"
    )

    tool_policy: ToolPolicy = Field(
        ToolPolicy.UNTIL_JSON,
        description="Policy for when tools should be available (ONCE, UNTIL_JSON, ALWAYS)",
    )
    require_tools: bool = Field(
        False, description="Require the model to call at least one tool"
    )

    force_json_after_tools: bool = Field(
        True, description="Force JSON mode after the tool phase"
    )
    force_json_initial_if_response_model: bool = Field(
        False,
        description="Force JSON mode even before tools if a response model exists",
    )

    coerce_sloppy_output: bool = Field(
        False,
        description=(
            "Coerce sloppy LLM output to expected types (e.g., 'true' -> True, "
            "'123' -> 123, '' -> []). Enable only if LLM outputs are unreliable."
        ),
    )

    required_tools_before_final: List[str] = Field(
        default_factory=list,
        description="List of tool names that must be executed before the agent can finalize",
    )

    def with_env_overrides(self) -> "AgentConfig":
        """Apply optional environment overrides for operational limits."""
        import os

        updates = {}
        if env_rounds := os.getenv("AGENT_MAX_TOOL_ROUNDS"):
            updates["max_tool_rounds"] = int(env_rounds)
        if env_per_round := os.getenv("AGENT_MAX_TOOL_CALLS_PER_ROUND"):
            updates["max_tool_calls_per_round"] = int(env_per_round)
        if env_total := os.getenv("AGENT_MAX_TOOL_CALLS_TOTAL"):
            updates["max_tool_calls_total"] = int(env_total)
        if env_temperature := os.getenv("AGENT_TEMPERATURE"):
            updates["temperature"] = float(env_temperature)
        if not updates:
            return self
        copier = getattr(self, "model_copy", None)
        if callable(copier):
            return copier(update=updates)
        return self.copy(update=updates)  # type: ignore[call-arg]
