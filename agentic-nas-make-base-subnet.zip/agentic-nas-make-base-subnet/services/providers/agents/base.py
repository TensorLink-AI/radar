# services/providers/agents/base.py
"""
Base utilities for simplified agents.

Following "The Bitter Lesson of Agent Frameworks":
- Simple for-loop until done() is called
- But PRESERVE the rich prompt engineering from original agents
- Context injection is important - models need good context
"""

from __future__ import annotations

import os
import json
import difflib
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Sequence, Tuple, Type

from pydantic import BaseModel

from services.providers.simple_agent import (
    SimpleAgent,
    tool,
    TaskComplete,
    ChutesAdapter,
)
from services.providers.clients.chutes_client import ChutesClient
from services.config import Config


# ============================================================================
# Common utilities
# ============================================================================

Section = Tuple[str, str]


def format_sections(sections: Sequence[Section]) -> str:
    """Render helper sections into markdown the LLM can follow."""
    formatted: List[str] = []
    for title, body in sections:
        if not body:
            continue
        formatted.append(f"## {title.strip()}\n{body.strip()}\n")
    return "\n".join(formatted)


def resolve_task_fragments(
    fragments: Optional[Dict[str, Any]], channel: str
) -> Dict[str, str]:
    """
    Extract task prompt fragments for a given channel.

    fragments structure:
    {
        "rewrite": {"task_objective": ..., "task_constraints": ..., ...},
        "user": {"task_objective": ..., "task_constraints": ..., ...},
    }
    """
    if not fragments:
        return {}
    channel_data = fragments.get(channel, {})
    if not isinstance(channel_data, dict):
        return {}
    return channel_data


def format_task_template(template: str, fragments: Optional[Dict], channel: str) -> str:
    """Format a template string with task fragments."""
    resolved = resolve_task_fragments(fragments, channel)
    # Build substitution dict with defaults
    subs = {
        "task_role": resolved.get("task_role", "neural architecture design"),
        "task_objective": resolved.get("task_objective", "Improve model performance"),
        "task_constraints": resolved.get("task_constraints", "Follow best practices"),
        "task_success_criteria": resolved.get("task_success_criteria", "Better metrics"),
    }
    try:
        return template.format(**subs)
    except KeyError:
        # If template has placeholders we don't have, return as-is
        return template


# ============================================================================
# LLM Client Factory
# ============================================================================

def get_llm(model_name: Optional[str] = None) -> ChutesAdapter:
    """Get an LLM client adapter."""
    return ChutesAdapter(
        ChutesClient(),
        model_name or os.getenv("MODEL_NAME", ""),
    )


# ============================================================================
# Common Tools
# ============================================================================

def make_read_file_tool(ephemeral: int = 2) -> Callable:
    """Create a file reading tool with ephemeral support."""
    read_schema = {
        "type": "object",
        "properties": {
            "file_path": {
                "type": "string",
                "description": "Path to the file to read"
            }
        },
        "required": ["file_path"],
    }
    @tool("Read a code file", ephemeral=ephemeral, schema=read_schema)
    def read_file(file_path: str) -> str:
        """Read and return file contents."""
        path = Path(file_path)
        if not path.exists():
            return f"Error: File not found: {file_path}"
        return path.read_text(encoding="utf-8", errors="replace")
    return read_file


def make_write_file_tool() -> Callable:
    """Create a file writing tool."""
    write_schema = {
        "type": "object",
        "properties": {
            "file_path": {
                "type": "string",
                "description": "Path to the file to write"
            },
            "content": {
                "type": "string",
                "description": "The complete file content to write"
            }
        },
        "required": ["file_path", "content"],
    }
    @tool("Write code to a file", schema=write_schema)
    def write_file(file_path: str, content: str) -> str:
        """Write content to file. Returns confirmation with diff."""
        path = Path(file_path)
        path.parent.mkdir(parents=True, exist_ok=True)

        # Calculate diff if file exists
        original = ""
        if path.exists():
            original = path.read_text(encoding="utf-8", errors="replace")

        # Strip markdown fences if present
        clean_content = content.strip()
        if clean_content.startswith("```"):
            lines = clean_content.splitlines()
            if lines:
                lines = lines[1:]
            if lines and lines[-1].strip() == "```":
                lines = lines[:-1]
            clean_content = "\n".join(lines)

        path.write_text(clean_content, encoding="utf-8")

        # Generate diff
        if original != clean_content:
            diff_lines = list(difflib.unified_diff(
                original.splitlines(),
                clean_content.splitlines(),
                fromfile=f"{file_path} (original)",
                tofile=f"{file_path} (updated)",
                lineterm="",
            ))
            diff_preview = "\n".join(diff_lines[:50])
            if len(diff_lines) > 50:
                diff_preview += f"\n... ({len(diff_lines) - 50} more lines)"
            return f"Wrote {len(clean_content)} bytes to {file_path}\n\nDiff:\n{diff_preview}"
        return f"Wrote {len(clean_content)} bytes to {file_path} (no changes)"
    return write_file


def get_source_file(override: Optional[str] = None) -> str:
    """Get the target source file path."""
    candidate = override or getattr(Config, "SOURCE_FILE", "")
    if not candidate:
        raise ValueError("SOURCE_FILE not configured")
    return candidate


# ============================================================================
# Base wrapper for backwards compatibility
# ============================================================================

class BaseAgentWrapper:
    """
    Base class for backwards-compatible agent wrappers.

    Provides:
    - last_messages tracking for logging
    - Common initialization
    """

    name: str = "Base Agent"

    def __init__(self, model_name: Optional[str] = None, **kwargs):
        self.model_name = model_name
        self.last_messages: List[Dict] = []
        self._kwargs = kwargs

    def _build_prompt_sections(self, **kwargs) -> List[Section]:
        """Override in subclasses to build context sections."""
        return []

    def _get_instructions(self) -> str:
        """Override in subclasses to return system instructions."""
        return "You are a helpful assistant."
