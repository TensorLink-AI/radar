# services/providers/agents/summarizer.py
"""
Simplified Summarizer agent with preserved detailed prompts.
"""

from __future__ import annotations

from typing import List, Optional, Type

from pydantic import BaseModel, Field

from services.providers.simple_agent import SimpleAgent, tool, TaskComplete

from .base import (
    BaseAgentWrapper,
    Section,
    format_sections,
    resolve_task_fragments,
    get_llm,
)


class SummarizerOutput(BaseModel):
    summary: str
    innovation_opportunities: List[str] = Field(default_factory=list)


# Preserved detailed instructions from original summarizer.py
SUMMARIZER_INSTRUCTIONS = """# Experience Synthesis Task

You are the "Long-Term Memory" of the architecture search. Your goal is to synthesize the results of the latest experiment into a concise but deep strategic summary that will guide the NEXT generation of the Planner.

## Synthesis Requirements

1. **Root Cause Diagnosis**:
   - Trace performance limitations to specific architectural design choices.
   - Did the results match the theoretical design motivation?

2. **Innovation Opportunity Identification**:
   - What research directions are most promising for addressing the observed limitations?
   - What specifically should be PRESERVED vs. MODIFIED in the next iteration?

After completing synthesis, call finish() with:
- summary: A comprehensive narrative summary (3-4 paragraphs) integrating performance patterns and theoretical validation.
- innovation_opportunities: A list of 3-5 concrete, actionable architectural directions for the Planner to try next.
"""


def create_summarizer(model_name: Optional[str] = None) -> SimpleAgent:
    """Create a Summarizer agent."""
    finish_schema = {
        "type": "object",
        "properties": {
            "summary": {
                "type": "string",
                "description": "Comprehensive narrative summary (3-4 paragraphs) integrating performance patterns and theoretical validation"
            },
            "innovation_opportunities": {
                "type": "array",
                "items": {"type": "string"},
                "description": "List of 3-5 concrete, actionable architectural directions for the Planner to try next"
            }
        },
        "required": ["summary"],
    }

    @tool("Complete summary", schema=finish_schema)
    def finish(summary: str, innovation_opportunities: list = None) -> None:
        """Call with synthesis result."""
        raise TaskComplete(SummarizerOutput(
            summary=summary,
            innovation_opportunities=innovation_opportunities or [],
        ))

    return SimpleAgent(
        llm=get_llm(model_name),
        instructions=SUMMARIZER_INSTRUCTIONS,
        tools=[finish],
        max_iterations=15,  # Increased for reasoning models that "think" before tool calls
        max_text_only_responses=10,  # Allow reasoning before requiring tool use
        include_done_tool=False,
    )


class Summarizer(BaseAgentWrapper):
    """
    Backwards-compatible Summarizer wrapper with full context injection.
    """

    name = "Experience Summarizer"

    async def run(
        self,
        user_prompt: str = "",
        response_model: Type[BaseModel] = None,
        **kwargs,
    ) -> SummarizerOutput:
        motivation = kwargs.get("motivation", "")
        analysis = kwargs.get("analysis", "")
        cognition = kwargs.get("cognition", "")
        task_prompt = kwargs.get("task_prompt", "")
        task_prompt_fragments = kwargs.get("task_prompt_fragments")

        # Build context sections
        sections = self._build_prompt_sections(
            motivation=motivation,
            analysis=analysis,
            cognition=cognition,
            task_prompt=task_prompt,
            task_prompt_fragments=task_prompt_fragments,
        )

        prompt = format_sections(sections)

        agent = create_summarizer(self.model_name)
        result = await agent.run(prompt)
        return result

    def _build_prompt_sections(
        self,
        motivation: str = "",
        analysis: str = "",
        cognition: str = "",
        task_prompt: str = "",
        task_prompt_fragments: Optional[dict] = None,
        **kwargs,
    ) -> List[Section]:
        """Build context sections - preserved from original Summarizer._prepare_user_prompt."""
        sections: List[Section] = []
        fragments = resolve_task_fragments(task_prompt_fragments, "user")

        # 1. Inject Task Context (Standard Protocol)
        if task_prompt.strip():
            sections.append(("Task Contract", task_prompt))
        elif fragments.get("task_objective"):
            sections.append(("Task Objective", fragments["task_objective"]))

        # 2. Inject Experiment Data
        if motivation:
            sections.append(("Design Motivation", motivation))
        if analysis:
            sections.append(("Performance Analysis", analysis))
        if cognition:
            sections.append(("Available Research Cognition", cognition))

        # 3. Response Requirements
        sections.append((
            "Final Response Requirements",
            "Call finish() with 'summary' and 'innovation_opportunities' based on the synthesis requirements."
        ))

        return sections
