# services/providers/agents/__init__.py
"""
Validator-side agents following "The Bitter Lesson of Agent Frameworks".

Miner-side agents (Planner, CodeChecker, Debugger, etc.) have moved to
miner.providers.agents.
"""

# Output models
from services.providers.agents.analyzer import AnalyzerOutput
from services.providers.agents.summarizer import SummarizerOutput
from services.providers.agents.judger import JudgerOutput

# Wrapper classes
from services.providers.agents.analyzer import Analyzer
from services.providers.agents.summarizer import Summarizer
from services.providers.agents.judger import Judger

# Factory functions
from services.providers.agents.analyzer import create_analyzer
from services.providers.agents.summarizer import create_summarizer
from services.providers.agents.judger import create_judger

# Base utilities (shared by both validator and miner agents)
from services.providers.agents.base import (
    format_sections,
    resolve_task_fragments,
    format_task_template,
    get_llm,
    get_source_file,
    make_read_file_tool,
    make_write_file_tool,
)

__all__ = [
    # Output models
    "AnalyzerOutput",
    "SummarizerOutput",
    "JudgerOutput",
    # Wrapper classes
    "Analyzer",
    "Summarizer",
    "Judger",
    # Factory functions
    "create_analyzer",
    "create_summarizer",
    "create_judger",
    # Utilities
    "format_sections",
    "resolve_task_fragments",
    "format_task_template",
    "get_llm",
    "get_source_file",
    "make_read_file_tool",
    "make_write_file_tool",
]
