# services/providers/agents/analyzer.py
"""
Simplified Analyzer agent with preserved detailed prompts.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional, Type

from pydantic import BaseModel, Field

from services.providers.simple_agent import SimpleAgent, tool, TaskComplete

from .base import (
    BaseAgentWrapper,
    Section,
    format_sections,
    get_llm,
    make_read_file_tool,
)


class AnalyzerOutput(BaseModel):
    design_evaluation: str
    experimental_results_analysis: str
    expectation_vs_reality_comparison: str
    theoretical_explanation_with_evidence: str
    synthesis_and_insights: str
    challenges_addressed: List[str] = Field(default_factory=list)


# Default fallback for tasks without challenge context
DEFAULT_CHALLENGE_CONTEXT = "Tag any key design challenges this experiment addressed based on the task domain."

# Preserved detailed instructions from original analyzer.py
ANALYZER_INSTRUCTIONS_BASE = """You are an expert AI architecture researcher specializing in long-range sequence modeling experiments. Every response must combine quantitative evidence, code-level citations, and motivation alignment.

You will receive task-owned context (metric definitions, baselines, rubrics), experimental logs, and motivation notes. Use the read_file tool to inspect the code implementation when needed for code-level analysis. Treat the task contract as the governing spec.

ANALYSIS APPROACH:
1. **Task Context Assimilation** – Summarize the provided rubric so the reader sees the grading curve.
2. **Ablation & Genealogy (CRITICAL)** – Compare this experiment to its parent/reference.
   - **Isolation**: Which specific code change caused the performance delta?
   - **Validation**: Did the change achieve the theoretical effect predicted in the Motivation?
   - **Trade-offs**: What was gained vs. lost (e.g., speed vs. memory)?
3. **Result Examination** – Parse the supplied training/eval outputs, call out percentage deltas vs. baseline rows, and highlight instability, convergence, or compute anomalies.
4. **Code Review** – Use read_file to inspect the implementation file and identify the concrete mechanisms responsible for the observed behavior.
5. **Motivation Cross-Check** – Compare the intended innovation with what actually shipped in code and with how it performed empirically.

OUTPUT REQUIREMENTS (deliver each section explicitly):
1. **Motivation and Design Evaluation** → `design_evaluation` field – Discuss theoretical soundness, implementation fidelity, and contract compliance.
2. **Experimental Results Analysis** → `experimental_results_analysis` field – Use the metric descriptions to interpret evaluation signals. Quantify gains/losses relative to baselines.
3. **Expectation vs. Reality** → `expectation_vs_reality_comparison` field – Tie each promised capability to its measured outcome, flag unexpected regressions.
4. **Theoretical Explanation with Evidence** → `theoretical_explanation_with_evidence` field – Cite specific code snippets and explain why they produced the measured effect.
5. **Synthesis and Insights** → `synthesis_and_insights` field – Provide actionable recommendations, trade-off analysis, and concrete follow-up experiments.
6. **Challenges Addressed** → `challenges_addressed` field – {challenge_context}

FIELD MAPPING: Populate each output field with the corresponding section's content.

ANALYSIS STANDARDS:
- Support EVERY claim with references to metrics, code lines/sections, or rubric thresholds.
- Highlight data quality/log issues separately from architecture flaws.
- Maintain scientific rigor: prefer quantified comparisons, mention uncertainty, and avoid speculation detached from evidence.
- For challenges_addressed, only include challenges that the experiment ACTUALLY targeted with concrete mechanisms—do not tag challenges that were merely mentioned but not implemented.

After completing analysis, call finish() with all fields.
"""


def create_analyzer(model_name: Optional[str] = None, challenge_context: str = "") -> SimpleAgent:
    """Create an Analyzer agent."""
    finish_schema = {
        "type": "object",
        "properties": {
            "design_evaluation": {
                "type": "string",
                "description": "Evaluation of theoretical soundness, implementation fidelity, and contract compliance"
            },
            "experimental_results_analysis": {
                "type": "string",
                "description": "Interpretation of evaluation signals with quantified gains/losses relative to baselines"
            },
            "expectation_vs_reality_comparison": {
                "type": "string",
                "description": "Comparison of promised capabilities to measured outcomes, flagging unexpected regressions"
            },
            "theoretical_explanation_with_evidence": {
                "type": "string",
                "description": "Code snippets citations explaining why they produced the measured effect"
            },
            "synthesis_and_insights": {
                "type": "string",
                "description": "Actionable recommendations, trade-off analysis, and concrete follow-up experiments"
            },
            "challenges_addressed": {
                "type": "array",
                "items": {"type": "string"},
                "description": "List of key design challenges this experiment addressed with concrete mechanisms"
            }
        },
        "required": ["design_evaluation", "experimental_results_analysis", "expectation_vs_reality_comparison", "theoretical_explanation_with_evidence", "synthesis_and_insights"],
    }

    @tool("Complete analysis", schema=finish_schema)
    def finish(
        design_evaluation: str,
        experimental_results_analysis: str,
        expectation_vs_reality_comparison: str,
        theoretical_explanation_with_evidence: str,
        synthesis_and_insights: str,
        challenges_addressed: list = None,
    ) -> None:
        """Call with complete analysis."""
        raise TaskComplete(AnalyzerOutput(
            design_evaluation=design_evaluation,
            experimental_results_analysis=experimental_results_analysis,
            expectation_vs_reality_comparison=expectation_vs_reality_comparison,
            theoretical_explanation_with_evidence=theoretical_explanation_with_evidence,
            synthesis_and_insights=synthesis_and_insights,
            challenges_addressed=challenges_addressed or [],
        ))

    instructions = ANALYZER_INSTRUCTIONS_BASE.format(
        challenge_context=challenge_context or DEFAULT_CHALLENGE_CONTEXT
    )

    return SimpleAgent(
        llm=get_llm(model_name),
        instructions=instructions,
        tools=[make_read_file_tool(ephemeral=1), finish],
        max_iterations=15,  # Increased for reasoning models that "think" before tool calls
        max_text_only_responses=10,  # Allow reasoning before requiring tool use
        include_done_tool=False,
    )


class Analyzer(BaseAgentWrapper):
    """
    Backwards-compatible Analyzer wrapper with full context injection.
    """

    name = "Architecture Performance Analyzer"

    async def run(
        self,
        user_prompt: str = "",
        response_model: Type[BaseModel] = None,
        **kwargs,
    ) -> AnalyzerOutput:
        return await self.analyze(user_prompt=user_prompt, **kwargs)

    async def analyze(
        self,
        user_prompt: str = "",
        *,
        name: str = "",
        motivation: str = "",
        ref_context: str = "",
        task=None,
        eval_type: str = "",
        result: str = "",
        task_context: Optional[Dict[str, Any]] = None,
        task_prompt: str = "",
        program_code: str = "",
        program_file_path: str = "",
        **kwargs,
    ) -> AnalyzerOutput:
        """Run analysis with full context."""
        task_context = task_context or {}

        # Get challenge context from task if available
        challenge_context = ""
        if task is not None and hasattr(task, "get_challenge_context_for_analyzer"):
            challenge_context = task.get_challenge_context_for_analyzer()
        if not challenge_context:
            challenge_context = DEFAULT_CHALLENGE_CONTEXT

        # Build context sections
        sections = self._build_prompt_sections(
            name=name,
            motivation=motivation,
            ref_context=ref_context,
            result=result,
            task_context=task_context,
            task_prompt=task_prompt,
            program_code=program_code,
            program_file_path=program_file_path,
            eval_type=eval_type,
            task_name=kwargs.get("task_name", ""),
        )

        prompt = format_sections(sections)

        agent = create_analyzer(self.model_name, challenge_context)
        return await agent.run(prompt)

    def _build_prompt_sections(
        self,
        name: str = "",
        motivation: str = "",
        ref_context: str = "",
        result: str = "",
        task_context: Dict[str, Any] = None,
        task_prompt: str = "",
        program_code: str = "",
        program_file_path: str = "",
        eval_type: str = "",
        task_name: str = "",
        **kwargs,
    ) -> List[Section]:
        """Build context sections - preserved from original Analyzer._prepare_user_prompt."""
        task_context = task_context or {}
        metric_descriptions = task_context.get("metric_descriptions", "No metric descriptions provided.")
        baseline_reference = task_context.get("baseline_reference", "No baseline reference provided.")
        performance_rubric = task_context.get("performance_rubric", "No performance rubric provided.")

        sections: List[Section] = []

        if task_prompt.strip():
            sections.append(("Task Contract", task_prompt))

        # Main analysis context - code is NOT embedded, use read_file tool instead
        analysis_context = f"""# Analysis Request: Model {name}

## Task-Specific Context
This experiment is for the '{task_name}' task.
The evaluation type for this analysis is: **{eval_type}**.

### Evaluation Metrics Understanding:
{metric_descriptions}

### Performance Rubric:
{performance_rubric}

### Baseline Reference:
{baseline_reference}

## Experiment Resources:
- **Results**: `{result}`
- **Code Implementation**: Use `read_file("{program_file_path}")` to inspect the code
- **Design Motivation**: {motivation}
- **Related Experiments for Ablation Study**:
{ref_context}

## Analysis Requirements:
Please perform a thorough, evidence-based analysis based on all the provided information, following the system instructions.
Use the read_file tool to examine the code implementation when you need to cite specific code sections.
"""
        sections.append(("Analysis Context", analysis_context))

        return sections
