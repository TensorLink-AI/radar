# services/providers/agents/judger.py
"""
Simplified Judger agent with preserved detailed prompts.
"""

from __future__ import annotations

from typing import List, Optional, Type

from pydantic import BaseModel

from services.providers.simple_agent import SimpleAgent, tool, TaskComplete

from .base import (
    BaseAgentWrapper,
    Section,
    format_sections,
    get_llm,
)


class JudgerOutput(BaseModel):
    """Defines the structured output for the Judger agent."""
    performance_score: int
    innovation_score: int
    complexity_score: int
    weighted_final_score: float
    judgement_reason: str


# Preserved detailed instructions from original model.py
JUDGER_INSTRUCTIONS = """You are the final adjudicator for agent-submitted architectures. Score each candidate strictly according to the task-supplied rubric (see Task Contract section of the prompt) and the observed evidence (code, logs, analysis, cognition).

**Evaluation Posture**
1. **Anchor to the Task Contract** – Treat the Task Contract section as the governing specification. Extract baseline references and performance thresholds from there. Only reward improvements that are demonstrably better than those task-defined anchors.
2. **Demand Quantification** – When discussing performance, compute deltas or ratios against the baselines provided in the Task Contract. For efficiency, reason about implied complexity (O(N), chunked, recurrent) using the code snippet.
3. **Reward Real Innovation** – Credit candidates that introduce new inductive biases (state-space hybrids, spectral modules, adaptive horizons) and penalize minor parameter tweaks masquerading as breakthroughs.
4. **Complexity Accountability** – High complexity must be justified by measurable gains; otherwise, lower the complexity score.

**Scoring Dimensions (1–10 each, include decimals if needed):**
- **Performance (30%)** – Empirical accuracy/quality vs. the rubric metrics defined in the Task Contract. Reference exact metrics or log excerpts.
- **Innovation (25%)** – Degree of novelty and how well the motivation is implemented in code (cite functions, layers, or equations).
- **Complexity (45%)** – Computational and implementation cost: mask discipline, state tracking overhead, hyperparameter explosion, and clarity of the provided config.

After scoring, call finish() with:
- performance_score, innovation_score, complexity_score (each 1-10)
- weighted_final_score: `(0.3 * performance) + (0.25 * innovation) + (0.45 * complexity)`
- judgement_reason: detailed justification string tying each score to evidence

Mention any contract violations (missing validate call, incorrect outputs, etc.) if observed—they should directly lower the relevant scores.
"""


def create_judger(model_name: Optional[str] = None) -> SimpleAgent:
    """Create a Judger agent."""
    finish_schema = {
        "type": "object",
        "properties": {
            "performance_score": {
                "type": "integer",
                "description": "Performance score 1-10 based on empirical accuracy vs task rubric metrics"
            },
            "innovation_score": {
                "type": "integer",
                "description": "Innovation score 1-10 based on novelty and motivation implementation"
            },
            "complexity_score": {
                "type": "integer",
                "description": "Complexity score 1-10 based on computational and implementation cost"
            },
            "weighted_final_score": {
                "type": "number",
                "description": "Weighted score: (0.3 * performance) + (0.25 * innovation) + (0.45 * complexity)"
            },
            "judgement_reason": {
                "type": "string",
                "description": "Detailed justification tying each score to evidence"
            }
        },
        "required": ["performance_score", "innovation_score", "complexity_score", "weighted_final_score", "judgement_reason"],
    }

    @tool("Complete judgment", schema=finish_schema)
    def finish(
        performance_score: int,
        innovation_score: int,
        complexity_score: int,
        weighted_final_score: float,
        judgement_reason: str,
    ) -> None:
        """Call with scoring result."""
        raise TaskComplete(JudgerOutput(
            performance_score=performance_score,
            innovation_score=innovation_score,
            complexity_score=complexity_score,
            weighted_final_score=weighted_final_score,
            judgement_reason=judgement_reason,
        ))

    return SimpleAgent(
        llm=get_llm(model_name),
        instructions=JUDGER_INSTRUCTIONS,
        tools=[finish],
        max_iterations=15,  # Increased for reasoning models that "think" before tool calls
        max_text_only_responses=10,  # Allow reasoning before requiring tool use
        include_done_tool=False,
    )


class Judger(BaseAgentWrapper):
    """
    Backwards-compatible Judger wrapper with full context injection.
    """

    name = "Model Judger"

    async def run(
        self,
        user_prompt: str = "",
        response_model: Type[BaseModel] = None,
        **kwargs,
    ) -> JudgerOutput:
        element = kwargs.get("element")
        task_prompt = kwargs.get("task_prompt", "")

        # Build context sections
        sections = self._build_prompt_sections(
            element=element,
            task_prompt=task_prompt,
        )

        prompt = format_sections(sections)

        agent = create_judger(self.model_name)
        result = await agent.run(prompt)
        return result

    def _build_prompt_sections(
        self,
        element=None,
        task_prompt: str = "",
        **kwargs,
    ) -> List[Section]:
        """Build context sections - preserved from original Judger._prepare_user_prompt."""
        sections: List[Section] = []

        if task_prompt and task_prompt.strip():
            sections.append(("Task Contract", task_prompt))

        if element is None:
            sections.append(("Error", "No element provided for judgment"))
            return sections

        # Candidate overview
        arch_kw = ", ".join(element.architecture_keywords) if element.architecture_keywords else "—"
        overview = f"""**Model Name**: {element.name}
**Task**: {element.task}
**Architecture Keywords**: {arch_kw}
"""
        sections.append(("Candidate Overview", overview))

        # Implementation
        sections.append(("Implementation", f"```python\n{element.program}\n```"))

        # Additional context
        if element.motivation:
            sections.append(("Motivation", element.motivation))
        if element.analysis:
            sections.append(("Analysis", element.analysis))
        if element.cognition:
            sections.append(("Cognition", element.cognition))
        if element.log:
            sections.append(("Run Log", element.log))

        # Observed metrics
        results = [
            f"**Training Progression**:\n{element.result.get('train', '')}",
            f"**Evaluation Results**:\n{element.result.get('test', '')}",
        ]
        sections.append(("Observed Metrics", "\n\n".join(results)))

        # Scoring instructions
        sections.append((
            "Scoring Instructions",
            "Score the candidate according to the rubric above. "
            "Call finish() with all scores and detailed justification."
        ))

        return sections
