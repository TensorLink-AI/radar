# services/providers/simple_agent.py
"""
Simplified agent framework following "The Bitter Lesson of Agent Frameworks".

Key principles:
1. An agent is just a for-loop of messages
2. Keep going until the model calls done()
3. Give the model maximal capability, then restrict via evals
4. Ephemeral messages for large state to avoid context bloat
5. The model is RL'd on this - trust it

This replaces the complex ProviderAgent with ~200 lines instead of ~800.
"""

from __future__ import annotations

import os
import json
import asyncio
from typing import Any, Callable, Dict, List, Optional, Type, Union, Awaitable
from dataclasses import dataclass, field

from pydantic import BaseModel


# ============================================================================
# Exceptions
# ============================================================================

class TaskComplete(Exception):
    """Raised by done() tool to signal completion."""
    def __init__(self, result: Any):
        self.result = result
        super().__init__(str(result))


class RequiredToolsNotCalled(Exception):
    """Raised when required tools were not called before completion."""
    def __init__(self, missing_tools: List[str]):
        self.missing_tools = missing_tools
        super().__init__(f"Required tools not called: {', '.join(missing_tools)}")


class AgentTimeout(Exception):
    """Raised when max_iterations exceeded."""
    pass


class AgentStalled(Exception):
    """Raised when agent produces too many text-only responses without tool calls."""
    pass


# ============================================================================
# Code block detection for stall recovery
# ============================================================================

import re

# Pattern to detect code blocks in text responses
CODE_BLOCK_PATTERN = re.compile(r'```(?:python|py)?\s*\n.*?```', re.DOTALL)

# Pattern to detect JSON code blocks (```json ... ```)
# Note: \s* instead of \s*\n to handle models that don't add newline after ```json
# IMPORTANT: 'json' must be required (not optional) or this matches ALL code blocks
# and breaks the code block recovery logic in contains_code_block()
JSON_BLOCK_PATTERN = re.compile(r'```json\s*(.*?)```', re.DOTALL)

# Recovery message to inject when code blocks detected in text
CODE_BLOCK_RECOVERY_MESSAGE = """STOP. You output code in text instead of using the write_file tool.

This is NOT acceptable. You MUST use the write_file tool to save code to a file.

Call write_file now with these parameters:
- file_path: the path to write to
- content: the complete code content

Do NOT respond with text. Make a tool call to write_file immediately."""

# Maximum number of code block recoveries before giving up
MAX_CODE_BLOCK_RECOVERIES = 5


def contains_code_block(text: str) -> bool:
    """Check if text contains markdown code blocks (excluding JSON)."""
    # Check if it's a JSON block first - don't treat those as code blocks
    if JSON_BLOCK_PATTERN.search(text):
        return False
    return bool(CODE_BLOCK_PATTERN.search(text))


def extract_file_write_json(text: str) -> Optional[Dict[str, Any]]:
    """
    Extract file write data from text if it contains JSON with file_path+content.

    Following the Bitter Lesson: instead of fighting the model when it outputs
    file write JSON in text, parse it and execute the write automatically.

    Returns dict with 'file_path' and 'content' keys if found, None otherwise.
    """
    def _normalize_file_write(obj: dict) -> Optional[Dict[str, Any]]:
        """Normalize different key variants to file_path/content."""
        if "file_path" in obj and "content" in obj:
            return {"file_path": obj["file_path"], "content": obj["content"]}
        if "path" in obj and "content" in obj:
            return {"file_path": obj["path"], "content": obj["content"]}
        return None

    # Try JSON code block first (```json {...} ```)
    json_match = JSON_BLOCK_PATTERN.search(text)
    if json_match:
        block_content = json_match.group(1).strip()
        try:
            decoder = json.JSONDecoder()
            obj, _ = decoder.raw_decode(block_content.strip())
            if isinstance(obj, dict):
                result = _normalize_file_write(obj)
                if result:
                    return result
        except (json.JSONDecodeError, ValueError):
            pass

    # Try to find JSON object anywhere in text
    text_stripped = text.strip()
    start = text_stripped.find('{')
    if start != -1:
        try:
            decoder = json.JSONDecoder()
            obj, _ = decoder.raw_decode(text_stripped[start:])
            if isinstance(obj, dict):
                result = _normalize_file_write(obj)
                if result:
                    return result
        except (json.JSONDecodeError, ValueError):
            pass

    return None


def _try_parse_json_object(text: str) -> Optional[Dict[str, Any]]:
    """
    Try to parse a JSON object from text, handling potential extra content.

    Uses Python's json decoder to find valid JSON, which handles nested braces
    and escaped characters correctly.
    """
    text = text.strip()

    # Find the first { character
    start = text.find('{')
    if start == -1:
        return None

    # Try parsing from each { to find valid JSON
    for i in range(start, len(text)):
        if text[i] == '{':
            try:
                # json.loads with strict=False is more permissive
                # Use JSONDecoder to get the end position
                decoder = json.JSONDecoder()
                obj, end = decoder.raw_decode(text[i:])
                if isinstance(obj, dict):
                    return obj
            except (json.JSONDecodeError, ValueError):
                continue

    return None


def extract_finish_json(text: str) -> Optional[Dict[str, Any]]:
    """
    Try to extract finish/done JSON from text response.

    Following the Bitter Lesson: instead of fighting the model when it outputs
    JSON in text, parse it and treat as a successful completion.

    Returns parsed dict if valid finish JSON found, None otherwise.
    """
    # Try JSON code block first (```json {...} ```)
    json_match = JSON_BLOCK_PATTERN.search(text)
    if json_match:
        block_content = json_match.group(1).strip()
        data = _try_parse_json_object(block_content)
        if data:
            # Check for Planner-style output (name + motivation)
            if "name" in data and "motivation" in data:
                return data
            # Check for CodeChecker-style output (success)
            if "success" in data:
                return data

    # Try to find JSON object anywhere in text
    data = _try_parse_json_object(text)
    if data:
        # Check for Planner-style output (name + motivation)
        if "name" in data and "motivation" in data:
            return data
        # Check for CodeChecker-style output (success)
        if "success" in data:
            return data

    return None


# ============================================================================
# Tool decorator with ephemeral support
# ============================================================================

def tool(description: str, *, ephemeral: int = 0, schema: Optional[Dict] = None):
    """
    Decorator to expose a function as a tool.

    Args:
        description: What the tool does
        ephemeral: If > 0, only keep the last N outputs of this tool in context.
                   Older outputs are replaced with "[previous output truncated]".
                   Use for large state like DOM snapshots, file contents, etc.
        schema: Optional JSON schema for parameters. If not provided, uses permissive schema.

    Example:
        @tool("Read a file", ephemeral=3)  # Keep only last 3 outputs
        def read_file(path: str) -> str:
            return open(path).read()
    """
    def decorator(func: Callable) -> Callable:
        func.tool_spec = {
            "type": "function",
            "function": {
                "name": func.__name__,
                "description": description,
                "parameters": schema or {
                    "type": "object",
                    "properties": {},
                    "required": [],
                    "additionalProperties": True,
                },
            },
        }
        func.ephemeral = ephemeral
        return func
    return decorator


# ============================================================================
# Built-in done() tool
# ============================================================================

_done_schema = {
    "type": "object",
    "properties": {
        "result": {
            "type": "string",
            "description": "Final result or message describing what was accomplished"
        },
        "success": {
            "type": "boolean",
            "description": "Whether the task succeeded (default: true)"
        }
    },
    "required": [],
}

@tool("Signal task completion with final result", schema=_done_schema)
def done(result: str = "", success: bool = True) -> None:
    """
    Call this when the task is complete.

    Args:
        result: Final result or message
        success: Whether the task succeeded
    """
    raise TaskComplete({"result": result, "success": success})


# Alias: some models (e.g., DeepSeek) call this "finish" instead of "done"
@tool("Signal task completion with final result (alias for done)", schema=_done_schema)
def finish(result: str = "", success: bool = True) -> None:
    """
    Alias for done(). Call this when the task is complete.

    Args:
        result: Final result or message
        success: Whether the task succeeded
    """
    raise TaskComplete({"result": result, "success": success})


# ============================================================================
# Simple LLM Protocol
# ============================================================================

class LLMProtocol:
    """
    Minimal LLM interface. Same for Anthropic, OpenAI, Google.

    Implement ainvoke() to return:
        {"text": str, "tool_calls": [{"id": str, "function": {"name": str, "arguments": str}}]}
    """

    async def ainvoke(
        self,
        messages: List[Dict[str, Any]],
        tools: Optional[List[Dict]] = None,
    ) -> Dict[str, Any]:
        raise NotImplementedError


# ============================================================================
# Message helpers
# ============================================================================

@dataclass
class EphemeralTracker:
    """Tracks ephemeral tool outputs to manage context size."""
    tool_outputs: Dict[str, List[int]] = field(default_factory=dict)  # tool_name -> [msg indices]

    def record(self, tool_name: str, msg_index: int, ephemeral_limit: int) -> List[int]:
        """Record a tool output and return indices to truncate."""
        if ephemeral_limit <= 0:
            return []

        if tool_name not in self.tool_outputs:
            self.tool_outputs[tool_name] = []

        self.tool_outputs[tool_name].append(msg_index)

        # Return indices that should be truncated (keep only last N)
        outputs = self.tool_outputs[tool_name]
        if len(outputs) > ephemeral_limit:
            to_truncate = outputs[:-ephemeral_limit]
            self.tool_outputs[tool_name] = outputs[-ephemeral_limit:]
            return to_truncate
        return []


def truncate_message(messages: List[Dict], index: int) -> None:
    """Replace message content with truncation notice."""
    if 0 <= index < len(messages):
        msg = messages[index]
        if msg.get("role") == "tool":
            msg["content"] = "[previous output truncated for context efficiency]"


# ============================================================================
# Context Compaction (from bu-agent-sdk pattern)
# ============================================================================

# Default prompt for summarizing conversation history
COMPACTION_SUMMARY_PROMPT = """Summarize the conversation progress so far. Include:
1. What task was requested
2. What actions have been taken (files read/written, tools called)
3. Current state and any pending work
4. Key findings or errors encountered

Be concise but preserve important details needed to continue the task."""


@dataclass
class CompactionConfig:
    """
    Configuration for automatic context compaction.

    When token usage exceeds threshold_ratio * context_window, the agent
    pauses to summarize older messages, preventing context overflow.

    Reference: bu_agent_sdk/agent/compaction/service.py
    """
    threshold_ratio: float = 0.80  # Trigger compaction at 80% capacity
    context_window: int = 128_000  # Model's max context (e.g., deepseek-coder)
    summary_prompt: str = COMPACTION_SUMMARY_PROMPT
    min_messages_to_compact: int = 6  # Don't compact if fewer messages than this


def _estimate_tokens(messages: List[Dict[str, Any]]) -> int:
    """
    Rough token estimation: ~4 chars per token.

    This is a heuristic - actual token count varies by model/tokenizer.
    For accurate counts, use the model's tokenizer or usage metadata.
    """
    total_chars = 0
    for msg in messages:
        content = msg.get("content", "")
        if isinstance(content, str):
            total_chars += len(content)
        # Count tool call arguments
        for tc in msg.get("tool_calls", []):
            fn = tc.get("function", {})
            total_chars += len(fn.get("name", ""))
            total_chars += len(fn.get("arguments", ""))
    return total_chars // 4


# ============================================================================
# SimpleAgent: Just a for-loop
# ============================================================================

class SimpleAgent:
    """
    An agent is just a for-loop of messages.

    The model calls tools until it calls done(). That's it.
    No complex state machines, no ToolPolicy, no budget tracking.

    Usage:
        agent = SimpleAgent(
            llm=MyLLMClient(),
            instructions="You are a code assistant.",
            tools=[read_file, write_file, run_tests],  # + done() added automatically
        )
        result = await agent.run("Fix the bug in main.py")
    """

    def __init__(
        self,
        llm: LLMProtocol,
        instructions: str = "You are a helpful assistant.",
        tools: Optional[List[Callable]] = None,
        *,
        max_iterations: int = 50,  # Safety limit, not a "budget"
        max_text_only_responses: int = 5,  # Prevent stalling on text-only responses
        include_done_tool: bool = True,
        required_tools: Optional[List[str]] = None,  # Tools that MUST be called before completion
        compaction: Optional[CompactionConfig] = None,  # Context compaction config
    ):
        self.llm = llm
        self.instructions = instructions
        self.max_iterations = max_iterations
        self.max_text_only_responses = max_text_only_responses
        self.required_tools: List[str] = list(required_tools or [])
        self.compaction = compaction
        self._compaction_count = 0  # Track how many times we've compacted

        # Build tool registry
        self.tools: List[Callable] = list(tools or [])
        if include_done_tool:
            self.tools.append(done)
            self.tools.append(finish)  # Alias for models that use "finish" instead of "done"

        self.tool_map: Dict[str, Callable] = {}
        self.tool_specs: List[Dict] = []
        self.ephemeral_limits: Dict[str, int] = {}

        for t in self.tools:
            spec = getattr(t, "tool_spec", None)
            if spec:
                name = spec["function"]["name"]
                self.tool_map[name] = t
                self.tool_specs.append(spec)
                self.ephemeral_limits[name] = getattr(t, "ephemeral", 0)

    async def _maybe_compact(
        self,
        messages: List[Dict[str, Any]],
        token_count: Optional[int] = None,
    ) -> List[Dict[str, Any]]:
        """
        Check if context needs compaction and summarize if over threshold.

        Compaction replaces messages[1:-2] (everything except system prompt and
        recent context) with a summary, allowing long-running agents to continue
        without hitting context limits.

        Args:
            messages: Current message history
            token_count: Actual token count from LLM response, or None to estimate

        Returns:
            Potentially compacted message list
        """
        if not self.compaction:
            return messages

        # Use actual token count if available, otherwise estimate
        tokens = token_count if token_count is not None else _estimate_tokens(messages)
        threshold = int(self.compaction.context_window * self.compaction.threshold_ratio)

        if tokens < threshold:
            return messages

        # Don't compact if not enough messages
        if len(messages) < self.compaction.min_messages_to_compact:
            return messages

        # Keep system prompt (index 0) and recent messages (last 2)
        # Summarize everything in between
        to_summarize = messages[1:-2]
        if len(to_summarize) < 2:
            return messages  # Not enough to summarize

        # Build summary request
        summary_content = []
        for msg in to_summarize:
            role = msg.get("role", "unknown")
            content = msg.get("content", "")
            tool_calls = msg.get("tool_calls", [])

            if role == "assistant" and tool_calls:
                # Summarize tool calls
                calls_summary = ", ".join(
                    tc.get("function", {}).get("name", "unknown")
                    for tc in tool_calls
                )
                summary_content.append(f"[Assistant called tools: {calls_summary}]")
                if content:
                    summary_content.append(f"[Assistant said: {content[:200]}...]")
            elif role == "tool":
                name = msg.get("name", "unknown")
                # Truncate long tool results
                result_preview = content[:300] + "..." if len(content) > 300 else content
                summary_content.append(f"[Tool {name} returned: {result_preview}]")
            elif content:
                summary_content.append(f"[{role.title()}: {content[:200]}...]")

        # Ask LLM to create a concise summary
        summary_request = [
            {"role": "system", "content": self.compaction.summary_prompt},
            {"role": "user", "content": "\n".join(summary_content)},
        ]

        try:
            response = await self.llm.ainvoke(summary_request, tools=None)
            summary = response.get("text", "") or "Progress summary unavailable."
        except Exception as e:
            # If summarization fails, use a basic summary
            summary = f"[Compaction failed: {e}. Conversation had {len(to_summarize)} messages.]"

        self._compaction_count += 1

        # Return compacted messages: system + summary + recent context
        return [
            messages[0],  # System prompt
            {"role": "user", "content": f"[CONTEXT SUMMARY (compaction #{self._compaction_count})]\n{summary}"},
            *messages[-2:],  # Keep recent context (last assistant + tool results)
        ]

    async def run(
        self,
        prompt: str,
        *,
        response_model: Optional[Type[BaseModel]] = None,
    ) -> Any:
        """
        Run the agent until done() is called or max_iterations exceeded.

        Args:
            prompt: The user's request
            response_model: Optional Pydantic model to parse the final result

        Returns:
            The result from done() call, optionally parsed to response_model
        """
        messages: List[Dict[str, Any]] = [
            {"role": "system", "content": self.instructions},
            {"role": "user", "content": prompt},
        ]

        ephemeral_tracker = EphemeralTracker()
        consecutive_text_only = 0  # Track text-only responses without tool calls
        code_block_recoveries = 0  # Track how many times we've tried to recover from code blocks
        called_tools: set = set()  # Track which tools have been called for required_tools validation

        # The loop. That's it.
        for iteration in range(self.max_iterations):
            # Call LLM
            response = await self.llm.ainvoke(
                messages=messages,
                tools=self.tool_specs if self.tool_specs else None,
            )

            text = response.get("text", "") or ""
            tool_calls = response.get("tool_calls", []) or []

            # No tool calls = model chose to respond with text
            # In autonomous mode, we'd continue. In CLI mode, we'd stop.
            # For NAS agents, we expect done() to be called.
            if not tool_calls:
                consecutive_text_only += 1
                if text:
                    # BITTER LESSON: Instead of fighting the model when it outputs
                    # JSON in text, parse it and treat as successful completion.
                    # The model knows what it's doing - adapt to its output format.
                    finish_json = extract_finish_json(text)
                    if finish_json:
                        # Check required tools BEFORE allowing JSON bypass completion
                        # This ensures agents with required_tools (like CodeChecker with
                        # check_shapes) can't bypass the tool requirement via text output
                        if self.required_tools:
                            missing = [t for t in self.required_tools if t not in called_tools]
                            if missing:
                                # Reject completion - required tools not called
                                print(f"[SimpleAgent] Rejecting JSON text completion - required tools not called: {missing}")
                                messages.append({"role": "assistant", "content": text})
                                messages.append({
                                    "role": "user",
                                    "content": (
                                        f"REJECTED: Cannot complete yet. You output completion JSON but have not "
                                        f"called these REQUIRED tools: {', '.join(missing)}. "
                                        f"You MUST call {', '.join(missing)} first and verify it returns SUCCESS before finishing."
                                    )
                                })
                                continue
                        # All required tools called (or none required) - allow completion
                        if response_model:
                            return self._parse_result(finish_json, response_model)
                        return finish_json

                    messages.append({"role": "assistant", "content": text})

                    # Check if the model output code blocks - this is a recoverable stall
                    # Inject a recovery message to prompt tool use
                    if contains_code_block(text):
                        code_block_recoveries += 1
                        if code_block_recoveries > MAX_CODE_BLOCK_RECOVERIES:
                            raise AgentStalled(
                                f"Agent stalled after {code_block_recoveries} code block outputs "
                                f"without using write_file tool. Last response: {text[:200]}..."
                            )
                        messages.append({
                            "role": "user",
                            "content": CODE_BLOCK_RECOVERY_MESSAGE
                        })
                        # Reset the counter since we're actively recovering - give the model
                        # another chance to use the tool properly after seeing the recovery message
                        consecutive_text_only = 0
                        continue

                    # Check if the model output JSON with file_path+content
                    # BITTER LESSON: Instead of fighting the model, auto-execute the write
                    file_write_data = extract_file_write_json(text)
                    if file_write_data:
                        # Auto-execute the file write the model intended
                        file_path = file_write_data["file_path"]
                        content = file_write_data["content"]
                        try:
                            from pathlib import Path
                            path = Path(file_path)
                            path.parent.mkdir(parents=True, exist_ok=True)
                            path.write_text(content, encoding="utf-8")
                            write_result = f"Successfully wrote {len(content)} bytes to {file_path}"
                        except Exception as e:
                            write_result = f"Error writing file: {e}"

                        # Add synthetic tool call and result to conversation
                        # This makes the model aware the write happened
                        messages.append({
                            "role": "assistant",
                            "content": text,
                            "tool_calls": [{
                                "id": "auto_write_file",
                                "function": {
                                    "name": "write_file",
                                    "arguments": json.dumps(file_write_data)
                                }
                            }]
                        })
                        messages.append({
                            "role": "tool",
                            "tool_call_id": "auto_write_file",
                            "content": write_result
                        })
                        # Reset counter - we effectively handled a tool call
                        consecutive_text_only = 0
                        continue

                # Check if stalled (too many consecutive text-only responses)
                if consecutive_text_only >= self.max_text_only_responses:
                    raise AgentStalled(
                        f"Agent stalled after {consecutive_text_only} consecutive text-only responses "
                        f"without making tool calls. Last response: {text[:200]}..."
                    )
                # Continue loop - model might just be thinking out loud
                continue

            # Reset counter when tool calls are made
            consecutive_text_only = 0

            # Add assistant message with tool calls
            messages.append({
                "role": "assistant",
                "content": text,
                "tool_calls": tool_calls,
            })

            # Execute each tool call
            for call in tool_calls:
                fn_info = call.get("function", {})
                name = fn_info.get("name", "")
                args_raw = fn_info.get("arguments", "{}")
                call_id = call.get("id", name)

                # Parse arguments
                try:
                    args = json.loads(args_raw) if isinstance(args_raw, str) else args_raw
                except json.JSONDecodeError:
                    args = {}

                if not isinstance(args, dict):
                    args = {}

                # Get tool function
                func = self.tool_map.get(name)
                if not func:
                    result = f"Error: Unknown tool '{name}'"
                else:
                    try:
                        # Track this tool call for required_tools validation
                        called_tools.add(name)

                        # Execute tool (sync or async)
                        res = func(**args)
                        if asyncio.iscoroutine(res):
                            res = await res
                        result = json.dumps(res) if not isinstance(res, str) else res
                    except TaskComplete as tc:
                        # done() was called - check if required tools were used first
                        if self.required_tools:
                            missing = [t for t in self.required_tools if t not in called_tools]
                            if missing:
                                # Reject completion - required tools not called
                                print(f"[SimpleAgent] Rejecting finish() call - required tools not called: {missing}")
                                result = (
                                    f"REJECTED: Cannot complete yet. You MUST call these tools first: {', '.join(missing)}. "
                                    f"Call the required tool(s) and verify they return SUCCESS before calling finish/done."
                                )
                                # Continue processing instead of returning
                            else:
                                # All required tools called - we're finished!
                                final_result = tc.result
                                if response_model:
                                    return self._parse_result(final_result, response_model)
                                return final_result
                        else:
                            # No required tools - we're finished!
                            final_result = tc.result
                            if response_model:
                                return self._parse_result(final_result, response_model)
                            return final_result
                    except Exception as e:
                        result = f"Error executing {name}: {e}"

                # Add tool result message
                msg_index = len(messages)
                messages.append({
                    "role": "tool",
                    "tool_call_id": call_id,
                    "name": name,
                    "content": result,
                })

                # Handle ephemeral messages
                ephemeral_limit = self.ephemeral_limits.get(name, 0)
                if ephemeral_limit > 0:
                    to_truncate = ephemeral_tracker.record(name, msg_index, ephemeral_limit)
                    for idx in to_truncate:
                        truncate_message(messages, idx)

            # Check for context compaction at end of each iteration
            # Get token count from response metadata if available
            usage = response.get("usage", {})
            token_count = usage.get("total_tokens") or usage.get("prompt_tokens")
            messages = await self._maybe_compact(messages, token_count)

        raise AgentTimeout(f"Agent did not complete within {self.max_iterations} iterations")

    def _parse_result(self, result: Any, model: Type[BaseModel]) -> BaseModel:
        """Parse result to Pydantic model."""
        if isinstance(result, model):
            return result
        if isinstance(result, dict):
            return model(**result)
        if isinstance(result, str):
            try:
                return model.model_validate_json(result)
            except Exception:
                data = json.loads(result)
                return model(**data)
        return model(**{"result": result})


# ============================================================================
# Adapter for existing ChutesClient
# ============================================================================

class ChutesAdapter(LLMProtocol):
    """Adapts existing ChutesClient to SimpleAgent's LLMProtocol."""

    def __init__(self, client, model_name: str):
        self.client = client
        self.model_name = model_name

    async def ainvoke(
        self,
        messages: List[Dict[str, Any]],
        tools: Optional[List[Dict]] = None,
    ) -> Dict[str, Any]:
        raw = await self.client.chat(
            model=self.model_name,
            messages=messages,
            tools=tools,
            tool_choice="auto" if tools else None,
        )
        normalized = self.client.normalize(raw)

        # Include usage info for context compaction
        usage = getattr(self.client, "last_usage", None) or {}

        return {
            "text": normalized.get("text_response", ""),
            "tool_calls": normalized.get("tool_calls", []),
            "usage": usage,
        }


# ============================================================================
# Example: Creating a simple code evolution agent
# ============================================================================

def create_simple_evolve_agent(
    llm: LLMProtocol,
    read_file: Callable,
    write_file: Callable,
) -> SimpleAgent:
    """
    Example of creating a minimal evolution agent.

    Instead of Planner + CodeChecker + MotivationChecker + Deduplicator,
    just give the model all the tools and let it figure it out.
    """

    instructions = """You are a neural architecture evolution agent.

Your task: Given a parent model, create a novel variation that could improve performance.

Available tools:
- read_file: Read any file
- write_file: Write code changes
- done: Call when finished with your final architecture name and motivation

Process:
1. Read the parent model
2. Think about what modifications could help
3. Write your changes
4. Call done() with name and motivation

The model knows how to do this. Trust it."""

    return SimpleAgent(
        llm=llm,
        instructions=instructions,
        tools=[read_file, write_file],
        max_iterations=25,
        max_text_only_responses=3,  # Fail fast if model stalls
    )
