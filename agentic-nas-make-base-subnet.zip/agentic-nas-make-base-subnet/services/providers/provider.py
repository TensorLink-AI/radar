# services/providers/provider.py
from __future__ import annotations
"""
Provider-agnostic agent with robust structured-output finalization.

Improvements in this version:
- Accurate JSON schema generation for Pydantic models (lists, optionals, enums, literals, nested).
- Finalizer tool now advertises correct types (arrays, objects, enums, etc.).
- Argument coercion layer converts messy tool args into the right Python types before Pydantic validation:
  * "" -> [] for list fields
  * JSON-in-strings parsed to dict/list
  * string numbers -> int/float
  * string booleans -> bool
  * per-item coercion for List[T]
- Hardened _normalize_tool_args for empty-string & non-JSON inputs.

Additional changes:
- Keep tools available on EVERY turn until final JSON is produced (configurable).
- Per-round and total tool call budgets; execute multiple tool calls per round up to budget.
- Deterministic handoff to JSON-only finalization once finalized.
"""

import os
import json
import asyncio
import enum
from typing import Any, Dict, List, Optional, Type, Union, Callable, Awaitable, Tuple, get_origin, get_args

from pydantic import BaseModel

from core.base_agent import BaseAgent
from services.providers.llm_client import LLMClient
from services.providers.clients.chutes_client import ChutesClient
from services.providers.config import AgentConfig, ToolPolicy
from services.providers.state import AgentState

JSONDict = Dict[str, Any]
ToolFn = Union[Callable[..., Any], Callable[..., Awaitable[Any]]]


# ---------------- Exceptions ---------------- #

class ToolConfigurationError(RuntimeError):
    pass

class ToolCallRequiredError(RuntimeError):
    pass


# ---------------- Utilities ---------------- #

def _maybe_json(x: Any) -> Any:
    if isinstance(x, (dict, list)):
        return x
    if isinstance(x, str):
        s = x.strip()
        if (s.startswith("{") and s.endswith("}")) or (s.startswith("[") and s.endswith("]")):
            try:
                return json.loads(s)
            except Exception:
                return x
    return x

def _build_tool_map(tools: List[Any]) -> Dict[str, ToolFn]:
    m: Dict[str, ToolFn] = {}
    for fn in tools or []:
        name = None
        spec = getattr(fn, "tool_spec", None)
        if isinstance(spec, dict):
            name = spec.get("function", {}).get("name")
        if not name:
            name = getattr(fn, "__name__", None)
        if name:
            m[name] = fn
    return m

def _collect_tool_specs(tools: List[Any]) -> List[dict]:
    out = []
    for fn in tools or []:
        spec = getattr(fn, "tool_spec", None)
        if isinstance(spec, dict) and spec.get("type") == "function" and "function" in spec:
            out.append(spec)
    return out

def _extract_first_json_object(text: str) -> Optional[dict]:
    """Scan for the first top-level {...} JSON object inside text and parse it."""
    if not text:
        return None
    try:
        obj = json.loads(text)
        if isinstance(obj, dict):
            return obj
    except Exception:
        pass
    depth = 0
    start = -1
    for i, ch in enumerate(text):
        if ch == '{':
            if depth == 0:
                start = i
            depth += 1
        elif ch == '}':
            if depth > 0:
                depth -= 1
                if depth == 0 and start != -1:
                    candidate = text[start:i+1]
                    try:
                        obj = json.loads(candidate)
                        if isinstance(obj, dict):
                            return obj
                    except Exception:
                        start = -1
                        continue
    return None


# ---------------- Schema building from Pydantic ---------------- #

def _model_to_schema(model: Type[BaseModel]) -> dict:
    """Build JSON schema for a Pydantic model using built-in schema generation.

    Uses Pydantic's native schema generation (v1/v2 compatible) and strips
    unnecessary fields like $defs for OpenAI tools compatibility.
    """
    # Use Pydantic's built-in schema generation
    if hasattr(model, "model_json_schema"):
        # Pydantic v2
        schema = model.model_json_schema()
    else:
        # Pydantic v1
        schema = model.schema()

    # Extract just what OpenAI tools need, stripping $defs and other extras
    properties = schema.get("properties", {})
    required = schema.get("required", [])

    # Resolve $ref references inline if present (for nested models)
    defs = schema.get("$defs", {}) or schema.get("definitions", {})
    if defs:
        properties = _resolve_refs(properties, defs)

    if not properties:
        properties = {"value": {"type": "string"}}
        required = ["value"]

    return {
        "type": "object",
        "properties": properties,
        "required": required,
        "additionalProperties": False,
    }


def _resolve_refs(obj: Any, defs: Dict[str, Any]) -> Any:
    """Recursively resolve $ref references in a JSON schema."""
    if isinstance(obj, dict):
        if "$ref" in obj:
            ref_path = obj["$ref"]
            # Extract definition name from "#/$defs/Name" or "#/definitions/Name"
            ref_name = ref_path.split("/")[-1]
            if ref_name in defs:
                return _resolve_refs(defs[ref_name], defs)
            return obj
        return {k: _resolve_refs(v, defs) for k, v in obj.items()}
    if isinstance(obj, list):
        return [_resolve_refs(item, defs) for item in obj]
    return obj


def _is_optional(ann) -> Tuple[bool, Any]:
    """Return (is_optional, inner_type) for Optional[T] or Union[T, None]."""
    origin = get_origin(ann)
    if origin is Union:
        args = [a for a in get_args(ann)]
        if type(None) in args:
            non_none = [a for a in args if a is not type(None)]
            return True, (non_none[0] if non_none else Any)
    return False, ann


def _enum_values(t: Any) -> Optional[List[Any]]:
    """Extract enum member values if t is an Enum subclass."""
    try:
        if isinstance(t, type) and issubclass(t, enum.Enum):
            return [m.value for m in t]
    except Exception:
        pass
    return None


# ---------------- Coercion helpers for tool args -> model ---------------- #

_TRUE_SET = {"true", "1", "yes", "y", "on"}
_FALSE_SET = {"false", "0", "no", "n", "off"}

def _coerce_bool(v: Any) -> Any:
    if isinstance(v, bool):
        return v
    if isinstance(v, (int, float)):
        return bool(v)
    if isinstance(v, str):
        s = v.strip().lower()
        if s in _TRUE_SET:
            return True
        if s in _FALSE_SET:
            return False
    return v

def _coerce_number(v: Any, to_float: bool) -> Any:
    if isinstance(v, (int, float)):
        return float(v) if to_float else int(v)
    if isinstance(v, str):
        s = v.strip()
        try:
            return float(s) if to_float else int(float(s))
        except Exception:
            return v
    return v

def _maybe_parse_json_string(v: Any) -> Any:
    if isinstance(v, str):
        s = v.strip()
        if s == "":
            return v
        if (s.startswith("{") and s.endswith("}")) or (s.startswith("[") and s.endswith("]")):
            try:
                return json.loads(s)
            except Exception:
                return v
    return v

def _coerce_item(v: Any, ann: Any) -> Any:
    """Coerce a single value into annotation ann where possible."""
    # Optional unwrap
    _, inner = _is_optional(ann)
    ann = inner
    origin = get_origin(ann)
    args = get_args(ann)

    # Enum
    ev = _enum_values(ann)
    if ev is not None:
        return v  # let Pydantic validate enum membership

    # Nested BaseModel
    try:
        if isinstance(ann, type) and issubclass(ann, BaseModel):
            if isinstance(v, dict):
                return v
            v2 = _maybe_parse_json_string(v)
            if isinstance(v2, dict):
                return v2
            return v
    except Exception:
        pass

    # Collections
    if origin in (list, List, tuple, set):
        item_ann = args[0] if args else Any
        v = _maybe_parse_json_string(v)
        if v == "" or v is None:
            return []
        if not isinstance(v, (list, tuple, set)):
            v = [v]
        return [_coerce_item(x, item_ann) for x in v]

    if origin in (dict, Dict):
        v2 = _maybe_parse_json_string(v)
        return v2 if isinstance(v2, dict) else v

    # Scalars
    if ann in (bool,):
        return _coerce_bool(v)
    if ann in (int,):
        return _coerce_number(v, to_float=False)
    if ann in (float,):
        return _coerce_number(v, to_float=True)
    # strings/default
    return v

def _coerce_args_for_model(kwargs: Dict[str, Any], response_model: Type[BaseModel]) -> Dict[str, Any]:
    """Coerce dict in-place to match model field annotations, recursively."""
    fields = getattr(response_model, "model_fields", None) or getattr(response_model, "__fields__", None) or {}
    out: Dict[str, Any] = {}
    for name, field in (fields.items() if isinstance(fields, dict) else []):
        ann = getattr(field, "annotation", None) or getattr(field, "type_", None) or Any
        if name in kwargs:
            out[name] = _coerce_item(kwargs[name], ann)
    for k, v in kwargs.items():
        if k not in out:
            out[k] = v
    return out


# ---------------- Provider Agent ---------------- #

class ProviderAgent(BaseAgent):
    """LLM-backed agent with tool orchestration and structured output handling.

    ``ProviderAgent`` now consumes :class:`AgentConfig` for every behavioral flag
    and maintains an :class:`AgentState` object for the duration of ``run``. The
    interaction loop is split into small helpers so subclasses can extend the
    behavior without re-implementing the full orchestration logic.

    Flow when ``response_model`` is provided:
      1) Keep tools available on every turn until final JSON is produced
         (configurable).
      2) Try JSON mode (OpenAI-compatible) when finalizing.
      3) If unparsable, inject a REQUIRED schema tool built from the model.
      4) Parse/coerce tool arguments into the model type and return.
    """

    name: str = "ProviderAgent"
    instructions: str = "You are a helpful agent."
    tools: List[Any] = []
    last_messages: List[JSONDict] = []

    def __init__(
        self,
        name: Optional[str] = None,
        instructions: Optional[str] = None,
        *,
        llm: Optional[LLMClient] = None,
        tools: Optional[List[Any]] = None,
        model_name: Optional[str] = None,
        config: Optional[AgentConfig] = None,
        **config_overrides,
    ):
        effective_name = name or getattr(self, "name", "ProviderAgent")
        effective_instructions = instructions or getattr(self, "instructions", "You are a helpful agent.")
        effective_tools = tools if tools is not None else list(getattr(self, "tools", []))
        super().__init__(name=effective_name, instructions=effective_instructions, tools=effective_tools)

        self.llm: LLMClient = llm or ChutesClient()
        self.model_name = model_name or os.getenv("MODEL_NAME")
        if not self.model_name:
            raise ValueError("ProviderAgent requires a model name. Pass model_name or set MODEL_NAME env.")

        base_config = config or AgentConfig()
        if config_overrides:
            copier = getattr(base_config, "model_copy", None)
            if callable(copier):
                base_config = copier(update=config_overrides)
            else:  # pragma: no cover - Pydantic v1 fallback
                base_config = base_config.copy(update=config_overrides)  # type: ignore[call-arg]
        self.config = base_config.with_env_overrides()

        # Build tool payloads
        self.tool_map: Dict[str, ToolFn] = _build_tool_map(effective_tools)
        self._tools_payload: Optional[List[dict]] = _collect_tool_specs(effective_tools) or None
        self._tool_choice_payload: Optional[str] = (
            self.config.tool_choice if self._tools_payload else None
        )

        # runtime state gets initialized inside run()
        self.state: Optional[AgentState] = None

    async def __aenter__(self):
        return self

    async def __aexit__(self, *exc):
        aclose = getattr(self.llm, "aclose", None)
        if callable(aclose):
            await aclose()

    async def _maybe_await(self, fn: ToolFn, *pargs, **kwargs):
        res = fn(*pargs, **kwargs)
        return await res if asyncio.iscoroutine(res) else res

    @staticmethod
    def _normalize_tool_args(args_any: Any) -> Tuple[List[Any], Dict[str, Any]]:
        """
        Robust argument normalizer:
        - Empty string -> {}
        - JSON string -> dict
        - Numeric-key dict -> ordered list
        """
        if args_any is None:
            return [], {}
        if isinstance(args_any, str):
            s = args_any.strip()
            if not s:
                return [], {}
            try:
                parsed = json.loads(s)
            except Exception:
                if not (s.startswith("{") and s.endswith("}")):
                    s2 = "{" + s + "}"
                    try:
                        parsed = json.loads(s2)
                    except Exception:
                        return [], {"value": s}
                else:
                    return [], {"value": s}
            args_any = parsed

        if isinstance(args_any, list):
            return list(args_any), {}
        if isinstance(args_any, dict):
            if args_any and all(str(k).isdigit() for k in args_any.keys()):
                ordered = [args_any[str(i)] for i in sorted(map(int, args_any.keys()))]
                return ordered, {}
            return [], args_any

        return [args_any], {}

    def _debug_meta(
        self,
        state: AgentState,
        messages: List[JSONDict],
        *,
        tool_choice: Optional[str],
        tools_sent: bool,
        json_mode: bool,
    ) -> None:
        if not self.config.debug_payload:
            return
        try:
            dbg = {
                "model": self.model_name,
                "temperature": self.config.temperature,
                "tool_choice": tool_choice if tool_choice is not None else "none",
                "tools_sent": tools_sent,
                "tools_count": (len(self._tools_payload) if tools_sent and self._tools_payload else 0),
                "json_mode": json_mode,
                "last_role": messages[-1].get("role") if messages else None,
                # NEW debug
                "tool_rounds": state.tool_rounds,
                "total_tool_calls": state.total_tool_calls,
                "have_final_json": state.have_final_json,
            }
            print("[ProviderAgent DEBUG] outgoing meta:", json.dumps(dbg, ensure_ascii=False))
        except Exception:
            pass

    async def _call_llm(
        self,
        state: AgentState,
        messages: List[JSONDict],
        *,
        force_no_tools: bool = False,
        json_mode: bool = False,
        override_tools: Optional[List[dict]] = None,
        override_tool_choice: Optional[str] = None,
    ) -> Dict[str, Any]:
        tools_payload = None if force_no_tools else (override_tools if override_tools is not None else self._tools_payload)
        tool_choice   = None if force_no_tools else (override_tool_choice if override_tool_choice is not None else self._tool_choice_payload)
        if not tools_payload:
            tool_choice = None

        extra = None
        if json_mode:
            extra = {"response_format": {"type": "json_object"}}

        self._debug_meta(state, messages, tool_choice=tool_choice, tools_sent=bool(tools_payload), json_mode=json_mode)

        raw = await self.llm.chat(
            model=self.model_name,
            messages=messages,
            temperature=self.config.temperature,
            tools=tools_payload,
            tool_choice=(None if tool_choice is None else tool_choice),
            extra=extra,
        )
        norm = self.llm.normalize(raw)
        if "text_response" not in norm or norm.get("text_response") is None:
            norm["text_response"] = ""
        if "tool_calls" not in norm or norm.get("tool_calls") is None:
            norm["tool_calls"] = []
        return norm

    def _inject_json_instruction(
        self, state: AgentState, messages: List[JSONDict], response_model: Type[BaseModel]
    ) -> None:
        if state.json_instruction_injected:
            return
        try:
            fields = getattr(response_model, "model_fields", None) or getattr(response_model, "__fields__", None) or {}
            keys = list(fields.keys()) if isinstance(fields, dict) else []
        except Exception:
            keys = []
        instruction = (
            "Return ONLY a valid JSON object. No markdown, no extra text.\n"
            "If a field is an array, provide it as a JSON array: e.g., \"repeated_index\": [0,1]."
            + (f" Expected keys: {keys}." if keys else "")
        )
        messages.append({"role": "system", "content": instruction})
        state.json_instruction_injected = True

    def _build_schema_tool_for_model(self, response_model: Type[BaseModel]) -> dict:
        model_schema = _model_to_schema(response_model)
        return {
            "type": "function",
            "function": {
                "name": "return_structured_output",
                "description": (
                    "Return the final structured result exactly matching the schema. "
                    "Important: Arrays must be JSON arrays (e.g., [1,2]), not strings."
                ),
                "parameters": model_schema,
            },
        }

    def _parse_to_model(self, response_model: Type[BaseModel], content: str) -> Optional[BaseModel]:
        try:
            return response_model.model_validate_json(content)  # Pydantic v2
        except AttributeError:
            try:
                return response_model.parse_raw(content)  # Pydantic v1
            except Exception:
                pass
        except Exception:
            pass
        obj = _extract_first_json_object(content)
        if obj is not None:
            try:
                return response_model(**obj)
            except Exception:
                return None
        return None

    def _should_send_tools_this_turn(self, state: AgentState) -> bool:
        """Decide whether to attach tools to this LLM call based on tool_policy."""
        if not self._tools_payload:
            return False
        if state.tools_budget_exhausted:
            return False

        policy = self.config.tool_policy

        if policy == ToolPolicy.ALWAYS:
            return True
        if policy == ToolPolicy.UNTIL_JSON:
            return not state.have_final_json
        if policy == ToolPolicy.ONCE:
            return not state.had_tool_round

        return False

    async def run(
        self,
        user_prompt: str,
        response_model: Type[BaseModel] = None,
        *,
        skip_prepare_prompt: bool = False,
        **kwargs
    ) -> Any:
        prompt = user_prompt if skip_prepare_prompt else self._prepare_prompt(user_prompt, **kwargs)
        messages: List[JSONDict] = [
            {"role": "system", "content": self.instructions},
            {"role": "user", "content": prompt},
        ]

        state = AgentState(messages=messages)
        self.state = state

        force_json_initial = bool(
            response_model and self.config.force_json_initial_if_response_model
        )

        for _ in range(self.config.max_turns):
            state.turn += 1
            send_tools_now = self._should_send_tools_this_turn(state)
            json_mode = self._should_force_json(state, response_model, send_tools_now, force_json_initial)

            if json_mode and response_model:
                self._inject_json_instruction(state, messages, response_model)

            resp = await self._call_llm(
                state,
                messages,
                force_no_tools=(not send_tools_now),
                json_mode=json_mode,
            )

            final = await self._handle_llm_response(state, messages, resp, response_model)
            if final is not None:
                return final

        self.last_messages = messages
        raise RuntimeError("max_turns exceeded without a terminating condition")

    def _prepare_prompt(self, user_prompt: str, **kwargs) -> str:
        """Return the prompt that will seed the conversation."""
        if hasattr(self, "_prepare_user_prompt") and callable(getattr(self, "_prepare_user_prompt")):
            prepared = self._prepare_user_prompt(**kwargs)
            return prepared or user_prompt
        return user_prompt

    def _should_force_json(
        self,
        state: AgentState,
        response_model: Optional[Type[BaseModel]],
        send_tools_now: bool,
        force_json_initial: bool,
    ) -> bool:
        """Decide when the next LLM call should run in JSON-only mode."""
        if not response_model or not self.config.force_json_after_tools:
            return False
        # Force JSON if tools aren't being sent, or if initial JSON is forced before tools
        return (not send_tools_now) or (force_json_initial and not state.had_tool_round)

    async def _handle_llm_response(
        self,
        state: AgentState,
        messages: List[JSONDict],
        response: Dict[str, Any],
        response_model: Optional[Type[BaseModel]],
    ) -> Optional[Any]:
        """Process an LLM turn and decide whether to continue or finalize."""
        content = response.get("text_response") or ""
        tool_calls = response.get("tool_calls") or []
        if not tool_calls:
            return await self._handle_no_tool_response(state, messages, content, response_model)

        assistant_message: JSONDict = {
            "role": "assistant",
            "content": content or "",
            "tool_calls": tool_calls,
        }
        messages.append(assistant_message)
        self.last_messages = list(messages)

        await self._handle_tool_calls(state, messages, tool_calls)
        self.last_messages = list(messages)
        return None

    async def _handle_no_tool_response(
        self,
        state: AgentState,
        messages: List[JSONDict],
        content: str,
        response_model: Optional[Type[BaseModel]],
    ) -> Optional[Any]:
        """Handle a pure text response (no tool calls)."""
        if self.config.require_tools and not state.had_tool_round and self._tools_payload:
            raise ToolCallRequiredError(
                "Model did not request any tools on the first round; tools are required for this agent."
            )

        if not content:
            return None

        assistant_message = {"role": "assistant", "content": content}

        required_tools = set(self.config.required_tools_before_final or [])
        if self.config.require_write_code:
            required_tools.add("write_code_file")

        if required_tools:
            missing = required_tools.difference(state.executed_tools)
            if missing:
                messages.append(assistant_message)
                messages.append(
                    {
                        "role": "system",
                        "content": (
                            "You must call the following tools BEFORE returning the final JSON answer: "
                            + ", ".join(sorted(missing))
                            + ". Use them now to apply your code changes (for example, by calling write_code_file) and then respond again."
                        ),
                    }
                )
                self.last_messages = list(messages)
                return None
        if response_model:
            parsed = self._parse_to_model(response_model, content)
            if parsed is not None:
                state.have_final_json = True
                self.last_messages = messages + [assistant_message]
                return parsed
            return await self._finalize_with_schema_tool(state, messages, response_model)

        self.last_messages = messages + [assistant_message]
        return content

    async def _finalize_with_schema_tool(
        self,
        state: AgentState,
        messages: List[JSONDict],
        response_model: Type[BaseModel],
    ) -> BaseModel:
        """Inject the schema tool to coerce the final structured response."""
        schema_tool = self._build_schema_tool_for_model(response_model)
        messages.append(
            {
                "role": "system",
                "content": (
                    "Final step: Call the provided function exactly once with the final structured result. "
                    "Do NOT write any text. Only call the function. "
                    "If a field expects an array, provide a JSON array (e.g., [] if empty)."
                ),
            }
        )
        resp2 = await self._call_llm(
            state,
            messages,
            force_no_tools=False,
            json_mode=False,
            override_tools=[schema_tool],
            override_tool_choice="required",
        )
        tool_calls2 = resp2.get("tool_calls") or []
        if not tool_calls2:
            raise ValueError(
                "Assistant did not return valid JSON for the expected response model. "
                "Strict tool-finalization also failed (no tool call)."
            )
        args_raw = (tool_calls2[0].get("function") or {}).get("arguments") or "{}"
        _, kwargs_norm = self._normalize_tool_args(args_raw)

        # Apply coercion only if configured
        if self.config.coerce_sloppy_output:
            final_args = _coerce_args_for_model(kwargs_norm or {}, response_model)
        else:
            final_args = kwargs_norm or {}

        try:
            state.have_final_json = True
            self.last_messages = messages
            return response_model(**final_args)
        except Exception as exc:
            coercion_note = " (coercion enabled)" if self.config.coerce_sloppy_output else " (coercion disabled)"
            raise ValueError(
                "Assistant did not return valid JSON for the expected response model. "
                f"Tool-finalization arguments could not be parsed{coercion_note}: {exc}"
            ) from None

    async def _handle_tool_calls(
        self,
        state: AgentState,
        messages: List[JSONDict],
        tool_calls: List[Dict[str, Any]],
    ) -> None:
        """Execute tool calls requested by the model and append their results."""
        if (
            self.config.max_tool_rounds > 0
            and state.tool_rounds >= self.config.max_tool_rounds
        ):
            state.tools_budget_exhausted = True
            messages.append(
                {
                    "role": "system",
                    "content": (
                        f"Tool round budget reached (max_tool_rounds={self.config.max_tool_rounds}). "
                        "Do not call any more tools. Produce the final JSON result now."
                    ),
                }
            )
            return

        state.record_tool_round()

        per_round_budget = (
            self.config.max_tool_calls_per_round
            if self.config.max_tool_calls_per_round > 0
            else len(tool_calls)
        )
        remaining_total = (
            self.config.max_tool_calls_total - state.total_tool_calls
            if self.config.max_tool_calls_total > 0
            else len(tool_calls)
        )
        allow_n = min(len(tool_calls), per_round_budget, max(remaining_total, 0))

        if allow_n <= 0:
            messages.append(
                {
                    "role": "system",
                    "content": (
                        "Tool-call budget for this round is exhausted. "
                        "If you still need tools, reply calling tools again next turn; "
                        "otherwise, produce the final JSON result."
                    ),
                }
            )
            return

        exec_calls = tool_calls[:allow_n]
        skipped = tool_calls[allow_n:]

        tool_outputs: List[JSONDict] = []
        for call in exec_calls:
            fn_info = call.get("function") or {}
            name = fn_info.get("name")
            if not name or name not in self.tool_map:
                raise ToolConfigurationError(f"Unknown tool requested by the model: {name!r}")

            args_raw = fn_info.get("arguments") or "{}"
            pargs, kwargs_norm = self._normalize_tool_args(args_raw)

            tool_call_id = call.get("id", name)
            log_tool = name in {"read_code_file", "write_code_file"}
            if log_tool:
                path_hint = (kwargs_norm or {}).get("file_path") or (kwargs_norm or {}).get("path")
                print(
                    f"[ProviderAgent] executing {name} (id={tool_call_id})"
                    + (f" on {path_hint}" if path_hint else ""),
                    flush=True,
                )

            try:
                result = await self._maybe_await(self.tool_map[name], *pargs, **(kwargs_norm or {}))
            except Exception as exc:
                if log_tool:
                    print(
                        f"[ProviderAgent] {name} (id={tool_call_id}) failed: {exc}",
                        flush=True,
                    )
                raise
            else:
                if log_tool:
                    print(
                        f"[ProviderAgent] {name} (id={tool_call_id}) completed",
                        flush=True,
                    )

            state.executed_tools.add(name)

            tool_outputs.append(
                {
                    "tool_call_id": tool_call_id,
                    "role": "tool",
                    "name": name,
                    "content": json.dumps(result, ensure_ascii=False),
                }
            )

            if name == "write_code_file":
                state.write_code_calls += 1

        state.total_tool_calls += len(exec_calls)
        messages.extend(tool_outputs)
        self.last_messages = list(messages)

        if skipped:
            messages.append(
                {
                    "role": "system",
                    "content": (
                        f"{len(skipped)} additional tool calls were skipped due to the per-round or total tool-call budget. "
                        "Please consolidate and call only the most necessary tools next turn, then finalize."
                    ),
                }
            )
