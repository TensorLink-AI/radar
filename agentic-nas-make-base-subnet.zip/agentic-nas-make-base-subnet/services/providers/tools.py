# tools.py
from __future__ import annotations

"""
Provider-safe tool utilities.

- @tool(description): decorate a Python function to expose it as a function tool
- ScriptPolicy: simple allowlist + timeout for script tools
- script_tool(name, script_path, arg_schema, policy): wrap a script as a tool
- to_tool_spec(func): return a validated, provider-safe tool spec (or None)
- build_tool_map(tools): build a lookup map keyed by tool spec names

Hardenings:
- Ensures JSON-serializable, provider-safe tool specs
- Normalizes "parameters" to a valid JSON Schema object
- Aligns callable __name__ with the tool spec name for script tools
- Filters invalid specs so you never send `{}` to the provider
"""

import json
import subprocess
from typing import Any, Callable, Dict, List, Optional

JSONDict = Dict[str, Any]
ToolFunc = Callable[..., Any]

__all__ = [
    "tool",
    "ScriptPolicy",
    "script_tool",
    "to_tool_spec",
    "build_tool_map",
]


# ----------------------------- JSON helpers ----------------------------- #

def _is_json_serializable(x: Any) -> bool:
    try:
        json.dumps(x)
        return True
    except Exception:
        return False


def _normalize_parameters(params: Dict[str, Any]) -> Dict[str, Any]:
    """
    Ensure a provider-safe parameters schema:
      - Must be an object schema with (possibly empty) properties
      - Coerces unknown/pythonic types to valid JSON Schema types
      - Keeps `required` if it's a list[str]
      - Allows additionalProperties by default
    """
    if not isinstance(params, dict):
        return {"type": "object", "properties": {}, "additionalProperties": True}

    schema_type = params.get("type")
    if schema_type != "object":
        # Force to object schema
        return {"type": "object", "properties": {}, "additionalProperties": True}

    props = params.get("properties", {})
    if not isinstance(props, dict):
        props = {}

    def _coerce_type(v: Dict[str, Any]) -> Dict[str, Any]:
        # Accept only valid JSON Schema primitives; coerce everything else to string
        if not isinstance(v, dict):
            return {"type": "string"}

        t = v.get("type")
        if t in {"string", "number", "integer", "boolean", "object", "array"}:
            return v

        # Common pythonic aliases
        if t in {"str", "text"}:
            return {"type": "string"}
        if t in {"int"}:
            return {"type": "integer"}
        if t in {"float"}:
            return {"type": "number"}
        if t in {"bool"}:
            return {"type": "boolean"}

        # Arrays without proper items spec → fallback to array of strings
        if t in {"list"}:
            return {"type": "array", "items": {"type": "string"}}

        # Fallback
        return {"type": "string"}

    safe_props = {k: _coerce_type(v) for k, v in props.items()}

    out = {
        "type": "object",
        "properties": safe_props,
        "additionalProperties": True,  # permissive by default
    }

    req = params.get("required")
    if isinstance(req, list) and all(isinstance(x, str) for x in req):
        out["required"] = req

    return out


def _validate_and_fix_tool_spec(spec: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    """
    Validate a raw tool spec and return a provider-safe version.
    Returns None if invalid or not JSON-serializable.
    """
    if not isinstance(spec, dict):
        return None

    if spec.get("type") != "function":
        return None

    fn = spec.get("function")
    if not isinstance(fn, dict):
        return None

    name = fn.get("name")
    if not isinstance(name, str) or not name:
        return None

    desc = (fn.get("description") or "").strip()
    params = _normalize_parameters(fn.get("parameters") or {"type": "object", "properties": {}})

    cleaned = {
        "type": "function",
        "function": {
            "name": name,
            "description": desc,
            "parameters": params,
        },
    }

    if not _is_json_serializable(cleaned):
        return None

    return cleaned


# ---------------------------- Public decorators ---------------------------- #

def tool(description: str):
    """
    Decorator to expose a Python function as a function tool with a safe, minimal schema.

    Example:
        @tool("Reads a code file by path")
        def read_code_file(file_path: str) -> str:
            ...
    """
    def decorator(func: ToolFunc) -> ToolFunc:
        func.tool_spec = {
            "type": "function",
            "function": {
                "name": func.__name__,
                "description": description,
                "parameters": {
                    "type": "object",
                    "properties": {},        # keep minimal; provider can still pass args
                    "required": [],
                    "additionalProperties": True,
                },
            },
        }
        return func
    return decorator


class ScriptPolicy:
    """
    Simple allowlist + timeout policy for script tools.
    """
    def __init__(self, allowlist: List[str], max_seconds: int):
        self.allowlist = allowlist
        self.max_seconds = max_seconds


def script_tool(
    name: str,
    script_path: str,
    arg_schema: Dict[str, Any],
    policy: ScriptPolicy,
) -> ToolFunc:
    """
    Wrap an external script as a tool with a validated schema.

    Args:
        name: tool/function name exposed to the model (must be unique)
        script_path: absolute/relative path to the script to execute
        arg_schema: JSON-Schema-like "parameters" object (normalized internally)
        policy: ScriptPolicy (allowlist + timeout)

    Returns:
        A callable tool. Its __name__ is set to `name` to align with tool spec and agent tool_map.
    """
    def func(**kwargs):
        if script_path not in policy.allowlist:
            return {"success": False, "error": f"Script not in allowlist: {script_path}"}

        # Deterministic argv order by argument name (stable + testable)
        ordered_items = sorted(kwargs.items())
        command = [script_path] + [str(v) for _, v in ordered_items]

        try:
            result = subprocess.run(
                command,
                capture_output=True,
                text=True,
                timeout=policy.max_seconds,
                check=True,  # raise if non-zero exit code
            )
            return {"success": True, "stdout": result.stdout, "stderr": result.stderr}
        except subprocess.TimeoutExpired:
            return {"success": False, "error": "Script timed out"}
        except subprocess.CalledProcessError as e:
            return {
                "success": False,
                "error": f"Script failed with exit code {e.returncode}",
                "stdout": e.stdout,
                "stderr": e.stderr,
            }
        except Exception as e:
            return {"success": False, "error": str(e)}

    # Align callable name with the exposed tool name so your tool_map works by spec-name
    func.__name__ = name

    # Attach a normalized spec
    func.tool_spec = {
        "type": "function",
        "function": {
            "name": name,
            "description": f"Executes the sandboxed script: {script_path}",
            "parameters": _normalize_parameters(arg_schema),
        },
    }
    return func


# ------------------------------ Spec extraction ------------------------------ #

def to_tool_spec(tool_func: Any) -> Optional[Dict[str, Any]]:
    """
    Extract and validate the tool spec from a decorated function.

    Returns:
        provider-safe spec dict, or None if invalid.
    """
    raw = getattr(tool_func, "tool_spec", None)
    return _validate_and_fix_tool_spec(raw or {})


def build_tool_map(tools: List[ToolFunc]) -> Dict[str, ToolFunc]:
    """
    Build a robust lookup map for tool execution.

    Keys both:
      - the spec/function name from the tool spec
      - the callable's __name__ (in case they differ)

    Invalid specs are skipped.
    """
    tool_map: Dict[str, ToolFunc] = {}
    for t in tools:
        spec = to_tool_spec(t)
        if not spec:
            continue
        spec_name = spec["function"]["name"]
        tool_map[spec_name] = t
        tool_map[getattr(t, "__name__", spec_name)] = t
    return tool_map

# --- keep your existing imports and code above ---

# Make finalize_check callable by LLMs (attach a function-tool spec)
def finalize_check(success: bool, error: str = "") -> dict:
    """No-op finalizer so agents can commit decision before the JSON-only reply."""
    return {"success": bool(success), "error": str(error or "")}

# Attach a JSON-schema tool spec so providers can advertise it
finalize_check.tool_spec = {
    "type": "function",
    "function": {
        "name": "finalize_check",
        "description": "Finalize the code-check decision before emitting the final JSON response.",
        "parameters": {
            "type": "object",
            "properties": {
                "success": {"type": "boolean", "description": "Set true if the code passes after fixes."},
                "error": {"type": "string", "description": "Short explanation if issues remain."}
            },
            "required": ["success"],
            "additionalProperties": False
        },
    },
}
