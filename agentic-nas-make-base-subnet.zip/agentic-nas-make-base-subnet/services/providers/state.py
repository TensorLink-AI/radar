"""Runtime state tracking for provider-backed agents."""
from __future__ import annotations

from dataclasses import dataclass, field, asdict
from typing import Any, Dict, List, Set

JSONDict = Dict[str, Any]


@dataclass
class AgentState:
    """Serializable container holding the runtime state of a provider agent.

    ``ProviderAgent`` mutates this dataclass during execution instead of keeping
    many ad-hoc attributes on ``self``. The shape of the state is therefore
    explicit and easy to serialize which prepares the codebase for external
    state stores (Redis/Postgres) and stateless workers.
    """

    messages: List[JSONDict] = field(default_factory=list)
    turn: int = 0
    tool_rounds: int = 0
    had_tool_round: bool = False
    total_tool_calls: int = 0
    tools_budget_exhausted: bool = False
    have_final_json: bool = False
    json_instruction_injected: bool = False
    write_code_calls: int = 0
    executed_tools: Set[str] = field(default_factory=set)

    def record_tool_round(self) -> None:
        self.had_tool_round = True
        self.tool_rounds += 1

    def to_dict(self) -> Dict[str, Any]:
        """Return a serializable view of the state for logging or persistence."""
        return asdict(self)
