# services/providers/clients/chutes_client.py
import asyncio
import json
import os
import re
from typing import Any, Dict, List, Optional
import httpx
from ..llm_client import LLMClient, Messages

# Retry configuration for transient errors
DEFAULT_MAX_RETRIES = 4
DEFAULT_RETRY_BASE_DELAY = 2.0  # seconds
RETRYABLE_STATUS_CODES = {429, 500, 502, 503, 504}

# =============================================================================
# Tool Call Parsing Patterns for Various Model Formats
# =============================================================================

# DeepSeek special token format
# Matches: function<｜tool▁sep｜>tool_name```json{...}```<｜tool▁call▁end｜>
DEEPSEEK_TOOL_PATTERN = re.compile(
    r'function[<\uff1c][|｜]tool[▁_]sep[|｜][>\uff1e](\w+)'  # function<|tool_sep|>name
    r'```(?:json)?\s*(\{.*?\})\s*```'  # ```json{...}```
    r'[<\uff1c][|｜]tool[▁_]call[▁_]end[|｜][>\uff1e]',  # <|tool_call_end|>
    re.DOTALL
)

# Hermes/Nous XML-style format
# Matches: <tool_call>{"name": "func", "arguments": {...}}</tool_call>
HERMES_TOOL_PATTERN = re.compile(
    r'<tool_call>\s*(\{.*?\})\s*</tool_call>',
    re.DOTALL
)

# Llama 3.1+ function tag format
# Matches: <function=func_name>{"arg": "val"}</function>
LLAMA_FUNCTION_PATTERN = re.compile(
    r'<function=(\w+)>\s*(\{.*?\})\s*</function>',
    re.DOTALL
)

# Mistral [TOOL_CALLS] format
# Matches: [TOOL_CALLS] [{"name": "func", "arguments": {...}}]
MISTRAL_TOOL_PATTERN = re.compile(
    r'\[TOOL_CALLS\]\s*(\[.*?\])',
    re.DOTALL
)

# Functionary triple-arrow format
# Matches: >>>func_name\n{"arg": "val"}
FUNCTIONARY_PATTERN = re.compile(
    r'>>>(\w+)\s*\n\s*(\{.*?\})(?=\n|$)',
    re.DOTALL
)

# ReAct/Command-R style format
# Matches: Action: func_name\nAction Input: {"arg": "val"}
REACT_PATTERN = re.compile(
    r'Action:\s*(\w+)\s*\n\s*Action\s*Input:\s*(\{.*?\})(?=\n|$)',
    re.DOTALL | re.IGNORECASE
)

# Generic JSON tool call in text (fallback)
# Matches standalone JSON with "name" and "arguments" keys
GENERIC_JSON_TOOL_PATTERN = re.compile(
    r'\{[^{}]*"name"\s*:\s*"(\w+)"[^{}]*"arguments"\s*:\s*(\{.*?\})[^{}]*\}',
    re.DOTALL
)


def _safe_parse_json(text: str) -> Optional[Dict]:
    """Safely parse JSON, returning None on failure."""
    try:
        return json.loads(text)
    except (json.JSONDecodeError, TypeError):
        return None


def _ensure_json_arguments(arguments: Any) -> str:
    """Ensure tool call arguments are a valid JSON string.

    The OpenAI-compatible API requires tool_calls.function.arguments to be
    a valid JSON string.  Various text-based parsers and model outputs can
    produce raw text that isn't valid JSON, which causes 400 errors.

    Returns a valid JSON string (the original if already valid, or "{}" as
    a safe fallback).
    """
    if not isinstance(arguments, str):
        # Already a dict/list – serialize it
        try:
            return json.dumps(arguments)
        except (TypeError, ValueError):
            return "{}"

    # Fast path: try parsing to confirm validity
    try:
        json.loads(arguments)
        return arguments
    except (json.JSONDecodeError, ValueError):
        pass

    # Strip surrounding whitespace / markdown fences that some models add
    stripped = arguments.strip()
    if stripped.startswith("```"):
        # Remove ```json ... ``` wrappers
        stripped = re.sub(r'^```(?:json)?\s*', '', stripped)
        stripped = re.sub(r'\s*```$', '', stripped)
        stripped = stripped.strip()

    try:
        json.loads(stripped)
        return stripped
    except (json.JSONDecodeError, ValueError):
        return "{}"


def _parse_deepseek_tool_calls(text: str) -> List[Dict[str, Any]]:
    """Parse DeepSeek special token format tool calls."""
    tool_calls = []
    for i, match in enumerate(DEEPSEEK_TOOL_PATTERN.finditer(text)):
        name = match.group(1)
        args = _ensure_json_arguments(match.group(2).strip())
        tool_calls.append({
            "id": f"call_{i}",
            "type": "function",
            "function": {"name": name, "arguments": args},
        })
    return tool_calls


def _parse_hermes_tool_calls(text: str) -> List[Dict[str, Any]]:
    """Parse Hermes/Nous XML-style tool calls."""
    tool_calls = []
    for i, match in enumerate(HERMES_TOOL_PATTERN.finditer(text)):
        parsed = _safe_parse_json(match.group(1))
        if parsed and "name" in parsed:
            args = parsed.get("arguments", parsed.get("parameters", {}))
            if isinstance(args, dict):
                args = json.dumps(args)
            tool_calls.append({
                "id": f"call_{i}",
                "type": "function",
                "function": {"name": parsed["name"], "arguments": args or "{}"},
            })
    return tool_calls


def _parse_llama_tool_calls(text: str) -> List[Dict[str, Any]]:
    """Parse Llama 3.1+ <function=name>{args}</function> format."""
    tool_calls = []
    for i, match in enumerate(LLAMA_FUNCTION_PATTERN.finditer(text)):
        name = match.group(1)
        args = _ensure_json_arguments(match.group(2).strip())
        tool_calls.append({
            "id": f"call_{i}",
            "type": "function",
            "function": {"name": name, "arguments": args},
        })
    return tool_calls


def _parse_mistral_tool_calls(text: str) -> List[Dict[str, Any]]:
    """Parse Mistral [TOOL_CALLS] format."""
    tool_calls = []
    match = MISTRAL_TOOL_PATTERN.search(text)
    if match:
        parsed = _safe_parse_json(match.group(1))
        if isinstance(parsed, list):
            for i, tc in enumerate(parsed):
                if isinstance(tc, dict) and "name" in tc:
                    args = tc.get("arguments", tc.get("parameters", {}))
                    if isinstance(args, dict):
                        args = json.dumps(args)
                    tool_calls.append({
                        "id": f"call_{i}",
                        "type": "function",
                        "function": {"name": tc["name"], "arguments": args or "{}"},
                    })
    return tool_calls


def _parse_functionary_tool_calls(text: str) -> List[Dict[str, Any]]:
    """Parse Functionary >>>func_name format."""
    tool_calls = []
    for i, match in enumerate(FUNCTIONARY_PATTERN.finditer(text)):
        name = match.group(1)
        args = _ensure_json_arguments(match.group(2).strip())
        tool_calls.append({
            "id": f"call_{i}",
            "type": "function",
            "function": {"name": name, "arguments": args},
        })
    return tool_calls


def _parse_react_tool_calls(text: str) -> List[Dict[str, Any]]:
    """Parse ReAct/Command-R Action: format."""
    tool_calls = []
    for i, match in enumerate(REACT_PATTERN.finditer(text)):
        name = match.group(1)
        args = _ensure_json_arguments(match.group(2).strip())
        tool_calls.append({
            "id": f"call_{i}",
            "type": "function",
            "function": {"name": name, "arguments": args},
        })
    return tool_calls


def _parse_generic_json_tool_calls(text: str) -> List[Dict[str, Any]]:
    """Parse generic JSON tool call format as fallback."""
    tool_calls = []
    for i, match in enumerate(GENERIC_JSON_TOOL_PATTERN.finditer(text)):
        name = match.group(1)
        args = _ensure_json_arguments(match.group(2).strip())
        tool_calls.append({
            "id": f"call_{i}",
            "type": "function",
            "function": {"name": name, "arguments": args},
        })
    return tool_calls


def _strip_tool_call_markers(text: str) -> str:
    """Remove all tool call markers from text."""
    # DeepSeek markers
    text = DEEPSEEK_TOOL_PATTERN.sub('', text)
    text = re.sub(r'[<\uff1c][|｜]tool[▁_]calls[▁_]end[|｜][>\uff1e]', '', text)
    # Hermes markers
    text = HERMES_TOOL_PATTERN.sub('', text)
    # Llama markers
    text = LLAMA_FUNCTION_PATTERN.sub('', text)
    # Mistral markers
    text = MISTRAL_TOOL_PATTERN.sub('', text)
    # Functionary markers
    text = FUNCTIONARY_PATTERN.sub('', text)
    # ReAct markers
    text = REACT_PATTERN.sub('', text)
    return text.strip()


def parse_tool_calls_from_text(text: str) -> List[Dict[str, Any]]:
    """
    Parse tool calls from text using multiple format patterns.

    Tries formats in order of specificity:
    1. DeepSeek special tokens
    2. Hermes/Nous XML tags
    3. Llama 3.1+ function tags
    4. Mistral [TOOL_CALLS]
    5. Functionary >>>
    6. ReAct Action:
    7. Generic JSON (fallback)

    Returns first successful parse result.
    """
    if not text:
        return []

    # Try each parser in order of specificity
    parsers = [
        _parse_deepseek_tool_calls,
        _parse_hermes_tool_calls,
        _parse_llama_tool_calls,
        _parse_mistral_tool_calls,
        _parse_functionary_tool_calls,
        _parse_react_tool_calls,
        _parse_generic_json_tool_calls,
    ]

    for parser in parsers:
        tool_calls = parser(text)
        if tool_calls:
            return tool_calls

    return []


# Legacy alias for backwards compatibility
_parse_special_token_tool_calls = parse_tool_calls_from_text
SPECIAL_TOKEN_TOOL_PATTERN = DEEPSEEK_TOOL_PATTERN


class ChutesClient(LLMClient):
    def __init__(
        self,
        base_url: Optional[str] = None,
        api_key: Optional[str] = None,
        timeout: Optional[httpx.Timeout] = None,
        default_temperature: Optional[float] = None,
    ):
        self.base_url = (
            base_url or os.getenv("CHUTES_API_URL") or "https://llm.chutes.ai"
        ).rstrip("/")
        self.api_key = api_key or os.getenv("CHUTES_API_KEY")
        if not self.api_key:
            raise ValueError("Missing CHUTES_API_KEY")

        # Temperature: constructor arg > env var > 0.0 default
        if default_temperature is not None:
            self.default_temperature = default_temperature
        elif (env_temp := os.getenv("CHUTES_TEMPERATURE")) is not None:
            self.default_temperature = float(env_temp)
        else:
            self.default_temperature = 0.0

        # Timeout config: constructor arg > env var > defaults
        # Use longer connect timeout for TEE handshakes to prevent stale connection issues
        if timeout is not None:
            self.timeout_config = timeout
        elif (env_timeout := os.getenv("CHUTES_TIMEOUT")) is not None:
            timeout_val = float(env_timeout)
            self.timeout_config = httpx.Timeout(timeout_val, connect=60.0, read=150.0, write=60.0)
        else:
            self.timeout_config = httpx.Timeout(60.0, connect=60.0, read=150.0, write=60.0)

        # telemetry for Runner / AgentLogger
        self.last_usage: Optional[Dict[str, Any]] = None
        self.history: List[Dict[str, Any]] = []
        self.last_response: Optional[Dict[str, Any]] = None

    async def aclose(self):
        # No-op: we create fresh clients per request to avoid TEE stale connection issues
        pass

    @staticmethod
    def _sanitize_messages(messages: Messages) -> Messages:
        """Strip tool_calls from assistant messages that aren't followed by tool results,
        and ensure all tool_call arguments are valid JSON.

        The OpenAI-compatible API requires that:
        1. Tool result messages (role="tool") must be preceded by an assistant message
           with tool_calls that references them
        2. Orphaned tool_calls (not followed by tool results) can cause issues with
           some providers
        3. tool_calls.function.arguments must be a valid JSON string

        This sanitizer:
        - Removes tool_calls ONLY from assistant messages that are NOT immediately
          followed by corresponding tool result messages
        - Validates all tool_call arguments are valid JSON strings
        """
        sanitized: Messages = []
        n = len(messages)

        for i, msg in enumerate(messages):
            if msg.get("role") == "assistant" and msg.get("tool_calls"):
                # Check if this assistant message is followed by tool result messages
                # Tool results must immediately follow the assistant message with tool_calls
                has_following_tool_results = False
                if i + 1 < n:
                    next_msg = messages[i + 1]
                    if next_msg.get("role") == "tool":
                        has_following_tool_results = True

                if has_following_tool_results:
                    # Keep tool_calls but ensure arguments are valid JSON
                    msg_copy = dict(msg)
                    msg_copy["tool_calls"] = [
                        {
                            **tc,
                            "function": {
                                **tc.get("function", {}),
                                "arguments": _ensure_json_arguments(
                                    tc.get("function", {}).get("arguments", "{}")
                                ),
                            },
                        }
                        for tc in msg.get("tool_calls", [])
                    ]
                    sanitized.append(msg_copy)
                else:
                    # Strip orphaned tool_calls to avoid Chutes API errors
                    msg_copy = dict(msg)
                    msg_copy.pop("tool_calls", None)
                    sanitized.append(msg_copy)
            else:
                sanitized.append(msg)
        return sanitized

    async def chat(
        self,
        *,
        model: Optional[str],
        messages: Messages,
        temperature: Optional[float] = None,
        tools: Optional[List[Dict[str, Any]]] = None,
        tool_choice: Optional[str] = "auto",
        response_format: Optional[Dict[str, Any]] = None,  # supports {"type": "json_object"}
        extra: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        effective_temperature = temperature if temperature is not None else self.default_temperature
        payload: Dict[str, Any] = {
            "model": model,
            "messages": self._sanitize_messages(messages),
            "temperature": effective_temperature,
        }
        if tools:
            payload["tools"] = tools
            if tool_choice is not None:
                payload["tool_choice"] = tool_choice
        if response_format is not None:
            payload["response_format"] = response_format
        if extra:
            payload.update(extra)

        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        }

        # Create fresh client per request to avoid TEE stale connection issues
        # Retry logic for transient errors with exponential backoff
        last_exc: Optional[Exception] = None
        for attempt in range(DEFAULT_MAX_RETRIES + 1):
            try:
                async with httpx.AsyncClient(timeout=self.timeout_config) as client:
                    resp = await client.post(
                        f"{self.base_url}/v1/chat/completions", json=payload, headers=headers
                    )
                    resp.raise_for_status()
                    resp_json = resp.json()
                    break  # Success - exit retry loop
            except httpx.HTTPStatusError as exc:
                status_code = exc.response.status_code
                # Check if this is a retryable error
                if status_code in RETRYABLE_STATUS_CODES and attempt < DEFAULT_MAX_RETRIES:
                    delay = DEFAULT_RETRY_BASE_DELAY * (2 ** attempt)  # Exponential backoff: 2s, 4s, 8s, 16s
                    await asyncio.sleep(delay)
                    last_exc = exc
                    continue

                # Non-retryable error or max retries exceeded - format and raise
                try:
                    detail_json = exc.response.json()
                except Exception:
                    detail_json = None

                if isinstance(detail_json, dict):
                    detail: Any = detail_json.get("error") or detail_json
                elif detail_json is not None:
                    detail = detail_json
                else:
                    detail = exc.response.text

                raise httpx.HTTPStatusError(
                    f"{exc.response.status_code} {exc.response.reason_phrase}: {detail}",
                    request=exc.request,
                    response=exc.response,
                ) from None
            except (httpx.ConnectError, httpx.ReadTimeout, httpx.WriteTimeout) as exc:
                # Network errors are also retryable
                if attempt < DEFAULT_MAX_RETRIES:
                    delay = DEFAULT_RETRY_BASE_DELAY * (2 ** attempt)
                    await asyncio.sleep(delay)
                    last_exc = exc
                    continue
                raise  # Max retries exceeded
        else:
            # Should not reach here, but just in case
            if last_exc:
                raise last_exc

        # Save for Runner logging
        self.last_response = resp_json
        self.history.append(resp_json)

        usage = resp_json.get("usage") or {}
        self.last_usage = {
            "prompt_tokens": usage.get("prompt_tokens", 0),
            "completion_tokens": usage.get("completion_tokens", 0),
            "total_tokens": usage.get("total_tokens", 0),
        }

        return resp_json

    @staticmethod
    def normalize(resp_json: Dict[str, Any]) -> Dict[str, Any]:
        choice = (resp_json.get("choices") or [{}])[0]
        msg = choice.get("message") or {}
        text = msg.get("content") or ""

        tool_calls_list: List[Dict[str, Any]] = []
        for i, tc in enumerate(msg.get("tool_calls") or []):
            fn = tc.get("function") or {}
            tool_calls_list.append(
                {
                    "id": tc.get("id", f"call_{i}"),
                    "type": "function",
                    "function": {
                        "name": fn.get("name"),
                        "arguments": _ensure_json_arguments(fn.get("arguments", "{}")),
                    },
                }
            )

        # If no structured tool calls found, check for text-based tool call formats
        # Various models output tool calls as text with different markers:
        # - DeepSeek: function<|tool_sep|>name```json{...}```<|tool_call_end|>
        # - Hermes/Nous: <tool_call>{"name": ..., "arguments": ...}</tool_call>
        # - Llama 3.1+: <function=name>{...}</function>
        # - Mistral: [TOOL_CALLS] [{"name": ..., "arguments": ...}]
        # - Functionary: >>>func_name\n{...}
        # - ReAct: Action: name\nAction Input: {...}
        if not tool_calls_list and text:
            text_tool_calls = parse_tool_calls_from_text(text)
            if text_tool_calls:
                tool_calls_list = text_tool_calls
                # Strip the tool call markers from the text response
                text = _strip_tool_call_markers(text)

        return {
            "text_response": text,
            "tool_calls": tool_calls_list,  # always a list
        }
