# Manual Testing Notebook Plan

## Key Areas Observed
- `core/` contains the base agent orchestration logic (`core.base_agent`, `core.runner`) and task registry definitions under `core/tasks`.
- `tasks/` houses concrete task families such as `tasks.ts_foundation` which rely on the registry contracts.
- `services/` provides templates, providers, and high-level pipelines including `services.pipeline` and `services.miner_pipeline` for orchestrating experiments.
- `database/` exposes lightweight storage helpers, embedding/FAISS utilities, and checkpoint handling scripts.
- `resources/` and `scaffolds/` include smaller utilities that support templates and trainer flows.

## Notebook Suite Outline
1. **00_repo_scan_and_env.ipynb** – Establish environment sanity: resolve repo path, set seeds, inspect directory layout, and verify imports for `core`, `tasks`, and `services` modules.
2. **01_registry_and_tasks_sanity.ipynb** – Explore the task registry APIs (`core.tasks.registry`, `tasks.ts_foundation`). Instantiate lightweight task configs to confirm wiring and error handling.
3. **02_dataset_streaming_and_sampler.ipynb** – Build a synthetic streaming dataset using utilities from `tasks.ts_foundation.dataset` (if available) or a local stub to validate deterministic loaders and sampler behaviors.
4. **03_model_builder_and_forward_smoke.ipynb** – Exercise model builders from `tasks.ts_foundation.models` (or nearest equivalent) to construct a tiny model, compute parameter counts, and run forward passes.
5. **04_trainer_step_debugger.ipynb** – Leverage training loops (e.g., `services.pipeline` helpers or task-specific trainers) to run a short CPU-only optimization loop with gradient/loss diagnostics.
6. **05_checkpoint_io_and_hashing.ipynb** – Use saving utilities from `database` or PyTorch directly to persist a model, reload, and hash parameters to ensure deterministic checkpoint IO.
7. **06_template_end_to_end_dry_run.ipynb** – Dry-run a template entry point such as `services.miner_pipeline` or similar with a tiny job spec to verify end-to-end flow without external services.
8. **07_metrics_and_crps_demo.ipynb** – Showcase metrics utilities (searching under `services/utils` or `tasks` metrics) by computing CRPS-like metrics on synthetic predictions, including a small visualization.

Each notebook will include deterministic seeds (`1337`), concise print diagnostics, and a manual checklist summarizing expected results.
