#!/usr/bin/env python3
"""
Basilica stress test: concurrently trains multiple models on the same GPU(s)
using torch.multiprocessing.

This script is designed to run inside a container with torch pre-installed.
It is the entrypoint for the stress test Dockerfile.
"""

import os
import time
import random
import json
import traceback
import threading
from http.server import HTTPServer, BaseHTTPRequestHandler

import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.multiprocessing as mp
from torch.utils.data import IterableDataset, DataLoader
from torch.optim import AdamW

# -------------------------
# CONFIG (from env)
# -------------------------
NUM_MODELS = int(os.getenv("STRESS_NUM_MODELS", "8"))
TRAIN_SECONDS = int(os.getenv("STRESS_TRAIN_SECONDS", str(30 * 60)))
GPU_MEM_FRACTION = float(os.getenv("STRESS_GPU_MEM_FRACTION", "0.12"))
OMP_THREADS = int(os.getenv("STRESS_OMP_THREADS", "2"))
ALLOC_CONF = os.getenv("STRESS_ALLOC_CONF", "max_split_size_mb:128")
RESULTS_PATH = os.getenv("STRESS_RESULTS_PATH", "/tmp/stress_results.json")
PORT = int(os.getenv("PORT", "8000"))

INPUT_DIM = 512
OUTPUT_DIM = 256
BATCH_SIZE = 16
LR = 3e-4

# Set multiprocessing start method at module level, before any threads.
# Use 'fork' because:
#   1. the parent process has NOT initialized CUDA yet, so fork is safe
#   2. 'fork' avoids the pickle/import overhead entirely
try:
    mp.set_start_method("fork", force=True)
except RuntimeError:
    pass  # already set


# -------------------------
# Model + data
# -------------------------
class RandomDataset(IterableDataset):
    def __iter__(self):
        while True:
            yield torch.randn(INPUT_DIM), torch.randn(OUTPUT_DIM)


class MockLargeModel(nn.Module):
    def __init__(self, hidden_dim: int, depth: int):
        super().__init__()
        self.in_proj = nn.Linear(INPUT_DIM, hidden_dim)
        self.blocks = nn.ModuleList([
            nn.Sequential(
                nn.Linear(hidden_dim, hidden_dim * 4),
                nn.GELU(),
                nn.Linear(hidden_dim * 4, hidden_dim),
                nn.LayerNorm(hidden_dim),
            )
            for _ in range(depth)
        ])
        self.out_proj = nn.Linear(hidden_dim, OUTPUT_DIM)

    def forward(self, x):
        x = self.in_proj(x)
        for block in self.blocks:
            x = torch.utils.checkpoint.checkpoint(
                block, x, use_reentrant=False
            )
        return self.out_proj(x)


def count_params(m: nn.Module) -> int:
    return sum(p.numel() for p in m.parameters())


def _set_cpu_caps():
    torch.set_num_threads(OMP_THREADS)
    torch.set_num_interop_threads(min(OMP_THREADS, 2))
    os.environ.setdefault("OMP_NUM_THREADS", str(OMP_THREADS))
    os.environ.setdefault("MKL_NUM_THREADS", str(OMP_THREADS))
    os.environ.setdefault("OPENBLAS_NUM_THREADS", str(OMP_THREADS))


def _vram_snapshot(device):
    torch.cuda.synchronize(device)
    return {
        "alloc_mb": round(torch.cuda.memory_allocated(device) / 1024**2, 1),
        "reserved_mb": round(torch.cuda.memory_reserved(device) / 1024**2, 1),
        "max_alloc_mb": round(torch.cuda.max_memory_allocated(device) / 1024**2, 1),
        "max_reserved_mb": round(torch.cuda.max_memory_reserved(device) / 1024**2, 1),
    }


def worker_main(model_id: int, start_time: float, shared_dict):
    try:
        os.environ["PYTORCH_CUDA_ALLOC_CONF"] = ALLOC_CONF
        _set_cpu_caps()

        if not torch.cuda.is_available():
            raise RuntimeError("CUDA not available in container")

        ngpu = torch.cuda.device_count()
        if ngpu <= 0:
            raise RuntimeError("No visible GPUs (device_count == 0)")

        gpu_id = model_id % ngpu
        device = torch.device(f"cuda:{gpu_id}")

        seed = 1337 + model_id
        random.seed(seed)
        torch.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)

        torch.cuda.set_per_process_memory_fraction(GPU_MEM_FRACTION, device=device)
        torch.cuda.reset_peak_memory_stats(device)

        hidden_dim = random.choice([1792, 2048, 2304])
        depth = random.choice([24, 26, 28])

        model = MockLargeModel(hidden_dim, depth).to(device).half()
        params = count_params(model)
        if not (100_000_000 <= params <= 130_000_000):
            raise AssertionError(f"params out of range: {params}")

        opt = AdamW(model.parameters(), lr=LR)
        loader = DataLoader(RandomDataset(), batch_size=BATCH_SIZE, num_workers=0)

        print(f"[worker {model_id}] gpu={gpu_id} params={params/1e6:.1f}M "
              f"hidden={hidden_dim} depth={depth}", flush=True)

        steps = 0
        last_loss = None

        for x, y in loader:
            if (time.time() - start_time) > TRAIN_SECONDS:
                break

            x = x.to(device).half()
            y = y.to(device).half()

            opt.zero_grad(set_to_none=True)
            loss = F.mse_loss(model(x), y)
            loss.backward()
            opt.step()

            last_loss = float(loss.item())
            steps += 1

            if steps % 100 == 0:
                snap = _vram_snapshot(device)
                print(f"[worker {model_id}] step={steps} loss={last_loss:.4f} "
                      f"alloc={snap['alloc_mb']:.0f}MB peak={snap['max_alloc_mb']:.0f}MB",
                      flush=True)

        snap = _vram_snapshot(device)
        shared_dict[str(model_id)] = {
            "status": "ok",
            "model_id": model_id,
            "gpu_id": gpu_id,
            "steps": steps,
            "last_loss": last_loss,
            "params": params,
            "vram": snap,
        }
        print(f"[worker {model_id}] done steps={steps} last_loss={last_loss}", flush=True)

    except RuntimeError as e:
        msg = str(e)
        is_oom = ("out of memory" in msg.lower()) or ("cuda oom" in msg.lower())
        shared_dict[str(model_id)] = {
            "status": "oom" if is_oom else "error",
            "model_id": model_id,
            "error": msg[:500],
            "traceback": traceback.format_exc()[:2000],
        }
        print(f"[worker {model_id}] FAILED: {msg}", flush=True)

    except Exception as e:
        shared_dict[str(model_id)] = {
            "status": "error",
            "model_id": model_id,
            "error": str(e)[:500],
            "traceback": traceback.format_exc()[:2000],
        }
        print(f"[worker {model_id}] FAILED (unexpected): {e}", flush=True)


# Global status for the /results endpoint when stress hasn't finished yet
_stress_status = {"phase": "starting", "error": None}


def run_stress():
    global _stress_status
    try:
        torch.backends.cuda.matmul.allow_tf32 = True
        torch.backends.cudnn.allow_tf32 = True

        _stress_status["phase"] = "initializing"

        print("=== Basilica: multi-process concurrent training stress test ===", flush=True)
        print("NUM_MODELS:", NUM_MODELS, flush=True)
        print("TRAIN_SECONDS:", TRAIN_SECONDS, flush=True)
        print("CUDA_VISIBLE_DEVICES:", os.getenv("CUDA_VISIBLE_DEVICES"), flush=True)
        print("mp start method:", mp.get_start_method(), flush=True)

        if not torch.cuda.is_available():
            _stress_status = {"phase": "failed", "error": "CUDA not available"}
            print("ERROR: CUDA not available in container", flush=True)
            return

        print("device_count:", torch.cuda.device_count(), flush=True)
        for i in range(torch.cuda.device_count()):
            print(f"  GPU {i}: {torch.cuda.get_device_name(i)}", flush=True)

        print("GPU_MEM_FRACTION(per process):", GPU_MEM_FRACTION, flush=True)
        print("OMP_THREADS(per process):", OMP_THREADS, flush=True)
        print("PYTORCH_CUDA_ALLOC_CONF:", ALLOC_CONF, flush=True)

        manager = mp.Manager()
        shared = manager.dict()
        start_time = time.time()

        _stress_status["phase"] = "training"

        procs = []
        for model_id in range(NUM_MODELS):
            p = mp.Process(
                target=worker_main,
                args=(model_id, start_time, shared),
                daemon=False,
            )
            p.start()
            procs.append(p)
            print(f"[main] started worker {model_id} (pid={p.pid})", flush=True)

        for i, p in enumerate(procs):
            p.join()
            exit_code = p.exitcode
            print(f"[main] worker {i} exited with code {exit_code}", flush=True)

        results = {k: dict(v) for k, v in shared.items()}
        ok = [r for r in results.values() if r.get("status") == "ok"]
        oom = [r for r in results.values() if r.get("status") == "oom"]
        err = [r for r in results.values() if r.get("status") == "error"]

        summary = {
            "num_models": NUM_MODELS,
            "train_seconds": TRAIN_SECONDS,
            "wall_time": round(time.time() - start_time, 1),
            "ok": len(ok),
            "oom": len(oom),
            "error": len(err),
            "results": results,
        }

        print("\n=== SUMMARY ===", flush=True)
        print("OK:", len(ok), "OOM:", len(oom), "ERR:", len(err), flush=True)
        if ok:
            steps = sorted([r["steps"] for r in ok])
            print("steps min/median/max:", steps[0], steps[len(steps)//2], steps[-1],
                  flush=True)

        try:
            with open(RESULTS_PATH, "w") as f:
                json.dump(summary, f, indent=2)
            print("Wrote:", RESULTS_PATH, flush=True)
        except Exception as e:
            print("Could not write results json:", e, flush=True)

        _stress_status["phase"] = "done"

    except Exception as e:
        _stress_status = {"phase": "failed", "error": str(e)}
        print(f"[main] stress test FAILED: {e}", flush=True)
        traceback.print_exc()


class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        if self.path in ("/", "/healthz", "/ready"):
            self.send_response(200)
            self.end_headers()
            status = json.dumps(_stress_status).encode()
            self.wfile.write(status)
            return
        if self.path == "/results":
            self.send_response(200)
            self.end_headers()
            try:
                with open(RESULTS_PATH, "rb") as f:
                    self.wfile.write(f.read())
            except FileNotFoundError:
                self.wfile.write(json.dumps({
                    "status": "in_progress",
                    "phase": _stress_status.get("phase", "unknown"),
                }).encode())
            except Exception as e:
                self.wfile.write(json.dumps({"error": str(e)}).encode())
            return
        self.send_response(404)
        self.end_headers()
        self.wfile.write(b"not found")

    def log_message(self, format, *args):
        # Suppress HTTP access logs to reduce noise
        pass


def main():
    # Start stress test in background thread
    t = threading.Thread(target=run_stress, daemon=True)
    t.start()

    print(f"HTTP server listening on :{PORT} (for readiness + /results)", flush=True)
    HTTPServer(("0.0.0.0", PORT), Handler).serve_forever()


if __name__ == "__main__":
    main()
