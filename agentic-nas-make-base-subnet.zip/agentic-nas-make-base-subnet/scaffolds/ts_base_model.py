# scaffolds/ts_base_model.py
from __future__ import annotations

from typing import Any, Dict, Optional, Tuple, Sequence
import math

import torch
import torch.nn as nn
import torch.nn.functional as F

# Contract import (do not rename)
from tasks.ts_foundation.model_base import (
    TimeSeriesFoundationModel as BaseTSFM,
    validate_time_series_model

)

# -------------------------------------------------------
# Defaults + constraint-aware config helpers
# -------------------------------------------------------
DEFAULT_CONFIG: Dict[str, Any] = {
    # Core dims
    "d_model":        256,
    "n_layers":       6,
    "n_heads":        8,
    "d_ff":           1024,
    "dropout":        0.10,

    # Sequence sizing (max cap)
    "max_len":        2048,   # cap on (past + horizon)

    # Horizon (will be synced to constraints.forecast_length if provided)
    "horizon":        96,

    # Feature dims
    "target_dim":     1,
    "past_cov_dim":   0,
    "future_cov_dim": 0,
    "static_dim":     0,

    # Prob. head
    "quantile_levels": (0.05, 0.10, 0.25, 0.50, 0.75, 0.90, 0.95),

    # Optional constraints mirror (so we can round-trip via to_config)
    "constraints": {
        "input_length":     512,
        "forecast_length":  96,
        "max_total_tokens": None,  # if set, enforce input_length + horizon <= max_total_tokens
    },
}


def _merge_constraints(user: Optional[Dict[str, Any]]) -> Dict[str, Any]:
    c = dict(DEFAULT_CONFIG["constraints"])
    if user is None:
        return c
    if "constraints" in user and isinstance(user["constraints"], dict):
        c.update(user["constraints"])
    # Also accept top-level overrides commonly provided by the task
    if "input_length" in user:
        c["input_length"] = int(user["input_length"])
    if "forecast_length" in user:
        c["forecast_length"] = int(user["forecast_length"])
    if "max_total_tokens" in user:
        c["max_total_tokens"] = user["max_total_tokens"]

    # Basic sanity
    if not isinstance(c["input_length"], int) or c["input_length"] <= 0:
        raise ValueError("constraints.input_length must be a positive int")
    if not isinstance(c["forecast_length"], int) or c["forecast_length"] <= 0:
        raise ValueError("constraints.forecast_length must be a positive int")
    mtt = c["max_total_tokens"]
    if mtt is not None and (not isinstance(mtt, int) or mtt <= 0):
        raise ValueError("constraints.max_total_tokens must be None or a positive int")

    return c


def _apply_constraints_to_config(cfg: Dict[str, Any], cons: Dict[str, Any]) -> None:
    """
    - Sync horizon to constraints.forecast_length
    - Optionally enforce max_total_tokens by reducing input_length cap at runtime (handled in model)
    """
    cfg["constraints"] = cons
    cfg["horizon"] = int(cons["forecast_length"])


def _merge_config(user: Optional[Dict[str, Any]]) -> Dict[str, Any]:
    cons = _merge_constraints(user or {})
    cfg = dict(DEFAULT_CONFIG)
    if user:
        # Shallow update, constraints handled separately
        for k, v in user.items():
            if k != "constraints":
                cfg[k] = v
        if "quantile_levels" in user and isinstance(user["quantile_levels"], Sequence):
            cfg["quantile_levels"] = tuple(user["quantile_levels"])

    _apply_constraints_to_config(cfg, cons)

    # basic sanity
    if cfg["d_model"] % cfg["n_heads"] != 0:
        raise ValueError("d_model must be divisible by n_heads")
    qs = list(cfg["quantile_levels"])
    if not qs or any(q <= 0.0 or q >= 1.0 for q in qs):
        raise ValueError("quantile_levels must lie in (0,1)")
    for i in range(len(qs) - 1):
        if qs[i] >= qs[i + 1]:
            raise ValueError("quantile_levels must be strictly increasing")
    if cfg["horizon"] <= 0 or cfg["max_len"] <= 0:
        raise ValueError("horizon/max_len must be > 0")
    return cfg


# -------------------------------------------------------
# Utilities
# -------------------------------------------------------
def build_causal_mask(L: int, device: torch.device) -> torch.Tensor:
    # True = masked (no attend). Apply BEFORE softmax.
    return torch.triu(torch.ones(L, L, device=device, dtype=torch.bool), diagonal=1)


# -------------------------------------------------------
# Positional Encoding (learned)
# -------------------------------------------------------
class LearnedPosEncoding(nn.Module):
    def __init__(self, max_len: int, d_model: int):
        super().__init__()
        self.pos_emb = nn.Embedding(max_len, d_model)

    def forward(self, seq_len: int, device: torch.device) -> torch.Tensor:
        if seq_len > self.pos_emb.num_embeddings:
            raise ValueError(
                f"seq_len {seq_len} exceeds max_len {self.pos_emb.num_embeddings}"
            )
        idx = torch.arange(seq_len, device=device, dtype=torch.long)
        return self.pos_emb(idx)  # [L, d_model]


# -------------------------------------------------------
# Attention & Blocks (decoder)
# -------------------------------------------------------
class CausalSelfAttention(nn.Module):
    def __init__(self, d_model: int, n_heads: int, dropout: float):
        super().__init__()
        assert d_model % n_heads == 0
        self.n_heads = n_heads
        self.head_dim = d_model // n_heads

        self.qkv = nn.Linear(d_model, 3 * d_model)
        self.out = nn.Linear(d_model, d_model)
        self.attn_drop = nn.Dropout(dropout)
        self.proj_drop = nn.Dropout(dropout)

    def forward(self, x: torch.Tensor, attn_mask: torch.Tensor) -> torch.Tensor:
        B, L, D = x.shape
        qkv = self.qkv(x)  # [B, L, 3D]
        q, k, v = qkv.split(D, dim=-1)

        def _split_heads(t: torch.Tensor) -> torch.Tensor:
            return t.view(B, L, self.n_heads, self.head_dim).transpose(1, 2)  # [B,H,L,Hd]

        q = _split_heads(q)
        k = _split_heads(k)
        v = _split_heads(v)

        att = (q @ k.transpose(-2, -1)) / math.sqrt(self.head_dim)  # [B,H,L,L]
        att = att.masked_fill(attn_mask, float("-inf"))  # mask BEFORE softmax
        att = F.softmax(att, dim=-1)
        att = self.attn_drop(att)

        out = att @ v  # [B,H,L,Hd]
        out = out.transpose(1, 2).contiguous().view(B, L, D)
        out = self.proj_drop(self.out(out))
        return out


class MLP(nn.Module):
    def __init__(self, d_model: int, d_ff: int, dropout: float):
        super().__init__()
        self.fc1 = nn.Linear(d_model, d_ff)
        self.fc2 = nn.Linear(d_ff, d_model)
        self.drop = nn.Dropout(dropout)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.drop(self.fc2(F.gelu(self.fc1(x))))


class DecoderBlock(nn.Module):
    def __init__(self, d_model: int, n_heads: int, d_ff: int, dropout: float):
        super().__init__()
        self.ln1 = nn.LayerNorm(d_model)
        self.attn = CausalSelfAttention(d_model, n_heads, dropout)
        self.ln2 = nn.LayerNorm(d_model)
        self.mlp = MLP(d_model, d_ff, dropout)

    def forward(self, x: torch.Tensor, attn_mask: torch.Tensor) -> torch.Tensor:
        x = x + self.attn(self.ln1(x), attn_mask)
        x = x + self.mlp(self.ln2(x))
        return x


class DecoderOnlyCore(nn.Module):
    def __init__(self, d_model: int, n_layers: int, n_heads: int, d_ff: int, dropout: float):
        super().__init__()
        self.blocks = nn.ModuleList(
            [DecoderBlock(d_model, n_heads, d_ff, dropout) for _ in range(n_layers)]
        )
        self.ln_f = nn.LayerNorm(d_model)

    def forward(self, x: torch.Tensor, attn_mask: torch.Tensor) -> torch.Tensor:
        for blk in self.blocks:
            x = blk(x, attn_mask)
        return self.ln_f(x)


# -------------------------------------------------------
# Embeddings
# -------------------------------------------------------
class TokenEmbedding(nn.Module):
    """
    Projects per-step features into d_model. Separate projectors for past and future
    steps allow different covariate sets. Static features are broadcast and added.
    """
    def __init__(
        self,
        *,
        d_model: int,
        dropout: float,
        target_dim: int,
        past_cov_dim: int,
        future_cov_dim: int,
        static_dim: int,
        max_len: int,
    ):
        super().__init__()
        inp_past = target_dim + past_cov_dim
        inp_future = target_dim + future_cov_dim
        self.past_proj = nn.Linear(inp_past, d_model) if inp_past > 0 else nn.Identity()
        self.future_proj = nn.Linear(inp_future, d_model) if inp_future > 0 else nn.Identity()
        self.static_proj = nn.Linear(static_dim, d_model) if static_dim > 0 else None
        self.pos = LearnedPosEncoding(max_len, d_model)
        self.drop = nn.Dropout(dropout)

        self.target_dim = target_dim
        self.future_cov_dim = future_cov_dim

    def forward(
        self,
        past_feats: torch.Tensor,   # [B, T, target_dim + past_cov_dim]
        future_feats: torch.Tensor, # [B, H, target_dim + future_cov_dim]
        static: Optional[torch.Tensor],  # [B, static_dim] or None
    ) -> torch.Tensor:
        B, T, _ = past_feats.shape
        H = future_feats.shape[1]
        x_past = self.past_proj(past_feats)
        x_future = self.future_proj(future_feats)
        x = torch.cat([x_past, x_future], dim=1)  # [B, T+H, D]
        x = x + self.pos(T + H, x.device).unsqueeze(0)
        if self.static_proj is not None and static is not None:
            x = x + self.static_proj(static).unsqueeze(1)
        return self.drop(x)


# -------------------------------------------------------
# Quantile head (monotonic)
# -------------------------------------------------------
class QuantileHead(nn.Module):
    def __init__(self, d_model: int, n_quantiles: int):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(d_model, d_model),
            nn.GELU(),
            nn.Linear(d_model, n_quantiles),
        )
        # zero-init last layer -> start at baseline
        nn.init.zeros_(self.net[-1].weight)
        nn.init.zeros_(self.net[-1].bias)

    def forward(self, h_forecast: torch.Tensor) -> torch.Tensor:
        raw = self.net(h_forecast)  # [B,H,Q]
        q0 = raw[..., :1]
        inc = F.relu(raw[..., 1:])
        return torch.cat([q0, q0 + torch.cumsum(inc, dim=-1)], dim=-1)


# ============================================================
#  Scaffold Model (decoder-only) — agent edits this file
#  Constraint-aware: honors task-provided input_length/forecast_length/max_total_tokens
# ============================================================
class TimeSeriesFoundationModel(BaseTSFM):
    def __init__(self, cfg: Dict[str, Any]):
        super().__init__()
        self.cfg = _merge_config(cfg)
        D = self.cfg["d_model"]

        self.embedding = TokenEmbedding(
            d_model=D,
            dropout=self.cfg["dropout"],
            target_dim=self.cfg["target_dim"],
            past_cov_dim=self.cfg["past_cov_dim"],
            future_cov_dim=self.cfg["future_cov_dim"],
            static_dim=self.cfg["static_dim"],
            max_len=self.cfg["max_len"],
        )
        self.core = DecoderOnlyCore(
            d_model=D,
            n_layers=self.cfg["n_layers"],
            n_heads=self.cfg["n_heads"],
            d_ff=self.cfg["d_ff"],
            dropout=self.cfg["dropout"],
        )
        self.head = QuantileHead(D, len(self.cfg["quantile_levels"]))
        self.register_buffer(
            "quantile_levels",
            torch.tensor(self.cfg["quantile_levels"], dtype=torch.float32),
            persistent=False,
        )

        self._expect_past = self.cfg["target_dim"] + self.cfg["past_cov_dim"]
        self._expect_future = self.cfg["target_dim"] + self.cfg["future_cov_dim"]

    # ---------- helpers ----------
    def _concat_step_feats(
        self,
        past_y: torch.Tensor,
        past_cov: Optional[torch.Tensor],
        future_cov: Optional[torch.Tensor],
        y_future_tf: Optional[torch.Tensor],
        H: int,
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        B, T, _ = past_y.shape
        dev = past_y.device

        if past_cov is None:
            past_cov = torch.zeros(
                B,
                T,
                self._expect_past - past_y.shape[-1],
                device=dev,
                dtype=past_y.dtype,
            )
        if y_future_tf is None:
            y_future_tf = torch.zeros(
                B,
                H,
                self.cfg["target_dim"],
                device=dev,
                dtype=past_y.dtype,
            )
        if future_cov is None:
            future_cov = torch.zeros(
                B,
                H,
                self._expect_future - y_future_tf.shape[-1],
                device=dev,
                dtype=y_future_tf.dtype,
            )

        past_feats = torch.cat([past_y, past_cov], dim=-1)
        future_feats = torch.cat([y_future_tf[:, :H, :], future_cov[:, :H, :]], dim=-1)
        return past_feats, future_feats

    def _effective_T_cap(self, H: int, override_input_len: Optional[int]) -> int:
        """
        Compute the left-window cap T_eff based on:
          - override_input_len (forward arg) or constraints.input_length
          - max_len cap
          - constraints.max_total_tokens (if provided)
        """
        cons = self.cfg["constraints"]
        want_T = int(override_input_len) if override_input_len is not None else int(cons["input_length"])

        # global max_len cap
        want_T = min(want_T, max(0, self.cfg["max_len"] - H))

        # optional max_total_tokens cap
        mtt = cons.get("max_total_tokens", None)
        if mtt is not None:
            want_T = min(want_T, max(0, int(mtt) - H))

        return max(0, want_T)

    def _cap_left_to(self, tensor: torch.Tensor, T_eff: int) -> torch.Tensor:
        """Crop a [B, T, C] tensor to the last T_eff steps (safe for T_eff <= 0)."""
        if T_eff <= 0:
            return tensor[:, 0:0, :]
        if tensor.shape[1] <= T_eff:
            return tensor
        return tensor[:, -T_eff:, :]

    # ---------- forward ----------
    def forward(
        self,
        past_y: torch.Tensor,
        past_cov: Optional[torch.Tensor] = None,
        future_cov: Optional[torch.Tensor] = None,
        static: Optional[torch.Tensor] = None,
        y_future_tf: Optional[torch.Tensor] = None,
        *,
        forecast_length: Optional[int] = None,
        input_length: Optional[int] = None,
    ) -> Dict[str, torch.Tensor]:
        """
        Teacher-forced pass for forecasts.

        Args:
            past_y: Target history shaped ``[B, T, C_y]``.
            past_cov: Optional past covariates shaped ``[B, T, C_p]``.
            future_cov: Optional future covariates shaped ``[B, H, C_f]``.
            static: Optional static features shaped ``[B, C_s]``.
            y_future_tf: Teacher-forcing labels shaped ``[B, H, C_y]``.
            forecast_length: Horizon ``H`` override.
            input_length: Past window ``T`` cap override.

        Returns:
            Dictionary containing:
                - ``quantiles``: forecast quantiles shaped ``[B, H, Q]``.
                - ``quantile_levels``: quantile levels shaped ``[Q]``.
        """
        H = int(forecast_length) if forecast_length is not None else int(self.cfg["horizon"])
        T_eff = self._effective_T_cap(H, input_length)
        past_y = self._cap_left_to(past_y, T_eff)
        if past_cov is not None:
            past_cov = self._cap_left_to(past_cov, T_eff)

        # safety against positional limit
        if past_y.shape[1] + H > self.cfg["max_len"]:
            raise ValueError("(T + H) exceeds max_len")

        past_feats, future_feats = self._concat_step_feats(past_y, past_cov, future_cov, y_future_tf, H)
        tok = self.embedding(past_feats, future_feats, static)
        attn_mask = build_causal_mask(tok.shape[1], tok.device)
        h = self.core(tok, attn_mask)
        h_fc = h[:, -H:, :]

        base = torch.zeros(h_fc.shape[0], H, 1, device=h_fc.device, dtype=h_fc.dtype)
        q = base + self.head(h_fc)

        return {
            "quantiles": q,                                  # [B,H,Q]
            "quantile_levels": self.quantile_levels.to(q.device),  # [Q]
            "baseline": base,
            "aux": {"hidden_forecast": h_fc},
        }

    # ---------- generate ----------
    @torch.no_grad()
    def generate(
        self,
        past_y: torch.Tensor,
        past_cov: Optional[torch.Tensor] = None,
        future_cov: Optional[torch.Tensor] = None,
        static: Optional[torch.Tensor] = None,
        *,
        forecast_length: Optional[int] = None,
        input_length: Optional[int] = None,
    ) -> Dict[str, torch.Tensor]:
        """
        Autoregressive generation without teacher forcing.

        Args mirror :meth:`forward` except ``y_future_tf`` is inferred/autoregressive.

        Returns:
            Dictionary containing:
                - ``quantiles``: forecast quantiles shaped ``[B, H, Q]``.
                - ``quantile_levels``: quantile levels shaped ``[Q]``.
        """
        self.eval()
        H = int(forecast_length) if forecast_length is not None else int(self.cfg["horizon"])
        T_eff = self._effective_T_cap(H, input_length)
        past_y = self._cap_left_to(past_y, T_eff)

        preds = []
        mid = int(torch.argmin(torch.abs(self.quantile_levels - 0.5)).item())

        for t in range(H):
            if preds:
                med = torch.stack(preds, dim=1)[..., mid:mid+1]  # [B,t,1]
                pad = H - med.shape[1]
                y_tf = torch.cat(
                    [
                        med,
                        torch.zeros(
                            med.shape[0],
                            pad,
                            med.shape[2],
                            device=med.device,
                            dtype=med.dtype,
                        ),
                    ],
                    dim=1,
                )
            else:
                y_tf = torch.zeros(
                    past_y.shape[0],
                    H,
                    self.cfg["target_dim"],
                    device=past_y.device,
                    dtype=past_y.dtype,
                )

            out = self.forward(
                past_y=past_y,
                past_cov=past_cov,
                future_cov=future_cov,
                static=static,
                y_future_tf=y_tf,
                forecast_length=H,
                input_length=input_length,
            )
            q_t = out["quantiles"][:, t:t+1, :]  # [B,1,Q]
            preds.append(q_t.squeeze(1))

            nxt = q_t[..., mid:mid+1]  # median
            past_y = torch.cat([past_y, nxt], dim=1)

            # roll window respecting constraints and caps as horizon shrinks
            T_next = self._effective_T_cap(H - (t + 1), input_length)
            past_y = self._cap_left_to(past_y, T_next)

        pred_q = torch.stack(preds, dim=1)  # [B,H,Q]
        return {
            "quantiles": pred_q,
            "quantile_levels": self.quantile_levels.to(pred_q.device),
            "baseline": out["baseline"],
        }

    # ---------- contract helpers ----------
    @classmethod
    def from_config(cls, cfg: Dict[str, Any]) -> "DecoderOnlyTimeSeriesModel":
        return cls(cfg)

    def to_config(self) -> Dict[str, Any]:
        # round-trip constraints as well
        out = dict(self.cfg)
        out["constraints"] = dict(self.cfg["constraints"])
        return out


# -------------------------------------------------------
# Required entrypoint — validator calls this
# -------------------------------------------------------
def instantiate_model(config: Optional[Dict[str, Any]] = None) -> BaseTimeSeriesFoundationModel:
    """
    Keep signature stable. Accepts either:
      - top-level {input_length, forecast_length, max_total_tokens} (task-style), or
      - nested {"constraints": {...}}.
    Both are honored. horizon is synced to forecast_length.
    """
    model = TimeSeriesFoundationModel.from_config(_merge_config(config or {}))
    return validate_time_series_model(model)
