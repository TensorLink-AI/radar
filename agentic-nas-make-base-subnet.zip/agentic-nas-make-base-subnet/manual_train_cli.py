#!/usr/bin/env python3
"""Manual training CLI for the time-series foundation task.

Uses the universal trainer from ``core.training`` with ts-specific
callables from ``tasks.ts_foundation.model_base``.
"""
from __future__ import annotations

import argparse
import json
import logging
import sys
from pathlib import Path
from typing import Any, Dict, Optional

from tasks.ts_foundation.dataloader import build_dataloaders
from tasks.ts_foundation.model_base import load_candidate_model
from tasks.ts_foundation.metrics import make_eval_fn, make_forward_fn, make_loss_fn
from core.training.universal_trainer import TrainingConfig, train_model


def parse_model_config(raw: Optional[str]) -> Optional[Dict[str, Any]]:
    if not raw or not raw.strip():
        return None
    config = json.loads(raw)
    if not isinstance(config, dict):
        raise ValueError("--model-config must be a JSON object.")
    return config


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Manual training CLI for the TS foundation task."
    )
    parser.add_argument("--code-path", required=True,
                        help="Python file that exposes instantiate_model().")
    parser.add_argument("--run-dir", required=True,
                        help="Directory where metrics and logs should be written.")
    parser.add_argument("--dataset-path", default=None,
                        help="Optional CSV/NPY with a 'value' column; generates synthetic data when omitted.")
    parser.add_argument("--model-config", default=None,
                        help="JSON string forwarded to instantiate_model().")
    parser.add_argument("--input-length", type=int, default=512)
    parser.add_argument("--forecast-length", type=int, default=96)
    parser.add_argument("--batch-size", type=int, default=32)
    parser.add_argument("--max-steps", type=int, default=256)
    parser.add_argument("--max-val-batches", type=int, default=None,
                        help="Limit the number of validation/test batches to evaluate.")
    parser.add_argument("--eval-interval", type=int, default=64)
    parser.add_argument("--learning-rate", type=float, default=1e-3)
    parser.add_argument("--weight-decay", type=float, default=1e-4)
    parser.add_argument("--device", default=None)
    parser.add_argument("--log-level", default="INFO")
    parser.add_argument("--log-file-name", default="manual_train.log")
    args = parser.parse_args()

    run_dir = Path(args.run_dir)
    run_dir.mkdir(parents=True, exist_ok=True)

    handlers = [logging.StreamHandler(sys.stderr)]
    if args.log_file_name:
        handlers.append(logging.FileHandler(run_dir / args.log_file_name, encoding="utf-8"))
    logging.basicConfig(
        level=getattr(logging, args.log_level.upper(), logging.INFO),
        format="%(asctime)s | %(levelname)s | %(message)s",
        handlers=handlers,
    )

    logging.info(
        "Preparing dataloaders (input=%d, forecast=%d, batch=%d)",
        args.input_length,
        args.forecast_length,
        args.batch_size,
    )
    bundle = build_dataloaders(
        input_length=args.input_length,
        forecast_length=args.forecast_length,
        batch_size=args.batch_size,
        dataset_path=args.dataset_path,
    )
    logging.info(
        "Dataloaders ready | train=%d | val=%d | test=%d",
        len(bundle.train),
        len(bundle.val),
        len(bundle.test),
    )

    # Load model
    import torch
    device = torch.device(args.device) if args.device else (
        torch.device("cuda" if torch.cuda.is_available() else "cpu")
    )
    model = load_candidate_model(
        args.code_path,
        device,
        model_config=parse_model_config(args.model_config),
        input_length=args.input_length,
        forecast_length=args.forecast_length,
    )

    # Build ts-specific callables
    mase_scale = getattr(bundle, "mase_scale", 1.0)
    ts_loss_fn = make_loss_fn()
    ts_forward_fn = make_forward_fn(args.forecast_length, args.input_length)
    ts_eval_fn = make_eval_fn(
        args.forecast_length, args.input_length, mase_scale,
        max_batches=args.max_val_batches,
    )

    config = TrainingConfig(
        max_steps=args.max_steps,
        eval_interval=args.eval_interval,
        batch_size=args.batch_size,
        learning_rate=args.learning_rate,
        weight_decay=args.weight_decay,
        device=str(device),
        max_val_batches=args.max_val_batches,
    )

    def _progress(event: Dict[str, Any]) -> None:
        logging.info(
            "Step %d | train_loss=%.4f | val_quantile_loss=%.4f | val_MASE=%.4f | val_CRPS=%.4f",
            event.get("step", 0),
            event.get("train_loss", float("nan")),
            event.get("val_quantile_loss", float("nan")),
            event.get("val_MASE", float("nan")),
            event.get("val_CRPS", float("nan")),
        )

    result = train_model(
        model=model,
        train_loader=bundle.train,
        loss_fn=ts_loss_fn,
        config=config,
        val_loader=bundle.val,
        eval_fn=ts_eval_fn,
        forward_fn=ts_forward_fn,
        run_dir=str(run_dir),
        eval_type="manual_cli",
        progress_callback=_progress,
    )

    json.dump(result.metrics, sys.stdout, indent=2)
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
